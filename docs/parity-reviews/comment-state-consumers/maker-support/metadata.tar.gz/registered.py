# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,os,concurrent.futures,subprocess,hashlib,xml.etree.ElementTree as ET,sys
S=Path(__file__).parent;R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-a295df45');phase=sys.argv[1];paths=sorted(p for p in (R/'test-diagrams/perturbations').rglob('*.puml') if p.with_suffix('.svg').exists());sha=lambda b:hashlib.sha256(b).hexdigest()
def run(p):
 d=S/'registered'/phase/p.relative_to(R/'test-diagrams/perturbations').with_suffix('');d.mkdir(parents=True,exist_ok=True)
 try:q=subprocess.run([S/(phase+'-rustuml'),'-pipe','-tsvg'],cwd=R,input=p.read_bytes(),capture_output=True,timeout=90,env=dict(os.environ,TZ='GMT+11:00',RAYON_NUM_THREADS='4',RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib'));code,out,err=q.returncode,q.stdout,q.stderr
 except subprocess.TimeoutExpired as e:code,out,err=124,e.stdout or b'',e.stderr or b''
 (d/'svg.stdout').write_bytes(out);(d/'svg.stderr').write_bytes(err)
 xml=None
 if out:
  try:ET.fromstring(out)
  except ET.ParseError as e:xml=str(e)
 return dict(source=str(p),source_sha256=sha(p.read_bytes()),stdout_sha256=sha(out),stderr_sha256=sha(err),exit=code,emitted=bool(out),xml_error=xml,panic=b'panicked at' in err)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,paths))
(S/('registered-'+phase+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print('registered',len(rows),'malformed',sum(bool(x['xml_error']) for x in rows),'errors',sum(x['exit']!=0 for x in rows),'panics',sum(x['panic'] for x in rows),flush=True)
