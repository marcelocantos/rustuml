# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/wbs.rs');s=p.read_text().replace("prefix_rest.strip_prefix('_') {","prefix_rest.strip_prefix('_').filter(|tail| tail.starts_with(char::is_whitespace) || tail.starts_with(\"[#\")) {");p.write_text(s)
p=Path('crates/rustuml-render/src/wbs.rs');s=p.read_text().replace('{WbsDiagram, WbsNode, WbsSide}','{WbsDiagram, WbsNode, WbsShape, WbsSide}');s=s.replace('''    label: String,
    fill: String,''','''    lines: Vec<TextLine>,
    shape: WbsShape,
    text_x: f64,
    text_top: f64,
    fill: String,''').replace('    text_baseline: f64,\n','');a=s.index('fn measure(node:');b=s.index('    let fill = node',a)
s=s[:a]+'''struct TextLine {
    content: String,
    height: f64,
    baseline: f64,
}

/// WBSDiagram.addIdea projects Display.getWithNewlines before constructing
/// its text block. Keep this caller projection separate from the raw label
/// stored in the model and from other consumers' display/escape policies.
fn display_lines(label: &str) -> Vec<String> {
    let mut lines = Vec::new();
    let mut current = String::new();
    let mut chars = label.char_indices().peekable();
    let mut raw = false;
    while let Some((offset, c)) = chars.next() {
        let rest = &label[offset..];
        if rest.starts_with("<math>") || rest.starts_with("<latex>") || rest.starts_with("[[") {
            raw = true;
        } else if rest.starts_with("</math>") || rest.starts_with("</latex>") || rest.starts_with("]]") {
            raw = false;
        }
        if c == '\\\\' && !raw && let Some((_, next)) = chars.next() {
            match next {
                'n' => lines.push(std::mem::take(&mut current)),
                '\\\\' => current.push('\\\\'),
                't' => current.push('\\t'),
                _ => { current.push(c); current.push(next); }
            }
        } else {
            current.push(c);
        }
    }
    // Display preserves the final line even when it is empty.
    lines.push(current);
    lines
}

fn measure(node: &WbsNode, is_root: bool) -> Itf {
    // FtileBoxOld and the unboxed Display block measure and paint the same
    // SheetBlock stripes: maximum width and accumulated line heights.
    let mut text_w: f64 = 0.0;
    let mut text_h = 0.0;
    let lines = display_lines(&node.label).into_iter().map(|content| {
        text_w = text_w.max(text_render::measure(&content, FONT_SIZE, false));
        let height = text_render::label_height(&content, FONT_SIZE);
        let baseline = text_render::label_first_baseline_ascent_with_family(&content, FONT_SIZE, "sans-serif");
        text_h += height;
        TextLine { content, height, baseline }
    }).collect();
    // WBSTextBlock.buildMain / ITFLeaf: BOX uses the style padding; NONE
    // uses TextBlockUtils.withMargin(text, 0, 3, 1, 1), i.e. left/right/top/bottom.
    let (text_x, right, text_top, bottom) = match node.shape {
        WbsShape::Box => (PAD_X, PAD_X, PAD_X, PAD_X),
        WbsShape::None => (0.0, 3.0, 1.0, 1.0),
    };
    let main_w = text_w + text_x + right;
    let main_h = text_h + text_top + bottom;
'''+s[b:];s=s.replace('''        label: node.label.clone(),
        fill,''','''        lines,
        shape: node.shape,
        text_x,
        text_top,
        fill,''').replace('        text_baseline,\n','');a=s.index('fn emit_box(');b=s.index('/// `ITFComposed.drawU`',a);old=s[a:b];old=old.replace('''    write!(
        buf,''','''    if node.shape == WbsShape::Box {
    write!(
        buf,''',1).replace('''    .unwrap();
    text_render::emit_text(''','''    .unwrap();
    }
    let mut line_top = y + node.text_top;
    for line in &node.lines {
    text_render::emit_text(''',1).replace('&node.label','&line.content').replace('x: x + PAD_X','x: x + node.text_x').replace('y: y + node.text_baseline','y: line_top + line.baseline').replace('''    );
}
''','''    );
    line_top += line.height;
    }
}
''');s=s[:a]+old+s[b:];p.write_text(s)
