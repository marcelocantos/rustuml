# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,re,collections
from pathlib import Path
S=Path(__file__).parent;rows=json.loads((S/'complete-attribute-inventory.json').read_bytes())
metadata={'font-family','href','xlink:href','title','xlink:title','id','class','data-qualified-name','data-entity-1','data-entity-2','data-entity-uid','data-link-type'}
colors={'fill','stroke','stop-color','flood-color'}
# These formatter inputs are generated numeric identities, never label strings.
numeric_ids={321,325,331,335,336,338,345,346,354,362,371,373,379,381,416,417,420,421,422,425,426,429,430,433,434,437,438,441,442,445,446,447,448,450,454,455,457,997,1057,1108,1260,2455}
# Existing pre-escaped bindings: route their original producer, not encoded bytes.
encoded={('class.rs','h'):'escape_xml(url)',('class.rs','title'):'entity.url_tooltip.as_deref().map(escape_xml)',('state.rs','href_e'):'escape_attr(href)',('state.rs','title_e'):'escape_attr(title)',('state.rs','fam'):'escape_attr(&title_style.family) / escape_attr(&attribute_style.family)',('svg.rs','h'):'escape_xml(url)',('svg.rs','t'):'title.map(escape_xml)',('text_render.rs','escaped'):'escape_xml_attr(url)',('text_render.rs','title'):'escape_xml_attr(&normalized_title)',('creole.rs','escaped_color'):'escape_creole_text(color)'}
num=re.compile(r'(?:\b(?:fmt_coord|fmt_f|fc|f|n)\(|\bas (?:u|i|f)\d+\b|\.len\(\)|\.source_line\b|\.decl_line\b|(?:stroke_width|stroke_w|thickness|border_thickness|border_width|font_size|CANVAS_|BORDER_WIDTH|ICON_STROKE_WIDTH))')
out=[];proposal=[]
for i,r in enumerate(rows):
 fn=Path(r['file']).name;a=r['attribute'];items=[]
 for e in r['expressions']:
  status='generated/numeric';why='Numeric geometry, generated SVG syntax or fixed token; no user string interpolation.'
  if re.fullmatch(r'[A-Z_0-9]+',e):status='constant';why='Named source constant.'
  elif a in metadata:
   status='user-string';why='Identity/name/link/font string from model or renderer argument; source expression and binding context retained.'
   if i in numeric_ids or re.search(r'\{:\d|\{:0|\{\w+:0',r['template']) or num.search(e):status='generated/numeric';why='Numeric UID/source position formatter.'
   if a=='class' and e in ['position','class_name']:status='constant';why='Internal fixed group role selector.'
   if 'autonomous_entity_id(' in e or 'ent_id_of(' in e or e in ['gmn_name','note_ent'] or e.startswith('note_ent.trim_'):status='generated/numeric';why='Renderer-allocated UID/GMN identifier.'
  elif a in colors:
   status='user-string';why='Color/style String from renderer argument, skinparam/model or imported oracle; XML escaping only at this callsite.'
  elif a=='style':
   if not num.search(e) and not re.fullmatch(r'(?:w|h|w_i|h_i|width|height|canvas_w|canvas_h|total_w_i|total_h_i|width_i|dash|dash_str|dash_attr|dash_style|sw)',e):
    status='user-string';why='CSS attribute string or color fragment from style/model; preserve structure and escape value only.'
  elif 'escape_xml_attr' in e or (a not in ['x','y','width','height','font-size','rx','ry','cx','cy','x1','x2','y1','y2','textLength','viewBox'] and e.startswith('escape_attr(')):
   status='user-string';why='Already explicitly treated as an attribute string; consolidate existing escaping.'
  elif a in ['d','points','filter','codeLine','font-style','font-weight','text-decoration','lengthAdjust','target','xlink:actuate','xlink:show','xlink:type'] and re.search(r'\b(?:edge|path|polygon|poly|rect|image|text|link)\.',e):
   status='user-string';why='Externally supplied oracle/model string; route at attribute boundary without modifying geometry/content.'
  if re.fullmatch(r'[A-Z_0-9]+',e):status='constant';why='Named source constant.'
  if status=='user-string' and r['sequence']:status='sequence-owned';why='Concurrent sequence owner; no edit. Compare its local escaping and report raw sites.'
  item=dict(expression=e,classification=status,reason=why)
  if (fn,e) in encoded:item['existing_encoding_producer']=encoded[(fn,e)]
  items.append(item)
 rr=dict(index=i,file=r['file'],line=r['line'],attribute=a,template=r['template'],inputs=items,macro=r['macro'],context=r['context'])
 out.append(rr)
 if any(x['classification']=='user-string' for x in items):proposal.append(rr)
(S/'classified-attribute-inventory.json').write_text(json.dumps(out,indent=2)+'\n');(S/'proposed-routing-list.json').write_text(json.dumps(proposal,indent=2)+'\n')
print('sites',len(out),'routing',len(proposal),'expressions',collections.Counter(x['classification'] for r in out for x in r['inputs']))
print(collections.Counter(Path(r['file']).name for r in proposal))
# Manual dataflow audit corrections: no routing of allocation/lookup ids,
# numeric formatting or strings used to search existing SVG rather than emit it.
for r in out:
 fn=Path(r['file']).name
 for x in r['inputs']:
  e=x['expression'];generated=(e in ['svg_w','svg_h','sep_w','filter_id','shadow_id','new_id','resource.id','gradient.id','qualified_id'] or 'allocated_ids' in e or e.startswith('svg_ids.') or e in ['endpoint_id(from)','endpoint_id(to)','position.entity_id'])
  generated|=fn=='activity.rs' and r['line']<28854 and r['attribute'] in ['id','data-entity-1','data-entity-2'] and not ('escape' in e)
  generated|=fn=='svg.rs' and r['attribute']=='data-diagram-type'
  generated|=fn=='filter_registry.rs' and r['attribute']=='id'
  generated|=(fn,r['line'],r['attribute']) in [('usecase.rs',2705,'id'),('usecase.rs',3383,'id')]
  if generated:x.update(classification='generated/numeric',reason='Manually traced allocation/lookup/numeric formatting or existing-SVG resource search; no user attribute value.')
proposal=[r for r in out if any(x['classification']=='user-string' for x in r['inputs'])]
(S/'classified-attribute-inventory.json').write_text(json.dumps(out,indent=2)+'\n');(S/'proposed-routing-list.json').write_text(json.dumps(proposal,indent=2)+'\n')
print('manual correction',len(proposal),'routing sites',len({r['file'] for r in proposal}),'files')
