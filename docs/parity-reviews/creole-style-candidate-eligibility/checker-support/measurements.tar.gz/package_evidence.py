# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
S=Path(__file__).parent;R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-3f18003d');D=R/'docs/parity-reviews/creole-style-candidate-eligibility/checker-support';sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
summary=json.loads((S/'summary.json').read_bytes());original=list(summary)[:9];fresh=['checker30','supplement8']
counts={kind:dict(entries=sum(summary[c]['entries'] for c in cs),valid=sum(summary[c]['valid'] for c in cs),before_pass=sum(summary[c]['before'] for c in cs),after_pass=sum(summary[c]['after'] for c in cs),losses=[x for c in cs for x in summary[c]['losses']],panics_before=sum(len(summary[c]['before_panics']) for c in cs),panics_after=sum(len(summary[c]['after_panics']) for c in cs)) for kind,cs in [('immutable_cohorts',original),('fresh',fresh)]}
counts['fresh']['forced_alignment_exception']=dict(entries=1,result='fail',counted_against_maker=False);counts['fresh']['nonpositive']=dict(syntax_error=2,reference_environment_math=3);counts['fresh']['verdict_eligible']=32;counts['fresh']['eligible_after_pass']=21;counts['all_new_cli_nonzero_exits']=[]
counts['model_effects']=dict(changed_historical_models=5,shape_none_additions=12,color_changes=1,other_semantic_changes=[],serialization_only_byte_changes_observed=0,maker_single_sprite_order_change='Verified archived maker model observations describe one map-order-only difference; independent replay produced identical map order for that case. No semantic discrepancy.')
counts['historical_preservation']=dict(old=9731,earlier_rejected=118,newly_imported=96,all_exact=True,additional_base_artifacts_compared_by_git_blob=10172)
dump(S/'review-summary.json',counts)
dump(S/'checker-tooling-notes.json',dict(setup_failures=[],build_failures=[],report_script_errors=[dict(script='residue_audit.py',error='SyntaxError: unclosed list in reporting print; corrected before execution; no CLI rerun needed'),dict(command='intermediate chronology/summary inspection',error='summary.json not yet created by concurrent aggregation; later successful read used')],production_changes=False,broad_gate_runs=1))
# Support files are reviewable summaries; complete raw captures and scripts are archived.
public=['review-summary.json','summary.json','gate-summary.json','gates.json','build-provenance.json','diagnostic-build.json','scope-audit.json','chronology.json','archive-audit.json','java-audit.json','additional-java-audit.json','historical-audit.json','model-observations.json','model-compatibility.json','unit-residue.json','residuals.json','registration-growth.json','standing-summary.json','fresh-classification.json','supplement-classification.json','registered-checker-pairs.json','checker-tooling-notes.json']
for name in public:shutil.copy2(S/name,D/name)
for name in ['html_escape_pairs','delimiter_escapes','html_parameters','s_delimiter_escape_overlap','s_display_commands','s_leaf_commands','s_leaf_escapes']:
 co='supplement8' if name.startswith('s_') else 'checker30';p=D/'counterexamples'/name;p.mkdir(parents=True,exist_ok=True)
 for src,dst in [(S/'fresh-reference'/name/'java.stdout','java.svg'),(S/'replay/after'/co/name/'svg.stdout','rust.svg'),(S/'replay/after'/co/name/'compare.stdout','comparison.txt'),(S/'replay/after'/co/name/'yaml.stdout','rust.yaml')]:shutil.copy2(src,p/dst)
# Only evidence artifacts, not any source checkouts, compiler targets, or executable binaries.
files=[]
for p in sorted(S.iterdir()):
 if p.is_file() and (p.suffix in ['.json','.gz','.py','.rs','.log']):files.append(p)
for name in ['new','supplement','fresh-reference','inputs','replay','logs','unit-residue']:
 files.extend(p for p in sorted((S/name).rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
files=sorted(set(files));rows=[dict(path=str(p.relative_to(S)),sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in files]
archive=D/'measurements.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(S)),recursive=False)
with tarfile.open(archive) as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  b=t.extractfile(m).read();assert m.name==r['path'] and sha(b)==r['sha256'] and len(b)==r['bytes']
dump(D/'archive-files.json',rows);dump(D/'archive-integrity.json',dict(archive='measurements.tar.gz',sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,files=len(rows),all_member_bytes_verified=True))
print(json.dumps(counts,indent=2));print('archive',len(rows),archive.stat().st_size,sha(archive.read_bytes()))
