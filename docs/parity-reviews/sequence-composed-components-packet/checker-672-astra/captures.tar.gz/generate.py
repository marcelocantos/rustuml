import base64, hashlib, json
from pathlib import Path
cache=Path(__file__).parent; dest=cache/'fresh'; dest.mkdir(exist_ok=True)
cases=[]
def add(name,body,claim,axes,valid=True,engine=None):
    source='@startuml\n'+('!pragma teoz true\n' if engine=='teoz' else '')+body+'\n@enduml\n'
    data=source.encode(); p=dest/(name+'.puml'); p.write_bytes(data)
    cases.append(dict(name=name,remote_name=name+'.puml',source=str(p),source_bytes=len(data),source_sha256=hashlib.sha256(data).hexdigest(),source_base64=base64.b64encode(data).decode(),resources=[],timezone='GMT+11:00',cwd='PRIVATE_CWD',invocation=['/Users/marcelo/rustuml-reference/bin/reference','--cwd','PRIVATE_CWD','--timezone','GMT+11:00','--','-pipe','-tsvg'],claim=claim,axes=axes,intended_valid=valid))
f='sequence-factory-command-viability'
add('factory_order', 'Cedar o-->>o Maple: before declarations\nparticipant Maple\nparticipant Cedar\nMaple o<<--o Cedar: answer',f,['command order','reverse async circles'])
add('factory_quoted_header', 'header\nclass Fake o-- Node\nendheader\nparticipant "Cedar o-- class" as C\nparticipant Maple as M\nC o-->>o M: quoted\n\' class Decoy\nM o<--o C: reply',f,['header and comment commands','quoted alias'])
add('factory_mixed_after', 'Cedar o-->>o Maple: first\nclass Cedar',f,['declaration order','mixed class'],False)
add('factory_unknown', 'participant Cedar\nparticipant Maple\nCedar o-->>o Maple: first\nthis command is not real',f,['unknown command','decorated trigger'],False)
add('factory_unclosed_group', 'participant Cedar\nparticipant Maple\nloop pending\nCedar o-->>o Maple: first',f,['unfinished group','decorated trigger'],False)
add('factory_unclosed_box', 'box pending\nparticipant Cedar\nparticipant Maple\nCedar o-->>o Maple: first',f,['unfinished box','decorated trigger'],False)
for kind in ['class','object','component']:
 add('factory_'+kind+'_control',f'{kind} Cedar\n{kind} Maple\nCedar o-- Maple',f,['factory ownership',kind])
add('factory_bare_circle', 'Cedar o--o Maple', f,['missing head','both circles'],False)
e='sequence-endpoint-dressing-composition'; b='sequence-note-body-composition'; c='sequence-created-participant-component'; q='sequence-queue-preferred-component'; h='sequence-resolved-head-alignment'
for eng in ['legacy','teoz']:
 add('endpoint_half_'+eng, 'participant Cedar\nparticipant Maple\nCedar o//--\\o Maple: crossed halves\nMaple o\\\\--/o Cedar: reverse\nCedar o<-->>o Maple ++: activate\nMaple o<<-->o Cedar --: close',e,['independent half and async dressings','reverse order and activation',eng],engine=eng)
 add('endpoint_self_'+eng, 'participant Cedar\nCedar o<<->o Cedar: open source\nCedar o<-->>o Cedar: open target\nCedar o\\--o Cedar: half\nCedar o//--o Cedar: thin half',e,['mixed self heads','half and circles',eng],engine=eng)
 add('endpoint_external_'+eng, 'participant Cedar\n[o-> Cedar: incoming\nCedar o->o]: outgoing\n[<-o Cedar: reverse incoming\nCedar o<--]: reverse outgoing',e,['external endpoints','direction and circles',eng],engine=eng)
 add('endpoint_negative_'+eng, 'participant Cedar\nparticipant Maple\nCedar -o> Maple: invalid',e,['invalid decoration placement',eng],False,eng)
 add('body_blocks_'+eng, 'participant Cedar\nparticipant Maple\nCedar -> Maple: attached\nnote right\n== Long section heading ==\nx\nsecond body\n.. ..\n__ narrow __\na much longer body than its title\n-- empty --\nend note\nMaple -> Cedar: done',b,['empty and nonempty multiple sections','title and body width',eng],engine=eng)
 add('body_right_'+eng, 'skinparam noteTextAlignment right\nskinparam noteFontSize 17\nparticipant Cedar\nnote over Cedar\n-- Long cap --\nx\nbody with width\n== Z ==\nsmall\nend note\nCedar -> Cedar: tail',b,['right alignment and font size','standalone self topology',eng],engine=eng)
 add('body_center_'+eng, 'skinparam noteTextAlignment center\nparticipant Cedar\nparticipant Maple\nnote over Cedar, Maple\nintro\n__ Cap __\nsmall\na longer body\n.. End ..\nend note\nCedar -> Maple: tail',b,['center alignment','multiple sections across participants',eng],engine=eng)
 add('create_scoped_'+eng, '<style>\nsequenceDiagram {\n actor {\n Shadowing 7\n }\n participant {\n Shadowing 2\n }\n}\n</style>\nparticipant Cedar\nactor "Long Maple" as Maple\ncreate Maple\nCedar -> Maple ++: create\nMaple -> Cedar --: reply',c,['actor versus participant scoped shadow','activation',eng],engine=eng)
 add('create_reverse_nested_'+eng, 'actor Cedar\nparticipant Maple\nloop outer\nalt branch\ncreate Cedar\nMaple -> Cedar: create\nCedar -> Maple: reply\nelse other\nMaple -> Maple: self\nend\nend',c,['reverse creation','nested loop alt',eng],engine=eng)
 add('queue_stereo_'+eng, 'box Workers\nparticipant Cedar\nqueue "Long Maple" as Maple <<work>>\nend box\ncreate Maple\nCedar -> Maple ++: create\nMaple -> Cedar --: reply\ndestroy Maple',q,['stereotype in box','activation destruction',eng],engine=eng)
 add('queue_only_'+eng, 'queue Cedar\nqueue Maple\ncreate Cedar\nMaple -> Cedar: create\nloop work\nCedar -> Maple: deliver\nend\ndestroy Cedar',q,['queue-only reverse creation','loop destruction',eng],engine=eng)
 add('head_scoped_'+eng, '<style>\nsequenceDiagram {\n actor {\n Shadowing 7\n }\n participant {\n Shadowing 2\n }\n}\n</style>\nactor Cedar\nparticipant Maple\nCedar -> Maple: first\nMaple -> Cedar: second',h,['unequal sibling shadow','message direction',eng],engine=eng)
 add('head_participant_'+eng, 'skinparam actorShadowing false\nskinparam participantShadowing true\nparticipant "Tall\\nMaple" as Maple\nactor Cedar\nCedar -> Maple: reverse\nMaple -> Cedar: answer',h,['participant-only shadow','multiline sibling and order',eng],engine=eng)
manifest=dict(schema_version=1,review_candidate='672cd8f26e1d7c6725d8971e01ad7575defd8567',java_revision='71806a23780b04a5ccde2f8ceb5121edad5eb711',jar_sha256='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053',resources=[],cases=cases)
p=cache/'reference-request.json';p.write_text(json.dumps(manifest,indent=2)+'\n');p.chmod(0o444)
print(len(cases),p,hashlib.sha256(p.read_bytes()).hexdigest())
