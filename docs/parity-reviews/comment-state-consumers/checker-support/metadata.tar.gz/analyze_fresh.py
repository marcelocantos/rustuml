# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,re,xml.etree.ElementTree as ET,sys
S=Path(__file__).parent;cohort=sys.argv[1] if len(sys.argv)>1 else 'checker94'
rows=json.loads((S/(cohort+'-membership.json')).read_text());out=[]
def projection(b):
 root=ET.fromstring(b);p=[]
 for el in root.iter():p.append([el.tag,sorted(el.attrib.items()),(el.text or '').strip()])
 return p
def slots(b):
 root=ET.fromstring(b,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)))
 out=[]
 for parent in root.iter():
  children=list(parent)
  for i,n in enumerate(children):
   if n.tag==ET.Comment:
    following=next((k for k in children[i+1:] if k.tag!=ET.Comment),None)
    out.append(dict(text=n.text,next_tag=following.tag if following is not None else None,next_class=following.get('class') if following is not None else None,next_qname=following.get('data-qualified-name') if following is not None else None))
 return out
def paints(b):
 root=ET.fromstring(b);out=[]
 def walk(e,owner):
  owner=e.get('data-qualified-name',owner)
  if 'fill' in e.attrib:out.append(dict(owner=owner,tag=e.tag.split('}')[-1],fill=e.get('fill'),opacity=e.get('fill-opacity'),style=e.get('style'),text=e.text))
  for child in e:walk(child,owner)
 walk(root,None);return out
for row in rows:
 id=row['id'];g=Path(row['golden_capture']).read_bytes();d=S/'replay/after'/cohort/id;b=(S/'replay/before'/cohort/id/'svg.stdout').read_bytes();a=(d/'svg.stdout').read_bytes();v=json.loads((d/'result.json').read_text());name=id.split('/')[-1]
 gc=re.findall(rb'<!--(.*?)-->',g,re.S);bc=re.findall(rb'<!--(.*?)-->',b,re.S);ac=re.findall(rb'<!--(.*?)-->',a,re.S)
 record=dict(name=name,valid=v['reference_valid'],whole_pass=v['svg_match'],comments_java=[c.decode() for c in gc],comments_before=[c.decode() for c in bc],comments_after=[c.decode() for c in ac],comments_match=gc==ac,comment_slots_java=slots(g),comment_slots_after=slots(a),comment_only_change=re.sub(rb'<!--.*?-->',''.encode(),b,flags=re.S)==re.sub(rb'<!--.*?-->',''.encode(),a,flags=re.S),decoded_noncomment_unchanged=projection(b)==projection(a),java_paints=paints(g),before_paints=paints(b),after_paints=paints(a),comparison=(d/'compare.stdout').read_text())
 out.append(record)
 if not name.startswith('paint_'):
  print(name,'whole',record['whole_pass'],'comments',record['comments_match']);print(' JAVA',record['comments_java']);print(' RUST',record['comments_after'])
(S/(cohort+'-observations.json')).write_text(json.dumps(out,indent=2)+'\n')
