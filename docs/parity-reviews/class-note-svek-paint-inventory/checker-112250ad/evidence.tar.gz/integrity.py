# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,subprocess
s=Path(__file__).resolve().parent;a=s/'maker-archive';root=Path.cwd();pkg=root/'docs/parity-reviews/class-note-svek-paint-inventory/maker-evidence/packet8';sha=lambda b:hashlib.sha256(b).hexdigest();report={}
def checked_files(base,rows):
 errors=[]
 for r in rows:
  p=base/r['path']; b=p.read_bytes()
  if sha(b)!=r['sha256'] or ('bytes' in r and len(b)!=r['bytes']):errors.append(r['path'])
 return dict(count=len(rows),mismatches=errors)
report['package']=checked_files(pkg,json.loads((pkg/'file-manifest.json').read_text()))
report['archive']=checked_files(a,json.loads((a/'archive-manifest.json').read_text()))
r=json.loads((pkg/'archive-integrity.json').read_text());b=(pkg/'packet8-evidence.tar.gz').read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'];report['archive_digest']=sha(b)
hist=json.loads((pkg/'historical-byte-integrity.json').read_text());report['historical']=checked_files(root,hist['records']);assert len(hist['records'])==9254
# Independently compare candidate-tree blob identities to the imported immutable tree.
old={line.split('\t')[1]:line.split()[2] for line in subprocess.check_output(['git','ls-tree','-r',hist['base'],'docs/parity-reviews','test-diagrams/perturbations','crates/rustuml-oracle','test-diagrams/no_oracle_baseline.txt'],text=True).splitlines()}
new={line.split('\t')[1]:line.split()[2] for line in subprocess.check_output(['git','ls-tree','-r','HEAD'],text=True).splitlines() if line.split()[1]=='blob'}
report['historical_git_blobs']={'count':len(old),'mismatches':[p for p,b in old.items() if new.get(p)!=b]}
orig=subprocess.check_output(['git','show','--format=','59d50dbc3da1d46f8a10ae703ae32d40c6e7a2ee']);imp=subprocess.check_output(['git','show','--format=','c51bb7686a96ac775d481273dfcf373402531524']);report['import_exact_diff']=orig==imp
prov=json.loads((pkg/'source-and-revision-provenance.json').read_text());report['maker_binaries']=[]
for path,expected in prov['binaries'].items():
 p=Path(path);report['maker_binaries'].append(dict(path=path,expected=expected,actual=sha(p.read_bytes()) if p.exists() else None))
report['accounts']=[]
for m,v in prov['accounts'].items():
 p='docs/parity-reviews/'+m+'/account.json';b=(root/p).read_bytes();assert sha(b)==v['sha256']==sha(subprocess.check_output(['git','show',v['commit']+':'+p]));subprocess.run(['git','merge-base','--is-ancestor',v['commit'],prov['production']],check=True);report['accounts'].append(dict(mechanism=m,commit=v['commit'],sha256=sha(b),original_bytes_unchanged=True))
jroot=Path('/Users/marcelo/work/github.com/plantuml/plantuml');report['java_source']=[]
for v in prov['java_source_files']:
 b=(jroot/v['path']).read_bytes();assert sha(b)==v['sha256'];assert b==subprocess.check_output(['git','-C',str(jroot),'show',prov['java_revision']+':'+v['path']]);report['java_source'].append(v)
for v in json.loads((pkg/'account-location-clarifications.json').read_text())['locations']:
 p=v['actual'].split('#')[0];assert sha((jroot/p).read_bytes())==v['java_sha256']
# Validate every frozen/fresh source/reference snapshot, without deduplicating entries.
snap=json.loads((a/'input-reference-snapshot.json').read_text());errors=[]
for r in snap:
 for k in ['source_blob','reference_blob']:
  p=a/'input-reference-blobs'/r[k]
  if sha(p.read_bytes())!=r[k]:errors.append(r)
report['snapshot']={'entries':len(snap),'unique_sources':len({r['source_blob'] for r in snap}),'duplicates':len(snap)-len({r['source_blob'] for r in snap}),'hash_errors':errors}
report['drafts']=[dict(path=p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in a.iterdir() if p.is_file() and (p.name.startswith('draft') or p.name in ['check1.log','build1.log','build2.log','focused-units1.log','focused-units2.log','final-build.log'])]
report['production_changed_files']=subprocess.check_output(['git','diff','--name-only','154d4c7','68ab512b','--','crates'],text=True).splitlines()
report['source_snapshot_before']='git archive 154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc; plain private source archive, not a worktree';report['candidate']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();report['rustc']=subprocess.check_output(['rustc','--version'],text=True).strip();report['cargo']=subprocess.check_output(['cargo','--version'],text=True).strip()
(s/'integrity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['java_source','drafts','accounts']},indent=2))
