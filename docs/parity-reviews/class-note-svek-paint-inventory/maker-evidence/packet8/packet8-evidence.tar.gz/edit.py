from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/class.rs');s=p.read_text()
a=s.index('        // UrlBuilder#getRegexp/getUrl tests');b=s.index('        let url = Some(url);',a)
body=s[a:b].replace('&caps["url"]','text').replace('return Ok(false);','return None;')
s=s[:a]+'''        let Some((url, tooltip)) = self.parse_note_or_command_url(&caps["url"]) else {
            return Ok(false);
        };
'''+s[b:]
a=s.index('    fn try_note(')
s=s[:a]+'''    fn parse_note_or_command_url(&self, text: &str) -> Option<(String, Option<String>)> {
'''+body+'''        Some((url, tooltip))
    }

'''+s[a:]
s=s.replace('(?P<target>"[^\"]+"|[^\\s{}"<>]+)', '(?P<target>["“”\\u{e121}][^"“”\\u{e121}]+["“”\\u{e121}]|[^\\s{}"“”\\u{e121}<>]+)')
s=s.replace('target.as_str().trim_matches(\'"\'),','target.as_str().trim_matches([\'"\', \'“\', \'”\']),')
a=s.index('            let url_text = if attached');b=s.index('            let mut note = Note {',a)
s=s[:a]+'''            // UrlBuilder#getRegexp is part of both command grammars, even
            // when createSingleLine deliberately passes null to executeInternal.
            let (mut url, mut tooltip) = if let Some(value) = caps.name("url") {
                let Some((url, tooltip)) = self.parse_note_or_command_url(value.as_str()) else {
                    return Ok(false);
                };
                (Some(url), tooltip)
            } else {
                (None, None)
            };
            if attached && caps.name("text").is_some() {
                url = None;
                tooltip = None;
            }
'''+s[b:]
s=s.replace('url_tooltip: super::extract_link_tooltip(url_text),','url_tooltip: tooltip,')
p.write_text(s)
p=Path('crates/rustuml-render/src/class.rs');s=p.read_text()
s=s.replace('use rustuml_parser::diagram::style::{StyleOrigin, StyleScheme};','use rustuml_parser::diagram::style::StyleScheme;')
a=s.index('fn has_shadowing_skinparam(');b=s.index('fn fashion_shadowing_delta',a);s=s[:a]+s[b:]
a=s.index('fn style_shadowing_delta(');b=s.index('\nfn resolved_note_shadowing',a)
s=s[:a]+'''fn style_shadowing_delta(style: &ResolvedStyle<'_>) -> Option<f64> {
    // FromSkinparamToStyle#convertNow maps true/false for mapped keys, but
    // getShadowingValue also maps yes/no only for the unmapped global/note
    // fallback. parse/style.rs has already made that distinction. Style then
    // applies ValueImpl to the resulting declaration regardless of its origin.
    style.property("shadowing").map(fashion_shadowing_delta)
}
'''+s[b:]
s=s.replace('struct ClassFontOverrides {','''struct ClassFontOverrides {
    /// EntityImageClass.drawInternal resolves this class style's shadow; the
    /// preferred calculateDimension is independent of the painted shadow.
    shadow: f64,''')
a=s.index('        let header_paint_style =', s.index('fn from_diagram_entity'))
s=s[:a]+'''        font.shadow = style_shadowing_delta(&class_style).unwrap_or(0.0);
'''+s[a:]
s=s.replace('has_shadowing_skinparam(diagram).then(|| {','''diagram.entities.iter().any(|entity| {
        let font = ClassFontOverrides::from_diagram_for_entity(diagram, entity);
        font.description.is_none() && font.shadow > 0.0
    }).then(|| {''')
s=s.replace('    class_shadow: bool,\n','').replace('                class_shadow_filter_id.is_some(),\n','').replace('                    class_shadow_filter_id.is_some(),\n','')
a=s.index('    // FromSkinparamToStyle maps enabled class shadowing');b=s.index('    (dim.width + extra',a)
s=s[:a]+'''    // EntityImageClass.drawInternal puts the resolved Style#getShadowing on
    // its rectangle. LimitFinder.drawRectangle adds 2*deltaShadow-1; other
    // existing preferred contributors prevent a negative envelope extension.
    let extra = (font.shadow * 2.0 - 1.0).max(0.0);
'''+s[b:]
s=s.replace('            class_shadow_filter_id.as_deref(),','''            class_shadow_filter_id.as_deref().filter(|_| entity_font.shadow > 0.0),''')
s=s.replace('        if diagram.notes.len() == 1 {','''        // DotData.isDegeneratedWithFewEntities also requires zero groups and
        // links. Empty package leaves must reach EntityImageEmptyPackage/SVEK.
        if diagram.notes.len() == 1 && diagram.packages.is_empty() && diagram.relationships.is_empty() {''',1)
s=s.replace('    cluster_positions.is_empty()\n        && diagram.relationships.is_empty()', '    cluster_positions.is_empty()\n        && diagram.packages.is_empty()\n        && diagram.relationships.is_empty()')
s=s.replace('    if diagram.notes.len() == 1\n        && diagram.relationships.is_empty()', '    if diagram.notes.len() == 1\n        && diagram.packages.is_empty()\n        && diagram.relationships.is_empty()')
# Complete paint inventory; layout still uses its existing distinct graph-node contract.
s=s.replace('enum SvekNodeEmission {\n    Entity(usize),','enum SvekNodeEmission {\n    Entity(usize),\n    Note(usize),')
a=s.index('        for (entity_idx, _) in self.diagram.entities.iter().enumerate() {',s.index("impl SvekEmissionOrder"));b=s.index('        for child_idx',a)
s=s[:a]+'''        self.collect_leaves(Some(pkg_idx));
'''+s[b:]
a=s.index('    fn collect_package(',s.index("impl SvekEmissionOrder"))
s=s[:a]+'''    fn collect_leaves(&mut self, owner: Option<usize>) {
        // GraphvizImageBuilder.printEntities uses insertion-ordered leaf data
        // for each owner; Bibliotekon insertion is paint order, not UID order
        // across groups. Preserve the parser's actual allocation stream within
        // each owner, with source order only for manually constructed ASTs.
        let mut leaves = self.diagram.entities.iter().enumerate()
            .filter(|(idx, _)| self.innermost_pkg[*idx] == owner)
            .map(|(idx, entity)| (SvekNodeEmission::Entity(idx), entity.source_line))
            .chain(self.diagram.notes.iter().enumerate().filter_map(|(idx, note)| {
                let note_owner = note.owner_package.as_ref().and_then(|id|
                    self.diagram.packages.iter().position(|package| &package.id == id));
                (note_owner == owner && (note.alias.is_some() || note.target.is_some()))
                    .then_some((SvekNodeEmission::Note(idx), note.source_line))
            })).collect::<Vec<_>>();
        leaves.sort_by_key(|&(node, line)| {
            let event = self.diagram.uid_events.iter().position(|event| match (node, event) {
                (SvekNodeEmission::Entity(idx), ClassUidEvent::Entity(id)) => self.diagram.entities[idx].id == *id,
                (SvekNodeEmission::Note(idx), ClassUidEvent::Note(other)) => idx == *other,
                _ => false,
            });
            (event.unwrap_or(usize::MAX), line)
        });
        self.node_order.extend(leaves.into_iter().map(|(node, _)| node));
    }

'''+s[a:]
a=s.index('    let mut root_entities =',s.index('fn svek_node_emission_order'));b=s.index('\n    emission.node_order',a)
s=s[:a]+'''    emission.collect_leaves(None);
'''+s[b:]
s=s.replace('SvekNodeEmission::EmptyPackage(_) => None,','SvekNodeEmission::EmptyPackage(_) | SvekNodeEmission::Note(_) => None,')
s=s.replace('    let svek_nodes = svek_node_emission_order(diagram);','''    // Paint inventory includes NOTE leaves. Graph nodes retain the existing
    // separate floating/attached-note slot and edge ownership contract below.
    let svek_nodes = svek_node_emission_order(diagram).into_iter()
        .filter(|node| !matches!(node, SvekNodeEmission::Note(_))).collect::<Vec<_>>();''')
s=s.replace('            ClassLayoutNodeEmission::FloatingNote(idx) => {','''            ClassLayoutNodeEmission::Svek(SvekNodeEmission::Note(_)) => unreachable!("notes use their own layout slots"),
            ClassLayoutNodeEmission::FloatingNote(idx) => {''')
a=s.index('    let emission_order = node_emission_order',s.index('    // Entity ID counter'));b=s.index('    // Cursor over `oracle_note_entities`',a)
s=s[:a]+'''    let mut non_opale_attached_notes = Vec::new();
    let note_slots = floating_notes.iter().copied().chain(attached_notes.iter()
        .map(|&(note_idx, node_idx, _)| (note_idx, node_idx))).collect::<Vec<_>>();

'''+s[b:]
a=s.index('    // Render each entity.\n    for &i in &emission_order');b=s.index('        let entity = &diagram.entities[i];',a)
s=s[:a]+'''    // SvekResult.drawU consumes Bibliotekon's group-before-root inventory.
    // UID allocation is independent and remains unchanged.
    for node in node_emission_order {
        let i = match node {
            SvekNodeEmission::Entity(i) => i,
            SvekNodeEmission::EmptyPackage(package_idx) => {
                if let Some(empty) = layout_empty_packages.iter().find(|empty| empty.package_idx == package_idx) {
                    let entity_id = svek_ids.package_ids[package_idx].as_deref().unwrap_or("ent0002");
                    emit_layout_empty_package(&mut svg, empty, entity_id);
                }
                continue;
            }
            SvekNodeEmission::Note(note_idx) => {
                if oracle.is_none()
                    && let Some((_, node_idx)) = note_slots.iter().find(|(idx, _)| *idx == note_idx)
                    && let Some(pos) = positions.get(*node_idx)
                    && let Some(entity_id) = svek_ids.note_ids[note_idx].as_deref()
                    && render_svek_note(&mut svg, diagram, note_idx, pos, entity_id,
                        &svek_ids, edge_paths, &resolved_relationship_edges,
                        floating_note_opale_relationships[note_idx], layout_x_bias, body_dx, body_dy)
                {
                    non_opale_attached_notes.push(note_idx);
                }
                continue;
            }
        };

'''+s[b:]
a=s.index('        while oracle.is_none()\n            && layout_note_cursor');b=s.index('        while note_cursor < oracle_note_entities.len()',a);s=s[:a]+s[b:]
a=s.index('    while oracle.is_none() && layout_note_cursor');b=s.index('    // Emit any remaining note entities',a);s=s[:a]+s[b:]
s=s.replace('SvekNodeEmission::Entity(idx) => diagram.entities[idx].label.as_str(),','SvekNodeEmission::Entity(idx) => diagram.entities[idx].label.as_str(),\n                SvekNodeEmission::Note(idx) => diagram.notes[idx].alias.as_deref().unwrap_or("attached"),')
p.write_text(s)
