// Copyright 2026 Marcelo Cantos
// SPDX-License-Identifier: Apache-2.0

//! Sequence diagram model.

use super::DiagramMeta;
use serde::{Deserialize, Serialize};

/// A complete sequence diagram.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SequenceDiagram {
    pub meta: DiagramMeta,
    pub participants: Vec<Participant>,
    pub events: Vec<Event>,
    pub autonumber: Option<AutoNumber>,
    /// Whether `hide footbox` was specified — suppresses tail participant boxes.
    #[serde(default)]
    pub hide_footbox: bool,
    /// Whether `!pragma teoz true` was specified.
    #[serde(default)]
    pub teoz: bool,
    /// Named `box ... end box` groupings of participants.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub boxes: Vec<ParticipantBox>,
}

/// A named `box "Title" #color ... end box` grouping of participants.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParticipantBox {
    /// Optional box title (empty string if unnamed).
    pub title: String,
    /// Optional background color (e.g., "#lightblue", "#FFE4E1").
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub color: Option<String>,
    /// Indices into `SequenceDiagram::participants` of the members, in order.
    pub members: Vec<usize>,
}

/// A participant (lifeline) in a sequence diagram.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Participant {
    pub id: String,
    pub label: String,
    pub kind: ParticipantKind,
    pub order: Option<usize>,
    /// Optional UML stereotype text, e.g. `<<service>>` → `"service"`.
    pub stereotype: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub url: Option<String>,
    /// Optional background color (e.g., "#red", "#FF0000").
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub color: Option<String>,
    /// 1-based line number within the `@startuml` block.
    #[serde(default)]
    pub source_line: usize,
}

/// The visual shape of a participant.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
pub enum ParticipantKind {
    #[default]
    Participant,
    Actor,
    Boundary,
    Control,
    Entity,
    Database,
    Collections,
    Queue,
}

/// A sequence diagram event (message, note, group boundary, etc.).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Event {
    Message(Message),
    Note(Note),
    NoteOnLink(String),
    GroupStart(GroupStart),
    GroupElse(GroupElse),
    GroupEnd,
    Divider(String),
    Delay(Option<String>),
    Space(Option<u32>),
    Ref(Ref),
    Activate(String, Option<String>),
    Deactivate(String),
    Destroy(String),
    Create(String),
    Return(ReturnMessage),
    NewPage(Option<String>),
    /// A mid-stream autonumber directive (`autonumber`, `autonumber N M "fmt"`,
    /// `autonumber stop`, `autonumber resume`). Applied to subsequent messages.
    Autonumber(AutonumberCmd),
}

/// An autonumber directive encountered in the event stream.
#[derive(Debug, Serialize, Deserialize, Clone)]
pub enum AutonumberCmd {
    /// `autonumber [start [step]] ["format"]` — (re)start numbering.
    Start {
        start: u32,
        step: u32,
        format: Option<String>,
    },
    /// `autonumber stop` — pause numbering (counter retained).
    Stop,
    /// `autonumber resume [step] ["format"]` — resume after a stop, keeping the
    /// retained counter; optionally change step/format.
    Resume {
        step: Option<u32>,
        format: Option<String>,
    },
}

/// A message arrow between participants.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Message {
    /// CommandArrow PARALLEL, retained for Teoz tile and history identity.
    #[serde(default)]
    pub parallel: bool,
    pub from: String,
    pub to: String,
    pub label: String,
    pub arrow: Arrow,
    pub activation: Option<ActivationChange>,
    /// Optional color for activation bar (e.g., "#blue", "#FF0000").
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub activation_color: Option<String>,
    /// 1-based line number within the `@startuml` block.
    #[serde(default)]
    pub source_line: usize,
}

/// Arrow style for a message.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Arrow {
    pub line: LineStyle,
    pub head: ArrowHead,
    pub direction: ArrowDirection,
    /// Optional arrow color (e.g., "#red", "#FF0000").
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub color: Option<String>,
    /// Half-arrowhead modifier from `/` (bottom half) or `\` (top half).
    /// Destination dressing only: CommandArrow starts with dressing2 present,
    /// so ArrowConfiguration#withPart leaves the source head FULL.
    /// `None` for a normal full destination arrowhead.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub head_half: Option<ArrowHalf>,
    /// True when the arrowhead is drawn as a thin open stroke rather than a
    /// filled triangle. Triggered by doubling the half modifier (`//`, `\\`).
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub thin_head: bool,
    /// True for source-cross arrows (`x->`): draw an X at the source side
    /// while keeping the normal target arrowhead.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub source_cross: bool,
    /// True for source-circle arrows (`o->`): draw a circle decoration at the
    /// source side while keeping the normal target arrowhead.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub source_circle: bool,
    /// ArrowConfiguration keeps decoration2 independent of its head dressing.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub target_circle: bool,
    /// Independent source head from CommandArrow/ArrowConfiguration. Missing
    /// values retain the historical bidirectional-head fallback for old models.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub source_dressing: Option<ArrowHead>,
}

/// Which half of the arrowhead is drawn when a `/` or `\` modifier is present.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ArrowHalf {
    /// `/` — only the bottom wing of the arrowhead.
    Bottom,
    /// `\` — only the top wing of the arrowhead.
    Top,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
pub enum LineStyle {
    #[default]
    Solid,
    Dotted,
    Hidden,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
pub enum ArrowHead {
    #[default]
    Filled,
    Open,
    Cross,
    Circle,
    None,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ArrowDirection {
    LeftToRight,
    RightToLeft,
    Bidirectional,
    Self_,
}

/// Activation change triggered by a message.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ActivationChange {
    Activate,
    Deactivate,
    Destroy,
}

/// A note attached to one or more participants.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Note {
    pub position: NotePosition,
    pub participants: Vec<String>,
    pub text: String,
    /// Visual shape of the note (default folded-corner, hnote hexagonal, rnote rectangular).
    #[serde(default)]
    pub shape: NoteShape,
    /// Optional background color (e.g., "#blue", "#FEFFDD").
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub color: Option<String>,
    /// True when this note was attached to the preceding message via a bare
    /// `note left` / `note right` (no participant). Such notes straddle the
    /// message's arrow band rather than consuming their own vertical row.
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub on_message: bool,
    /// 1-based line number within the `@startuml` block.
    #[serde(default)]
    pub source_line: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum NotePosition {
    Left,
    Right,
    Over,
}

/// Visual shape of a note.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
pub enum NoteShape {
    /// Standard note with folded corner.
    #[default]
    Note,
    /// Hexagonal note (hnote).
    Hexagonal,
    /// Rectangular note without fold (rnote).
    Rectangular,
}

/// Start of a grouping construct (alt, opt, loop, etc.).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GroupStart {
    pub kind: GroupKind,
    pub label: Option<String>,
    /// 1-based line number within the `@startuml` block.
    #[serde(default)]
    pub source_line: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum GroupKind {
    Alt,
    Opt,
    Loop,
    Par,
    Break,
    Critical,
    Group,
}

/// An "else" branch within a group.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GroupElse {
    pub label: Option<String>,
    /// 1-based line number within the `@startuml` block.
    #[serde(default)]
    pub source_line: usize,
}

/// A reference to another diagram.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Ref {
    pub participants: Vec<String>,
    pub text: String,
    /// 1-based line number within the `@startuml` block.
    #[serde(default)]
    pub source_line: usize,
}

/// A return message (shorthand for dotted reply).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReturnMessage {
    /// CommandReturn PARALLEL, applied to internal reverse messages.
    #[serde(default)]
    pub parallel: bool,
    pub label: String,
    /// Optional CommandReturn arrow-configuration color override.
    #[serde(default)]
    pub color: Option<String>,
    /// 1-based line number within the `@startuml` block.
    #[serde(default)]
    pub source_line: usize,
}

/// Auto-numbering configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AutoNumber {
    pub start: u32,
    pub step: u32,
    pub format: Option<String>,
}

/// Resolve command-generated messages before drawing. Source activation ownership
/// is independent of accepted graphical life variations (account ea313c62).
/// Java SequenceDiagram#activate pushes on ACTIVATE, pops on DEACTIVATE, and
/// leaves the stack intact on DESTROY. CommandReturn reads that exact stack.
pub fn resolve_sequence_returns(events: &[Event]) -> Result<Vec<Event>, (usize, String)> {
    use std::collections::{HashMap, HashSet};
    let mut result: Vec<Event> = Vec::with_capacity(events.len());
    let mut owner = None;
    let mut stack: Vec<usize> = Vec::new();
    let mut closed: HashMap<usize, HashSet<String>> = HashMap::new();
    for event in events {
        let event = if let Event::Return(ret) = event {
            let context = stack.last().copied().or_else(|| {
                owner.filter(|&index| {
                    matches!(&result[index], Event::Message(m)
                    if !matches!(m.from.as_str(), "[" | "]") && !matches!(m.to.as_str(), "[" | "]"))
                })
            });
            let Some(context) = context else {
                return Err((ret.source_line, "Nowhere to return to.".to_owned()));
            };
            let Event::Message(call) = &result[context] else {
                unreachable!()
            };
            let mut arrow = call.arrow.clone();
            arrow.line = LineStyle::Dotted;
            if let Some(color) = &ret.color {
                arrow.color = Some(color.clone());
            }
            Event::Message(Message {
                // CommandReturn does not apply PARALLEL to MessageExo.
                parallel: ret.parallel
                    && !matches!(call.from.as_str(), "[" | "]")
                    && !matches!(call.to.as_str(), "[" | "]"),
                from: call.to.clone(),
                to: call.from.clone(),
                label: ret.label.clone(),
                arrow,
                activation: (!stack.is_empty()).then_some(ActivationChange::Deactivate),
                activation_color: None,
                source_line: ret.source_line,
            })
        } else {
            event.clone()
        };
        let life = match &event {
            Event::Message(m) => {
                owner = Some(result.len());
                m.activation.map(|change| {
                    let id = if matches!(m.from.as_str(), "[" | "]") {
                        &m.to
                    } else if matches!(m.to.as_str(), "[" | "]")
                        || change == ActivationChange::Deactivate
                    {
                        &m.from
                    } else {
                        &m.to
                    };
                    (id.clone(), change)
                })
            }
            Event::Activate(id, _) => Some((id.clone(), ActivationChange::Activate)),
            Event::Deactivate(id) => Some((id.clone(), ActivationChange::Deactivate)),
            Event::Destroy(id) => Some((id.clone(), ActivationChange::Destroy)),
            // SequenceDiagram#grouping replaces lastEventWithDeactivate with END.
            Event::GroupEnd => {
                owner = None;
                None
            }
            _ => None,
        };
        result.push(event);
        if let Some((id, change)) = life {
            if change == ActivationChange::Activate {
                if let Some(index) = owner {
                    stack.push(index);
                }
            } else if change == ActivationChange::Deactivate {
                stack.pop();
            }
            if let Some(index) = owner {
                let Event::Message(message) = &result[index] else {
                    unreachable!()
                };
                // AbstractMessage#addLifeEvent excludes another participant's
                // transition only for a self message; notes do not reset owner.
                if message.from == message.to && message.from != id {
                    continue;
                }
                let forbidden = closed.entry(index).or_default();
                if change == ActivationChange::Activate && forbidden.contains(&id) {
                    return Err((
                        message.source_line,
                        format!("Activate/Deactivate already done on {id}"),
                    ));
                }
                if matches!(
                    change,
                    ActivationChange::Deactivate | ActivationChange::Destroy
                ) {
                    forbidden.insert(id);
                }
            }
        }
    }
    Ok(result)
}
