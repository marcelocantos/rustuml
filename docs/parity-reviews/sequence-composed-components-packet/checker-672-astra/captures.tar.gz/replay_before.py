import subprocess,shutil
from pathlib import Path
c=Path(__file__).parent
for n in ['no_oracle_failure_names.txt','golden_failure_names.txt']:shutil.copy2(Path('test-diagrams')/n,c/'before'/n)
for manifest,label in [('preserved-manifest.json','preserved-before'),('reference-measure-manifest.json','fresh-before'),('supplement-reference-measure-manifest.json','supplement-before')]:
 argv=['uv','run','--no-project','python',str(c/'measure.py'),str(c/manifest),str(c/'before/bin'),str(c/label)]
 with (c/(label+'.log')).open('wb') as f:subprocess.run(argv,check=True,stdout=f,stderr=subprocess.STDOUT)
 print(label,flush=True)
for label in ['before','candidate']:subprocess.run(['uv','run','--no-project','python',str(c/'models.py'),label],check=True)
