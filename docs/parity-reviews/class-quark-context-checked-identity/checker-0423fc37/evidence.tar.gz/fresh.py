# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import base64
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'fresh'
DEST.mkdir(exist_ok=True)
rows = []
def add(mechanism, name, body, axes, valid=True):
    source = DEST / (name + '.puml')
    data = ('@startuml\n' + body + '\n@enduml\n').encode()
    source.write_bytes(data)
    rows.append(dict(name=source.name, source=str(source), source_bytes=len(data),
        source_sha256=hashlib.sha256(data).hexdigest(), source_base64=base64.b64encode(data).decode(),
        remote_name=source.name, mechanism=mechanism, axes=axes, expected_java_valid=valid,
        timezone='GMT+11:00'))

q = 'class-quark-context-checked-identity'
a = ['root/local or current-group resolution', 'declaration order and consuming command']
add(q, 'q_native_enum_local', 'enum Token\npackage Cove {\nenum Token\nurl Token [[https://example.org/local]]\n}', a)
add(q, 'q_root_note_local_note', 'note "root memorandum" as Token\npackage Cove {\nnote "local memorandum" as Token\nurl Token [[https://example.org/local]]\n}', a)
add(q, 'q_local_note_root_note', 'package Cove {\nnote "local memorandum" as Token\n}\nnote "root memorandum" as Token\nurl Token [[https://example.org/root]]', a)
add(q, 'q_current_inline_member', 'package Cove {\nclass Beacon\nCove : aField\nurl Cove [[https://example.org/child]]\n}', a)
add(q, 'q_current_supertype', 'package Cove {\nclass Beacon extends Cove\nurl Cove [[https://example.org/parent]]\n}', a)
add(q, 'q_rootclass_localnote', 'class Token\npackage Cove {\nnote "local memorandum" as Token\nurl Token [[https://example.org/local]]\n}', a)
add(q, 'q_null_note_first', 'set namespaceSeparator none\nnote "root memorandum" as Token\npackage Cove {\nurl Token [[https://example.org/first]]\n}', a)
add(q, 'q_custom_trailing_decl', 'set namespaceSeparator ::\nclass "Beacon" as Cove::', ['custom separator', 'declaration rather than URL'], False)
add(q, 'q_repeat_supertype', 'class Beacon extends Cove..Token', ['repeated separator', 'supertype creation'], False)
add(q, 'q_current_note_negative', 'package Cove {\nclass Beacon\nnote right of Cove : memo\n}', a, False)
add(q, 'q_curly_url_mixed', 'note "memorandum" as Token\nurl “Token" [[”docs with spaces“{tip}]]', ['mixed delimiter pairs', 'lone note and URL spaces'])
add(q, 'q_curly_note_target', 'class Beacon\nnote right of “Beacon”\nmemorandum\nend note', ['smart quote delimiter', 'attached note sibling command'])
add(q, 'q_invisible_url_target', 'class Beacon\nurl \ue121Beacon\ue121 [[https://example.org/opaque]]', ['internal quote delimiter', 'URL target cleanup'], False)

n = 'class-note-url-command-lifecycle'
a = ['single-line/braced/end-note command', 'implicit/named/group target and URL grammar']
add(n, 'n_implicit_single', 'class Beacon\nnote bottom [[https://example.org/ignored{tip}]] : memorandum', a)
add(n, 'n_implicit_multi', 'class Beacon\nnote bottom [[https://example.org/kept{tip}]]\nmemorandum\nend note', a)
add(n, 'n_named_note_target', 'note "named memorandum" as Token\nnote right of Token [[https://example.org/attached{tip}]] {\nsecond memorandum\n}', a)
add(n, 'n_group_single', 'package Cove {\nclass Beacon\n}\nnote left of Cove [[https://example.org/ignored]] : memorandum', a)
add(n, 'n_group_multi', 'package Cove {\nclass Beacon\n}\nnote left of Cove [[https://example.org/kept]]\nmemorandum\nend note', a)
add(n, 'n_multiline_quoted_url', 'class Beacon\nnote right of Beacon [[“docs with spaces”{tip}]]\nmemorandum\nend note', a)
add(n, 'n_lone_url_top_target', 'skinparam topurl https://example.org/base/\nskinparam svgLinkTarget _self\nnote "wide memorandum\\nsecond row" as Token\nurl Token [[old]]\nurl Token [["new page"{final tip}]]', ['URL replacement/base/target', 'lone multiline note'])
add(n, 'n_note_redeclare', 'note "first memo" as Token\nurl Token [[https://example.org/first]]\nnote "second memo" as Token', ['named note lifecycle', 'duplicate declaration after URL'], False)
add(n, 'n_unknown_url_negative', 'note "memo" as Token\nurl Absent [[https://example.org/missing]]', ['named note lifecycle', 'unknown URL owner'], False)

f = 'class-fashion-value-digit-semantics'
a = ['numeric spelling and CSS/legacy origin', 'lone/attached note or actor/boundary kind']
for name, setting, body in [
    ('f_note_css_false', '<style>\nnote {\nShadowing false\n}\n</style>', 'note "memorandum" as Token'),
    ('f_note_legacy_no', 'skinparam noteShadowing no', 'note "memorandum" as Token'),
    ('f_note_legacy_yes', 'skinparam noteShadowing yes', 'note "memorandum" as Token'),
    ('f_note_decimal', '<style>\nnote {\nShadowing -0.75px\n}\n</style>', 'class Beacon\nnote right of Beacon : memorandum'),
    ('f_note_malformed', '<style>\nnote {\nShadowing 1.2.3\n}\n</style>', 'note "memorandum" as Token\nurl Token [[https://example.org/note]]'),
    ('f_note_zero', '<style>\nnote {\nShadowing -0\n}\n</style>', 'class Beacon\nnote right of Beacon\nmemorandum\nend note'),
    ('f_actor_css_no', '<style>\nactor {\nShadowing no\n}\n</style>', 'allowmixing\nactor "Reader" as Person\nclass Beacon\nPerson --> Beacon'),
    ('f_boundary_fraction', '<style>\nboundary {\nShadowing -.25rem\n}\n</style>', 'allowmixing\nboundary "Gateway" as Port\nclass Beacon\nPort --> Beacon'),
    ('f_actor_legacy_yes', 'skinparam actorShadowing yes', 'allowmixing\nactor "Reader" as Person\nclass Beacon\nPerson --> Beacon'),
    ('f_actor_legacy_negative', 'skinparam shadowing -0.75', 'allowmixing\nactor "Reader" as Person\nclass Beacon\nPerson --> Beacon'),
    ('f_note_cascade_origin', 'skinparam noteShadowing yes\n<style>\nnote {\nShadowing false\n}\n</style>', 'note "memorandum" as Token'),
]:
    add(f, name, setting + '\n' + body, a)

manifest = dict(batch='independent-class-review-0423fc37', candidate='154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc',
    java_revision='71806a23780b04a5ccde2f8ceb5121edad5eb711',
    jar_sha256='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053',
    wrapper_argv=['/Users/marcelo/rustuml-reference/bin/reference','--cwd','PRIVATE_CWD','--timezone','GMT+11:00','--','-pipe','-tsvg'],
    timezone='GMT+11:00', resources=[], inputs=rows)
data = (json.dumps(manifest, indent=2, ensure_ascii=False)+'\n').encode()
(ROOT/'fresh-manifest.json').write_bytes(data)
(ROOT/'fresh-manifest.json.gz').write_bytes(gzip.compress(data,mtime=0))
for path in [ROOT/'fresh-manifest.json', ROOT/'fresh-manifest.json.gz']:
    path.chmod(0o444)
    print(path, hashlib.sha256(path.read_bytes()).hexdigest())
print('cases', len(rows))
