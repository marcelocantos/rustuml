# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import copy, hashlib, json, shutil
from pathlib import Path
S=Path('/Users/marcelo/Library/Caches/rustuml-tim7-checker'); N=S/'new'; N.mkdir(exist_ok=True)
cases=[]
def add(name,mech,body,axes,validity='intended_valid'):
 cases.append((name,'tim-'+mech,body,axes,validity))
for name,key in [('cedar','cedar'),('birch','birch')]:
 add('dual_'+name,'exact-memory-identities',f'''!{key}="bare"
!${key}="cash"
!function $frame({key}="007",${key}="09")
!local {key}={key}+2
!undef ${key}
!return {key}+"/"+${key}+"/"+%get_variable_value("{key}")
!endfunction
!$answer=$frame()
class "$answer / {key} / ${key} / x{key} / x${key}" as Node''',['renamed exact keys','local override removal and display boundary'])
add('defaults_siblings','exact-memory-identities','''!leaf="first"
!$leaf="second"
!function $sibling()
!return leaf+"/"+$leaf
!endfunction
!function $frame(leaf=leaf,$leaf=$leaf)
!local leaf="hidden"
!return $sibling()+"/"+leaf+"/"+$leaf
!endfunction
!leaf="changed"
!$answer=$frame()
class "$answer" as Node''',['captured defaults versus mutated global','sibling frame versus overrides'])
add('builtin_global_remove','exact-memory-identities','''!leaf="global"
!$leaf="cash"
!function $edit(leaf="param")
!$discard=%set_variable_value("leaf","new")
!undef leaf
!return leaf+"/"+$leaf+"/"+%variable_exists("leaf")
!endfunction
!$answer=$edit()
!undef $leaf
class "$answer/%variable_exists("$leaf")/leaf" as Node''',['global builtin assignment','override removal and exact existence'])
for k in ['a$b','twiǵ']:
 add('key_'+('dollar' if '$' in k else 'combining'),'exact-memory-identities',f'''!$ignored=%set_variable_value("{k}","spruce")
!$answer=%get_variable_value("{k}")
class "$answer / {k} / %{''}variable_exists("{k}")" as Node''',['builtin-created exact name','text trie versus direct lookup'])
add('parameter_duplicate','exact-memory-identities','''!function $same(b="one",b="two")
!return b
!endfunction
class "$same(b="named") / $same("left","right")" as Node''',['duplicate declared parameter keys','named versus positional assignment'])
for reverse in [False,True]:
 blocks=['!function pick(a,b="two")\n!return a+"/"+b\n!endfunction','!function pick(a)\n!return "single "+a\n!endfunction']
 if reverse: blocks.reverse()
 add('select_'+str(int(reverse)),'function-signature-availability','\n'.join(blocks)+'''\n!$answer=pick("elm")
class "$answer / pick(a="fir",b="yew") / xpick("skip") / $pick("cash")" as Node''',['declaration order','exact arity versus named fallback and bare boundary'])
add('pending_replace','function-signature-availability','''!function $choose(a="old")
!return a
!endfunction
!function $choose(a=$choose(),b="captured")
!return a+"/"+b
!endfunction
!function $choose(a="new")
!return a
!endfunction
!$answer=$choose()+"/"+$choose("one","two")
class "$answer" as Node''',['pending defaults call completed signature','replacement preserves other arity'])
add('kind_after_exact','function-signature-availability','''!function $choose(a,b="fallback")
!return a+b
!endfunction
!procedure $choose(a)
class Never
!endprocedure
!$answer=$choose("elm")
class Survivor''',['exact versus compatible fallback','procedure rejected by expression kind'],'intended_negative')
add('named_coverage','function-signature-availability','''!function $choose(a="one",b="two")
!return a+b
!endfunction
!function $choose(c="three",d="four",e="five")
!return c+d+e
!endfunction
class "$choose(c="named")" as Node''',['multiple compatible arities','named-key coverage filters candidates'])
# Derive a name whose two adjacent arities cross bucket128 but not bucket256.
def bucket(name,arity,capacity):
 h=0
 for c in name: h=(31*h+ord(c))&0xffffffff
 h=((31+h)*31+arity)&0xffffffff
 return (h^(h>>16))&(capacity-1)
fallback_name=next('$oak'+str(i) for i in range(10000) if bucket('$oak'+str(i),2,128)>bucket('$oak'+str(i),3,128) and bucket('$oak'+str(i),2,256)<bucket('$oak'+str(i),3,256))
for n in [20,21]:
 blocks=[f'!function $filler{i}()\n!return {i}\n!endfunction' for i in range(n)]
 blocks += [f'!function {fallback_name}(a="one",b="two",c="three")\n!return "three"\n!endfunction',f'!function {fallback_name}(a="one",b="two")\n!return "two"\n!endfunction',f'!$answer={fallback_name}()', 'class "$answer" as Node']
 add('capacity_'+str(n),'function-signature-availability','\n'.join(blocks),['ordinary HashMap size96 versus97','bucket order differs from declaration order'])
for kind,end,ret in [('procedure','endprocedure',''),('function','endfunction','\n!return 1'),('definelong','enddefinelong','')]:
 decl='!'+kind+' '+('BLOCK()' if kind=='definelong' else '$unused()')
 add('sub_'+kind,'sub-before-function-buffering',decl+'''\n!startsub stash
class "retained" as Node
!endsub'''+ret+'\n!'+end+'\n!includesub stash',['collector kind','uncalled storage versus located inclusion'])
add('sub_effects','sub-before-function-buffering','''!$count=0
!procedure $increment()
!startsub stash
!$count=$count+1
!endsub
!endprocedure
!$before=$count
!includesub stash
$increment()
!includesub stash
class "$before/$count" as Node''',['no early effects','stored and called replay count'])
add('sub_inactive','sub-before-function-buffering','''!if 0
!procedure $unused()
!startsub stash
class Node
!endsub
!endprocedure
!endif
!includesub stash''',['inactive declaration','sub availability before conditional collector'])
add('sub_nested_negative','sub-before-function-buffering','''!procedure $unused()
!startsub outer
!$fail=%intval("bad")
!startsub inner
!endsub
!endprocedure
class Survivor''',['nested validation inside uncalled collector','error precedence before body effects'],'intended_negative')
for inside in [False,True]:
 body='class Anchor\n'+('!procedure $unused()\n' if inside else '')+'!startsub empty\n!endsub\n'+('!endprocedure\n' if inside else '')+'class Tail\nAnchor --> Tail'
 add('sub_empty_'+str(int(inside)),'sub-before-function-buffering',body,['empty stored body','top-level versus pending function'],'intended_valid_or_empty_truncation')
add('sub_comment_origin','sub-before-function-buffering', '''!procedure $unused()
!startsub stash
/' hidden marker !startsub ignored '/
class "source origin" as Node
!endsub
!endprocedure
!includesub stash''',['comment handling before sub collector','located replay after uncalled procedure'])
rows=[]
for name,mech,body,axes,validity in cases:
 p=N/(name+'.puml'); assert not p.exists();p.write_text('@startuml\n'+body+'\n@enduml\n')
 rows.append(dict(source=str(p),mechanism=mech,negative=validity=='intended_negative',intended_validity=validity,axes=axes,cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={}))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
probe=S/'SourceProbe.java';shutil.copyfile('docs/parity-reviews/tim-corrective-execution-maker/SourceProbe.java',probe)
assert sha(probe)=='fa9dde4b9f18e337741c73fdc23fa8d94034d2341725566e378eab0ac95ad4b4'
manifest=S/'new-manifest.json';manifest.write_text(json.dumps(rows,indent=2)+'\n')
request=json.loads(Path('/Users/marcelo/Library/Caches/rustuml-tim7-maker/remote-request.json').read_bytes())
resources=[dict(local_path=str(p),remote_relative_path='new/'+p.name,sha256=sha(p),bytes=p.stat().st_size) for p in sorted(N.iterdir())]+[dict(local_path=str(probe),remote_relative_path='SourceProbe.java',sha256=sha(probe),bytes=probe.stat().st_size)]
contracts=[]
for row in rows:
 p=Path(row['source']);c=copy.deepcopy(request['case_contracts'][0]);c.update(source=str(p),source_sha256=sha(p));c['probe_argv'][-2]='<worker>/new/'+p.name;contracts.append(c)
request.update(manifest_path=str(manifest),manifest_sha256=sha(manifest),case_count=len(rows),resources=resources,case_contracts=contracts)
p=S/'remote-request.json';p.write_text(json.dumps(request,indent=2)+'\n')
(S/'capacity-design.json').write_text(json.dumps(dict(name=fallback_name,note='Actual selected function name is present in capacity input; bucket formula copied from pinned TFunctionSignature and JDK hash.',cases=[{'count':n,'expected_size':74+n+2} for n in [20,21]]),indent=2)+'\n')
print(json.dumps(dict(request=str(p),sha256=sha(p),manifest=str(manifest),manifest_sha256=sha(manifest),case_count=len(rows),resources=len(resources))))
