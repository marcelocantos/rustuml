// SequenceDiagramFactory#initCommandsList / CommonCommands#addCommonCommands1,
// pinned 71806a23. Registration order and exact original patterns are preserved
// in sequence-registered-command-rejection/inventory.json (81-command source
// probe). These are source grammars, not fixture data. Account 3b38384b3.
static REGISTERED_SEQUENCE_COMMANDS: LazyLock<Vec<RegisteredSequenceCommand>> = LazyLock::new(|| {
    vec![
        // 0: net.sourceforge.plantuml.command.CommandTitle
        RegisteredSequenceCommand::new("CommandTitle", r###"^title(?:[%s]*:[%s]*|[%s]+)(?:[%g](.*)[%g]|(.*[%pLN_.].*))$"###, 2106432u64,
            CommandEnd::Single, true),
        // 1: net.sourceforge.plantuml.command.CommandMainframe
        RegisteredSequenceCommand::new("CommandMainframe", r###"^mainframe(?:[%s]*:[%s]*|[%s]+)(.*[%pLN_.].*)$"###, 574660u64,
            CommandEnd::Single, false),
        // 2: net.sourceforge.plantuml.command.CommandCaption
        RegisteredSequenceCommand::new("CommandCaption", r###"^caption(?:[%s]*:[%s]*|[%s]+)(?:[%g](.*)[%g]|(.*[%pLN_.].*))$"###, 2327572u64,
            CommandEnd::Single, true),
        // 3: net.sourceforge.plantuml.command.CommandMultilinesCaption
        RegisteredSequenceCommand::new("CommandMultilinesCaption", r###"^caption$"###, 0u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?caption$"###)), false),
        // 4: net.sourceforge.plantuml.command.CommandMultilinesTitle
        RegisteredSequenceCommand::new("CommandMultilinesTitle", r###"^title$"###, 0u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?title$"###)), false),
        // 5: net.sourceforge.plantuml.command.CommandMultilinesLegend
        RegisteredSequenceCommand::new("CommandMultilinesLegend", r###"^legend(?:[%s]+(top|bottom))?(?:[%s]+(left|right|center))?$"###, 41312u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?legend$"###)), true),
        // 6: net.sourceforge.plantuml.command.CommandLegend
        RegisteredSequenceCommand::new("CommandLegend", r###"^legend(?:[%s]*:[%s]*|[%s]+)(?:[%g](.*)[%g]|(.*[%pLN_.].*))$"###, 41312u64,
            CommandEnd::Single, false),
        // 7: net.sourceforge.plantuml.command.CommandFooter
        RegisteredSequenceCommand::new("CommandFooter", r###"^(?:(left|right|center))?[%s]*footer(?:[%s]*:[%s]*|[%s]+)(?:[%g](.*)[%g]|(.*[%pLN_.].*))$"###, 2687168u64,
            CommandEnd::Single, true),
        // 8: net.sourceforge.plantuml.command.CommandMultilinesFooter
        RegisteredSequenceCommand::new("CommandMultilinesFooter", r###"^(?:(left|right|center)?[%s]*)footer$"###, 0u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?footer$"###)), false),
        // 9: net.sourceforge.plantuml.command.CommandHeader
        RegisteredSequenceCommand::new("CommandHeader", r###"^(?:(left|right|center))?[%s]*header(?:[%s]*:[%s]*|[%s]+)(?:[%g](.*)[%g]|(.*[%pLN_.].*))$"###, 524900u64,
            CommandEnd::Single, true),
        // 10: net.sourceforge.plantuml.command.CommandMultilinesHeader
        RegisteredSequenceCommand::new("CommandMultilinesHeader", r###"^(?:(left|right|center)?[%s]*)header$"###, 0u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?header$"###)), false),
        // 11: net.sourceforge.plantuml.classdiagram.command.CommandNamespaceSeparator
        RegisteredSequenceCommand::new("CommandNamespaceSeparator", r###"^set[%s]+(?:separator|namespaceseparator)[%s]+(\S+)$"###, 3145793u64,
            CommandEnd::Single, false),
        // 12: net.sourceforge.plantuml.command.CommandNope
        RegisteredSequenceCommand::new("CommandNope", r###"^[%s]*$"###, 0u64,
            CommandEnd::Single, true),
        // 13: net.sourceforge.plantuml.command.CommandPragma
        RegisteredSequenceCommand::new("CommandPragma", r###"^!pragma[%s]+([A-Za-z_][A-Za-z_0-9]*)(?:[%s]+(.*))?$"###, 537542917u64,
            CommandEnd::Single, true),
        // 14: net.sourceforge.plantuml.command.CommandAssumeTransparent
        RegisteredSequenceCommand::new("CommandAssumeTransparent", r###"^!assume[%s]+transparent[%s]+(dark|light)$"###, 544915525u64,
            CommandEnd::Single, false),
        // 15: net.sourceforge.plantuml.command.CommandSkinParam
        RegisteredSequenceCommand::new("CommandSkinParam", r###"^(skinparam|skinparamlocked)[%s]+([\w.]*(?:\<\<[^<>]*\>\>)?[\w.]*)[%s]+([^{}]*)$"###, 1758213u64,
            CommandEnd::Single, true),
        // 16: net.sourceforge.plantuml.command.CommandSkinParamJaws
        RegisteredSequenceCommand::new("CommandSkinParamJaws", r###"^((skinparam|skinparamlocked)[%s]+.*.*)+$"###, 0u64,
            CommandEnd::Single, false),
        // 17: net.sourceforge.plantuml.command.CommandSkinParamMultilines
        RegisteredSequenceCommand::new("CommandSkinParamMultilines", r###"^skinparam[%s]*(?:[%s]+([\w.]*(?:\<\<.*\>\>)?[\w.]*))?[%s]*\{$"###, 0u64,
            CommandEnd::Brace, true),
        // 18: net.sourceforge.plantuml.sequencediagram.command.CommandSkin
        RegisteredSequenceCommand::new("CommandSkin", r###"^skin[%s]+([\w.]+)$"###, 1086465u64,
            CommandEnd::Single, false),
        // 19: net.sourceforge.plantuml.command.CommandMinwidth
        RegisteredSequenceCommand::new("CommandMinwidth", r###"^minwidth[%s]+(\d+)$"###, 18925089u64,
            CommandEnd::Single, false),
        // 20: net.sourceforge.plantuml.command.CommandPage
        RegisteredSequenceCommand::new("CommandPage", r###"^page[%s]+(\d+)[%s]*x*[%s]*(\d+)$"###, 131397u64,
            CommandEnd::Single, false),
        // 21: net.sourceforge.plantuml.command.CommandRotate
        RegisteredSequenceCommand::new("CommandRotate", r###"^rotate$"###, 2687044u64,
            CommandEnd::Single, false),
        // 22: net.sourceforge.plantuml.command.CommandFactorySprite$1
        RegisteredSequenceCommand::new("CommandFactorySprite$1", r###"^sprite[%s]+\$?([-.%pLN_]+)[%s]*(?:\[(\d+)x(\d+)/(?:(\d+)(z)?|(color))\])?[%s]*\{$"###, 72057594041730113u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?sprite|\}$"###)), false),
        // 23: net.sourceforge.plantuml.command.CommandFactorySprite$2
        RegisteredSequenceCommand::new("CommandFactorySprite$2", r###"^sprite[%s]+\$?([-.%pLN_]+)[%s]*(?:\[(\d+)x(\d+)/(?:(\d+)(z)|(color))\])?[%s]+([-_A-Za-z0-9]+)$"###, 3802177u64,
            CommandEnd::Single, false),
        // 24: net.sourceforge.plantuml.command.CommandSpriteSvg
        RegisteredSequenceCommand::new("CommandSpriteSvg", r###"^sprite[%s]+\$?([-%pLN_]+)[%s]+(\<svg\b.*\</svg\>)$"###, 360639826101569u64,
            CommandEnd::Single, false),
        // 25: net.sourceforge.plantuml.command.CommandSpriteStdlib
        RegisteredSequenceCommand::new("CommandSpriteStdlib", r###"^sprite[%s]+\$([-%pLN_]+)[%s]*#([^#]+)#([^%s]+)$"###, 4298769473u64,
            CommandEnd::Single, false),
        // 26: net.sourceforge.plantuml.command.CommandSpriteStdlibSvg
        RegisteredSequenceCommand::new("CommandSpriteStdlibSvg", r###"^sprite[%s]+\$?([-%pLN_]+)[%s]*:([^:]+):([^%s]+)$"###, 3802177u64,
            CommandEnd::Single, false),
        // 27: net.sourceforge.plantuml.command.CommandSpriteSvgMultiline
        RegisteredSequenceCommand::new("CommandSpriteSvgMultiline", r###"^sprite[%s]+\$?([-%pLN_]+)[%s]+(\<svg\b.*)$"###, 70368756368705u64,
            CommandEnd::End(registered_regex(r###"(.*\</svg\>)$"###)), false),
        // 28: net.sourceforge.plantuml.command.CommandSpriteFile
        RegisteredSequenceCommand::new("CommandSpriteFile", r###"^sprite[%s]+\$?([-%pLN_]+)[%s]+([^<>%g#]*)$"###, 3802177u64,
            CommandEnd::Single, false),
        // 29: net.sourceforge.plantuml.style.CommandStyleMultilinesCSS
        RegisteredSequenceCommand::new("CommandStyleMultilinesCSS", r###"^\<style\>$"###, 351843791151168u64,
            CommandEnd::End(registered_regex(r###"^[%s]*\</?style\>[%s]*$"###)), false),
        // 30: net.sourceforge.plantuml.style.CommandStyleImport
        RegisteredSequenceCommand::new("CommandStyleImport", r###"^\<style[%s]*\w+[%s]*=[%s]*[%q%g]?([^%q%g]*)[%q%g]?\>$"###, 492581279506498u64,
            CommandEnd::Single, false),
        // 31: net.sourceforge.plantuml.command.CommandScale
        RegisteredSequenceCommand::new("CommandScale", r###"^scale[%s]+([0-9.]+)(?:[%s]*/[%s]*([0-9.]+))?$"###, 1056853u64,
            CommandEnd::Single, false),
        // 32: net.sourceforge.plantuml.command.CommandScaleWidthAndHeight
        RegisteredSequenceCommand::new("CommandScaleWidthAndHeight", r###"^scale[%s]+([0-9.]+)[%s]*[*x][%s]*([0-9.]+)$"###, 1056853u64,
            CommandEnd::Single, false),
        // 33: net.sourceforge.plantuml.command.CommandScaleWidthOrHeight
        RegisteredSequenceCommand::new("CommandScaleWidthOrHeight", r###"^scale[%s]+([0-9.]+)[%s]+(width|height)$"###, 3155541u64,
            CommandEnd::Single, false),
        // 34: net.sourceforge.plantuml.command.CommandScaleMaxWidth
        RegisteredSequenceCommand::new("CommandScaleMaxWidth", r###"^scale[%s]+max[%s]+([0-9.]+)[%s]+width$"###, 53503605u64,
            CommandEnd::Single, false),
        // 35: net.sourceforge.plantuml.command.CommandScaleMaxHeight
        RegisteredSequenceCommand::new("CommandScaleMaxHeight", r###"^scale[%s]+max[%s]+([0-9.]+)[%s]+height$"###, 36726613u64,
            CommandEnd::Single, false),
        // 36: net.sourceforge.plantuml.command.CommandScaleMaxWidthAndHeight
        RegisteredSequenceCommand::new("CommandScaleMaxWidthAndHeight", r###"^scale[%s]+max[%s]+([0-9.]+)[%s]*[*x][%s]*([0-9.]+)$"###, 34627669u64,
            CommandEnd::Single, false),
        // 37: net.sourceforge.plantuml.statediagram.command.CommandHideEmptyDescription
        RegisteredSequenceCommand::new("CommandHideEmptyDescription", r###"^(hide|show)[%s]+empty[%s]+description$"###, 71026289u64,
            CommandEnd::Single, false),
        // 38: net.sourceforge.plantuml.classdiagram.command.CommandHideShowByVisibility
        RegisteredSequenceCommand::new("CommandHideShowByVisibility", r###"^(hide|show)[%s]+((?:public|private|protected|package)?(?:[,%s]+(?:public|private|protected|package))*)[%s]+(members?|attributes?|fields?|methods?)$"###, 577u64,
            CommandEnd::Single, false),
        // 39: net.sourceforge.plantuml.classdiagram.command.CommandHideShowByGender
        RegisteredSequenceCommand::new("CommandHideShowByGender", r###"^(hide|show)[%s]+(?:(class|object|interface|enum|annotation|dataclass|record|abstract|[%pLN_.]+|[%g][^%g]+[%g]|\<\<.*\>\>)[%s]+)*?(?:(empty)[%s]+)?(members?|attributes?|fields?|methods?|circles?|circled?|stereotypes?)$"###, 577u64,
            CommandEnd::Single, true),
        // 40: net.sourceforge.plantuml.sequencediagram.command.CommandHideUnlinked
        RegisteredSequenceCommand::new("CommandHideUnlinked", r###"^(hide|show)[%s]+@?unlinked$"###, 4240993u64,
            CommandEnd::Single, false),
        // 41: net.sourceforge.plantuml.sequencediagram.command.CommandActivate
        RegisteredSequenceCommand::new("CommandActivate", r###"^(activate|deactivate|destroy|create)[%s]+([%pLN_.@]+|[%g][^%g]+[%g])[%s]*(?P<seq_color0>#\w+)?(?:[%s]+(?P<seq_color1>#\w+))?$"###, 2097217u64,
            CommandEnd::Single, true),
        // 42: net.sourceforge.plantuml.sequencediagram.command.CommandDeactivateShort
        RegisteredSequenceCommand::new("CommandDeactivateShort", r###"^deactivate[%s]*$"###, 10486900u64,
            CommandEnd::Single, false),
        // 43: net.sourceforge.plantuml.sequencediagram.command.CommandParticipantA
        RegisteredSequenceCommand::new("CommandParticipantA", r###"^(?:(participant|actor|create|boundary|control|entity|queue|database|collections)|create[%s](participant|actor|boundary|control|entity|queue|database|collections))[%s]+(?:[%g]([^%g]+)[%g][%s]+as[%s]+)?([%pLN_.@]+)[%s]*(?:(\<\<.+?\>\>))?[%s]*(?:order[%s]+(-?\d{1,7}))?[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*{COLOR}$"###, 1u64,
            CommandEnd::Single, true),
        // 44: net.sourceforge.plantuml.sequencediagram.command.CommandParticipantA2
        RegisteredSequenceCommand::new("CommandParticipantA2", r###"^(?:(participant|actor|create|boundary|control|entity|queue|database|collections)|create[%s](participant|actor|boundary|control|entity|queue|database|collections))[%s]+([%pLN_.@]+)[%s]+as[%s]+[%g]([^%g]+)[%g][%s]*(?:(\<\<.+?\>\>))?[%s]*(?:order[%s]+(-?\d{1,7}))?[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*{COLOR}$"###, 1048581u64,
            CommandEnd::Single, true),
        // 45: net.sourceforge.plantuml.sequencediagram.command.CommandParticipantA3
        RegisteredSequenceCommand::new("CommandParticipantA3", r###"^(?:(participant|actor|create|boundary|control|entity|queue|database|collections)|create[%s](participant|actor|boundary|control|entity|queue|database|collections))[%s]+([%pLN_.@]+)[%s]+as[%s]+([%pLN_.@]+)[%s]*(?:(\<\<.+?\>\>))?[%s]*(?:order[%s]+(-?\d{1,7}))?[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*{COLOR}$"###, 1048581u64,
            CommandEnd::Single, true),
        // 46: net.sourceforge.plantuml.sequencediagram.command.CommandParticipantA4
        RegisteredSequenceCommand::new("CommandParticipantA4", r###"^(?:(participant|actor|create|boundary|control|entity|queue|database|collections)|create[%s](participant|actor|boundary|control|entity|queue|database|collections))[%s]+[%g]([^%g]+)[%g][%s]*(?:(\<\<.+?\>\>))?[%s]*(?:order[%s]+(-?\d{1,7}))?[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*{COLOR}$"###, 1u64,
            CommandEnd::Single, true),
        // 47: net.sourceforge.plantuml.sequencediagram.command.CommandParticipantMultilines
        RegisteredSequenceCommand::new("CommandParticipantMultilines", r###"^(participant)[%s]+([%pLN_.@]+)[%s]*(?:(\<\<.+?\>\>))?[%s]*(?:order[%s]+(-?\d{1,7}))?[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*{COLOR}[%s]*\[$"###, 2251799816471573u64,
            CommandEnd::End(registered_regex(r###"^([^\[\]]*)\]$"###)), false),
        // 48: net.sourceforge.plantuml.sequencediagram.command.CommandArrow
        RegisteredSequenceCommand::new("CommandArrow", r###"^(&[%s]*)?(\{([%pLN_]+)\}[%s]+)?(([%pLN_.@]+)|[%g]([^%g]+)[%g]|[%g]([^%g]+)[%g][%s]*as[%s]+([%pLN_.@]+)|([%pLN_.@]+)[%s]+as[%s]*[%g]([^%g]+)[%g])(\{([%pLN_]+)\}[%s]+)?[%s]*(?:([%s][ox]|(?:[%s][ox]|\(\d+\))?<<?_?|(?:[%s][ox])?//?|(?:[%s][ox])?\\\\?))?(?:(-+)(?:\[(?P<seq_style0>(?:#\w+|dotted|dashed|plain|bold|hidden|norank|single|node|thickness=\d+)(?:,#\w+|,dotted|,dashed|,plain|,bold|,hidden|,norank|,single|,node|,thickness=\d+)*)\])?(-*)|(-*)(?:\[(?P<seq_style1>(?:#\w+|dotted|dashed|plain|bold|hidden|norank|single|node|thickness=\d+)(?:,#\w+|,dotted|,dashed|,plain|,bold|,hidden|,norank|,single|,node|,thickness=\d+)*)\])?(-+))(?:(_?>>?(?:[ox][%s]|\(\d+\))?|//?(?:[ox][%s])?|\\\\?(?:[ox][%s])?|[ox][%s]))?[%s]*(([%pLN_.@]+)|[%g]([^%g]+)[%g]|[%g]([^%g]+)[%g][%s]*as[%s]+([%pLN_.@]+)|([%pLN_.@]+)[%s]+as[%s]*[%g]([^%g]+)[%g])((?:\s&\s[%pLN_.@]+)*)(\{([%pLN_]+)\}[%s]+)?[%s]*(?:(\+\+|\*\*|!!|--|--\+\+|\+\+--)?)[%s]*(?:(?P<seq_color0>#\w+)?)[%s]*(?:(\<\<.+?\>\>))?[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*(?::[%s]*(.*))?$"###, 0u64,
            CommandEnd::Single, true),
        // 49: net.sourceforge.plantuml.sequencediagram.command.CommandExoArrowLeft
        RegisteredSequenceCommand::new("CommandExoArrowLeft", r###"^(&[%s]*)?(\{([%pLN_]+)\}[%s]+)?([?\[\]][ox]?)?(?:(<<?|//?|\\\\?)?(-+)(?:\[(?P<seq_style0>(?:#\w+|dotted|dashed|plain|bold|hidden|norank|single|node|thickness=\d+)(?:,#\w+|,dotted|,dashed|,plain|,bold|,hidden|,norank|,single|,node|,thickness=\d+)*)\])?(-*)(>>?|//?|\\\\?)|(<<?|//?|\\\\?)(-*)(?:\[(?P<seq_style1>(?:#\w+|dotted|dashed|plain|bold|hidden|norank|single|node|thickness=\d+)(?:,#\w+|,dotted|,dashed|,plain|,bold|,hidden|,norank|,single|,node|,thickness=\d+)*)\])?(-+))([ox][%s]+)?[%s]*([%pLN_.@]+|[%g][^%g]+[%g])[%s]*(?:([+*!-]+)?)[%s]*(?:(?P<seq_color0>#\w+)?)[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*(?::[%s]*(.*))?$"###, 0u64,
            CommandEnd::Single, true),
        // 50: net.sourceforge.plantuml.sequencediagram.command.CommandExoArrowRight
        RegisteredSequenceCommand::new("CommandExoArrowRight", r###"^(&[%s]*)?(\{([%pLN_]+)\}[%s]+)?([%pLN_.@]+|[%g][^%g]+[%g])[%s]*([%s]+[ox])?(?:(<<?|//?|\\\\?)?(-+)(?:\[(?P<seq_style0>(?:#\w+|dotted|dashed|plain|bold|hidden|norank|single|node|thickness=\d+)(?:,#\w+|,dotted|,dashed|,plain|,bold|,hidden|,norank|,single|,node|,thickness=\d+)*)\])?(-*)(>>?|//?|\\\\?)|(<<?|//?|\\\\?)(-*)(?:\[(?P<seq_style1>(?:#\w+|dotted|dashed|plain|bold|hidden|norank|single|node|thickness=\d+)(?:,#\w+|,dotted|,dashed|,plain|,bold|,hidden|,norank|,single|,node|,thickness=\d+)*)\])?(-+))([ox]?[?\]\[])?[%s]*(?:([+*!-]+)?)[%s]*(?:(?P<seq_color0>#\w+)?)[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*(?::[%s]*(.*))?$"###, 0u64,
            CommandEnd::Single, true),
        // 51: net.sourceforge.plantuml.command.note.sequence.FactorySequenceNoteCommand$2
        RegisteredSequenceCommand::new("FactorySequenceNoteCommand$2", r###"^(&[%s]*)?(/)?[%s]*(note|hnote|rnote)[%s]*(?:(\<\<.+?\>\>))?[%s]*(right|left|over)[%s]+(?:of[%s])?([%pLN_.@]+|[%g][^%g]+[%g])[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*:[%s]*(.*)$"###, 17592188239937u64,
            CommandEnd::Single, true),
        // 52: net.sourceforge.plantuml.command.note.sequence.FactorySequenceNoteOverSeveralCommand$1
        RegisteredSequenceCommand::new("FactorySequenceNoteOverSeveralCommand$1", r###"^(&[%s]*)?(/)?[%s]*(note|hnote|rnote)[%s]*(?:(\<\<.+?\>\>))?[%s]*over[%s]+([%pLN_.@]+|[%g][^%g]+[%g])[%s]*,[%s]*([%pLN_.@]+|[%g][^%g]+[%g])[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*:[%s]*(.*)$"###, 18691708780609u64,
            CommandEnd::Single, true),
        // 53: net.sourceforge.plantuml.command.note.sequence.FactorySequenceNoteAcrossCommand$1
        RegisteredSequenceCommand::new("FactorySequenceNoteAcrossCommand$1", r###"^(/)?[%s]*(note|hnote|rnote)[%s]*(?:(\<\<.+?\>\>))?[%s]*(accross|across)[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*:[%s]*(.*)$"###, 17592189812820u64,
            CommandEnd::Single, true),
        // 54: net.sourceforge.plantuml.sequencediagram.command.CommandBoxStart
        RegisteredSequenceCommand::new("CommandBoxStart", r###"^box(?:(?:[%s]+[%g]([^%g]+)[%g]|[%s]+([^#]+)))?[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}$"###, 33619976u64,
            CommandEnd::Single, true),
        // 55: net.sourceforge.plantuml.sequencediagram.command.CommandBoxEnd
        RegisteredSequenceCommand::new("CommandBoxEnd", r###"^end[%s]*box$"###, 33652840u64,
            CommandEnd::Single, true),
        // 56: net.sourceforge.plantuml.sequencediagram.command.CommandGrouping
        RegisteredSequenceCommand::new("CommandGrouping", r###"^(&[%s]*)?(?:(opt|alt|loop|par|par2|break|critical|group|partition)(?P<seq_color0>#\w+)?|(else|end|also))(?:[%s]+(?P<seq_color1>#\w+))?(?:[%s]+(.*?))?$"###, 0u64,
            CommandEnd::Single, true),
        // 57: net.sourceforge.plantuml.sequencediagram.command.CommandActivate2
        RegisteredSequenceCommand::new("CommandActivate2", r###"^([%pLN_.@]+)[%s]*(\+\+|--)[%s]*(?P<seq_color0>#\w+)?$"###, 0u64,
            CommandEnd::Single, false),
        // 58: net.sourceforge.plantuml.sequencediagram.command.CommandReturn
        RegisteredSequenceCommand::new("CommandReturn", r###"^(&[%s]*)?[%s]*return[%s]*(?:(?P<seq_color0>#\w+)[%s]+)?(.*)$"###, 6848576u64,
            CommandEnd::Single, true),
        // 59: net.sourceforge.plantuml.command.note.sequence.FactorySequenceNoteOnArrowCommand$1
        RegisteredSequenceCommand::new("FactorySequenceNoteOnArrowCommand$1", r###"^[%s]*(note|hnote|rnote)[%s]*(?:(\<\<.+?\>\>))?[%s]*(right|left|bottom|top)[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?[%s]*:[%s]*(.*)$"###, 17592188239936u64,
            CommandEnd::Single, true),
        // 60: net.sourceforge.plantuml.command.note.sequence.FactorySequenceNoteCommand$1
        RegisteredSequenceCommand::new("FactorySequenceNoteCommand$1", r###"^(&[%s]*)?(/)?[%s]*(note|hnote|rnote)[%s]*(?:(\<\<.+?\>\>))?[%s]*(right|left|over)[%s]+(?:of[%s]+)?([%pLN_.@]+|[%g][^%g]+[%g])[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?$"###, 2195521u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?(note|hnote|rnote)$"###)), true),
        // 61: net.sourceforge.plantuml.command.note.sequence.FactorySequenceNoteOverSeveralCommand$2
        RegisteredSequenceCommand::new("FactorySequenceNoteOverSeveralCommand$2", r###"^(&[%s]*)?(/)?[%s]*(note|hnote|rnote)[%s]*(?:(\<\<.+?\>\>))?[%s]*over[%s]+([%pLN_.@]+|[%g][^%g]+[%g])[%s]*,[%s]*([%pLN_.@]+|[%g][^%g]+[%g])[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?$"###, 1099522736193u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?(note|hnote|rnote)$"###)), true),
        // 62: net.sourceforge.plantuml.command.note.sequence.FactorySequenceNoteOnArrowCommand$2
        RegisteredSequenceCommand::new("FactorySequenceNoteOnArrowCommand$2", r###"^[%s]*(note|hnote|rnote)[%s]*(?:(\<\<.+?\>\>))?[%s]*(right|left|bottom|top)[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?$"###, 2195520u64,
            CommandEnd::End(registered_regex(r###"^[%s]*end[%s]?note$"###)), true),
        // 63: net.sourceforge.plantuml.command.note.sequence.FactorySequenceNoteAcrossCommand$2
        RegisteredSequenceCommand::new("FactorySequenceNoteAcrossCommand$2", r###"^(/)?[%s]*(note|hnote|rnote)[%s]*(?:(\<\<.+?\>\>))?[%s]*(accross|across)[%s]*(?:(\<\<.+?\>\>))?[%s]*{COLOR}[%s]*(?:(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]))?$"###, 3768404u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?(note|hnote|rnote)$"###)), true),
        // 64: net.sourceforge.plantuml.sequencediagram.command.CommandNewpage
        RegisteredSequenceCommand::new("CommandNewpage", r###"^@?newpage(?:(?:[%s]*:[%s]*|[%s]+)(.*[%pLN_.].*))?$"###, 16941380u64,
            CommandEnd::Single, true),
        // 65: net.sourceforge.plantuml.sequencediagram.command.CommandIgnoreNewpage
        RegisteredSequenceCommand::new("CommandIgnoreNewpage", r###"^ignore[%s]*newpage$"###, 17532228u64,
            CommandEnd::Single, false),
        // 66: net.sourceforge.plantuml.sequencediagram.command.CommandAutoNewpage
        RegisteredSequenceCommand::new("CommandAutoNewpage", r###"^autonewpage[%s]+(\d+)$"###, 23298373u64,
            CommandEnd::Single, false),
        // 67: net.sourceforge.plantuml.sequencediagram.command.CommandDivider
        RegisteredSequenceCommand::new("CommandDivider", r###"^==[%s]*(.*)[%s]*==$"###, 140737488355330u64,
            CommandEnd::Single, true),
        // 68: net.sourceforge.plantuml.sequencediagram.command.CommandHSpace
        RegisteredSequenceCommand::new("CommandHSpace", r###"^\|\|(\d+)?\|+$"###, 144115188075855872u64,
            CommandEnd::Single, true),
        // 69: net.sourceforge.plantuml.sequencediagram.command.CommandReferenceOverSeveral
        RegisteredSequenceCommand::new("CommandReferenceOverSeveral", r###"^ref(?P<seq_color0>#\w+)?[%s]+over[%s]+(([%pLN_.@]+|[%g][^%g]+[%g])([%s]*,[%s]*([%pLN_.@]+|[%g][^%g]+[%g]))*)[%s]*(?:(\[\[.*?\]\]))?[%s]*:[%s]*(.*)$"###, 17592195023041u64,
            CommandEnd::Single, true),
        // 70: net.sourceforge.plantuml.sequencediagram.command.CommandReferenceMultilinesOverSeveral
        RegisteredSequenceCommand::new("CommandReferenceMultilinesOverSeveral", r###"^ref(?P<seq_color0>#\w+)?[%s]+over[%s]+((?:[%pLN_.@]+|[%g][^%g]+[%g])(?:[%s]*,[%s]*(?:[%pLN_.@]+|[%g][^%g]+[%g]))*)[%s]*(?:(\[\[.*?\]\]))?[%s]*(?P<seq_color1>#\w+)?$"###, 0u64,
            CommandEnd::End(registered_regex(r###"^end[%s]?(ref)?$"###)), true),
        // 71: net.sourceforge.plantuml.sequencediagram.command.CommandAutonumber
        RegisteredSequenceCommand::new("CommandAutonumber", r###"^autonumber[%s]*(\d(?:(?:[^%pLN%s]+|\d+)*\d)?)?(?:[%s]+(\d+))?(?:[%s]+[%g]([^%g]+)[%g])?[%s]*$"###, 6930508u64,
            CommandEnd::Single, true),
        // 72: net.sourceforge.plantuml.sequencediagram.command.CommandAutonumberStop
        RegisteredSequenceCommand::new("CommandAutonumberStop", r###"^autonumber[%s]+stop[%s]*$"###, 8110157u64,
            CommandEnd::Single, true),
        // 73: net.sourceforge.plantuml.sequencediagram.command.CommandAutonumberResume
        RegisteredSequenceCommand::new("CommandAutonumberResume", r###"^autonumber[%s]+resume[%s]*(?:[%s]+(\d+))?(?:[%s]+[%g]([^%g]+)[%g])?$"###, 7979085u64,
            CommandEnd::Single, true),
        // 74: net.sourceforge.plantuml.sequencediagram.command.CommandAutonumberIncrement
        RegisteredSequenceCommand::new("CommandAutonumberIncrement", r###"^autonumber[%s]+inc(?:[%s]+([A-Za-z]))?[%s]*$"###, 6931549u64,
            CommandEnd::Single, false),
        // 75: net.sourceforge.plantuml.sequencediagram.command.CommandAutoactivate
        RegisteredSequenceCommand::new("CommandAutoactivate", r###"^autoactivate[%s]+(off|on)$"###, 14746709u64,
            CommandEnd::Single, true),
        // 76: net.sourceforge.plantuml.sequencediagram.command.CommandFootbox
        RegisteredSequenceCommand::new("CommandFootbox", r###"^(hide|show)?[%s]*footbox$"###, 35717256u64,
            CommandEnd::Single, true),
        // 77: net.sourceforge.plantuml.sequencediagram.command.CommandDelay
        RegisteredSequenceCommand::new("CommandDelay", r###"^(?:\.{3}|…)(?:(.*)(?:\.{3}|…))?$"###, 0u64,
            CommandEnd::Single, true),
        // 78: net.sourceforge.plantuml.sequencediagram.command.CommandFootboxOld
        RegisteredSequenceCommand::new("CommandFootboxOld", r###"^footbox[%s]*(on|off)?[%s]*$"###, 35717256u64,
            CommandEnd::Single, true),
        // 79: net.sourceforge.plantuml.sequencediagram.command.CommandUrl
        RegisteredSequenceCommand::new("CommandUrl", r###"^url[%s]*(?:of|for)?[%s]+([%pLN_.@]+|[%g][^%g]+[%g])[%s]+(?:is)?[%s]*(\[\[[%s]*[%g]([^%g]+)[%g](?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\]|\[\[[%s]*\{(.*)\}[%s]*\]\]|\[\[[%s]*\{([^{}]*)\}[%s]*([^\[%s\{\}\[\]][^\[\]]*)[%s]*\]\]|\[\[[%s]*([^\s%g{}\[\]]+?)[%s]*\{(.+)\}[%s]*\]\]|\[\[[%s]*([^%s%g\[\]]+?)(?:[%s]*\{([^{}]*)\})?(?:[%s]([^%s\{\}\[\]][^\[\]]*))?[%s]*\]\])$"###, 4726785u64,
            CommandEnd::Single, false),
        // 80: net.sourceforge.plantuml.sequencediagram.command.CommandLinkAnchor
        RegisteredSequenceCommand::new("CommandLinkAnchor", r###"^\{([%pLN_]+)\}[%s]*\<-\>[%s]*\{([%pLN_]+)\}[%s]*(?::[%s]*(.*))?$"###, 354042744143874u64,
            CommandEnd::Single, false),
    ]
});
