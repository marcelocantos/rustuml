# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,re,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent
put=lambda n,v:(S/n).write_text(json.dumps(v,indent=2)+'\n')
residuals={'raw_deployment_links':'T14.23 identity projection: Java data-qualified-name .clair-- / Peer.-, Rust Éclair-- / Peeré-. Comment lists now exact; attributes intentionally untouched.','state_concurrent_alpha':'Concurrent state allocation: Java Leaf id ent0003, Rust ent0004. Paint repaired, identity allocation remains.','state_choice_alpha':'Choice consumer selects global state background instead of its own default: Java #F1F1F1, Rust #345678 opacity0.49804. Serialization is exercised but does not fix style selection.','state_history_names':'History consumer geometry/shape: Java108x235, Rust193x223,21 versus20 elements; wrong ellipse radius/style/paint. Comments now exact; no geometry compensation.'}
rows=[]
for c in ['checker54','consumer16']:
 members=json.loads((S/f'{c}-membership.json').read_text());b=json.loads((S/f'{c}-before.json').read_text());a=json.loads((S/f'{c}-after.json').read_text())
 for m,x,y in zip(members,b,a):
  raw={p:(S/'replay'/p/m['id']/'svg.stdout').read_bytes() for p in ['before','after']};raw['java']=Path(m['golden_capture']).read_bytes();projections={}
  for phase,data in raw.items():
   try:
    root=ET.fromstring(data);projections[phase]=dict(root_attributes=root.attrib,paint=[dict(tag=e.tag.split('}')[-1],**e.attrib) for e in root.iter() if e.tag.split('}')[-1] in ['rect','ellipse','polygon','path','line'] and ('fill' in e.attrib or 'stroke' in e.attrib or 'style' in e.attrib)])
   except ET.ParseError as e:projections[phase]=dict(xml_error=str(e),bytes=len(data),nul_count=data.count(b'\0'))
  rows.append(dict(cohort=c,id=m['id'],source=m['source_capture'],source_sha256=m['source_sha256'],reference=m['golden_capture'],reference_valid=y['reference_valid'],before_pass=x['svg_match'],after_pass=y['svg_match'],before_exit=x['svg']['exit'],after_exit=y['svg']['exit'],before_panic=x['panic'],after_panic=y['panic'],projections=projections,whole_difference=(S/'replay/after'/m['id']/'compare.stdout').read_text(),residual=residuals.get(m['id'].split('/')[-1])))
put('fresh-checker-paint-and-whole-observations.json',rows)
# Complete producer lists, including unchanged whole failures and all goldens.
rows=[]
for c in json.loads((S/'cohorts.json').read_text())+['consumer16','full-golden']:
 members=json.loads((S/f'{c}-membership.json').read_text());b=json.loads((S/f'{c}-before.json').read_text());a=json.loads((S/f'{c}-after.json').read_text())
 for m,x,y in zip(members,b,a):
  def comments(data):return [z.decode('utf8','replace') for z in re.findall(rb'<!--(.*?)-->',data,re.S) if z.startswith((b'class ',b'entity ',b'cluster ',b'link ',b'reverse link '))]
  j=comments(Path(m['golden_capture']).read_bytes());p=comments((S/'replay/before'/m['id']/'svg.stdout').read_bytes());q=comments((S/'replay/after'/m['id']/'svg.stdout').read_bytes())
  if p==q==j:continue
  rows.append(dict(cohort=c,id=m['id'],reference_valid=y['reference_valid'],before_whole_pass=x['svg_match'],after_whole_pass=y['svg_match'],java=j,before=p,after=q,before_exact=p==j,after_exact=q==j,newly_exact=p!=j and q==j))
put('producer-list-census.json',rows)
print('golden unmatched producer lists',sum(x['cohort']=='full-golden' and not x['after_exact'] for x in rows))
