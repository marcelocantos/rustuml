import concurrent.futures,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
c=Path(__file__).parent;root=Path.cwd();label=sys.argv[1]
old=json.loads(gzip.decompress(subprocess.check_output(['git','show','672cd8f:docs/parity-reviews/sequence-composed-components-packet/maker-results/model-and-ascii.json.gz'])))
preserved=json.loads((c/'preserved-manifest.json').read_text());by_sha={hashlib.sha256(Path(x['source']).read_bytes()).hexdigest():x for x in preserved}
items=[dict(by_sha[x['source_sha256']],cohort='prior55') for x in old]
for n in ['reference-request.json','reference-supplement.json']:
 items += [dict(source=x['source'],cohort='fresh42',name=x['name']) for x in json.loads((c/n).read_text())['cases']]
env=dict(os.environ,RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')
def one(i):
 b=Path(i['source']).read_bytes();r=dict(i,source_sha256=hashlib.sha256(b).hexdigest(),results={})
 for mode,args in [('model',['--ast','-pipe']),('ascii',['-ttxt','-pipe'])]:
  argv=[str(c/label/'bin/rustuml'),*args];p=subprocess.run(argv,input=b,capture_output=True,cwd=root,env=env,timeout=30);r['results'][mode]=dict(command=argv,exit=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode(),stdout_sha256=hashlib.sha256(p.stdout).hexdigest())
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(one,items))
(c/('models-'+label+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(len(rows))
