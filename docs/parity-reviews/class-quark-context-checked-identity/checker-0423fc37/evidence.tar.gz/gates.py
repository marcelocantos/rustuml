# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
S=Path(__file__).resolve().parent
R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-0423fc37')
for r in json.loads((S/'fresh-manifest.json').read_text())['inputs']:
    for root in [R,S/'after-source']:
        dest=root/'test-diagrams/perturbations'/r['mechanism']/'checker-0423fc37'
        dest.mkdir(parents=True,exist_ok=True)
        for suffix in ['.puml','.svg']:
            src=Path(r['source']).with_suffix(suffix)
            shutil.copyfile(src,dest/src.name)
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(S/'after-target'),PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib',RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100')
env['PATH']='/Users/marcelo/Library/Caches/rustuml-class-cff7/no-local-jvm'+os.pathsep+env['PATH']
checks=[('fmt',['cargo','fmt','--check']),('units',['cargo','test','--workspace','--release','--lib','--no-fail-fast']),('cli-errors-docs',['cargo','test','--workspace','--release','--test','pipe_mode','--test','error_paths','--test','doc_claims','--no-fail-fast']),('no-oracle',['cargo','test','--release','--test','golden_no_oracle','--','--nocapture']),('assisted',['cargo','test','--release','--test','golden_pairs','--','--nocapture']),('guards',['cargo','test','--release','--test','harness_guards','--','--nocapture']),('clippy',['cargo','clippy','--workspace','--release','--','-D','warnings']),('standing-perturbations',['cargo','test','--release','--test','parity_perturbations','--','--nocapture'])]
rows=[]
for name,cmd in checks:
    start=time.time()
    with (S/('gate-'+name+'.log')).open('wb') as stream:
        p=subprocess.run(cmd,cwd=S/'after-source',env=env,stdout=stream,stderr=subprocess.STDOUT)
    rows.append(dict(name=name,command=cmd,cwd=str(S/'after-source'),revision='154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc',exit=p.returncode,seconds=time.time()-start,environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','PLANTUML_STDLIB','RUSTUML_DEBUG','PATH']},log='gate-'+name+'.log'))
    (S/'gates.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,p.returncode,flush=True)
