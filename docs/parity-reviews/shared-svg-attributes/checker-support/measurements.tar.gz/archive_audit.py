# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import gzip,hashlib,json,tarfile
from pathlib import Path
S=Path(__file__).parent; A=S/'docs/parity-reviews/shared-svg-attributes/maker-support'; out=S/'maker-extracted'; out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
results=[]
for row in json.loads((A/'archives.json').read_bytes()):
    archive=A/row['archive']; manifest=A/row['entry_manifest']
    assert sha(archive.read_bytes())==row['sha256']; assert sha(manifest.read_bytes())==row['entry_manifest_sha256']
    wanted=json.loads(gzip.decompress(manifest.read_bytes())); count=0; total=0
    with tarfile.open(archive) as t:
        for entry,expected in zip(t,wanted,strict=True):
            assert entry.isfile() and entry.name==expected['path']
            b=t.extractfile(entry).read(); assert len(b)==expected['bytes'] and sha(b)==expected['sha256'],entry.name
            total+=len(b); count+=1
            if row['archive'] in ['metadata.tar.gz','frozen-inputs.tar.gz','fresh-relay.tar.gz','logs.tar.gz']:
                p=out/entry.name; assert p.resolve().is_relative_to(out.resolve());p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    assert count==row['entries'] and total==row['uncompressed_bytes']
    results.append(dict(archive=row['archive'],entries=count,bytes=total,sha256=row['sha256'],verified=True));print(results[-1],flush=True)
(S/'archive-integrity.json').write_text(json.dumps(results,indent=2)+'\n');print('total',sum(r['entries'] for r in results))
