# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import concurrent.futures,hashlib,json,os,pathlib,subprocess
O=pathlib.Path(__file__).parent;R=pathlib.Path('/Users/marcelo/.t3/worktrees/rustuml/t3-5c023380');items=json.loads((O/'fresh64.json').read_text());env=dict(os.environ,RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')
def one(item):
 body=(R/item['source']).read_bytes();out=dict(source=item['source'],source_sha256=hashlib.sha256(body).hexdigest(),results={})
 for version in ['before','after']:
  out['results'][version]={}
  for mode,flags in [('model',['--ast','-pipe']),('ascii',['-ttxt','-pipe'])]:
   cmd=[str(O/(version+'-bin')/'rustuml'),*flags];p=subprocess.run(cmd,cwd=R,env=env,input=body,capture_output=True,timeout=60);out['results'][version][mode]=dict(command=cmd,cwd=str(R),exit=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode())
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(one,items))
(O/'fresh-model-and-ascii.json').write_text(json.dumps(rows,indent=2));print('fresh captures',len(rows))
