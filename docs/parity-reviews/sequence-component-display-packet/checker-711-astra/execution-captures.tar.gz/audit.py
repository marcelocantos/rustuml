# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections, hashlib, json, pathlib, subprocess
R=pathlib.Path('/Users/marcelo/.t3/worktrees/rustuml/t3-5c023380'); O=pathlib.Path(__file__).parent
B='672cd8f26e1d7c6725d8971e01ad7575defd8567'; A='711dbca7c5e29592395f0927881aabfc2517b217'; I='16b28fc6de23d3920150efe50cfad7d065985c1a'
def git(*a): return subprocess.check_output(['git',*a],cwd=R)
def tree(rev,*paths):
    return {line.split('\t')[1]:line.split()[2] for line in git('ls-tree','-r',rev,*paths).decode().splitlines()}
prior=tree(B,'docs/parity-reviews','test-diagrams/perturbations'); after=tree(A); imported=git('diff-tree','--no-commit-id','--name-only','-r',I).decode().splitlines()
result=dict(before=B,packet=A,prior_paths=len(prior),prior_changes=[p for p,blob in prior.items() if after.get(p)!=blob],imported_paths=len(imported),imported_changes=[p for p in imported if after.get(p)!=tree(I,p).get(p)],prior_blobs=prior,imported_blobs={p:tree(I,p).get(p) for p in imported})
assert len(prior)==8221 and len(imported)==103 and not result['prior_changes'] and not result['imported_changes'],result
mapping=json.loads(git('show',A+':docs/parity-reviews/sequence-component-display-packet/maker-results/implementation-map.json'))
accounts=[]
for item in mapping['accounts']:
    account=item['account_commit']; path='docs/parity-reviews/'+item['mechanism']+'/account.json'
    row=dict(item,account_blob=tree(account,path)[path],candidate_blob=after[path],implementations=[])
    for impl in item['implementation_commits']:
        row['implementations'].append(dict(commit=impl,earlier=subprocess.run(['git','merge-base','--is-ancestor',account,impl+'^'],cwd=R).returncode==0,message=git('show','-s','--format=%B',impl).decode(),account_unchanged=git('show',account+':'+path)==git('show',A+':'+path)))
    accounts.append(row)
result['chronology']=accounts
result['production_diff_paths']=git('diff','--name-only',B,A,'--','crates').decode().splitlines()
result['protected_diff_paths']=git('diff','--name-only',B,A,'--','bullseye.yaml','test-diagrams/no_oracle_baseline.txt','crates/rustuml-oracle').decode().splitlines()
(O/'preservation-and-chronology.json').write_text(json.dumps(result,indent=2))
manifest=json.loads(git('show',A+':docs/parity-reviews/sequence-component-display-packet/maker-results/all-inputs.json'))
(O/'all2083.json').write_text(json.dumps(manifest,indent=2))
hashes=[hashlib.sha256((R/x['source']).read_bytes() if (R/x['source']).exists() else git('show',A+':'+x['source'])).hexdigest() for x in manifest]
summary=dict(entries=len(manifest),unique_source_bytes=len(set(hashes)),duplicate_entries=len(hashes)-len(set(hashes)),cohorts=dict(collections.Counter(x['cohort'] for x in manifest)),source_hashes=hashes)
(O/'membership.json').write_text(json.dumps(summary,indent=2))
print({k:v for k,v in result.items() if k not in ['prior_blobs','imported_blobs','chronology']})
print({k:v for k,v in summary.items() if k!='source_hashes'})
