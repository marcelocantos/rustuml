# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
"""Check complete comment macro transformation against the precommitted inventory."""
from pathlib import Path
import json,re,subprocess,hashlib
S=Path(__file__).parent;R=Path.cwd()
exec((S/'inventory.py').read_text().split('rows=[]')[0])
def macros(s):
 out=[]
 for m in re.finditer(r'\b(format|write|writeln)!\s*\(',s):
  spans,end=args(s,m.end()-1);fi=0 if m[1]=='format' else 1
  a=[s[x:y].strip() for x,y in spans]
  if len(a)>fi:out.append((s[m.start():end],a,fi))
 return out
def compact(s):
 # Preserve string literal contents, discard only Rust inter-token whitespace.
 out=[];last=0
 for m in lex.finditer(s):
  out.append(re.sub(r'\s+','',s[last:m.start()]));out.append(m[0]);last=m.end()
 out.append(re.sub(r'\s+','',s[last:]));return ''.join(out)
rows=json.loads((S/'comment-routing-applied.json').read_text());seen=[]
for file in sorted({r['file'] for r in rows}):
 before=subprocess.check_output(['git','show','db8955411:'+file]).decode();after=(R/file).read_text();all_after=macros(after)
 old=[r for r in rows if r['file']==file]
 for row in old:
  _,aa,fi=macros(row['after'])[0]
  hit=[(m,a,f) for m,a,f in all_after if [compact(x) for x in a]==[compact(x) for x in aa]]
  expected=sum([compact(x) for x in macros(other['after'])[0][1]]==[compact(x) for x in aa] for other in old)
  assert len(hit)==expected,(file,row['line'],len(hit),expected)
  _,ba,bfi=macros(row['before'])[0];assert fi==bfi
  body=re.search(r'<!--([\s\S]*?)-->',ba[fi])[1];count=body.count('{}')
  assert aa[fi]==ba[fi].replace('<!--'+body+'-->','<!--{svg_comment}-->')
  assert aa[:fi]==ba[:fi] and aa[fi+1:-1]==ba[fi+1+count:]
  seen.append(dict(file=file,base_line=row['line'],outside_comment_template_identical=True,non_comment_arguments_identical=True,whole_body_routed=True))
assert len(seen)==45
changed=subprocess.check_output(['git','diff','--name-only','db8955411','--','crates']).decode().splitlines()
assert set(changed)=={r['file'] for r in rows}|{'crates/rustuml-render/src/svg.rs'}
assert not any('sequence' in p for p in changed)
result=dict(base='db8955411',comment_macros=seen,comment_sites=45,files=changed,scope='Only 45 comment producers, shared encoder/unit, visibility and two state fill attribute producers.',state_fill_sites=[dict(base_line=n,attribute='fill plus optional fill-opacity',producer='svg::fill_attributes',geometry_unchanged=True) for n in [7323,7403]],production_diff_sha256=hashlib.sha256(subprocess.check_output(['git','diff','db8955411','--','crates'])).hexdigest())
(S/'scope-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('45/45 complete comment macros preserve all outside template bytes and argument expressions; 9 owned files; no sequence')
