# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,os,concurrent.futures
from pathlib import Path
import replay_checker as m
S=Path(__file__).parent;env=dict(os.environ,RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',TZ='GMT+11:00',RAYON_NUM_THREADS='4')
rows=json.loads((S/'checker94-membership.json').read_text())+json.loads((S/'checker6-membership.json').read_text())
def run(row):
 d=S/'assisted'/row['id'];d.mkdir(parents=True,exist_ok=True)
 result=m.call([S/'assisted-probe',row['source_capture'],row['golden_capture']],row['cwd'],env,None,d,'svg')
 cmp=m.call([S/'probe','compare',row['golden_capture'],d/'svg.stdout'],row['cwd'],env,None,d,'compare')
 return dict(id=row['id'],svg=result,compare=cmp,reference_valid=row['membership']['reference_valid'],assisted_match=row['membership']['reference_valid'] and result['exit']==0 and cmp['exit']==0)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,rows))
(S/'fresh-assisted-diagnostics.json').write_text(json.dumps(results,indent=2)+'\n');print('assisted diagnostic only',sum(r['assisted_match'] for r in results),'/',sum(r['reference_valid'] for r in results),'errors',sum(r['svg']['exit']!=0 for r in results))
