# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,hashlib,base64,xml.etree.ElementTree as ET,importlib.util,concurrent.futures,subprocess
from pathlib import Path
S=Path(__file__).parent;R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-3f18003d');sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((S/'reference-results.json.gz').read_bytes())=='6c8113c452ca83e0958a84f4928c3a867af2a01f3dd2bf14b63e37a9ad0177c3'
assert sha((S/'reference-transport.json').read_bytes())=='d32eb146942f600569c8dbb7779c56549860feb3d839f380c9977651583dd120'
d=json.loads((S/'reference-results.json').read_bytes());manifest=json.loads((S/'manifest.json').read_bytes());assert len(d['results'])==len(manifest)==30
rows=[];classes=[]
for c,v in zip(manifest,d['results']):
 p=Path(c['source']);assert str(p)==v['source'];assert sha(p.read_bytes())==v['source_sha256']==v['stdin_sha256'];assert v['timezone']=='GMT+11:00' and v['env_overrides']=={} and not v['timed_out'];assert v['cwd']==d['environment']['worker']+'/new'
 f=S/'fresh-reference'/p.stem;f.mkdir(parents=True,exist_ok=True)
 for stream in ['stdout','stderr']:
  b=base64.b64decode(v[stream+'_base64']);assert sha(b)==v[stream+'_sha256'];(f/('java.'+stream)).write_bytes(b)
 (f/'command.json').write_text(json.dumps({k:x for k,x in v.items() if 'base64' not in k},indent=2)+'\n')
 root=ET.fromstring((f/'java.stdout').read_bytes());texts=[''.join(x.itertext()) for x in root.iter() if x.tag.endswith('}text')]
 helper=subprocess.run([S/'probe','compare',f/'java.stdout',f/'java.stdout'],capture_output=True)
 negative=helper.returncode==2 or any('Syntax Error' in t or 'java.lang.' in t or 'Welcome to PlantUML' in t for t in texts)
 cls=dict(name=p.stem,intended_validity=c['intended_validity'],observed='error_svg' if negative else 'valid_diagram',reference_valid=not negative,java_exit=v['exit_code'],helper_self_compare_exit=helper.returncode,stderr=(f/'java.stderr').read_text(),text=texts)
 classes.append(cls)
 row=dict(id='checker30/'+p.stem,membership=dict(c,reference_valid=not negative),source_capture=str(p),source_sha256=sha(p.read_bytes()),golden_capture=str(f/'java.stdout'),golden_sha256=sha((f/'java.stdout').read_bytes()),cwd=str(S/'new'))
 rows.append(row)
(S/'fresh-classification.json').write_text(json.dumps(classes,indent=2)+'\n');(S/'checker30-membership.json').write_text(json.dumps(rows,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('replay',S/'maker/replay.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.S=S;m.R=R
for phase in ['before','after']:
 def run(row):
  v=m.measure(row,phase);v['reference_valid']=row['membership']['reference_valid'];v['svg_match']=v['reference_valid'] and v['svg']['exit']==0 and v['compare']['exit']==0;return v
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,rows))
 (S/('checker30-'+phase+'.json')).write_text(json.dumps(results,indent=2)+'\n')
 print(phase,[(r['id'],r['svg_match'],r['svg']['exit']) for r in results],flush=True)
print('classification',[(x['name'],x['observed'],x['java_exit']) for x in classes])
