from pathlib import Path
import json,gzip,tarfile,hashlib,subprocess,urllib.request,re
S=Path(__file__).parent;R=Path.cwd();M=R/'docs/parity-reviews/shared-svg-corrective/maker-support';sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(n,x):(S/n).write_text(json.dumps(x,indent=2)+'\n')
records=[]
for row in json.loads((M/'archives.json').read_bytes()):
 p=M/row['archive'];assert sha(p.read_bytes())==row['sha256']; entries=json.loads(gzip.decompress((M/row['entry_manifest']).read_bytes()));lookup={x['path']:x for x in entries}
 with tarfile.open(p) as t:
  for member in t:
   if not member.isfile():continue
   b=t.extractfile(member).read(); e=lookup.pop(member.name);assert sha(b)==e['sha256']
  assert not lookup
 records.append(dict(archive=p.name,entries=len(entries),sha256=row['sha256'],verified=True));print('verified',p.name,flush=True)
 if p.name=='frozen-inputs.tar.gz':
  d=S/'frozen-inputs';d.mkdir(exist_ok=True)
  with tarfile.open(p) as t:t.extractall(d,filter='data')
dump('archive-integrity.json',records)
J=Path('/Users/marcelo/work/github.com/plantuml/plantuml');pin='71806a23780b04a5ccde2f8ceb5121edad5eb711';records=[]
for row in json.loads((M/'java-source-provenance.json').read_bytes())['files']:
 p=Path(row['path']);b=subprocess.check_output(['git','-C',str(J),'show',pin+':'+str(p.relative_to(J))]);assert sha(b)==row['sha256']==sha(p.read_bytes());records.append(dict(path=str(p),sha256=sha(b),matches_pin=True))
dump('java-source-audit.json',records)
jdk=json.loads((M/'jdk-comment-source-provenance.json').read_bytes());records=[];(S/'jdk-source').mkdir(exist_ok=True)
for row in jdk['new_sources']+jdk['retained_serializer_provenance']:
 b=urllib.request.urlopen(row['url']).read();assert sha(b)==row['sha256'];(S/'jdk-source'/row['url'].rsplit('/',1)[1]).write_bytes(b);records.append(dict(url=row['url'],sha256=sha(b),verified=True))
dump('jdk-source-audit.json',records)
records=[]
for account,commit,impl in [('doctype-account.json','4157ec70f','47dece176'),('comment-account.json','db8955411','346f6b3f6'),('state-fill-account.json','db8955411','346f6b3f6')]:
 p='docs/parity-reviews/shared-svg-corrective/'+account
 assert subprocess.run(['git','merge-base','--is-ancestor',commit,impl]).returncode==0
 b=subprocess.check_output(['git','show',commit+':'+p]);assert b==(R/p).read_bytes();records.append(dict(account=p,commit=subprocess.check_output(['git','rev-parse',commit]).decode().strip(),implementation=subprocess.check_output(['git','rev-parse',impl]).decode().strip(),unchanged_since_account=True))
old=subprocess.check_output(['git','ls-tree','-r','2ed88eb55','--','docs/parity-reviews','test-diagrams/perturbations']).decode().splitlines();new=dict(x.split('\t',1)[::-1] for x in subprocess.check_output(['git','ls-tree','-r','HEAD','--','docs/parity-reviews','test-diagrams/perturbations']).decode().splitlines());assert all(new.get(x.split('\t')[1])==x.split('\t')[0] for x in old)
dump('history-audit.json',dict(accounts=records,prior_files=len(old),all_prior_blobs_identical=True))
print('source and history audit complete',len(old),flush=True)
