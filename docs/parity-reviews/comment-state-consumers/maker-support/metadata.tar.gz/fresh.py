# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,gzip,base64
S=Path(__file__).parent;N=S/'new';N.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();old=S.parent/'rustuml-shared-svg-corrective-maker'
wrap=lambda x:'@startuml\n'+x+'\n@enduml\n'
cases={
'alias_class':wrap('class "**Juniper**" as J\nclass "Birch--" as B\nJ --> B'),
'alias_nested_class':wrap('package "Visible Grove" as G {\nclass "Visible Leaf" as L\n}\nclass Peer\nG.L --> Peer'),
'cluster_raw':wrap('package "Shelf<!--]]>--" {\nclass Seed\n}'),
'cluster_nested_alias':wrap('package "Outer Display" as O {\npackage "Inner Display" as I {\nclass Leaf\n}\n}'),
'alias_deployment':wrap('node "Visible Host" as H\nnode "Visible Disk" as D\nH --> D'),
'raw_deployment_links':wrap('node "Éclair--"\nnode "Peeré-"\n"Éclair--" --> "Peeré-"'),
'alias_usecase':wrap('actor "Visible Person" as P\nusecase "Visible Task" as T\nP --> T'),
'alias_component':wrap('component "Visible Unit" as U\ncomponent "Visible Peer" as V\nU --> V'),
'object_existing_links':wrap('object Oak\nobject Fir\nOak --> Fir'),
'activity_existing_links':wrap('(*) --> "Oak"\n"Oak" --> (*)'),
'state_named_transparent':wrap('skinparam stateBackgroundColor transparent\nstate Willow : detail'),
'state_named_unknown':wrap('skinparam stateBackgroundColor RebeccaPurple\nstate Aspen : detail'),
'state_composite_alpha':wrap('skinparam stateBackgroundColor #3456787f\nstate Grove {\nstate Leaf : detail\n}'),
'state_concurrent_alpha':wrap('skinparam stateBackgroundColor #34567801\nstate Grove {\nstate Leaf : detail\n--\nstate Twig : detail\n}'),
'state_choice_alpha':wrap('skinparam stateBackgroundColor #3456787f\nstate Pick <<choice>>\nstate Leaf\nPick --> Leaf'),
'state_history_names':wrap('state Grove {\n[*] --> [H*]\n[H*] --> Leaf\n}')}

rows=[]
for name,src in cases.items():
 p=N/(name+'.puml');assert not p.exists();p.write_bytes(src.encode());rows.append(dict(source=str(p),mechanism='shared-svg-comments' if not name.startswith('state_') else 'shared-svg-state-paint',axes=['comment runs/Unicode/symbols/consumer family' if not name.startswith('state_') else 'alpha endpoint/empty-description branch'],cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=False,intended_validity='intended_valid; independently classify returned SVG'))
(S/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n');resources=[dict(local_path=str(p),remote_relative_path='new/'+p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(N.glob('*.puml'))];request=json.loads((old/'request.json').read_bytes());request.update(manifest_path=str(S/'manifest.json'),manifest_sha256=sha((S/'manifest.json').read_bytes()),case_count=len(rows),resources=resources,case_contracts=[dict(source=x['source'],source_sha256=sha(Path(x['source']).read_bytes()),cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']) for x in rows]);(S/'request.json').write_text(json.dumps(request,indent=2)+'\n');files=[dict(local_path=x['local_path'],remote_relative_path=x['remote_relative_path'],sha256=x['sha256'],base64=base64.b64encode(Path(x['local_path']).read_bytes()).decode()) for x in resources];(S/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=request,manifest=rows,files=files)).encode(),mtime=0));print({p.name:sha(p.read_bytes()) for p in [S/'request.json',S/'manifest.json',S/'input-bundle.json.gz']})
