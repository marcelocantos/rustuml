# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,re,hashlib,xml.etree.ElementTree as ET,yaml,collections
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();M=S/'maker-archive';sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(name,x):(S/name).write_text(json.dumps(x,indent=2)+'\n')
def decoded(b):
 root=ET.fromstring(b)
 def visit(e):return [e.tag,sorted(e.attrib.items()),e.text,e.tail,[visit(c) for c in e]]
 return visit(root)
def model(b):
 def node(n):
  if isinstance(n,yaml.ScalarNode):return ('scalar',n.tag,n.value)
  if isinstance(n,yaml.SequenceNode):return ('sequence',n.tag,tuple(node(v) for v in n.value))
  if isinstance(n,yaml.MappingNode):return ('mapping',n.tag,tuple(sorted((node(k),node(v)) for k,v in n.value)))
  return None
 return node(yaml.compose(b))
rows=json.loads((S/'replay-membership.json').read_text());before=json.loads((S/'before-results.json').read_text());after=json.loads((S/'after-results.json').read_text());assert len(rows)==len(before)==len(after)==14827
summary={};changed=[];yaml_changes=[]
for row,b,a in zip(rows,before,after):
 assert row['id']==b['id']==a['id'];c=row['cohort'];s=summary.setdefault(c,dict(entries=0,valid=0,before_pass=0,after_pass=0,losses=[],gains=[],new_errors=[],new_panics=[],before_errors=0,after_errors=0,before_panics=0,after_panics=0,before_malformed=0,after_malformed=0))
 s['entries']+=1;s['valid']+=a['reference_valid'];s['before_pass']+=b['svg_match'];s['after_pass']+=a['svg_match']
 for phase,v in [('before',b),('after',a)]:s[phase+'_errors']+=v['svg']['exit']!=0;s[phase+'_panics']+=v['panic'];s[phase+'_malformed']+=bool(v['xml_error'])
 for flag,test in [('losses',b['svg_match'] and not a['svg_match']),('gains',not b['svg_match'] and a['svg_match']),('new_errors',b['svg']['exit']==0 and a['svg']['exit']!=0),('new_panics',not b['panic'] and a['panic'])]:
  if test:s[flag].append(row['id'])
 bd=S/'replay/before'/c/row['id'];ad=S/'replay/after'/c/row['id'];yb=(bd/'yaml.stdout').read_bytes();ya=(ad/'yaml.stdout').read_bytes()
 if yb!=ya:
  eq=model(yb)==model(ya);yaml_changes.append(dict(id=row['id'],semantic_equal=eq,before_sha256=sha(yb),after_sha256=sha(ya)))
 if b['svg']['stdout_sha256']!=a['svg']['stdout_sha256']:
  bs=(bd/'svg.stdout').read_bytes();as_=(ad/'svg.stdout').read_bytes();gs=Path(row['golden_capture']).read_bytes();comments=lambda x:[c.decode() for c in re.findall(rb'<!--(.*?)-->',x,re.S)]
  rec=dict(id=row['id'],cohort=c,before_pass=b['svg_match'],after_pass=a['svg_match'],valid=a['reference_valid'],comment_only=re.sub(rb'<!--.*?-->',b'',bs,flags=re.S)==re.sub(rb'<!--.*?-->',b'',as_,flags=re.S),comments_before=comments(bs),comments_after=comments(as_),comments_java=comments(gs),comments_match=comments(as_)==comments(gs))
  if c=='full-golden':rec['decoded_noncomment_equal']=decoded(bs)==decoded(as_)
  changed.append(rec)
checks=[]
for e in json.loads((M/'comparison-summary.json').read_text()):
 s=summary[e['cohort']]
 keys=['entries','valid','before_pass','after_pass','losses','gains','new_errors','new_panics','before_panics','after_panics']
 checks.append(dict(cohort=e['cohort'],differences={k:dict(expected=e[k],measured=s[k]) for k in keys if e[k]!=s[k]}))
gc=[r for r in changed if r['cohort']=='full-golden'];gsummary=dict(changed=len(gc),all_comment_only=all(r['comment_only'] for r in gc),decoded_equal=all(r['decoded_noncomment_equal'] for r in gc),exact_java_comment_lists=sum(r['comments_match'] for r in gc),remaining_comment_differences=[r['id'] for r in gc if not r['comments_match']],changed_passing=sum(r['after_pass'] for r in gc),changed_nonpassing=sum(not r['after_pass'] for r in gc))
assert len(gc)==194 and gsummary['exact_java_comment_lists']==188 and gsummary['all_comment_only'] and gsummary['decoded_equal']
dump('replay-summary.json',summary);dump('golden-194-decoded.json',gc);dump('all-changed-output-observations.json',changed);dump('golden-byte-validation.json',gsummary);dump('yaml-semantic-validation.json',dict(memberships=len(rows),byte_equal=len(rows)-len(yaml_changes),byte_changes=yaml_changes,all_semantically_equal=all(r['semantic_equal'] for r in yaml_changes)));dump('maker-measurement-comparison.json',checks)
# Compare library failure-name files byte-for-byte, separate from CLI truth.
failures=[]
for name,count in [('no_oracle_failure_names.txt',72),('golden_failure_names.txt',754)]:
 actual=(R/'test-diagrams'/name).read_bytes();expected=(M/('final-'+name)).read_bytes();(S/name).write_bytes(actual);failures.append(dict(name=name,lines=len(actual.splitlines()),expected_lines=count,byte_identical=actual==expected,sha256=sha(actual)))
dump('failure-set-validation.json',failures)
gates=[]
for g in json.loads((S/'gates.json').read_text()):
 text=(S/'logs'/(g['name']+'.log')).read_text();gates.append(g|dict(test_results=re.findall(r'^test result:.*',text,re.M),measurements=[l for l in text.splitlines() if any(s in l for s in ['golden_no_oracle:','golden pairs:','eligible pairs','XML corpus=','held-out perturbations','passed,','failed,'])]))
dump('gate-summary.json',gates)
print('goldens',gsummary);print('cohorts',sum(v['before_pass'] for k,v in summary.items() if k!='full-golden'),'->',sum(v['after_pass'] for k,v in summary.items() if k!='full-golden'),'/',sum(v['valid'] for k,v in summary.items() if k!='full-golden'));print('yaml',len(yaml_changes),'byte changes; semantic mismatches',sum(not r['semantic_equal'] for r in yaml_changes));print('maker differences',[r for r in checks if r['differences']]);print('failure files',failures)
