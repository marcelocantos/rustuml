import os,json,subprocess,hashlib,shutil,sys
from pathlib import Path
cache=Path(__file__).parent; root=Path.cwd(); label=sys.argv[1]; out=cache/label;out.mkdir(exist_ok=False)
env=dict(os.environ,CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='4',CARGO_TARGET_DIR=str(cache/('target-'+label)),PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib',RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100')
cmds=[('build',['cargo','build','--release','-p','rustuml','--bin','rustuml','-p','rustuml-oracle','--example','diff_one']),('units',['cargo','test','--release','--lib','-p','rustuml-parser','-p','rustuml-render']),('cli',['cargo','test','--release','-p','rustuml','--test','pipe_mode']),('main-tiers-and-guards',['cargo','test','--release','--no-fail-fast','-p','rustuml-oracle','--test','golden_no_oracle','--test','golden_pairs','--test','parity_perturbations','--test','harness_guards','--','--nocapture']),('fmt',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','-p','rustuml-parser','-p','rustuml-render','--','-D','warnings']),('clippy-render',['cargo','clippy','-p','rustuml-render','--no-deps','--','-D','warnings'])]
if label == "intermediate":
 cmds=[cmds[0],("main-tiers",["cargo","test","--release","--no-fail-fast","-p","rustuml-oracle","--test","golden_no_oracle","--test","golden_pairs","--","--nocapture"])]
records=[]
for name,argv in cmds:
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=argv,cwd=str(root),exit=r.returncode,revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()))
 (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n'); print(label,name,r.returncode,flush=True)
 if name=='build':
  assert r.returncode==0
  bins=out/'bin';bins.mkdir()
  for src,dst in [('rustuml','rustuml'),('examples/diff_one','diff_one')]:shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'release'/src,bins/dst)
  lib=list((Path(env['CARGO_TARGET_DIR'])/'release/deps').glob('librustuml_oracle-*.rlib'));assert len(lib)==1
  argv=['rustc','--edition=2024','docs/parity-reviews/sequence-dependency-closure/checker-support/compare_cli.rs','--extern','rustuml_oracle='+str(lib[0]),'-L','dependency='+str(lib[0].parent),'-o',str(bins/'compare_cli')]
  subprocess.run(argv,check=True)
  (out/'binding.json').write_text(json.dumps(dict(revision=records[0]['revision'],status=subprocess.check_output(['git','status','--porcelain'],text=True),binaries={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in bins.iterdir()},environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','RUSTUML_DEBUG']}),indent=2)+'\n')
