# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest()
# Account and implementation chain / immutable source provenance.
java=Path('/Users/marcelo/work/github.com/plantuml/plantuml');jrev='71806a23780b04a5ccde2f8ceb5121edad5eb711'
locations={
 'klimt/color/HColorSet.java':['75-155 parseColor/parseSimpleColor: strip optional #; transparent/background; short, full and RRGGBBAA'],
 'klimt/color/ColorTrieNode.java':['named CSS and seven Archimate palette entries'],
 'klimt/color/HColor.java':['70-80 toRGB/toSvg alpha role split'],
 'klimt/color/HColorSimple.java':['132-150 transparency; 211-214 opposite'],
 'klimt/awt/XColor.java':['105-117 uppercase RGB/RGBA; zero alpha black sentinel'],
 'klimt/drawing/svg/SvgGraphics.java':['514-539 fixColor; 657-734 text DOM attributes; 751-785 filter and US-ASCII transformer; 891-898 fillMe alpha/255 five decimals; 1164-1166 createComment'],
 'klimt/drawing/svg/DriverTextSvg.java':['89-97 early return transparent before background; 162-180 BACKCOLOR RGB and foreground toSvg'],
 'klimt/font/UFontImpl.java':['104-123 full definition quote substitution; additional SansSerif mapping explicitly deferred'],
 'klimt/creole/legacy/AtomText.java':['measurement and draw advance; 123-130 background-adjusted color'],
 'klimt/font/FontConfiguration.java':['349-355 automatic color resolution'],
 'klimt/color/HColorAutomagic.java':['40-41 background-dependent color'],
 'xml/XmlFactories.java':['25-34 default TransformerFactory'],
 'klimt/drawing/svg/UGraphicSvg.java':['writeToStream wraps TransformerException as IOException'],
 'UgDiagram.java':['75-104 exporter catches Throwable and emits crash diagram'],
}
proof=[]
for rel,claims in locations.items():
 path='src/main/java/net/sourceforge/plantuml/'+rel;b=subprocess.check_output(['git','-C',str(java),'show',jrev+':'+path]);assert b==(java/path).read_bytes();proof.append(dict(path=path,sha256=sha(b),claims=claims))
# Exact failure-name sets and broad standing denominator.
text=(S/'logs/gate-standing.log').read_text();failures=re.findall(r'^  (test-diagrams/perturbations/[^\n]+?\.puml):',text,re.M)
sources=list((R/'test-diagrams/perturbations').rglob('*.puml'));assert len(sources)==1966;assert len(failures)==len(set(failures))==1115
(S/'standing-failure-names.txt').write_text('\n'.join(sorted(failures))+'\n')
# Every actual fresh source is new, checking against all prior sources including duplicate cohorts.
old_hashes={sha(p.read_bytes()) for p in (R/'test-diagrams').rglob('*.puml')}
fresh=json.loads((S/'fresh-results.json').read_bytes());assert all(r['source_sha256'] not in old_hashes for r in fresh)
# Direct bounded serialization checks inspect emitted raw attributes, without pretending they prove URL grammar/whole diagrams.
attribute_observations=[]
for r in fresh:
 for phase in ['java','after']:
  b=(S/'fresh'/r['name']/(phase+'.svg')).read_bytes()
  raw=[]
  for m in re.finditer(rb'([\w:-]+)="([^"<>]*)"',b):
   if any(ch>127 for ch in m[2]) or b'\t' in m[2] or b'\r' in m[2] or b'\n' in m[2]:raw.append(dict(attribute=m[1].decode(),value=m[2].decode('utf-8','replace')))
  if raw:attribute_observations.append(dict(case=r['name'],phase=phase,raw_non_ascii_or_whitespace=raw))
# Raw stream checks for C0 classification, no inference from exit 0.
for r in fresh:
 if r['java_classification']=='SAXException crash SVG':
  d=S/'fresh'/r['name'];assert b'SAXException' in (d/'java.stderr').read_bytes();assert b'SAXException' in (d/'java.svg').read_bytes()
  assert r['after']['malformed'] and r['before']['malformed']
# Source and binary identity distinguish compilation evidence from product data.
production_changed=subprocess.check_output(['git','diff','--name-only','a33dccc8e','a2167f936','--','crates','Cargo.lock','Cargo.toml']).decode().splitlines();assert not production_changed
binary=[]
for phase,revision in [('before','b8905e296b8865e53f3c573abaebf4adb632d751'),('after','a33dccc8e94dc44b5bafdc756fc1b88c42823a7d')]:
 p=S/('target-'+phase)/'release/rustuml';binary.append(dict(phase=phase,production_revision=revision,path=str(p),sha256=sha(p.read_bytes()),bytes=p.stat().st_size,jobs=4))
result=dict(java_source_proof=proof,standing=dict(inputs=len(sources),passed=len(sources)-len(failures),failed=len(failures)),fresh_independence=dict(cases=len(fresh),all_sources_absent_from_prior_corpora=True),fresh_summary=dict(valid=sum(r['java_classification']=='valid diagram' for r in fresh),nonpositive=sum(r['java_classification']!='valid diagram' for r in fresh),before_pass=sum(r['before']['whole_pass'] for r in fresh),after_pass=sum(r['after']['whole_pass'] for r in fresh),losses=[r['name'] for r in fresh if r['before']['whole_pass'] and not r['after']['whole_pass']],new_errors=[r['name'] for r in fresh if r['before']['exit']==0 and r['after']['exit']!=0],new_panics=[r['name'] for r in fresh if not r['before']['panic'] and r['after']['panic']],malformed=[r['name'] for r in fresh if r['after']['malformed']],errors=[r['name'] for r in fresh if r['after']['exit']!=0],panics=[r['name'] for r in fresh if r['after']['panic']]),raw_attribute_residue=attribute_observations,binaries=binary,production_code_identical_at_evidence_tip=True,model='gpt-6-astra',effort='high',tool='T3 Code / Codex harness',review_branch=subprocess.check_output(['git','branch','--show-current']).decode().strip())
(S/'audit-completion.json').write_text(json.dumps(result,indent=2)+'\n');print(result['standing']);print(result['fresh_summary']);print('raw attribute residue',len(attribute_observations))
