# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import concurrent.futures,gzip,hashlib,io,json,tarfile
from pathlib import Path
S=Path(__file__).parent;D=Path.cwd()/'docs/parity-reviews/shared-svg-attributes/maker-support';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def archive(name,files):
 files=sorted(files);target=D/(name+'.tar.gz');entries=[]
 with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as t:
  for p in files:
   assert p.is_file() and not p.is_symlink();b=p.read_bytes();rel=str(p.relative_to(S));info=tarfile.TarInfo(rel);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b));entries.append(dict(path=rel,bytes=len(b),sha256=sha(b)))
 expected={e['path']:e for e in entries};seen=set()
 with tarfile.open(target,'r:gz') as t:
  for m in t:
   assert m.isfile() and m.name in expected;data=t.extractfile(m).read();assert sha(data)==expected[m.name]['sha256'];assert len(data)==expected[m.name]['bytes'];seen.add(m.name)
 assert seen==set(expected)
 manifest=D/(name+'.entries.json.gz');manifest.write_bytes(gzip.compress((json.dumps(entries,indent=2)+'\n').encode(),mtime=0))
 row=dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,entries=len(entries),uncompressed_bytes=sum(e['bytes'] for e in entries),entry_manifest=manifest.name,entry_manifest_sha256=sha(manifest.read_bytes()),readback_verified=True);print(name,row['entries'],row['bytes'],flush=True);return row
exclude={'before-rustuml','after-rustuml','probe'}
groups=[('metadata',[p for p in S.iterdir() if p.is_file() and p.name not in exclude]),('logs',list((S/'logs').rglob('*'))),('frozen-inputs',list((S/'frozen').rglob('*'))),('fresh-relay',[p for n in ['new','fresh-reference','jdk-source','java-source','xml-parser-source'] for p in (S/n).rglob('*')]),('registered-cli',list((S/'registered').rglob('*')))]+[('captures-'+n,list((S/'replay'/n).rglob('*'))) for n in ['before','after','initial-draft']]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(lambda pair:archive(pair[0],[p for p in pair[1] if p.is_file()]),groups))
(D/'archives.json').write_text(json.dumps(rows,indent=2)+'\n')
print('TOTAL',sum(r['bytes'] for r in rows),'entries',sum(r['entries'] for r in rows),flush=True)
