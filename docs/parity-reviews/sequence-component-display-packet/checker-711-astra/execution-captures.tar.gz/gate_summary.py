# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,pathlib,re,subprocess
R=pathlib.Path('/Users/marcelo/.t3/worktrees/rustuml/t3-5c023380');O=pathlib.Path(__file__).parent
s={}
for name,file in [('before','before-main-tiers.log'),('intermediate','intermediate-main-tiers.log'),('after','main-tiers-and-guards.log')]:
 log=(O/file).read_text(); p=re.search(r'golden_no_oracle: (\d+)/(\d+)',log);a=re.search(r'golden_pairs: (\d+) total, (\d+) passed, (\d+) failed, (\d+) skipped',log);q=re.search(r'^  sequence\s+(\d+)/(\d+)',log,re.M)
 s[name]=dict(product=[int(p[1]),int(p[2])],assisted=[int(a[2]),int(a[1])-int(a[4])],assisted_total=int(a[1]),assisted_skips=int(a[4]),sequence=[int(q[1]),int(q[2])],log=file)
log=(O/'main-tiers-and-guards.log').read_text();tail=log.split('held-out no-oracle perturbations diverged from Java:\n',1)[1];failures=re.findall(r'^  (test-diagrams/perturbations/.*?\.puml):',tail,re.M)
paths=subprocess.check_output(['git','ls-tree','-r','--name-only','711dbca7','test-diagrams/perturbations'],cwd=R).decode().splitlines();census=[p for p in paths if p.endswith('.puml')]
s['standing_before_new_registration']=dict(entries=len(census),failures=len(failures),passed=len(census)-len(failures),failure_sources=failures,cwd=str(R/'crates/rustuml-oracle'),not_cli=True)
s['units']=re.findall(r'test result:.*', (O/'units.log').read_text());s['cli']=re.findall(r'test result:.*',(O/'cli.log').read_text());s['ascii_unit_names']=[l for l in (O/'units.log').read_text().splitlines() if 'ascii::tests::' in l]
s['guards_before_new_registration']='4/6 green; evidence schema and high precision ratchet red; no baseline or allow-list edits'
s['format']='Owned three files pass; workspace class formatting fails'
s['clippy']='Parser dead code and 19 renderer findings; raw diagnostics preserved'
# Freeze exact source hashes from extracted local git archive.
golden_repo='/Users/marcelo/work/github.com/marcelocantos/rustuml/test-diagrams/golden';rev='9efdc12fb057bbfecb6a8e2d25d31ec1e5ead19a'
entries=subprocess.check_output(['git','-C',golden_repo,'ls-tree','-r',rev],text=True).splitlines();bad=[]
for line in entries:
 meta,path=line.split('\t');mode,typ,blob=meta.split();data=(R/'test-diagrams/golden'/path).read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if actual!=blob:bad.append(path)
assert not bad
(O/'golden-hydration.json').write_text(json.dumps(dict(revision=rev,source=golden_repo,method='git archive exact revision, tar extraction into existing missing submodule directory; no fetch and no Java generation',entries=len(entries),changed_files=bad,archive_sha256=hashlib.sha256((O/'golden.tar').read_bytes()).hexdigest(),setup='Golden directory initially empty. Hydrated before any tier ran; no green-from-missing-corpus claim.'),indent=2))
(O/'gates-summary.json').write_text(json.dumps(s,indent=2));print({k:v for k,v in s.items() if k not in ['standing_before_new_registration','ascii_unit_names']});print({k:v for k,v in s['standing_before_new_registration'].items() if k!='failure_sources'})
