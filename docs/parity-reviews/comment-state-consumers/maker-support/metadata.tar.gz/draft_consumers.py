# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import re,json
R=Path.cwd();S=Path(__file__).parent
# Class comment data only; existing relationship identity projection is shared.
p=R/'crates/rustuml-render/src/class.rs';s=p.read_text();s=s.replace('format!("class {}", entity.label)','format!("class {}", relationship_endpoint_name(diagram, &entity.id))')
for struct in ['LayoutPackageCluster','EmptyPackageLayout']:
 marker='struct '+struct+' {\n';assert marker in s;s=s.replace(marker,marker+'    // Root Quark name is recoverable; nested identity remains T14.23.\n    comment_name: Option<String>,\n',1)
s=s.replace('Some(LayoutPackageCluster {\n','Some(LayoutPackageCluster {\n                comment_name: pkg.parent.is_none().then(|| pkg.name.clone()),\n',1)
s=s.replace('Some(EmptyPackageLayout {\n','Some(EmptyPackageLayout {\n                comment_name: package.parent.is_none().then(|| package.name.clone()),\n',1)
s=s.replace('format!("cluster {}", &cluster.qualified_name)','format!("cluster {}", cluster.comment_name.as_deref().unwrap_or(&cluster.qualified_name))')
s=s.replace('format!("entity {}", &package.qualified_name)','format!("entity {}", package.comment_name.as_deref().unwrap_or(&package.qualified_name))')
# Oracle clusters lack raw identity fields. Recover only a unique root model match.
s=s.replace('format!("cluster {}", cluster.qualified_name)','format!("cluster {}", root_package_comment_name(diagram, &cluster.qualified_name))')
marker='fn relationship_endpoint_name';i=s.index(marker);s=s[:i]+'''// Cluster.drawU:309 uses Entity.getName, before SVG metadata translation.
// T14.23 owns nested/local identity and ambiguous translated-name recovery.
fn root_package_comment_name<'a>(diagram: &'a ClassDiagram, qualified: &'a str) -> &'a str {
    let mut roots = diagram.packages.iter().filter(|package| {
        package.parent.is_none() && translate_qualified_name(&package.name) == qualified
    });
    match (roots.next(), roots.next()) {
        (Some(package), None) => &package.name,
        _ => qualified,
    }
}

'''+s[i:];p.write_text(s)
# Deployment label/code reconstruction mirrors existing parser-derived ID rule;
# it is kept separate from metadata/path identifier production.
p=R/'crates/rustuml-render/src/deployment.rs';s=p.read_text();i=s.index('struct OracleRenderContext');s=s[:i]+'''// EntityImageDescription.drawU:289 / Cluster.drawU:309 use the local Quark
// name, not the display or metadata-translated name. T14.23 owns the
// remaining explicit-alias/derived-id ambiguity in DeploymentNode.
fn deployment_comment_name(node: &DeploymentNode) -> &str {
    if label_to_id(&node.label) == node.id {
        &node.label
    } else {
        &node.id
    }
}

fn deployment_comment_endpoint<'a>(diagram: &'a DeploymentDiagram, id: &'a str) -> &'a str {
    diagram.nodes.iter().find(|node| node.id == id)
        .map(deployment_comment_name).unwrap_or(id)
}

'''+s[i:]
s=s.replace('format!("cluster {}", node.label)','format!("cluster {}", deployment_comment_name(node))').replace('format!("entity {}", node.label)','format!("entity {}", deployment_comment_name(node))')
s=s.replace('fn render_connection(\n    svg: &mut SvgBuilder,','fn render_connection(\n    svg: &mut SvgBuilder,\n    diagram: &DeploymentDiagram,',1)
s=s.replace('render_connection(\n            &mut svg,','render_connection(\n            &mut svg,\n            diagram,',1)
a=s.index('    let (comment_from, comment_to) = if is_reverse {');b=s.index('    let prefix =',a)
s=s[:a]+'''    let from_comment = deployment_comment_endpoint(diagram, &conn.from);
    let to_comment = deployment_comment_endpoint(diagram, &conn.to);
    let (comment_from, comment_to) = if is_reverse {
        (to_comment, from_comment)
    } else {
        (from_comment, to_comment)
    };
'''+s[b:]
s=s.replace('format!("reverse link {} to {}", conn.to, conn.from)','format!("reverse link {} to {}", deployment_comment_endpoint(diagram, &conn.to), deployment_comment_endpoint(diagram, &conn.from))').replace('format!("link {} to {}", conn.from, conn.to)','format!("link {} to {}", deployment_comment_endpoint(diagram, &conn.from), deployment_comment_endpoint(diagram, &conn.to))');p.write_text(s)
# Add comments before existing linear activity element producers. Geometry untouched.
p=R/'crates/rustuml-render/src/activity.rs';s=p.read_text();sites=[]
for m in list(re.finditer(r'^fn (emit_legacy_v1_\w*edge(?:_numbered)?)\(',s,re.M))[::-1]:
 name=m[1];start=s.index('{',m.end())+1
 if 'start_edge' in name:body='format!("link start to {}", target)'
 elif 'end_edge' in name:
  arg='&from.label' if name=='emit_legacy_v1_up_end_edge' else 'from'
  body='format!("link {} to end", '+arg+')'
 elif name in ['emit_legacy_v1_action_edge','emit_legacy_v1_action_edge_numbered']:body='format!("link {} to {}", from, to)'
 elif name=='emit_legacy_v1_left_edge':body='format!("reverse link {} to {}", to.label, from.label)'
 elif name=='emit_legacy_v1_up_edge':body='format!("reverse link {} to {}", from.label, to.label)'
 else:body='format!("link {} to {}", from.label, to.label)'
 new='\n    // SvekEdge.drawU:837 emits Link.commentForSvg before the edge elements.\n    write!(out, "<!--{}-->", crate::svg::comment_text(&'+body+')).unwrap();'
 s=s[:start]+new+s[start:];sites.append(dict(function=name,comment_expression=body))
assert len(sites)==11;p.write_text(s);(S/'activity-new-producers.json').write_text(json.dumps(sites,indent=2)+'\n')
