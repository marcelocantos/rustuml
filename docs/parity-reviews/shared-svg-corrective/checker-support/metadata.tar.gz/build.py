from pathlib import Path
import subprocess,tarfile,io,os,json,time,shutil
S=Path(__file__).parent; R=Path.cwd(); rows=[]
for phase,rev in [('before','a33dccc8e94dc44b5bafdc756fc1b88c42823a7d'),('after','346f6b3f680895d3eb457041ed88ae224c583d95')]:
 d=S/('source-'+phase); d.mkdir(exist_ok=True)
 data=subprocess.check_output(['git','archive',rev])
 with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(d,filter='data')
 env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(S/('target-'+phase)))
 argv=['cargo','build','--release','--locked','-p','rustuml','-p','rustuml-oracle']; start=time.time()
 with (S/('build-'+phase+'.log')).open('wb') as f:q=subprocess.run(argv,cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(phase=phase,revision=rev,argv=argv,cwd=str(d),target=env['CARGO_TARGET_DIR'],jobs=4,exit=q.returncode,seconds=time.time()-start)); (S/'builds.json').write_text(json.dumps(rows,indent=2))
 if q.returncode:raise SystemExit(q.returncode)
 shutil.copy2(S/('target-'+phase)/'release/rustuml',S/(phase+'-rustuml'));print(phase,'built',flush=True)
