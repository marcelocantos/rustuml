# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,hashlib,base64,xml.etree.ElementTree as E
from pathlib import Path
S=Path(__file__).parent
classes=json.loads((S/'fresh-classification.json').read_bytes());(S/'fresh-classification-preliminary.json').write_bytes((S/'fresh-classification.json').read_bytes())
for c in classes:
 if c['name'] in ['html_url_math','display_raw_math']:
  c.update(observed='reference_dependency_failure' if c['name']=='html_url_math' else 'formula_and_reference_dependency_failure',reference_valid=False,classification_reason='Embedded Java math fallback images and stderr expose missing org.apache.batik.dom.GenericDOMImplementation; not a clean positive reference.'+(' Also invalid latex command nt.' if c['name']=='display_raw_math' else ''))
  root=E.fromstring((S/'fresh-reference'/c['name']/'java.stdout').read_bytes());c['embedded_svg_images']=[]
  for n in root.iter():
   url=n.get('{http://www.w3.org/1999/xlink}href','')
   if url.startswith('data:image/svg+xml;base64,'):c['embedded_svg_images'].append(base64.b64decode(url.split(',',1)[1]).decode())
 if c['name']=='display_forced_alignment':c['verdict_excluded']=True;c['classification_reason']='Explicit user exception: alignment effects recorded, never counted against maker.'
(S/'fresh-classification.json').write_text(json.dumps(classes,indent=2)+'\n')
index={c['name']:c for c in classes}
for phase in ['before','after']:
 p=S/('checker30-'+phase+'.json');v=json.loads(p.read_bytes());(S/('checker30-'+phase+'-preliminary.json')).write_bytes(p.read_bytes())
 for r in v:
  c=index[r['id'].split('/')[-1]];r['reference_valid']=c['reference_valid'];r['svg_match']=r['reference_valid'] and r['svg']['exit']==0 and r['compare']['exit']==0;r['observed_classification']=c['observed'];r['verdict_excluded']=c.get('verdict_excluded',False)
 p.write_text(json.dumps(v,indent=2)+'\n')
p=S/'checker30-membership.json';v=json.loads(p.read_bytes())
for r in v:r['membership']['reference_valid']=index[r['id'].split('/')[-1]]['reference_valid']
p.write_text(json.dumps(v,indent=2)+'\n')
print('30 entries, 26 clean positive; one positive alignment exception excluded from verdict. Intent unchanged for all four nonpositive outputs.')
