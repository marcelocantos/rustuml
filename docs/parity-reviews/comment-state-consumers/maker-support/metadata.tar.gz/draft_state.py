# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import re,json
R=Path.cwd();S=Path(__file__).parent
p=R/'crates/rustuml-render/src/activity.rs';s=p.read_text().replace('format!("link {} to end", from)','format!("link {} to end", &from.label)');p.write_text(s)
p=R/'crates/rustuml-render/src/creole.rs';s=p.read_text();assert s.count('fn is_resolvable_color(')==1;s=s.replace('fn is_resolvable_color(', 'pub(crate) fn is_resolvable_color(');p.write_text(s)
p=R/'crates/rustuml-render/src/state.rs';s=p.read_text();pos=s.index('fn resolve_state_paint(');s=s[:pos]+'''// EntityImageStateCommon.applyColor:122–135 -> ValueImpl.asColor:90–103
// resolves style BACK separately from stroke. HColorSet.getColorOrWhite uses
// the pinned palette; CSS4-only names are not accepted there.
fn resolve_state_fill_color(value: &str) -> String {
    let value = value.trim();
    if value.eq_ignore_ascii_case("none") {
        return "none".to_string();
    }
    if value.eq_ignore_ascii_case("automatic") {
        // T14.15 owns background-aware automatic selection; retain the
        // existing consumer behavior until that context is available.
        return crate::sequence::resolve_color(value);
    }
    if crate::creole::is_resolvable_color(value) {
        text_render::normalize_color(value)
    } else {
        "#FFFFFF".to_string()
    }
}

'''+s[pos:]
s=s.replace('|| crate::sequence::resolve_color(value),','|| resolve_state_fill_color(value),',1)
a=s.index('fn resolve_pseudo_state_color(');b=s.index('\nfn state_gradients',a);s=s[:a]+'''fn resolve_pseudo_state_color(value: &str) -> String {
    resolve_state_fill_color(value)
}
'''+s[b:]
a=s.index('fn state_gradient_fill(');b=s.index('\nfn emit_state_gradient_defs',a);chunk=s[a:b].replace('return crate::sequence::resolve_color(value);','return resolve_state_fill_color(value);');s=s[:a]+chunk+s[b:]
s=re.sub(r'(\.fill\s*\.as_deref\(\)\s*\.map\()crate::sequence::resolve_color(\))',r'\1resolve_state_fill_color\2',s)
s=re.sub(r'(\.and_then\(\|state\| state\.fill\.as_deref\(\)\)\s*\.map\()crate::sequence::resolve_color(\))',r'\1resolve_state_fill_color\2',s)
# Comment projection only: keep existing path IDs and layout endpoints.
pos=s.index('fn emit_autonomous_scope_entities(');s=s[:pos]+'''// StateDiagram.getHistorical/getDeepHistory:125–182 constructs these
// synthetic local Quark names. Keep this projection out of path/layout IDs.
fn state_comment_endpoint(endpoint: &str, is_source: bool) -> String {
    for (marker, name) in [("[H*]", "*deephistory*"), ("[H]", "*historical*")] {
        if let Some(scope) = endpoint.strip_prefix(marker) {
            return format!("{name}{}", scope.rsplit('.').next().unwrap_or(scope));
        }
    }
    autonomous_endpoint_svg_name(endpoint, is_source)
}

'''+s[pos:]
s=s.replace('format!(\n                    "reverse link {edge_from_name} to {edge_to_name}"\n                )','format!(\n                    "reverse link {} to {}", state_comment_endpoint(edge_from_name, true), state_comment_endpoint(edge_to_name, false)\n                )')
s=s.replace('format!("link {edge_from_name} to {edge_to_name}")','format!("link {} to {}", state_comment_endpoint(edge_from_name, true), state_comment_endpoint(edge_to_name, false))')
# Main consumer has already replaced root history names for path IDs. Resolve
# comments from its actual transition endpoints before that lossy projection.
a=s.index('            // HTML comment.',s.index('let STATE_FILL:'));b=s.index('\n            let link_id',a)
chunk=s[a:b].replace('edge_from_name, edge_to_name','state_comment_endpoint(if solved_reversed { &t.to } else { &t.from }, !solved_reversed), state_comment_endpoint(if solved_reversed { &t.from } else { &t.to }, solved_reversed)');s=s[:a]+chunk+s[b:]
p.write_text(s)
# Mechanically route variable fill fields only; preserve all other template
# bytes, positions and producer arguments. Fixed colors/none remain explicit.
exec((S/'inventory.py').read_text().split('rows=[]')[0])
s=p.read_text();production=s.split('#[cfg(test)]')[0];edits=[];records=[]
for m in re.finditer(r'\b(format|write|writeln)!\s*\(',production):
 spans,end=args(s,m.end()-1);fi=0 if m[1]=='format' else 1;aa=[s[a:b].strip() for a,b in spans]
 if len(aa)<=fi:continue
 fmt=aa[fi];raw=re.fullmatch(r'r(\#*)"([\s\S]*)"\1',fmt)
 if not raw:continue
 template=raw[2];fields=list(re.finditer(r'(?<!\{)\{([^{}]*)\}(?!\})',template));n=0;pos=[];named={}
 for k,arg in enumerate(aa[fi+1:],fi+1):
  v=re.match(r'^(\w+)\s*=\s*(?!=)([\s\S]*)',arg)
  if v:named[v[1]]=(k,v[2])
  else:pos.append(k)
 mapping={}
 for f in fields:
  key=f[1].split(':')[0]
  if not key:key=str(n);n+=1
  mapping[f.start()]=(key, pos[int(key)] if key.isdigit() else named.get(key,(None,None))[0])
 changes=[];extra=[]
 for attr in re.finditer(r'fill="(\{[^{}]+\}|\{\})"',template):
  start=attr.start(1);key,argidx=mapping[start]
  if not key.isdigit() and key.isupper() and key!='STATE_FILL':continue
  expression=aa[argidx] if key.isdigit() else named.get(key,(None,key))[1]
  esc=re.fullmatch(r'crate::svg::escape_attribute\(([\s\S]*)\)',expression)
  expression=esc[1] if esc else '&('+expression+')'
  value='crate::svg::fill_attributes('+expression+')'
  if key.isdigit():
   aa[argidx]=value;replacement=attr[1]
  else:
   # Add a distinct argument only when original field also serves stroke etc.
   other=template[:attr.start()]+template[attr.end():]
   if re.search(r'\{'+re.escape(key)+r'(?::[^}]*)?\}',other):
    field='state_fill_'+str(len(extra));extra.append(field+' = '+value);replacement='{'+field+'}'
   else:
    if argidx is None:extra.append(key+' = '+value)
    else:aa[argidx]=key+' = '+value
    replacement=attr[1]
  changes.append((attr.start(),attr.end(),replacement));records.append(dict(line=s[:m.start()].count('\n')+1,raw_value=expression,field=key))
 if not changes:continue
 for a,b,value in reversed(changes):template=template[:a]+value+template[b:]
 aa[fi]='r'+raw[1]+'"'+template+'"'+raw[1];aa+=extra
 new=m[1]+'!(\n'+',\n'.join(aa)+',\n)';edits.append((m.start(),end,new))
for a,b,new in reversed(edits):s=s[:a]+new+s[b:]
p.write_text(s);(S/'state-routing-applied.json').write_text(json.dumps(records,indent=2)+'\n');print('routed variable fill sites',len(records),'macros',len(edits))
