# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,re,collections
S=Path(__file__).parent;R=Path.cwd()
exec((S/'inventory.py').read_text().split('rows=[]')[0])
rows=json.loads((R/'docs/parity-reviews/shared-svg-corrective/comment-routing-list.json').read_bytes());group=collections.defaultdict(list);log=[]
for r in rows:group[r['file']].append(r)
for file,rs in group.items():
 s=(R/file).read_text();edits=[]
 for r in rs:
  macro=r['macro'];assert s[r['start']:r['end']]==macro
  m=re.match(r'(format|write|writeln)!\s*\(',macro);spans,end=args(macro,m.end()-1);fi=0 if m[1]=='format' else 1;arg=[macro[a:b].strip() for a,b in spans];body=r['body'];count=body.count('{}');assert not re.search(r'\{\d',body)
  inputs=[]
  for expr in arg[fi+1:fi+1+count]:
   esc=re.fullmatch(r'(?:crate::svg::escape_attribute|escape_xml|escape_text)\(([\s\S]*)\)',expr)
   inputs.append(esc[1] if esc else expr)
  inner='format!('+json.dumps(body)+(' , '+', '.join(inputs) if inputs else '')+')'
  value='crate::svg::comment_text(&'+inner+')'
  fmt=arg[fi].replace('<!--'+body+'-->','<!--{svg_comment}-->');assert fmt!=arg[fi]
  newargs=arg[:fi]+[fmt]+arg[fi+1+count:]+['svg_comment = '+value]
  new=m[1]+'!(\n'+',\n'.join(newargs)+',\n)';edits.append((r['start'],r['end'],new));log.append(dict(file=file,line=r['line'],before=macro,after=new,comment_inputs=inputs,java=r['java_emission']))
 for a,b,new in sorted(edits,reverse=True):s=s[:a]+new+s[b:]
 (R/file).write_text(s)
(S/'comment-routing-applied.json').write_text(json.dumps(log,indent=2)+'\n');print('routed',len(log))
