# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
p=Path('crates/rustuml-render/src/creole.rs');s=p.read_text();start=s.index('        "b" | "B" => walk_with(',s.index('fn handle_tag'));end=s.index('        "mono" =>',start)
s=s[:start]+'''        "b" | "B" => return walk_style_tag(chars, &["b", "B"], style, |s| s.bold = true, skip_underline, out),
        "i" | "I" => return walk_style_tag(chars, &["i", "I"], style, |s| s.italic = true, skip_underline, out),
        "u" | "U" => return walk_style_tag(chars, &["u", "U"], style, |s| s.underline = true, skip_underline, out),
        "w" | "W" => return walk_style_tag(chars, &["w", "W"], style, |s| s.wavy_underline = true, skip_underline, out),
        "s" | "S" | "del" | "DEL" | "strike" | "STRIKE" => return walk_style_tag(
            chars, &["s", "S", "del", "DEL", "strike", "STRIKE"], style,
            |s| s.line_through = true, skip_underline, out,
        ),
'''+s[end:]
a=s.index('        _ if tag.starts_with("back:")');b=s.index('        _ if tag.starts_with("img:")',a)
s=s[:a]+'''        _ if tag.starts_with("back:") || tag.starts_with("BACK:") => {
            let color = tag.split_once(':').map(|(_, c)| c.to_string()).unwrap_or_default();
            return walk_style_tag(chars, &["back", "BACK", "Back", "bAck", "baCk", "bacK", "BAck", "BacK", "BaCk", "bACk", "bAcK", "baCK", "BACk", "BAcK", "BaCK", "bACK"], style,
                |s| s.background = Some(color), skip_underline, out);
        }
'''+s[b:]
# Use a style-family closing predicate for case-insensitive BACKCOLOR instead of a case ladder.
s=s.replace('&["back", "BACK", "Back", "bAck", "baCk", "bacK", "BAck", "BacK", "BaCk", "bACk", "bAcK", "baCK", "BACk", "BAcK", "BaCK", "bACK"]','&["back"]')
at=s.index('/// Helper that pushes a style modification')
s=s[:at]+'''/// CommandCreoleBuilder orders the bounded style candidate before its EOL
/// alternative. CommandCreoleStyle.matchingSize returns captured body length,
/// unlike size/color commands, whose parameter groups determine eligibility.
fn walk_style_tag(
    chars: &mut std::iter::Peekable<std::str::Chars>,
    closing_names: &[&str],
    style: &Style,
    apply: impl FnOnce(&mut Style),
    skip_underline: bool,
    out: &mut Vec<Segment>,
) -> bool {
    let remaining: String = chars.clone().collect();
    let mut closed = None;
    let mut scan = remaining.char_indices().peekable();
    while let Some((offset, c)) = scan.next() {
        // StripeSimple.analyzeAndAdd applies CharHidder before matching. A
        // tilde pair hides its second character; escaped tildes hide only ~.
        if c == '~' || (c == '\\\\' && scan.peek().is_some_and(|(_, c)| *c == '~')) {
            scan.next();
            continue;
        }
        if c == '<' && let Some(rest) = remaining[offset..].strip_prefix("</")
            && let Some(end) = rest.find('>') {
            let name = &rest[..end];
            let matches = closing_names.contains(&name)
                || (closing_names == ["back"] && name.eq_ignore_ascii_case("back"));
            if matches {
                closed = Some((offset, offset + end + "</>".len()));
                break;
            }
        }
    }
    let (content_end, consumed) = match closed {
        Some((body, consumed)) if body > 0 => (body, consumed),
        _ if !remaining.is_empty() => (remaining.len(), remaining.len()),
        _ => return false,
    };
    for _ in remaining[..consumed].chars() {
        chars.next();
    }
    let mut nested = style.clone();
    apply(&mut nested);
    // StripeSimple flushes before a selected command and at the end of its
    // recursive body, even when the surrounding and nested styles coincide.
    out.push(Segment { text: String::new(), style: style.clone() });
    walk_segments(&remaining[..content_end], &nested, skip_underline, out);
    out.push(Segment { text: String::new(), style: style.clone() });
    true
}

'''+s[at:];p.write_text(s)
p=Path('crates/rustuml-parser/src/diagram/wbs.rs');s=p.read_text();at=s.index('/// A single node');s=s[:at]+'''/// Java IdeaShape: a boxed node or a text-only node.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum WbsShape {
    #[default]
    Box,
    None,
}

impl WbsShape {
    fn is_box(&self) -> bool {
        *self == Self::Box
    }
}

'''+s[at:];s=s.replace('    pub label: String,','''    pub label: String,
    /// Command shape, separate from literal label content. Old models omit it.
    #[serde(default, skip_serializing_if = "WbsShape::is_box")]
    pub shape: WbsShape,''');p.write_text(s)
p=Path('crates/rustuml-parser/src/parse/wbs.rs');s=p.read_text().replace('{WbsDiagram, WbsNode, WbsSide}','{WbsDiagram, WbsNode, WbsShape, WbsSide}');s=s.replace('''        let rest = trimmed[prefix_len..].trim_start();''','''        let prefix_rest = &trimmed[prefix_len..];
        // CommandWBSItemNew/Old capture SHAPE adjacent to the prefix, on
        // either side of the optional color token. Whitespace starts LABEL.
        let adjacent = !prefix_rest.starts_with(char::is_whitespace);
        let (mut shape, rest) = if let Some(rest) = prefix_rest.strip_prefix('_') {
            (WbsShape::None, rest)
        } else {
            (WbsShape::Box, prefix_rest)
        };
        let rest = rest.trim_start();''');s=s.replace('''        let label = after_color.trim().to_string();''','''        let after_shape = if adjacent && color.is_some() && shape == WbsShape::Box {
            if let Some(rest) = after_color.strip_prefix('_') {
                shape = WbsShape::None;
                rest
            } else {
                after_color
            }
        } else {
            after_color
        };
        let label = after_shape.trim().to_string();''');s=s.replace('''            label,
            color,''','''            label,
            shape,
            color,''');p.write_text(s)
