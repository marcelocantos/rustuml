# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,importlib.util,concurrent.futures,subprocess,hashlib,re,sys
S=Path(__file__).parent;R=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest()
spec=importlib.util.spec_from_file_location('replay',S/'metadata/replay.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.S=S;m.R=R
phase=sys.argv[1]
if not (S/'probe').exists():
 deps=S/'target-before/release/deps';args=['rustc','--edition=2024',str(S/'metadata/probe.rs'),'-L','dependency='+str(deps),'--extern','rustuml_oracle='+str(next(deps.glob('librustuml_oracle-*.rlib'))),'--extern','rustuml_parser='+str(next(deps.glob('librustuml_parser-*.rlib'))),'-o',str(S/'probe')];subprocess.run(args,check=True);(S/'probe-build.json').write_text(json.dumps(args))
cohorts=json.loads((S/'metadata/cohorts.json').read_bytes())+['corrective16','full-golden']
for cohort in cohorts:
 if (S/(cohort+'-'+phase+'.json')).exists(): continue
 rows=json.loads((S/'metadata'/(cohort+'-membership.json')).read_bytes())
 for row in rows:
  for field in ['source_capture','golden_capture','reference_source_capture']:
   if field in row:
    path=(R/'test-diagrams/perturbations/shared-svg-corrective'/(row['id'].split('/')[-1]+('.puml' if field=='source_capture' else '.svg'))) if cohort=='corrective16' else S/'frozen-inputs/frozen'/Path(row[field]).relative_to('/Users/marcelo/Library/Caches/rustuml-shared-svg-corrective-maker/frozen')
    assert path.exists(),path; row[field]=str(path)
  for field in ['source','golden']:assert sha(Path(row[field+'_capture']).read_bytes())==row[field+'_sha256']
  row['cwd']=re.sub(r'/Users/marcelo/\.t3/worktrees/rustuml/t3-[^/]+',str(R),row['cwd']);assert Path(row['cwd']).is_dir(),row['cwd']
 if phase=='before':(S/(cohort+'-membership.json')).write_text(json.dumps(rows,indent=2))
 def run(row):
  v=m.measure(row,phase)
  if cohort!='full-golden':
   v['helper_reference_valid']=v['reference_valid'];v['reference_valid']=row['membership']['reference_valid'];v['svg_match']=v['reference_valid'] and v['svg']['exit']==0 and v['compare']['exit']==0
  return v
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,rows))
 (S/(cohort+'-'+phase+'.json')).write_text(json.dumps(results,indent=2)+'\n')
 print(cohort,phase,len(rows),sum(x['reference_valid'] for x in results),sum(x['svg_match'] for x in results),sum(x['svg']['exit']!=0 for x in results),sum(x['panic'] for x in results),flush=True)
