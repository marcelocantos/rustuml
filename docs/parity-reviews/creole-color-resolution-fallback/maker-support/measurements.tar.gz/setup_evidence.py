# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import shutil
S=Path(__file__).parent;old=S.parent/'rustuml-creole-parameter-maker'
cohorts=['retained','maker18','sprites50','checker38','fresh15','fresh26','new15','delimiters4','focused2','checker30','supplement8','fresh12','checker28','fresh16','golden-regressions','checker36','fallback16']
for name in ['summarize.py','models.py','observations.py','standing_mapping.py','gates.py','unit-controls.py']:
 v=(old/name).read_text().replace(str(old),str(S)).replace("'checker28','fresh16'", "'checker28','fresh16','golden-regressions','checker36','fallback16'")
 if name=='summarize.py':v=v.replace("'4e2918c608c9845751c937088dd1a68631657316'", "'4e2918c608c9845751c937088dd1a68631657316','f6c84a6215e734955890f6058c309423cf228f1d'")
 (S/name).write_text(v)
# Exact baseline files from last candidate's verified broad diagnostics.
d=S/'baseline';d.mkdir(exist_ok=True)
for n in ['final-no_oracle_failure_names.txt','final-golden_failure_names.txt','baseline-diagnostics.json','golden-regression-summary.json']:shutil.copy2(old/n,d/n)
