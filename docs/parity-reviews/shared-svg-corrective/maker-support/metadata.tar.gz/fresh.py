# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,gzip,base64
S=Path(__file__).parent;N=S/'new';N.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();old=S.parent/'rustuml-shared-svg-maker'
wrap=lambda x:'@startuml\n'+x+'\n@enduml\n'
cases={
'comment_class_runs':wrap('class "Pine---Ridge-"'),
'comment_class_unicode':wrap('class "ÉΩ𐐷--Leaf-"'),
'comment_class_symbols':wrap('class "Oak & Fir--"'),
'comment_class_links':wrap('class "Fir--"\nclass "Ash-"\n"Fir--" --> "Ash-"'),
'comment_package':wrap('package "Grove--" {\nclass "Pine-"\n}'),
'comment_component':wrap('component "Node--Tail-"'),
'comment_deployment':wrap('node "Host--Tail-" {\ncomponent "Disk--"\n}'),
'comment_usecase':wrap('actor "Guide--"\nusecase "Case--Tail-"\n"Guide--" --> "Case--Tail-"'),
'comment_object_links':wrap('object "Obj--"\nobject "Peer-"\n"Obj--" --> "Peer-"'),
'comment_state_links':wrap('state "Stage--"\nstate "Pause-"\n"Stage--" --> "Pause-"'),
'comment_activity_legacy':wrap('(*) --> "Task--"\n"Task--" --> (*)'),
'comment_archimate':wrap('archimate #Business "Thing--Tail-" as Ledger'),
'state_alpha_empty':wrap('hide empty description\nskinparam stateBackgroundColor #2468ac01\nstate Cedar'),
'state_alpha_description':wrap('skinparam stateBackgroundColor #2468acfe\nstate Alder : branch'),
'state_alpha_zero':wrap('skinparam stateBackgroundColor #2468ac00\nstate Birch'),
'state_alpha_opaque':wrap('skinparam stateBackgroundColor #2468acff\nstate Willow')}
rows=[]
for name,src in cases.items():
 p=N/(name+'.puml');assert not p.exists();p.write_bytes(src.encode());rows.append(dict(source=str(p),mechanism='shared-svg-comments' if name.startswith('comment_') else 'shared-svg-state-paint',axes=['comment runs/Unicode/symbols/consumer family' if name.startswith('comment_') else 'alpha endpoint/empty-description branch'],cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=False,intended_validity='intended_valid; independently classify returned SVG'))
(S/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n');resources=[dict(local_path=str(p),remote_relative_path='new/'+p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(N.glob('*.puml'))];request=json.loads((old/'request.json').read_bytes());request.update(manifest_path=str(S/'manifest.json'),manifest_sha256=sha((S/'manifest.json').read_bytes()),case_count=len(rows),resources=resources,case_contracts=[dict(source=x['source'],source_sha256=sha(Path(x['source']).read_bytes()),cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']) for x in rows]);(S/'request.json').write_text(json.dumps(request,indent=2)+'\n');files=[dict(local_path=x['local_path'],remote_relative_path=x['remote_relative_path'],sha256=x['sha256'],base64=base64.b64encode(Path(x['local_path']).read_bytes()).decode()) for x in resources];(S/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=request,manifest=rows,files=files)).encode(),mtime=0));print({p.name:sha(p.read_bytes()) for p in [S/'request.json',S/'manifest.json',S/'input-bundle.json.gz']})
