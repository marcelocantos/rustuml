# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import base64,gzip,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
from replay import S,R,sha,dump,measure
req=json.loads((S/'remote-request.json').read_bytes());manifest=json.loads((S/'new-manifest.json').read_bytes());blob=(S/'reference-results.json.gz').read_bytes();assert sha(blob)=='221e9e974b5b2b622fa732e7f2f7449722bb535627d19cbd814553cad4c85d30'
raw=gzip.decompress(blob);assert raw==(S/'reference-results.json').read_bytes();b=json.loads(raw);env=b['environment'];transport=json.loads((S/'reference-transport.json').read_bytes());assert base64.b64decode(transport['data'],validate=True)==blob
assert env['request_sha256']==sha((S/'remote-request.json').read_bytes());assert env['manifest_sha256']==req['manifest_sha256']==sha((S/'new-manifest.json').read_bytes());assert env['jar_sha256']==req['jar_sha256'];assert env['headless']
assert b['resources']==req['resources']
for r in b['resources']:
 data=Path(r['local_path']).read_bytes();assert sha(data)==r['sha256'] and len(data)==r['bytes']
assert len(b['results'])==len(manifest)==23
assert {r['source'] for r in b['results']}=={r['source'] for r in manifest}
contracts={r['source']:r for r in req['case_contracts']};meta={r['source']:r for r in manifest};results=[]
for i,ref in enumerate(b['results']):
 row=meta[ref['source']];p=Path(row['source']);d=S/'fresh-references'/p.stem;d.mkdir(parents=True,exist_ok=True);contract=contracts[str(p)];assert sha(p.read_bytes())==ref['source_sha256']==contract['source_sha256']
 for mode,c in [('svg',ref),('source',ref['probe'])]:
  argv=[x.replace('<worker>',env['worker']) for x in contract['svg_argv' if mode=='svg' else 'probe_argv']];argv[0]=req['wrapper'];assert c['argv']==argv
  assert c['cwd']==env['worker']+'/new' and c['timezone']=='GMT+11:00' and c['env_overrides']=={}
  assert not c['timed_out']
  expected=[env['java'],'-Djava.awt.headless=true','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=AU','-Duser.timezone=GMT+11:00']
  if mode=='svg':expected+=['-jar',env['jar'],'-pipe','-tsvg']
  else:expected+=['--class-path',env['jar']+':'+env['worker'],env['worker']+'/SourceProbe.java',env['worker']+'/new/'+p.name,env['worker']+'/new']
  # Wrapper expands source-file mode with -cp; validate exact prefix and tail below.
  assert c['java_argv'][:len(expected[:6])]==expected[:6]
  if mode=='svg':assert c['java_argv']==expected
  else:
   assert c['java_argv'][6:] in [expected[6:],['-cp',env['jar']+':'+env['worker'],env['worker']+'/SourceProbe.java',env['worker']+'/new/'+p.name,env['worker']+'/new']]
  for stream in ['stdout','stderr']:
   data=base64.b64decode(c[stream+'_base64'],validate=True);assert sha(data)==c[stream+'_sha256'];(d/('java.'+mode+'.'+stream)).write_bytes(data)
 svg=(d/'java.svg.stdout').read_bytes();source=(d/'java.source.stdout').read_bytes();xml=None
 try:xml=ET.fromstring(svg);xml_valid=True
 except ET.ParseError:xml_valid=False
 q=subprocess.run([S/'probe','compare',d/'java.svg.stdout',d/'java.svg.stdout'],capture_output=True);(d/'classification.stdout').write_bytes(q.stdout);(d/'classification.stderr').write_bytes(q.stderr)
 observed_valid=ref['exit_code']==0 and xml_valid and xml.tag.endswith('svg') and q.returncode==0
 factory=None if xml is None else xml.attrib.get('data-diagram-type')
 classification=dict(intended=row['intended_validity'],observed_valid=observed_valid,svg_exit=ref['exit_code'],source_exit=ref['probe']['exit_code'],xml_valid=xml_valid,factory=factory,comparator_rejects_reference=q.returncode==2,reference_category='valid_class' if observed_valid else ('syntax_error' if ref['exit_code']==200 else 'welcome_after_empty_sub_truncation'),svg_empty=not svg,source_empty=not source,source_has_class=b'class ' in source,source_has_end=b'@enduml' in source)
 commands={k:v for k,v in ref.items() if 'base64' not in k and k!='probe'}|{'probe':{k:v for k,v in ref['probe'].items() if 'base64' not in k}}
 dump(d/'commands.json',commands);dump(d/'classification.json',classification)
 measured=measure(('fresh23',i,dict(row,source_sha256=sha(p.read_bytes()),golden=str(d/'java.svg.stdout'),golden_sha256=sha(svg),reference_source=str(d/'java.source.stdout'),reference_valid=observed_valid,cwd=str(p.parent))))
 classification['semantic_outcome_equal']=measured['phases']['after']['svg']['exit']!=0 if classification['reference_category']=='syntax_error' else measured['phases']['after'].get('exact_source_equal',False)
 measured['classification']=classification;dump(d/'classification.json',classification);results.append(measured)
 print(p.stem,classification,'before/after SVG',[measured['phases'][p]['svg_match'] for p in ['before','after']],'after exact',measured['phases']['after'].get('exact_source_equal'),flush=True)
 if observed_valid and not measured['phases']['after'].get('exact_source_equal'):
  print('JAVA SOURCE',source.decode(),'RUST SOURCE',(measured['phases']['after'].get('model') or {}).get('source'),flush=True)
dump(S/'fresh23-results.json',results)
summary=dict(total=len(results),valid=sum(r['classification']['observed_valid'] for r in results),svg_matches=sum(r['phases']['after']['svg_match'] for r in results),exact_valid_sources=sum(r['classification']['observed_valid'] and r['phases']['after'].get('exact_source_equal',False) for r in results),negative_rejected=sum(not r['classification']['observed_valid'] and r['phases']['after']['svg']['exit']!=0 for r in results),valid_failures=[Path(r['input']).stem for r in results if r['classification']['observed_valid'] and not r['phases']['after']['svg_match']],transport_hash=sha(blob),resources_verified=len(b['resources']),calls_verified=2*len(results))
dump(S/'fresh23-summary.json',summary);print(summary)
