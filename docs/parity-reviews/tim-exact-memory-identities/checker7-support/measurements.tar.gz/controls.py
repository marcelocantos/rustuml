# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,os,subprocess,hashlib,re
from pathlib import Path
from replay import S,R,call,dump,model
rows=json.loads((R/'docs/parity-reviews/tim-builtin-value-boundaries/checker5-support/controls.json').read_bytes());out=[]
env=dict(os.environ,RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',RAYON_NUM_THREADS='4',TZ='GMT+11:00',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')
collateral={r['membership']['source']:r for r in json.loads((S/'collateral-results.json').read_bytes())}
for row in rows:
 p=R/row['source']
 if 'argv' in row:
  result=dict(source=row['source'],phases={})
  for phase in ['before','after']:
   d=S/'controls'/p.stem/phase;d.mkdir(parents=True,exist_ok=True)
   q=call([S/('target-'+phase)/'release/rustuml',p],R,env,None,d,'svg');c=call([S/'probe','compare',p.with_suffix('.svg'),d/'svg.stdout'],R,env,None,d,'compare')
   result['phases'][phase]=dict(svg=q,compare=c,svg_match=q['exit']==c['exit']==0)
  out.append(result)
 else:out.append(collateral[row['source']])
dump(S/'controls.json',out)
# Keep unchanged original unit inputs in an independent private include directory.
units=json.loads((S/'ordinary-units-audit.json').read_bytes());unitrows=[]
for u in units:
 d=S/'original-units'/u['test'];d.mkdir(parents=True,exist_ok=True);(d/'input.puml').write_text(u['input'])
 if u['test']=='include_with_defines':(d/'defs.puml').write_text('!define AUTHOR Alice\n')
 result=dict(u,phases={})
 for phase in ['before','after']:
  dest=d/phase;dest.mkdir(exist_ok=True)
  q=call([S/('target-'+phase)/'release/rustuml','--yaml','-pipe'],d,env,u['input'].encode(),dest,'yaml')
  try:m=model((dest/'yaml.stdout').read_bytes())
  except (AttributeError,KeyError,TypeError,ValueError):m=None
  result['phases'][phase]=dict(yaml=q,model=m)
 dump(d/'result.json',result);unitrows.append(result)
dump(S/'original-units-results.json',unitrows)
# Original failed assertion run remains immutable; verify all five named failures.
old=Path('/Users/marcelo/Library/Caches/rustuml-tim7-maker/parser1.log').read_bytes()
(S/'logs'/'historical-parser1.log').write_bytes(old)
assert all(("preprocess::tests::"+u['test']).encode() in old for u in units)
# Filename actual CLI is a new standalone frozen input measurement.
p=R/'test-diagrams/golden/preprocessing/preproc_builtin_filename.puml';filename=[]
for phase in ['before','after']:
 d=S/'filename'/phase;d.mkdir(parents=True,exist_ok=True)
 q=call([S/('target-'+phase)/'release/rustuml','-pipe'],R,env,p.read_bytes(),d,'svg');c=call([S/'probe','compare',p.with_suffix('.svg'),d/'svg.stdout'],R,env,None,d,'compare')
 filename.append(dict(phase=phase,svg=q,comparison=c,svg_match=q['exit']==c['exit']==0))
dump(S/'filename-cli.json',filename)
print('controls',len(out),'units',len(unitrows),'filename',[r['svg_match'] for r in filename])
