# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections,hashlib,json,re,shutil,subprocess
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();D=R/'docs/parity-reviews/shared-svg-attributes/checker-support';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
fresh=json.loads((S/'fresh-results.json').read_bytes());audit=json.loads((S/'audit-completion.json').read_bytes());measure=json.loads((S/'verified-measurements.json').read_bytes())
identity=dict(task_id='thread:delegated-task:command%3Amcp%3A3e6fe12c-b445-432a-9536-14b1ab9096f8%3Adelegate-task%3A02b1a747-7512-424a-bf7a-dd53d71bb634',model='gpt-6-astra',effort='high',tool='T3 Code / Codex harness',independence='New checker with no implementation involvement. No child agents, worktrees or production edits. Native review branch prepared by T3.')
implementation='a33dccc8e94dc44b5bafdc756fc1b88c42823a7d';evidence='a2167f93695497e49b8ae71c4830bac96309023b';java='71806a23780b04a5ccde2f8ceb5121edad5eb711';base='b8905e296b8865e53f3c573abaebf4adb632d751'
# Persist every fresh pair including nonpositives. Each source is copied byte-exact.
perturbations=[]
for row in fresh:
 directory=R/'test-diagrams/perturbations'/row['mechanism']/'checker-independent-astra';directory.mkdir(parents=True,exist_ok=True)
 p=directory/(row['name']+'.puml');g=p.with_suffix('.svg');p.write_bytes((S/'new'/p.name).read_bytes());g.write_bytes((S/'fresh'/row['name']/'java.svg').read_bytes())
 assert sha(p.read_bytes())==row['source_sha256'] and sha(g.read_bytes())==row['java_sha256']
 perturbations.append(dict(source=str(p.relative_to(R)),golden=str(g.relative_to(R)),axes=row['axes'],result='pass' if row['after']['whole_pass'] else 'fail',java_classification=row['java_classification'],source_sha256=row['source_sha256'],golden_sha256=row['java_sha256'],before_pass=row['before']['whole_pass'],after_pass=row['after']['whole_pass'],malformed=row['after']['malformed'],process_exit=row['after']['exit'],panic=row['after']['panic']))
(S/'registered-fresh-pairs.json').write_text(json.dumps(perturbations,indent=2)+'\n')
common=dict(schema_version=1,reviewer=identity,account_commit='d48ed1e7033e5539568a59b63c3d3229d07972db',implementation_commit=implementation,evidence_revision=evidence,base_revision=base,java_revision=java,jar_sha256='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053',jdk='OpenJDK 21.0.5 Homebrew',commands=['CARGO_TARGET_DIR=<private>/target-before CARGO_BUILD_JOBS=4 cargo build --release --locked -p rustuml (base revision)','CARGO_TARGET_DIR=<private>/target-after CARGO_BUILD_JOBS=4 cargo build --release --locked -p rustuml -p rustuml-oracle (evidence tip, identical production sources)','uv run --no-project python replay.py (12550 goldens plus 2104 membership-preserved retained/maker observations; actual CLI SVG and YAML both phases)','uv run --no-project python fresh_measure.py (87 held-out actual CLI before/after; immutable Java relay)','uv run --no-project python gates.py (eight broad gates once, frozen candidate before registering checker cases)','reference --cwd /Users/marcelo/rustuml-reference/scratch/worker.L9dFp3l5/new --timezone GMT+11:00 -- -pipe -tsvg (parent existing runner only; Java argv derived, not process-traced)'],support='docs/parity-reviews/shared-svg-attributes/checker-support/',verdict='rejected',policy='Whole-output failures reject; bounded helper/attribute evidence is not acceptance. No combined correctness claim with concurrent sequence work.')
attr_findings=[
 'Independent pinned JDK source downloads match all five maker hashes. ToStream.writeAttrString/accumDefaultEscape and CharInfo implement the stated entities, LF/CR/TAB decimal references, US-ASCII decimal non-ASCII scalar references, and SAXException for XML-invalid characters. SvgGraphics.getTransformer selects us-ascii through XmlFactories. Source proof and hashes are retained.',
 'Scope audit: frozen 901-site/24-file routing list verified; 868 nonowned sites checked at the same macro dataflow and 33 owned sites reviewed in the complete four-file implementation diff. 534 changed nonowned macros preserve format templates and expressions after erasing only encoder wrappers/borrows; approved state placeholder exception preserves comment text. Outside-macro changes are serializer producer substitutions, formatting, and the approved unused helper removal. No sequence, geometry, parser/model, comparator, baseline, skip or allow-list edits. No repair pass or fixture-shaped logic found.',
 'Each of the 16 changed goldens decodes identically before/after including comments, processing instructions, attributes, text and element structure; 14 remain passing and 2 remain failing. No new double-escaping found. Fresh raw attributes contain no unencoded non-ASCII or LF/CR/TAB, but URL grammar means some intended values do not reach Java attributes.',
 'Fresh whole-output attribute/font cohort is 2→5/37 valid plus four SAXException crash references. Every failure is preserved. Font-only subset is separately recorded; URL branches in UrlBuilder.java:53-95 and creole.rs:1215-1246 differ: Rust removes brace tooltip unconditionally before splitting, while Java requires the matching regex/label separator. Escaping cannot repair this decoded model divergence.',
 'Valid comment_double_hyphen disproves universal XML well-formedness: class.rs:5487 writes <!--class Double--Tail---> verbatim; SvgGraphics.addComment creates a DOM Comment and OpenJDK ToStream.comment:2312-2333 inserts spaces for consecutive/trailing dashes. Rust is malformed before and after. The inventory of 45 comment sites and clean measured maker corpus is accurate but not a universal guarantee.',
 'href_c0 (U+0002) and raw_c0_{zero,one,escape} produce Java SAXException crash SVGs with matching stderr, despite exit0; Rust emits malformed XML before and after. These are new source hashes outside the three approved exceptions, not waivers.',
 'Sequence handoff correctly identifies four primary user-attribute emission groups and LF/CR/TAB/non-ASCII divergence; it is not a complete helper-call census. Warning polygon/style/textLength attributes and title text also call escape_xml; generated IDs are safe domain. No sequence code changed.',
 'T14.15/T14.16/T14.20 are absent in the evidence-tip bullseye.yaml; the exact requested target definitions were read from the T3 starting revision d10f91cc9db68775a55859513f9bae8892810dd9. No targets changed.'
]
color_findings=[
 'HColorSet.parseColor/parseSimpleColor, ColorTrieNode, HColor.toRGB/toSvg, XColor.toSvg and SvgGraphics.fillMe independently confirm 1/3/6/8 hex, optional #, CSS and seven Archimate names, uppercase RGB, alpha/255 five decimals, transparent/background sentinel and role-dependent BACKCOLOR RGB. Current normal production dependency graph is byte-identical; Cargo.lock adds seven nodes and exactly two rustuml dev edges.',
 'Fresh color cohort is 0→20/30 valid whole outputs. The ten scalar color controls plus nested restoration pass, including alpha01/80/ff and transparent/background behind text. Sixteen cross-family transparent-background cases show that not every consumer uses the shared model. No whole-output failure is waived.',
 'shape_alpha is a concrete unclosed color path: Java state rect has fill=#3579BD and fill-opacity=0.50196; Rust emits fill=#3579bd80 without opacity. state.rs:7323/7403 routes through escape_attribute only, bypassing color_with_opacity/fillMe semantics. This is pre-existing and mechanically unchanged by the approved routing, but rejects a cross-family color completion claim.',
 'automatic_000000 and automatic_ffffff remain failures. Source traces to AtomText.drawU → FontConfiguration.adjustColorForBackground → HColorAutomagic.getAppropriateColor; no fixed scalar alias can replace background context.',
 'Logical-family/alias metrics, gradient painting T14.18, base-style OR T14.19, crash propagation T14.20, warnings T14.12, stripes T14.13, plain/code T14.14, unconsumed lines T14.17 and sequence escaping remain explicit failures/dependencies. No production fixes or target rewrites are included.'
]
transparent_findings=[
 'DriverTextSvg.draw:94-97 returns before painting transparent foreground and before BACKCOLOR allocation. Rust write_text_element now checks alpha zero before filter/link/text emission; its caller retains measurement/advance. Source and shared unit tests support that narrow mechanism.',
 'Fresh zero-alpha text inside mixed L/.../R runs with a nested opaque BACKCOLOR matches whole Java output in nine families: activity, class, state, deployment, component, usecase, object, mindmap and WBS. All 16 references are valid; 0→9/16 whole passes.',
 'Seven held-out family outputs still fail: archimate, gantt, timing, salt, json, nwdiag, regex. In salt/json/nwdiag the product emits literal markup rather than shared Creole runs; for example transparent_salt includes the escaped <color:#3579bd00><back:#e73>Veil... text and width355 versus Java180. These are existing consumer-path gaps, not evidence that shared advance was lost. They still reject whole-output acceptance.',
 'Transparent BACKCOLOR with opaque text remains distinct from transparent foreground. All generated inputs and references, including failures, remain executable.'
]
font_findings=[
 'UFontImpl.getFamily(SVG):118-121 replaces each double quote with apostrophe before DOM serialization. font_family_attribute performs the same final operation; it does not change measurement.',
 'The 16-family fresh font subset passes 1→4/16. Quoted & and angle/non-ASCII names, nested apostrophe/double quotes, and padding are included. Salt/json are valid Java references but Rust process errors with empty stdout; these are not counted as malformed SVGs.',
 'family_component shows pre-serializer truncation: Java Quill\'\'Reed\'\' versus Rust Quill\'\'Reed\'. component.rs::canonical_font_family repeatedly trim_matches quotes before adding wrapping quotes, unlike Java retaining the definition. Deployment/object/gantt/mindmap/WBS retain ignored family/default or metric gaps. Final XML quote substitution alone cannot achieve the whole-family contract.'
]
xml_findings=[
 'Frozen candidate actual-CLI gate passes16/16: golden12550 inputs,12470 emitted,0 malformed,80 errors,0 panics; perturbation1966 inputs,1857 emitted,3 expected malformed,109 errors,32 panics. Exact 26 standard DOT DOCTYPE count passes. Source-hash exception list is exactly the approved three attr_link_c0 names owned by T14.20.',
 'Compiling the unchanged test source against a private scratch corpus proves both ratchet directions: an unlisted actual malformed class-comment output fails; replacing a listed C0 source with a valid class fails both source hash and stale expected-malformed checks. Control passes and mutations are discarded.',
 'Independent stdout fault injection disproves the strict allow-DTD policy: prefix an XML comment containing the exact approved declaration, then an actual internal-entity DOCTYPE. svg.find("<!DOCTYPE") accepts the comment decoy and allow_dtd:true parses the unapproved DTD. Both the control and injected unchanged test exit0 with count26. This is an oracle acceptance bug, not an observed shipping attack path or a product parity count.',
 'roxmltree0.20 tokenizer parse_external_id discards identifiers and external parse_entity_def returns None; no network/filesystem resolver exists. No external DTD/entity was fetched or resolved. The demonstrated internal entity expands in-memory only.',
 'Fresh87 actual CLI exposes five unlisted malformed outputs (four C0, one valid comment case), all pre-existing; two empty-output process errors and zero panics. Registering these cases does not authorize extending the expected-failure list.'
]
def record(path,mechanism,selected,findings,account=None):
 pairs=[p for p,r in zip(perturbations,fresh) if selected(r)]
 v=common|dict(mechanism=mechanism,perturbations=pairs,findings=findings)
 if account:v['account_commit']=account
 v['measurements']=dict(inputs=len(pairs),valid=sum(p['java_classification']=='valid diagram' for p in pairs),before_pass=sum(p['before_pass'] for p in pairs),after_pass=sum(p['after_pass'] for p in pairs))
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p;p.write_text(json.dumps(v,indent=2)+'\n')
record('docs/parity-reviews/shared-svg-attributes/review.json','shared-svg-attributes',lambda r:r['mechanism']=='shared-svg-attributes',attr_findings)
record('docs/parity-reviews/shared-svg-color/review.json','shared-svg-color',lambda r:r['mechanism']=='shared-svg-color',color_findings)
record('docs/parity-reviews/shared-svg-color/transparent-text/review.json','transparent-text-emission',lambda r:r['mechanism']=='transparent-text-emission',transparent_findings,subprocess.check_output(['git','rev-parse','597f067cb']).decode().strip())
record('docs/parity-reviews/shared-svg-attributes/font-family/review.json','font-family-normalization',lambda r:r['name'].startswith('family_'),font_findings)
record('docs/parity-reviews/shared-svg-attributes/strict-xml/review.json','strict-xml-oracle',lambda r:r['after']['malformed'] is not None,xml_findings)
# Bounded/source findings are explicit and separate from rejected acceptance.
findings=dict(attribute_encoding=attr_findings,font_family=font_findings,color=color_findings,transparent_text=transparent_findings,strict_xml=xml_findings)
(S/'causal-findings.json').write_text(json.dumps(findings,indent=2)+'\n')
# Summary curated from fresh checks; raw streams and exact per-input commands go in archive.
for name in ['archive-integrity.json','source-audit.json','routing-audit.json','verified-measurements.json','audit-completion.json','xml-mutation-results.json','dtd-mutation-results.json','causal-findings.json','gates.json','replay-summary.json','registered-fresh-pairs.json','production-before.txt','production-after.txt','no_oracle_failure_names.txt','golden_failure_names.txt','standing-failure-names.txt']:
 shutil.copyfile(S/name,D/name)
print('records5, fresh pairs',len(perturbations))
