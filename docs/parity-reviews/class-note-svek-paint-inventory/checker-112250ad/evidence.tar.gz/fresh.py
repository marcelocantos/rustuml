# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import base64, gzip, hashlib, json
s=Path(__file__).resolve().parent; d=s/'fresh';d.mkdir(exist_ok=True); rows=[]
def add(name,body,mechanism,axes,valid=True):
 p=d/(name+'.puml');raw=('@startuml\n'+body+'\n@enduml\n').encode();p.write_bytes(raw)
 rows.append(dict(name=p.name,source=str(p),source_bytes=len(raw),source_sha256=hashlib.sha256(raw).hexdigest(),source_base64=base64.b64encode(raw).decode(),remote_name=p.name,mechanism=mechanism,axes=axes,expected_java_valid=valid,timezone='GMT+11:00'))
m='class-note-svek-paint-inventory';axes=['owner/declaration order','nested/empty group and native/description topology']
add('inventory_root_first','note "root memo" as Journal\nclass Zed\npackage Cove {\nnote "local memo" as Journal\nclass Zed\n}\nclass Tail',m,axes)
add('inventory_local_first','package Cove {\nclass Zed\nnote "local memo" as Journal\n}\nnote "root memo" as Journal\nclass Zed\nclass Tail',m,axes)
add('inventory_nested_empty','note "outer" as N\npackage Outer {\nclass Anchor\npackage Hollow {\n}\npackage Inner {\nnote "inner" as N\nclass Vessel\n}\nnote left of Anchor : local\n}',m,axes)
add('inventory_empty_native','class Anchor\npackage Hollow {\n}',m,axes)
add('inventory_two_empty_note','package LeftBox {\n}\nnote "root memo" as N\npackage RightBox {\n}',m,axes)
add('inventory_mixed','allowmixing\nactor Reader\nnote "outer" as N\npackage Cove {\nclass Page\nrectangle Index\nnote right of Page : check\n}',m,axes)
add('inventory_tim_repeat','!procedure $item($id)\nclass $id\nnote right of $id : memo\n!endprocedure\n$item("Zed")\n$item("Alpha")',m,['repeated evaluated source lines','creation order/renamed labels'])
add('inventory_group_note','package Cove {\nclass Anchor\n}\nnote right of Cove : extended group memo',m,['group attachment','label width'])
m='class-attached-note-consuming-url-grammar';axes=['quote/URL alternatives','body ownership/order/scoped target']
add('grammar_jaws_url','class Vessel\nnote left of Vessel [[\ue121manual path\ue121{read}]]\nreceipt\nend note',m,axes)
add('grammar_curly_brace','skinparam topurl https://example.org/base/\npackage Cove {\nclass Vessel\nnote right of ”Vessel“ [["manual path”{read me} label]] {\nclass this is body\n}\n}',m,axes)
add('grammar_single_null','class Vessel\nnote bottom of “Vessel" [[{tip {nested}}]] : receipt',m,axes)
add('grammar_tooltip_only','skinparam topurl https://example.org/base/\nclass Vessel\nnote top of Vessel [[{tip {nested}}]]\nreceipt\nend note',m,axes)
add('grammar_brackets_quoted','class Vessel\nnote right of Vessel [["manual]]page"{read}]]\nreceipt\nend note',m,axes)
add('grammar_url_followup','package Cove {\nclass Vessel\nnote left of “Vessel” [[manual{tip}]]\nfirst\nend note\n}\nurl Cove.Vessel [[https://example.org/entity]]\nnote right of Cove.Vessel [[file:/manual]] {\nsecond\n}',m,axes)
add('grammar_empty_target','class Vessel\nnote right of "" : bad',m,axes,False)
add('grammar_jaws_target','class Vessel\nnote right of \ue121Vessel\ue121 : bad',m,axes,False)
add('grammar_named_url','note "memo" as Journal [[manual]]',m,axes,False)
add('grammar_bad_empty_url','class Vessel\nnote right of Vessel [[“”]]\nbad\nend note',m,axes,False)
add('grammar_nbsp','class Vessel\nnote right of Vessel [[manual\u00a0label]]\nreceipt\nend note',m,['Pattern2 whitespace versus Rust Unicode whitespace','unquoted link/label'])
m='class-normalized-shadow-style-consumer';axes=['mapped/global/raw conversion','per-entity style/topology/paint extent']
for name,settings in [('note_yes','skinparam shadowing no\nskinparam noteShadowing yes'),('mapped_unit','skinparam actorShadowing -2.5px'),('mapped_yes','skinparam actorShadowing yes'),('global_no','skinparam shadowing no')]:
 add('shadow_'+name,'allowmixing\n'+settings+'\nactor Pilot\nclass Vessel\nPilot --> Vessel\nnote right of Vessel : memo',m,axes)
add('shadow_stereo','skinparam shadowing -2.5px\nskinparam classShadowing<<quiet>> false\nclass Vessel <<quiet>>\nclass Cargo\nVessel --> Cargo',m,axes)
add('shadow_order','class Vessel\nskinparam shadowing -2.5px\nclass Cargo\nVessel --> Cargo',m,axes)
add('shadow_raw_bool','<style>\nclass {\nShadowing false\n}\n</style>\nclass Vessel\nclass Cargo\nVessel --> Cargo',m,axes)
add('shadow_boundary','allowmixing\nskinparam shadowing -2.5px\nboundary Gate\nclass Vessel\nGate --> Vessel',m,axes)
add('shadow_degenerate','skinparam shadowing -2.5px\nclass Vessel',m,axes)
add('shadow_empty_group','skinparam shadowing -2.5px\nclass Vessel\npackage Hollow {\n}',m,axes)
add('shadow_invalid_digits','skinparam shadowing 1.2.3\nclass Vessel\nclass Cargo\nVessel --> Cargo',m,['ValueImpl malformed extracted double','native nondegenerate topology'],False)
manifest=dict(batch='checker-packet8-112250ad',candidate='68ab512be964e243ae1943f7a9fefd3537091401',java_revision='71806a23780b04a5ccde2f8ceb5121edad5eb711',jar_sha256='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053',wrapper_argv=['/Users/marcelo/rustuml-reference/bin/reference','--cwd','PRIVATE_CWD','--timezone','GMT+11:00','--','-pipe','-tsvg'],timezone='GMT+11:00',resources=[],inputs=rows)
raw=(json.dumps(manifest,indent=2)+'\n').encode();(s/'fresh-manifest.json').write_bytes(raw);blob=gzip.compress(raw,mtime=0);(s/'fresh-inputs.json.gz').write_bytes(blob);(s/'fresh-transport.json').write_text(json.dumps(dict(sha256=hashlib.sha256(blob).hexdigest(),data=base64.b64encode(blob).decode()))+'\n')
print('cases',len(rows),'manifest sha256',hashlib.sha256(raw).hexdigest(),'gzip sha256',hashlib.sha256(blob).hexdigest())
