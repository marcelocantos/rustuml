from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/class.rs');s=p.read_text();i=s.rfind('\n}')
s=s[:i]+r'''

    #[test]
    fn attached_note_pattern2_target_and_url_share_consuming_grammar() {
        for (left, right) in [('"', '"'), ('“', '”'), ('”', '"')] {
            for (body, has_url) in [(" : memo", false), ("\nmemo\nend note", true), (" {\nmemo\n}", true)] {
                let d = parse(&format!("skinparam topurl https://example.org/\npackage Bay {{\nclass Dock\nnote right of {left}Dock{right} [[{left}local docs{right}{{read}}]]{body}\n}}"));
                assert_eq!(d.entities.len(), 1);
                assert_eq!(d.notes.len(), 1);
                let note = &d.notes[0];
                assert_eq!(note.target.as_deref(), Some("Bay.Dock"));
                assert_eq!(note.owner_package.as_deref(), Some("Bay"));
                assert_eq!(note.lines, ["memo"]);
                assert_eq!(note.url.as_deref(), has_url.then_some("https://example.org/local docs"));
                assert_eq!(note.url_tooltip.as_deref(), has_url.then_some("read"));
                assert!(matches!(d.uid_events.last(), Some(ClassUidEvent::Note(0))));
            }
        }
    }

    #[test]
    fn attached_url_validation_precedes_single_line_null_url_semantics() {
        for command in [
            "note right of Dock [[“”]] : memo",
            "note right of “Dock : memo",
            "note right of \u{e121}Dock\u{e121} : memo",
            "note \"memo\" as Archive [[docs]]",
        ] {
            let input = format!("class Dock\n{command}");
            let lines = input.lines().map(str::to_string).collect::<Vec<_>>();
            assert!(parse_class(&lines).is_err(), "{input}");
        }
    }
''' +s[i:];p.write_text(s)
p=Path('crates/rustuml-render/src/class.rs');s=p.read_text();i=s.rfind('\n}')
s=s[:i]+r'''

    #[test]
    fn svek_note_paint_owner_order_is_independent_of_uid_allocation() {
        let input = "@startuml\nnote \"root\" as Ledger\npackage Bay {\nclass Dock\nnote \"local\" as Ledger\n}\n@enduml";
        let rustuml_parser::diagram::Diagram::Class(d) = rustuml_parser::parse::parse(input).unwrap() else { panic!("class"); };
        let ids = svek_id_allocation(&d);
        assert_eq!(ids.note_ids[0].as_deref(), Some("ent0002"));
        assert_eq!(ids.note_ids[1].as_deref(), Some("ent0005"));
        assert_eq!(svek_node_emission_order(&d), [SvekNodeEmission::Entity(0), SvekNodeEmission::Note(1), SvekNodeEmission::Note(0)]);
        let svg = render(&d, &Theme::default());
        assert!(svg.find("id=\"entity_Bay.Ledger\"").unwrap() < svg.find("id=\"entity_Ledger\"").unwrap());
    }

    #[test]
    fn empty_group_prevents_notes_only_degenerated_image() {
        let input = "@startuml\nset namespaceSeparator none\nnote \"memo\" as Ledger\npackage Bay {\nurl Ledger [[docs]]\n}\n@enduml";
        let rustuml_parser::diagram::Diagram::Class(d) = rustuml_parser::parse::parse(input).unwrap() else { panic!("class"); };
        assert_eq!(d.packages.len(), 1);
        let svg = render(&d, &Theme::default());
        assert!(svg.contains("id=\"entity_Bay\""), "{svg}");
        assert!(svg.contains("id=\"entity_Ledger\""), "{svg}");
        assert!(svg.contains("xlink:href=\"docs\""), "{svg}");
    }

    #[test]
    fn normalized_shadow_declarations_preserve_mapping_path_and_native_value() {
        for (key, value, actor, native) in [
            ("actorShadowing", "yes", 1.5, 0.0),
            ("actorShadowing", "no", 1.5, 0.0),
            ("actorShadowing", "true", 3.0, 0.0),
            ("shadowing", "yes", 3.0, 3.0),
            ("shadowing", "-1.25", 1.25, 1.25),
        ] {
            let input = format!("@startuml\nallowmixing\nskinparam {key} {value}\nactor Reader\nclass Ledger\nReader --> Ledger\n@enduml");
            let rustuml_parser::diagram::Diagram::Class(d) = rustuml_parser::parse::parse(&input).unwrap() else { panic!("class"); };
            let a = ClassFontOverrides::from_diagram_for_entity(&d, &d.entities[0]);
            let c = ClassFontOverrides::from_diagram_for_entity(&d, &d.entities[1]);
            assert_eq!(a.description.unwrap().shadow, actor, "{input}");
            assert_eq!(c.shadow, native, "{input}");
            let svg = render(&d, &Theme::default());
            let class_svg = svg.split("id=\"entity_Ledger\"").nth(1).unwrap().split("</g>").next().unwrap();
            assert_eq!(class_svg.contains("filter=\"url("), native > 0.0, "{input}");
        }
    }
''' +s[i:];p.write_text(s)
