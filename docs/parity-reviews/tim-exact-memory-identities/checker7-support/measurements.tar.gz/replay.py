# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
"""Independent two-binary replay of frozen membership; never calls Java."""
import concurrent.futures, hashlib, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
import yaml
R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-c0d7c6ac'); S=Path('/Users/marcelo/Library/Caches/rustuml-tim7-checker'); M=Path('/Users/marcelo/Library/Caches/rustuml-tim7-maker'); P=Path('/Users/marcelo/Library/Caches/rustuml-review-4a288dd-checker6')
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def resolve(p):
 p=re.sub(r'/Users/marcelo/\.t3/worktrees/rustuml/t3-[^/]+',str(R),str(p));return R/Path(p)
def model(data):
 node=yaml.compose(data);root={k.value:v for k,v in node.value}; d={k.value:v for k,v in root['diagram'].value};meta={k.value:v for k,v in d['meta'].value}
 return dict(type=root['type'].value,entities=len(d['entities'].value) if 'entities' in d else None,source=meta['source'].value)
def call(argv,cwd,env,data,d,prefix):
 start=time.monotonic()
 try:q=subprocess.run(list(map(str,argv)),input=data,cwd=cwd,env=env,capture_output=True,timeout=90);code=q.returncode;out=q.stdout;err=q.stderr
 except subprocess.TimeoutExpired as e:code=124;out=e.stdout or b'';err=e.stderr or b''
 (d/(prefix+'.stdout')).write_bytes(out);(d/(prefix+'.stderr')).write_bytes(err)
 return dict(argv=list(map(str,argv)),cwd=str(cwd),exit=code,stdout_sha256=sha(out),stderr_sha256=sha(err),seconds=time.monotonic()-start)
def measure(job):
 suite,index,row=job;p=resolve(row['source']);g=resolve(row.get('golden',p.with_suffix('.svg')));data=p.read_bytes();gold=g.read_bytes()
 assert sha(data)==row['source_sha256'],str(p)
 assert sha(gold)==row['golden_sha256'],str(g)
 base=S/'replay'/suite/f'{index:04}-{p.stem}';base.mkdir(parents=True,exist_ok=True)
 (base/'input.puml').write_bytes(data);(base/'java.svg').write_bytes(gold)
 ref=None
 if 'reference_source' in row:ref=resolve(row['reference_source']).read_bytes();(base/'java.source').write_bytes(ref)
 env_overrides=dict(RUSTUML_DEBUG=row.get('debug','date=1774210426000,tz=AEDT+1100'),TZ=row.get('zone','GMT+11:00'),RAYON_NUM_THREADS='4',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')|row.get('env',{})
 env=dict(os.environ,**env_overrides);cwd=resolve(row.get('cwd','.'));phases={}
 for phase in ['before','after']:
  d=base/phase;d.mkdir(exist_ok=True);binary=S/('target-'+phase)/'release/rustuml'
  svg=call([binary,'-pipe'],cwd,env,data,d,'svg');ym=call([binary,'--yaml','-pipe'],cwd,env,data,d,'yaml');cmp=call([S/'probe','compare',base/'java.svg',d/'svg.stdout'],R,env,None,d,'compare')
  z=dict(svg=svg,yaml=ym,compare=cmp,svg_match=bool(row['reference_valid'] and svg['exit']==0 and cmp['exit']==0),panic=b'panicked at' in (d/'svg.stderr').read_bytes())
  try:
   z['model']=model((d/'yaml.stdout').read_bytes());src=z['model']['source'].encode();(d/'rust.source').write_bytes(src)
   if ref is not None:z['exact_source_equal']=src==ref
  except (yaml.YAMLError,AttributeError,KeyError,ValueError,TypeError):z['model']=None
  phases[phase]=z
 result=dict(suite=suite,index=index,input=str(p),golden=str(g),membership=row,env_overrides=env_overrides,phases=phases)
 dump(base/'result.json',result);return result

def main():
 shutil.copyfile(M/'probe',S/'probe');(S/'probe').chmod(0o755)
 assert sha((S/'probe').read_bytes())=='43ce27167f6ad8697a8043edbb4f580ddbf9ab68b4e0ea4db15f2a69e3fc97b5'
 allrows=[]
 for suite in ['collateral','prior31','fresh29','maker15','maker17','maker18','fresh6','newmaker15','supplement2']:
  if suite in ['newmaker15','supplement2']:
   folder=M/('relay15-final2' if suite=='newmaker15' else 'relay2-final2');rows=json.loads((folder/'results.json').read_bytes())
   rows=[dict(r,golden=str(folder/Path(r['source']).stem/'java.svg.stdout'),reference_source=str(folder/Path(r['source']).stem/'java.source.stdout'),golden_sha256=sha((folder/Path(r['source']).stem/'java.svg.stdout').read_bytes()),cwd=str(Path(r['source']).parent)) for r in rows]
  else:rows=json.loads((P/(('fresh' if suite=='fresh6' else suite)+'-results.json')).read_bytes())
  rows=[{k:v for k,v in r.items() if k not in ['phases','measurements']} for r in rows]
  dump(S/'memberships'/(suite+'.json'),rows)
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:out=list(pool.map(measure,[(suite,i,r) for i,r in enumerate(rows)]))
  allrows.extend(out);dump(S/(suite+'-results.json'),out)
  summary=dict(total=len(out),valid=sum(r['membership']['reference_valid'] for r in out))
  for phase in ['before','after']:
   summary[phase]=dict(svg=sum(r['phases'][phase]['svg_match'] for r in out),source=sum(r['membership']['reference_valid'] and r['phases'][phase].get('exact_source_equal',False) for r in out),source_oracles=sum(r['membership']['reference_valid'] and 'reference_source' in r['membership'] for r in out),negative_rejected=sum(not r['membership']['reference_valid'] and r['phases'][phase]['svg']['exit']!=0 for r in out),panics=sum(r['phases'][phase]['panic'] for r in out))
  summary['lost_passes']=[r['input'] for r in out if r['phases']['before']['svg_match'] and not r['phases']['after']['svg_match']]
  summary['new_valid_errors']=[r['input'] for r in out if r['membership']['reference_valid'] and not r['phases']['before']['svg']['exit'] and r['phases']['after']['svg']['exit']]
  dump(S/(suite+'-summary.json'),summary);print(suite,json.dumps(summary),flush=True)
 dump(S/'all-replay-results.json',allrows)
if __name__=='__main__':main()
