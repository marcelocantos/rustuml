# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import concurrent.futures,hashlib,json,os,shutil,subprocess
s=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
for src,dest in [(s/'target-after/release/deps/rustuml-4174fc7f4edc50f2',s/'replay-rustuml'),(s/'target-after/release/rustuml',s/'post-gates-rustuml'),(s/'target-before/release/rustuml',s/'before-rustuml')]:shutil.copy2(src,dest)
rows=json.loads((s/'replay-historical.json').read_text())['results']+json.loads((s/'replay-fresh.json').read_text())['results'];out=s/'post-gates-cli';out.mkdir(exist_ok=True);env=dict(os.environ,PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib',RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100')
def one(item):
 i,r=item;result={'source':r['source'],'source_sha256':r['source_sha256'],'cohort':r['cohort']};cwd='/Users/marcelo/.t3/worktrees/rustuml/t3-cff2cd0e' if i<1851 else str(Path.cwd())
 for label,flag,ext in [('cli','-tsvg','svg'),('yaml','--yaml','yaml')]:
  cmd=[str(s/'post-gates-rustuml'),flag,r['source']];p=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,timeout=60);dest=out/f'{i:04d}-{Path(r["source"]).stem}.{ext}';dest.write_bytes(p.stdout);Path(str(dest)+'.stderr').write_bytes(p.stderr);result[label]={'command':cmd,'cwd':cwd,'exit':p.returncode,'sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'matches_independent_replay':(p.returncode,sha(p.stdout))==(r['after'][label]['exit'],r['after'][label]['sha256']),'capture':str(dest.relative_to(s))}
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:results=list(ex.map(one,enumerate(rows)))
report={'reason':'Cargo workspace CLI tests produced a second feature-unified executable for the same exact candidate after the independent standalone CLI replay. Preserve both actual binaries and verify the final executable outputs; no build, broad gate or reference generation is repeated.','binary_sha256':sha((s/'post-gates-rustuml').read_bytes()),'independent_replay_binary_sha256':sha((s/'replay-rustuml').read_bytes()),'before_binary_sha256':sha((s/'before-rustuml').read_bytes()),'environment':{k:env[k] for k in ['PLANTUML_STDLIB','RUSTUML_DEBUG']},'results':results,'differences':[r['source'] for r in results if not r['cli']['matches_independent_replay'] or not r['yaml']['matches_independent_replay']]};(s/'post-gates-binary-check.json').write_text(json.dumps(report,indent=2)+'\n');print('post-gate comparisons',len(results),'differences',len(report['differences']),flush=True)
