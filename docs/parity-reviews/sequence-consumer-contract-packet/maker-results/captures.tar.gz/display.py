from pathlib import Path
p=Path('crates/rustuml-render/src/sequence.rs');s=p.read_text()
# Replace duplicate text painters by a complete ordered Display painter.
a=s.index('    /// Write participant text label.');b=s.index('    /// Write a sequence message/arrow label.',a)
s=s[:a]+'''    /// AbstractTextualComponent receives Participant#getDisplay as one ordered
    /// text block. Each stripe uses its own ascent at the accumulated origin.
    fn participant_display(&mut self, display: &[(String, bool)], center_x: f64, top: f64) {
        let mut y = top;
        for (text, stereotype) in display {
            let block = ParticipantTextBlock::new(text, self.participant_font_size as f64,
                &self.participant_font_family, !stereotype && self.participant_font_bold);
            block.draw(&mut self.buf, &TextBase {
                x: center_x - block.width / 2.0,
                y: y + block.lines[0].2.ascent,
                font_size: self.participant_font_size,
                font_family: &self.participant_font_family,
                fill: if *stereotype { "#000000" } else { &self.participant_font_color },
                bold: !stereotype && self.participant_font_bold,
                italic: *stereotype || self.participant_font_italic,
                underline: false,
                skip_underline: false,
            });
            y += block.height;
        }
    }

'''+s[b:]
# Rectangle complete Display, retain component rect and text origin.
a=s.index('    fn participant_box(');b=s.index('    /// Open a participant group',a);t=s[a:b];t=t.replace('        text_x: f64,\n        text_y: f64,\n        text_content: &str,\n        text_len: f64,\n        stereotype: Option<(&str, f64)>, // (stereotype text, text width)\n','        text_top: f64,\n        display: &[(String, bool)],\n');i=t.index('        let line_h =');j=t.index('        self.participant_group_close();',i);t=t[:i]+'''        self.participant_display(display, rect_x + rect_w / 2.0, text_top);

'''+t[j:];s=s[:a]+t+s[b:]
# The five figure kinds compose Display and symbol in the same source order.
for name,height in [('actor','ACTOR_SYMBOL_HEIGHT + shadow_delta'),('boundary','CIRCLE_SYMBOL_HEIGHT'),('control','CIRCLE_SYMBOL_HEIGHT'),('entity','CIRCLE_SYMBOL_HEIGHT'),('database','DB_CYLINDER_HEIGHT')]:
 a=s.index('    fn '+name+'_shape(');b=s.index('    /// ',a);t=s[a:b];t=t.replace('        text_x: f64,\n        text_content: &str,\n        text_len: f64,','        display: &[(String, bool)],\n        display_height: f64,').replace('        stereo: Option<(&str, f64)>,\n        line_h: f64,\n','');i=t.index('        let is_tail =');j=t.index('        self.participant_text(',i);j=t.index('\n',j)+1;t=t[:i]+f'''        // ComponentRose{name.title()}#drawInternalU places the complete Display
        // before a legacy tail symbol and after a head symbol. MarginX1/2=3
        // participate in getTextWidth; the text block itself starts at -marginX1
        // relative to the symbol center (getTextMiddlePostion).
        let is_tail = position == "tail" && !teoz;
        let (text_top, figure_base) = if is_tail {{
            (base_y, base_y + display_height)
        }} else {{
            (base_y + {height}, base_y)
        }};
        self.participant_display(display, cx - ACTOR_TEXT_PAD, text_top);
'''+t[j:];s=s[:a]+t+s[b:]
# Collections is the same participant Display, with a stacked rectangle.
a=s.index('    fn collections_shape(');b=s.index('    /// Write a queue shape',a);t=s[a:b];t=t.replace('        text_x: f64,\n        text_y: f64,\n        text_content: &str,\n        text_len: f64,','        text_top: f64,\n        display: &[(String, bool)],\n        display_height: f64,').replace('        stereo: Option<(&str, f64)>,\n        line_h: f64,\n','');i=t.index('        // A boxed stereotype');j=t.index('        // Back rectangle',i);t=t[:i]+'''        // Rose#createComponentParticipant selects ComponentRoseParticipant
        // with collections=true: complete Display plus marginY7 twice.
        let rect_h = display_height + 2.0 * 7.0;

'''+t[j:];i=t.index('        // Stereotype line');j=t.index('        self.participant_group_close();',i);t=t[:i]+'''        self.participant_display(display, box_x + rect_w / 2.0, text_top);

'''+t[j:];s=s[:a]+t+s[b:]
# Queue uses the same painter as its sibling components.
a=s.index('        // USymbolQueue#asSmall translates');b=s.index('        self.participant_group_close();',a);s=s[:a]+'''        // USymbolQueue#asSmall translates the complete Display by its margin.
        let center = box_x + QUEUE_TEXT_X_PAD + (box_w - QUEUE_TEXT_H_PAD) / 2.0;
        self.participant_display(display, center, text_top);

'''+s[b:]
# Replace dispatch arguments, removing independently reconstructed stereotypes.
a=s.index('fn render_participant_shape(');b=s.index('/// Render a sequence diagram with',a);t=s[a:b];i=t.index('    // Participant#getDisplay');j=t.index('    match p.kind',i);t=t[:i]+t[j:];t=t.replace('            let text_x = p.center_x - (p.text_width + 2.0 * ACTOR_TEXT_PAD) / 2.0;\n','');t=t.replace('                        text_x,\n                        &p.label,\n                        p.text_width,','                        &p.display,\n                        p.display_height,');t=t.replace('                        stereo_ref,\n                        figure_line_h,\n','');t=t.replace('            let text_x = p.box_x + participant_inner_pad;\n','');t=t.replace('            let text_y = base_y + COLLECTIONS_OFFSET + p.text_y_offset;','            let text_top = base_y + COLLECTIONS_OFFSET + p.text_top_offset;');t=t.replace('                text_x,\n                text_y,\n                &p.label,\n                p.text_width,','                text_top,\n                &p.display,\n                p.display_height,');t=t.replace('                stereo_ref,\n                figure_line_h,\n','');i=t.index('        ParticipantKind::Participant => {');j=t.index('            svg.participant_box(',i);t=t[:i]+'''        ParticipantKind::Participant => {
            let text_top = base_y + p.text_top_offset;
'''+t[j:];t=t.replace('                &p.display,\n                p.display_height,\n                stereo_ref,','                &p.display,');t=t.replace('    participant_inner_pad: f64,','    _participant_inner_pad: f64,');s=s[:a]+t+s[b:]
# Data and dimensions: final filtered Display exists before any component.
s=s.replace('    /// Optional stereotype text\n    stereotype: Option<String>,\n','');s=s.replace('    /// Text width at the participant label font size.\n    text_width: f64,','    /// Complete filtered Display height, used by every component consumer.\n    display_height: f64,');s=s.replace('    /// Baseline offset from the participant box top for the label.\n    text_y_offset: f64,\n    /// Stereotype Display width in the resolved participant component font.\n    stereotype_width: f64,','    /// ComponentRoseParticipant marginY plus component padding.\n    text_top_offset: f64,');a=s.index('    /// True when this participant is enclosed');b=s.index('    in_box: bool,',a)+len('    in_box: bool,\n');s=s[:a]+s[b:]
a=s.index('    // Decl indices of participants enclosed');b=s.index('    let any_box_titled',a);s=s[:a]+s[b:]
s=s.replace('            let label_ascent = label_block.lines[0].2.ascent;\n','')
a=s.index('            // Participant#getDisplay composes the stereotype above');b=s.index('            ParticipantLayout {',a);s=s[:a]+'''            // DrawableSetInitializer#createParticipant passes Participant#getDisplay
            // to every component, irrespective of box membership. Participant and
            // queue already include the complete Display in their branches above.
            let bh = match p.kind {
                ParticipantKind::Participant | ParticipantKind::Queue => bh,
                _ => bh + stereotype_height,
            };

'''+s[b:];s=s.replace('                stereotype: st,\n','').replace('                text_width: tw,','                display_height: label_height + stereotype_height,').replace('                text_y_offset: label_ascent + 7.0 + global_padding,\n                stereotype_width: st_w,','                text_top_offset: 7.0 + global_padding,').replace('                in_box,\n','');p.write_text(s)
