# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import importlib.util,json,sys,concurrent.futures,hashlib,shutil
from pathlib import Path
S=Path(__file__).parent; M=S/'maker'; R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-3f18003d'); sha=lambda b:hashlib.sha256(b).hexdigest()
spec=importlib.util.spec_from_file_location('replay',M/'replay.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.S=S;m.R=R
phase=sys.argv[1]
for cohort in sys.argv[2:] or ['retained','maker18','sprites50','checker38','fresh15','fresh26','new15','delimiters4','focused2']:
 rows=json.loads((M/(cohort+'-membership.json')).read_bytes())
 for row in rows:
  for field in ['source_capture','golden_capture','reference_source_capture']:
   if field in row:
    path=Path(row[field]); mapped=M/path.relative_to('/Users/marcelo/Library/Caches/rustuml-style-wbs-maker')
    assert sha(mapped.read_bytes())==row[field.removesuffix('_capture')+'_sha256']
    row[field]=str(mapped)
  assert Path(row['cwd']).is_dir(),row['cwd']
 def run(row):
  v=m.measure(row,phase);valid=row['membership']['reference_valid'];v['helper_reference_valid']=v['reference_valid'];v['reference_valid']=valid;v['svg_match']=valid and v['svg']['exit']==0 and v['compare']['exit']==0;return v
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,rows))
 (S/(cohort+'-membership.json')).write_text(json.dumps(rows,indent=2)+'\n')
 (S/(cohort+'-'+phase+'.json')).write_text(json.dumps(results,indent=2)+'\n')
 print(cohort,phase,'entries',len(rows),'valid',sum(x['reference_valid'] for x in results),'pass',sum(x['svg_match'] for x in results),'panics',sum(x['panic'] for x in results),flush=True)
