# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import base64,collections,hashlib,json,pathlib,xml.etree.ElementTree as ET
O=pathlib.Path(__file__).parent;R=pathlib.Path('/Users/marcelo/.t3/worktrees/rustuml/t3-5c023380')
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((O/'relay-manifest.json').read_bytes()); bundle=json.loads((O/'reference-results.json').read_bytes());results=bundle['results']; env=bundle['environment']
assert sha((O/'relay-manifest.json').read_bytes())=='81508a66934ee73c4af590221071c9c1ecba69fc635aa2b0f6569feaffaf04e1'
assert sha((O/'reference-results.json.gz').read_bytes())=='faf2119c470cd6293b5e12fe0f13ce52f53d5c06e3a20cbf3572dbb541817ce9'
assert env['jar_sha256']==manifest['jar_sha256'] and env['java_revision']==manifest['java_revision']
assert [x['name'] for x in results]==[x['name'] for x in manifest['cases']]
rows=[]
for case,raw in zip(manifest['cases'],results):
    body=base64.b64decode(case['source_b64']);assert body==pathlib.Path(case['path']).read_bytes()
    assert sha(body)==case['source_sha256']==raw['source_sha256']==raw['stdin_sha256']
    assert len(body)==case['source_bytes']==raw['source_bytes']==raw['stdin_bytes']
    assert raw['path']==case['path'] and raw['provenance_source']==case['source']
    assert not raw['timed_out'] and raw['timezone']=='GMT+11:00' and raw['env_overrides']=={}
    expected=[env['wrapper'],'--cwd',env['worker'],'--timezone','GMT+11:00','--','-pipe','-tsvg']
    assert raw['argv']==raw['actual_wrapper_argv']==expected and raw['cwd']==env['worker']
    stdout=base64.b64decode(raw['stdout_base64']);stderr=base64.b64decode(raw['stderr_base64'])
    assert sha(stdout)==raw['stdout_sha256'] and sha(stderr)==raw['stderr_sha256']
    xml=ET.fromstring(stdout); text=' '.join(xml.itertext()); kinds=sorted({e.attrib['data-diagram-type'] for e in xml.iter() if 'data-diagram-type' in e.attrib})
    syntax='Syntax Error' in text or 'syntax error' in text or b'Error line' in stderr
    valid=raw['exit_code']==0 and not syntax and bool(stdout)
    target=R/case['source'];target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(body)
    target.with_suffix('.svg').write_bytes(stdout)
    row=dict(case,cohort='fresh52',observed_validity='valid' if valid else 'invalid',validity_disagreement=(valid != (case['intended_validity']=='valid')),java_exit=raw['exit_code'],java_types=kinds,java_stderr=stderr.decode(),java_syntax_marker=syntax)
    rows.append(row)
(O/'fresh52.json').write_text(json.dumps(rows,indent=2))
(O/'reference-validation.json').write_text(json.dumps(dict(manifest_sha256=sha((O/'relay-manifest.json').read_bytes()),entries=len(rows),classification=dict(collections.Counter(x['observed_validity'] for x in rows)),disagreements=[x['name'] for x in rows if x['validity_disagreement']],validation='Exact membership/bytes/base64/path/hash/streams/wrapperargv/cwd/timezone/resources and pinned revision/JAR validated independently. Java argv derived from wrapper, not process-traced. Historical font/Graphviz equivalence not proved.',environment=env),indent=2))
for x in rows:print(x['name'],x['observed_validity'],x['java_types'],'intention differs' if x['validity_disagreement'] else '')
