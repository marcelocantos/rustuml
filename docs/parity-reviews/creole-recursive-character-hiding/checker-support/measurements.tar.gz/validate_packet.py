# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,subprocess
from pathlib import Path
R=Path.cwd();S=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();reports=[]
for mechanism in ['creole-recursive-character-hiding','creole-parameter-command-flush']:
 p=R/'docs/parity-reviews'/mechanism/'review.json';v=json.loads(p.read_bytes());assert v['schema_version']==1 and v['mechanism']==mechanism and v['verdict']=='rejected';assert v['reviewer']['task_id'] and v['reviewer']['model'];assert len(v['commands'])>=2
 for field in ['account_commit','implementation_commit','java_revision']:assert len(v[field])==40 and all(c in '0123456789abcdef' for c in v[field])
 named=set();axes=set()
 for pair in v['perturbations']:
  source=Path(pair['source']);gold=Path(pair['golden']);assert not source.is_absolute() and '..' not in source.parts;assert str(source).startswith('test-diagrams/perturbations/'+mechanism+'/');assert gold==source.with_suffix('.svg');assert source not in named;named.add(source);axes.update(pair['axes']);assert pair['result'] in ['pass','fail'];assert sha((R/source).read_bytes())==pair['source_sha256'];assert sha((R/gold).read_bytes())==pair['golden_sha256']
 all_sources={p.relative_to(R) for p in (R/'test-diagrams/perturbations'/mechanism).rglob('*.puml')};assert named==all_sources and len(axes)>=2
 reports.append(dict(mechanism=mechanism,records_named=len(named),all_executable_pairs_named_and_hash_exact=True,verdict='rejected',expected_acceptance_guard='red; rejection/failing pairs intentionally remain'))
old=json.loads((S/'base-preservation.json').read_bytes());assert all(sha((R/x['path']).read_bytes())==x['sha256'] for x in old['inventory'])
assert not subprocess.check_output(['git','diff','HEAD','--name-only'])
summary=dict(mechanisms=reports,base_artifacts_unchanged=len(old['inventory']),tracked_files_changed_before_commit=0,record_structure_checks='passed',acceptance='rejected; these structure checks are not parity acceptance and do not replace the once-only red broad gates')
(S/'packet-validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
