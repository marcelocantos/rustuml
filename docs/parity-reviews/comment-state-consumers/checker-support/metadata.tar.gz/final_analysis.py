# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,re,hashlib,xml.etree.ElementTree as ET,collections
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd()
def dump(name,x):(S/name).write_text(json.dumps(x,indent=2)+'\n')
all_obs=[];summary={};fresh=[]
for cohort in ['checker94','checker6']:
 b=json.loads((S/(cohort+'-before.json')).read_text());a=json.loads((S/(cohort+'-after.json')).read_text());obs=json.loads((S/(cohort+'-observations.json')).read_text());rows=json.loads((S/(cohort+'-membership.json')).read_text());all_obs+=obs
 sm=dict(entries=len(rows),valid=sum(v['reference_valid'] for v in a),before_pass=sum(v['svg_match'] for v in b),after_pass=sum(v['svg_match'] for v in a),comment_and_comparator_pass=sum(v['svg_match'] and o['comments_match'] for v,o in zip(a,obs)),losses=[],gains=[],new_errors=[],new_panics=[],errors=sum(v['svg']['exit']!=0 for v in a),panics=sum(v['panic'] for v in a),malformed=sum(bool(v['xml_error']) for v in a))
 for row,bv,av,o in zip(rows,b,a,obs):
  for flag,test in [('losses',bv['svg_match'] and not av['svg_match']),('gains',not bv['svg_match'] and av['svg_match']),('new_errors',bv['svg']['exit']==0 and av['svg']['exit']!=0),('new_panics',not bv['panic'] and av['panic'])]:
   if test:sm[flag].append(row['id'])
  src=Path(row['source_capture']);g=Path(row['golden_capture']);fresh.append(dict(name=src.stem,cohort=cohort,mechanism=row['membership']['mechanism'],axes=row['membership']['axes'],source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),java_sha256=hashlib.sha256(g.read_bytes()).hexdigest(),reference_valid=av['reference_valid'],before_cli_pass=bv['svg_match'],after_cli_pass=av['svg_match'],comments_match=o['comments_match'],whole_output_pass=av['svg_match'] and o['comments_match'],java_exit=json.loads((g.parent/'reference-command.json').read_text())['exit_code'],cli_exit=av['svg']['exit']))
 summary[cohort]=sm
# Direct serializer bypass inventory; retain current exact lines, expressions, and function context.
inventory=json.loads((S/'complete-attribute-inventory.json').read_text());state=(R/'crates/rustuml-render/src/state.rs').read_text();lines=state.splitlines();direct=[]
for r in inventory:
 if r['file']=='crates/rustuml-render/src/state.rs' and r['attribute']=='fill':
  line=r['line'];prefix='\n'.join(lines[:line]);functions=re.findall(r'(?:pub\s+)?fn\s+(\w+)',prefix);direct.append(dict(line=line,function=functions[-1] if functions else None,expressions=r['expressions'],template=r['template'],scope='fixed shape constant' if set(r['expressions'])<={'NOTE_FILL','PSEUDO_COLOR','BAR_COLOR'} else 'text paint bypass; upstream text color may be dynamic'))
dump('state-direct-fill-census.json',dict(dynamic_template_sites=direct,sites=len(direct),fixed_shapes=sum(r['scope']=='fixed shape constant' for r in direct),text_sites=sum('text paint' in r['scope'] for r in direct),shared_fill_calls=len(re.findall(r'crate::svg::fill_attributes\(',state.split('#[cfg(test)]')[0]))))
# Check comment placement against Java independently of geometry, using following sibling identity.
def slots(data):
 root=ET.fromstring(data,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)));out=[]
 for parent in root.iter():
  children=list(parent)
  for i,c in enumerate(children):
   if c.tag!=ET.Comment:continue
   nxt=next((n for n in children[i+1:] if n.tag!=ET.Comment),None)
   out.append(dict(text=c.text,next_tag=nxt.tag if nxt is not None else None,next_class=nxt.get('class') if nxt is not None else None,next_qname=nxt.get('data-qualified-name') if nxt is not None else None))
 return out
member={r['id']:r for r in json.loads((S/'replay-membership.json').read_text()) if r['cohort']=='full-golden'};placements=[]
for x in json.loads((S/'golden-194-decoded.json').read_text()):
 row=member[x['id']];g=Path(row['golden_capture']).read_bytes();a=(S/'replay/after/full-golden'/x['id']/'svg.stdout').read_bytes();j=slots(g);r=slots(a);placements.append(dict(id=x['id'],same_comment_list=x['comments_match'],following_producer_slots_match=j==r,java=j,rust=r))
dump('golden-comment-placements.json',placements)
# Oracle-assisted consumers are a diagnostic, never product truth.
assisted=[]
for x in json.loads((S/'fresh-assisted-diagnostics.json').read_text()):
 row=next(r for cohort in ['checker94','checker6'] for r in json.loads((S/(cohort+'-membership.json')).read_text()) if r['id']==x['id']);g=Path(row['golden_capture']).read_bytes();a=(S/'assisted'/x['id']/'svg.stdout').read_bytes()
 assisted.append(dict(id=x['id'],whole_comparator_pass=x['assisted_match'],java_comments=re.findall(r'<!--(.*?)-->',g.decode(),re.S),rust_comments=re.findall(r'<!--(.*?)-->',a.decode(),re.S),producer_slots_equal=slots(g)==slots(a)))
dump('assisted-comment-observations.json',assisted);dump('fresh-summary.json',summary);dump('fresh-case-manifest.json',fresh)
print(json.dumps(summary,indent=2));print('direct fill census',len(direct),collections.Counter(r['scope'] for r in direct));print('194 producer slots',sum(x['following_producer_slots_match'] for x in placements));print('fresh result count',len(fresh))
