# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import concurrent.futures,hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent;R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-2f87fc19')
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def call(argv,cwd,env,data,d,label):
    start=time.monotonic()
    try:
        q=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,input=data,capture_output=True,timeout=90)
        code,out,err=q.returncode,q.stdout,q.stderr
    except subprocess.TimeoutExpired as e:code,out,err=124,e.stdout or b'',e.stderr or b''
    (d/(label+'.stdout')).write_bytes(out);(d/(label+'.stderr')).write_bytes(err)
    return dict(argv=list(map(str,argv)),cwd=str(cwd),exit=code,seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err))
def measure(row,phase):
    d=S/'replay'/phase/row['cohort']/row['id'];d.mkdir(parents=True,exist_ok=True)
    m=row['membership'];overrides=dict(TZ=m.get('zone','GMT+11:00'),RUSTUML_DEBUG=m.get('debug','date=1774210426000,tz=AEDT+1100'),RAYON_NUM_THREADS='4',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')|m.get('env',{})
    env=dict(os.environ,**overrides);data=Path(row['source_capture']).read_bytes()
    svg=call([S/(phase+'-rustuml'),'-pipe'],row['cwd'],env,data,d,'svg')
    ym=call([S/(phase+'-rustuml'),'--yaml','-pipe'],row['cwd'],env,data,d,'yaml')
    cmp=call([S/'probe','compare',row['golden_capture'],d/'svg.stdout'],R,env,None,d,'compare')
    gold=Path(row['golden_capture']).read_bytes();out=(d/'svg.stdout').read_bytes();err=(d/'svg.stderr').read_bytes()
    try:
        root=ET.fromstring(gold);valid=cmp['exit']!=2 and not any('Welcome to PlantUML!' in (n.text or '') for n in root.iter())
    except ET.ParseError:valid=False
    helper_valid=valid
    if row['cohort']!='full-golden':valid=m['reference_valid']
    xmlerr=None
    if out:
        try:ET.fromstring(out)
        except ET.ParseError as e:xmlerr=str(e)
    result=dict(id=row['id'],cohort=row['cohort'],phase=phase,env_overrides=overrides,svg=svg,yaml=ym,compare=cmp,reference_valid=valid,helper_reference_valid=helper_valid,svg_match=valid and svg['exit']==0 and cmp['exit']==0,panic=b'panicked at' in err,emitted=bool(out),xml_error=xmlerr)
    dump(d/'result.json',result);return result
if __name__=='__main__':
    phase=sys.argv[1];rows=json.loads((S/'replay-membership.json').read_text());results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for v in pool.map(lambda r:measure(r,phase),rows):
            results.append(v)
            if len(results)%500==0:print(phase,len(results),flush=True)
    dump(S/(phase+'-results.json'),results)
    for cohort in dict.fromkeys(r['cohort'] for r in rows):
        vs=[v for v in results if v['cohort']==cohort]
        print(cohort,dict(entries=len(vs),valid=sum(v['reference_valid'] for v in vs),passes=sum(v['svg_match'] for v in vs),errors=sum(v['svg']['exit']!=0 for v in vs),panics=sum(v['panic'] for v in vs),malformed=sum(bool(v['xml_error']) for v in vs)),flush=True)
