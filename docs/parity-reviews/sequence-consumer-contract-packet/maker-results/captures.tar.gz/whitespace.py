from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/sequence.rs');s=p.read_text();s=s.replace('Regex::new(', 'sequence_regex(').replace(r'\s', '[%s]').replace(r'\S', '[^%s]')
# Explicit placeholder expansion, not Rust Unicode whitespace or shared regex changes.
i=s.index('static INLINE_ARROW_STYLE');s=s[:i]+'''// Pattern2#QUOTED_REPLACEMENTS expands %s to Java \\s plus NBSP;
// compileInternal uses CASE_INSENSITIVE without UNICODE_CHARACTER_CLASS.
// RegexLeaf.spaceOneOrMore/spaceZeroOrMore and sequence command factories all
// use this class. Keep negation consistent for command token boundaries.
fn sequence_regex(pattern: &str) -> Result<Regex, regex::Error> {
    const JAVA_SPACE: &str = r"[\\x09-\\x0d \\u{00a0}]";
    const JAVA_NON_SPACE: &str = r"[^\\x09-\\x0d \\u{00a0}]";
    Regex::new(&pattern.replace("[^%s]", JAVA_NON_SPACE).replace("[%s]", JAVA_SPACE))
}

'''+s[i:];pos=s.rindex('\n}');s=s[:pos]+'''
    #[test]
    fn java_pattern2_whitespace_is_shared_across_sequence_commands() {
        for (space, valid) in [(' ', true), ('\\t', true), ('\\u{00a0}', true), ('\\u{2003}', false), ('\\u{202f}', false)] {
            for body in [
                format!("participant{space}Birch\\nBirch -> Elm"),
                format!("participant Birch\\nparticipant Elm\\nBirch{space}->{space}Elm"),
                format!("participant Birch\\nrnote over Birch\\nbody\\nend{space}rnote"),
            ] {
                let lines = body.lines().map(str::to_owned).collect::<Vec<_>>();
                assert_eq!(parse_sequence(&lines).is_ok(), valid, "{body:?}");
            }
        }
        let whitespace = sequence_regex(r"^[%s]$").unwrap();
        let non_whitespace = sequence_regex(r"^[^%s]$").unwrap();
        for character in ['\\t', '\\n', '\\u{000b}', '\\u{000c}', '\\r', ' ', '\\u{00a0}'] {
            assert!(whitespace.is_match(&character.to_string()));
            assert!(!non_whitespace.is_match(&character.to_string()));
        }
    }
'''+s[pos:];p.write_text(s)
