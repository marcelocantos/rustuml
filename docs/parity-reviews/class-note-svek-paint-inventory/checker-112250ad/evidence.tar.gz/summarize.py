# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,re,shutil,subprocess,xml.etree.ElementTree as ET
s=Path(__file__).resolve().parent;root=Path.cwd();a=s/'maker-archive';sha=lambda b:hashlib.sha256(b).hexdigest();historical=json.loads((s/'replay-historical.json').read_text())['results'];fresh=json.loads((s/'replay-fresh.json').read_text())['results'];allrows=historical+fresh;out={}
def cohort(rows):
 hashes=Counter(r['source_sha256'] for r in rows)
 return {'entries':len(rows),'unique_sources':len(hashes),'duplicate_entries':sum(n-1 for n in hashes.values()),'counts':{v:dict(Counter(r[v]['status'] for r in rows)) for v in ['before','after']}}
out['cohorts']={c:cohort([r for r in allrows if r['cohort']==c]) for c in ['frozen1826','fresh25','checker33']};out['combined1851']=cohort(historical);out['combined1884']=cohort(allrows)
out['maker_agreement']={v:{k:{'checked':len(historical),'disagreements':[r['source'] for r in historical if not r[v][k]]} for k in ['maker_status_agrees','maker_svg_agrees','maker_yaml_agrees']} for v in ['before','after']}
out['lost_passes']=[r['source'] for r in allrows if r['before']['status']=='pass' and r['after']['status']!='pass'];out['new_valid_errors']=[r['source'] for r in allrows if r['before']['status'] in ['pass','mismatch'] and r['after']['status']=='process_error'];out['uid_deltas']=[];out['count_drops']=[]
for r in allrows:
 if r['after']['status']=='invalid_reference':continue
 b=r['before'].get('model');c=r['after'].get('model')
 if not b:continue
 if not c:out['count_drops'].append({'source':r['source'],'reason':'previous valid model missing'});continue
 if b['type']=='Class' and b['uid_events']!=c['uid_events']:out['uid_deltas'].append(r['source'])
 for k,n in b['counts'].items():
  if c['counts'][k]<n:out['count_drops'].append({'source':r['source'],'field':k,'before':n,'after':c['counts'][k]})
out['frozen_yaml_unchanged']=sum((r['before']['yaml']['exit'],r['before']['yaml']['sha256'])==(r['after']['yaml']['exit'],r['after']['yaml']['sha256']) for r in historical[:1826]);out['frozen_yaml_changed']=[r['source'] for r in historical[:1826] if (r['before']['yaml']['exit'],r['before']['yaml']['sha256'])!=(r['after']['yaml']['exit'],r['after']['yaml']['sha256'])];out['mechanisms']={m:cohort([r for r in fresh if r['mechanism']==m]) for m in sorted({r['mechanism'] for r in fresh})}
out['fresh_outcomes']=[{k:v for k,v in r.items() if k not in ['before','after','java_dom']}|{'before':r['before']['status'],'after':r['after']['status'],'java_extent':None if not r['java_dom'] else [r['java_dom']['width'],r['java_dom']['height']],'rust_extent':None if not r['after']['dom'] else [r['after']['dom']['width'],r['after']['dom']['height']]} for r in fresh]
# Parse DOM without losing anchor ancestry or empty-package comment inventory.
def dom(path):
 try:x=ET.fromstring(path.read_bytes(),parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)))
 except ET.ParseError:return None
 objects=[];comments=[];anchors=[];primitives=[]
 def visit(e,owner=None,active_url=None):
  if e.tag is ET.Comment:comments.append(e.text);return
  tag=e.tag.rsplit('}',1)[-1]
  if tag=='a':
   active_url=dict(e.attrib);anchors.append({'attrs':active_url,'direct_owner':owner})
  if e.get('class') in ['entity','cluster']:
   owner=e.get('id');objects.append({'class':e.get('class'),'id':owner,'name':e.get('data-qualified-name'),'source_line':e.get('data-source-line'),'inherited_url':active_url})
  if tag in ['rect','path','ellipse','polygon','line','text']:primitives.append({'tag':tag,'owner':owner,'url':active_url,'filter':e.get('filter'),'text':e.text if tag=='text' else None})
  for c in e:visit(c,owner,active_url)
 visit(x);return {'width':x.get('width'),'height':x.get('height'),'objects':objects,'comments':comments,'anchors':anchors,'primitives':primitives}
ledgers=[]
for r in fresh:
 j=dom(Path(r['source']).with_suffix('.svg'));b=dom(s/r['before']['cli']['capture']);c=dom(s/r['after']['cli']['capture']);ledgers.append({'source':r['source'],'java':j,'before':b,'after':c})
(s/'fresh-dom-ledger.json').write_text(json.dumps(ledgers,indent=2)+'\n')
out['dom_bounds']={'valid_rendered':sum(r['after']['status'] in ['pass','mismatch'] for r in fresh),'exact_metadata_order':[r['source'] for r in ledgers if r['after'] and r['java']['objects']==r['after']['objects']],'note':'Empty packages have comment/primitive inventory rather than entity <g>; full inherited/direct URL, comments and filter primitives are retained. DOM agreement is not whole geometry.'}
main={}
for name in ['no_oracle','golden']:
 filename=name+'_failure_names.txt';p=root/'test-diagrams'/filename;shutil.copy2(p,s/filename);before=(a/('before-'+filename)).read_bytes();maker=(a/filename).read_bytes();actual=p.read_bytes();bs=set(before.decode().splitlines());cs=set(actual.decode().splitlines());main[name]={'count':len(cs),'sha256':sha(actual),'maker_after_exact':actual==maker,'new_failure_names':sorted(cs-bs),'recovered_failure_names':sorted(bs-cs)}
out['main_failure_names']=main
units=lambda name:sum(map(int,re.findall(r'test result: ok\. (\d+) passed', (s/name).read_text())))
standing=(s/'gate-standing.log').read_text();failed=re.findall(r'^  (test-diagrams/perturbations/[^\n]+\.puml): (.*)',standing,re.M);total=len(list((root/'test-diagrams/perturbations').rglob('*.puml')));out['gates']={'units_passed':units('gate-units.log'),'cli_error_docs_passed':units('gate-cli-errors.log'),'no_oracle_library':{'matched':11189,'eligible':11251,'exit':101},'assisted_library':{'matched':10525,'eligible':11251,'total':12550,'skipped':1299,'failed':726,'exit':101},'standing_pre_registration':{'total':total,'failures':len(failed),'passed':total-len(failed),'invalid_refs':sum('Java error page' in msg for _,msg in failed),'panics':sum('renderer panicked' in msg for _,msg in failed),'parse_errors':sum('parse failed:' in msg for _,msg in failed),'exit':101}}
clippy=lambda path:re.findall(r'^error(?:\[.*?\])?: (?!could not compile)(.*)$',path.read_text(),re.M)
out['gates']['clippy']={'diagnostic_count':len(clippy(s/'gate-clippy.log')),'same_categories_and_counts_as_maker':Counter(clippy(s/'gate-clippy.log'))==Counter(clippy(a/'corrected-clippy.log')),'exit':101};out['gates']['guard_passed']=4;out['gates']['guard_total']=6;out['gates']['fmt_exit']=0
out['binary_after_gates_sha256']=sha((s/'target-after/release/rustuml').read_bytes());out['binary_before_sha256']=sha((s/'target-before/release/rustuml').read_bytes());out['jvm_guard_marker_present']=any('LOCAL_JVM_LAUNCH_DISABLED' in p.read_text() for p in s.glob('gate-*.log'))
(s/'summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['fresh_outcomes','dom_bounds']},indent=2))
