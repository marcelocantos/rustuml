# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();D=R/'docs/parity-reviews/shared-svg-attributes/maker-support';D.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
# All prior review/account/perturbation bytes, including imported rejection.
base='bb550b42bf7bc3bd23774df31e9b137493cb6743'
entries=[]
for line in subprocess.check_output(['git','ls-tree','-r',base,'docs/parity-reviews','test-diagrams/perturbations']).decode().splitlines():
 info,name=line.split('\t');mode,typ,oid=info.split()
 if typ=='blob':entries.append((oid,name))
proc=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
# Request/read incrementally to avoid pipe deadlock on the evidence archives.
rows=[]
for oid,name in entries:
 proc.stdin.write((oid+'\n').encode());proc.stdin.flush();head=proc.stdout.readline();size=int(head.split()[2]);data=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n';actual=(R/name).read_bytes();assert data==actual,name;rows.append(dict(path=name,sha256=sha(data),bytes=len(data)))
proc.stdin.close();proc.wait();put(S/'historical-preservation.json',dict(base_revision=base,count=len(rows),all_byte_identical=True,files=rows))
# Imported independent rejection is a byte-for-byte patch/tree addition.
original='84b5439aef3b41d10257d4ec964f0134a2e24ce1';names=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',original]).decode().splitlines();check=[]
for name in names:
 a=subprocess.check_output(['git','show',original+':'+name]);b=(R/name).read_bytes();assert a==b;check.append(dict(path=name,sha256=sha(a)))
put(S/'rejection-preservation.json',dict(original=original,import_commit=base,files=check,all_byte_identical=True))
# Exact production scope and before/after source hashes.
files=subprocess.check_output(['git','diff','--name-only']).decode().splitlines();approved=json.loads((R/'docs/parity-reviews/shared-svg-attributes/approved-file-hashes.json').read_bytes());allowed=set(approved)|{'Cargo.lock','crates/rustuml/Cargo.toml','crates/rustuml/tests/pipe_mode.rs'};assert set(files)<=allowed,set(files)-allowed
source=[]
for name in files:
 before=subprocess.check_output(['git','show',base+':'+name]);after=(R/name).read_bytes();source.append(dict(path=name,before_sha256=sha(before),after_sha256=sha(after)))
put(S/'production-source-hashes.json',source)
put(S/'binary-provenance.json',dict(binaries=[dict(path=str(S/n),sha256=sha((S/n).read_bytes()),bytes=(S/n).stat().st_size) for n in ['before-rustuml','after-rustuml','probe']],comparator_source_sha256=sha((S/'probe.rs').read_bytes()),before_revision='b8905e296b8865e53f3c573abaebf4adb632d751',after_source_hashes='production-source-hashes.json',build_jobs=4,shipping=False))
# XML result per immutable cohort, every output including negatives.
xml=[]
for p in sorted(S.glob('*-membership.json')):
 cohort=p.name.removesuffix('-membership.json')
 if cohort.endswith('-original') or not (S/(cohort+'-after.json')).exists():continue
 for phase in ['before','after']:
  observations=json.loads((S/(cohort+'-'+phase+'.json')).read_bytes());bad=[];emitted=0
  for row in observations:
   b=(S/'replay'/phase/row['id']/'svg.stdout').read_bytes()
   if not b:continue
   emitted+=1
   try:ET.fromstring(b)
   except ET.ParseError as e:bad.append(dict(id=row['id'],error=str(e)))
  xml.append(dict(cohort=cohort,phase=phase,inputs=len(observations),emitted=emitted,malformed=len(bad),malformed_cases=bad,process_errors=sum(r['svg']['exit']!=0 for r in observations),panics=sum(r['panic'] for r in observations)))
put(S/'xml-by-cohort.json',xml)
# Explanations of each decoded change, without treating whole-output failures as passes.
changes=json.loads((S/'changed-outputs.json').read_bytes())
for row in changes:
 if row['cause']=='XML parse transition':row['explanation']='Raw user font-family double quotes or raw metadata angle/ampersand made before XML invalid. Shared normalization/escaping makes after XML well-formed; comparator result remains separately recorded.'
 elif row['id'].endswith('/attr_link_whitespace'):row['explanation']='Java ToStream decimal TAB/CR references preserve actual tooltip whitespace. Before raw TAB/CR normalized to spaces on XML parse. URL/tooltip selection still differs from Java; whole failure retained.'
 elif row['id'].endswith('/back_special_alpha'):row['explanation']='DriverTextSvg BACKCOLOR.toRGB maps transparent and background to #000000; existing FilterRegistry now deduplicates the identical RGB. One redundant filter (three XML elements) disappears; note-height whole failure retained.'
 elif row['cause'].startswith('element count'):row['explanation']='DriverTextSvg transparent-text early return removes only alpha-zero text; atom widths and next-run coordinates preserved. Automatic whole failure remains where present.'
 elif row['cause']=='color serialization':row['explanation']='HColorSet/XColor normalization and shared fillMe alpha emission; decoded fill/stroke/flood-color and opacity changes source-accounted. Original comparator verdict retained.'
 else:row['explanation']='Same decoded XML including text, structure and attributes; changed lexical attribute encoding only.'
put(S/'changed-outputs-classified.json',changes)
# Source-linked fresh whole outcomes and independent negative classification.
a=json.loads((S/'shared22-after.json').read_bytes());b=json.loads((S/'shared22-before.json').read_bytes());observations=[]
residuals={'attr_link_ascii':'URL/label tokenizer and layout difference; escaping itself well-formed','attr_link_whitespace':'URL/tooltip grammar differs; shared TAB/CR/LF serialization follows source','attr_link_unicode':'Java splits URL at NBSP; cannot claim whole Unicode-URL preservation','attr_actor_metadata':'qualified-name normalization differs (Java Oak . .Fir. vs Rust literal punctuation); XML fixed','color_alpha':'shared text atoms match; sequence note path height122.4883 vs121.4883 remains','back_special_alpha':'shared text/filter values match; sequence note path height122.4883 vs121.4883 remains','color_automatic_light':'T14.15 consumer active/default-background adjustment absent','color_automatic_dark':'T14.15 consumer active/default-background adjustment absent'}
for x,y in zip(b,a):
 name=y['id'].split('/')[-1];ref=(S/'fresh-reference'/name/'java.svg.stdout').read_bytes();err=(S/'fresh-reference'/name/'java.svg.stderr').read_bytes();is_c0='c0_' in name;is_font=name=='font_invalid_color'
 if is_c0:assert b'SAXException' in err and b'SAXException' in ref
 if is_font:assert b'NoSuchColorRuntimeException' in err and b'NoSuchColorRuntimeException' in ref
 observations.append(dict(id=y['id'],source=str(S/'new'/(name+'.puml')),source_sha256=sha((S/'new'/(name+'.puml')).read_bytes()),reference=str(S/'fresh-reference'/name/'java.svg.stdout'),java_exit=0,java_valid=y['reference_valid'],classification='SAXException export crash SVG, nonpositive' if is_c0 else 'NoSuchColorRuntimeException crash SVG, nonpositive' if is_font else 'valid diagram',before_pass=x['svg_match'],after_pass=y['svg_match'],whole_failure=residuals.get(name,'T14.20 negative error contract' if not y['reference_valid'] else None),rust_malformed=is_c0))
put(S/'fresh-outcomes.json',observations)
# Pinned local parser source proves no external entity I/O.
reg=next(Path('/Users/marcelo/.cargo/registry/src').glob('*/roxmltree-0.20.0/src'));put(S/'xml-parser-provenance.json',dict(version='0.20.0',files=[dict(path=str(reg/n),sha256=sha((reg/n).read_bytes())) for n in ['parse.rs','tokenizer.rs']],source_boundary='parse.rs315–345 optional allow_dtd policy; tokenizer.rs390–430 external identifiers consumed;471–504 external entity defs return None; no resolver/network/filesystem access',no_external_dtd_or_entity_fetched_or_resolved=True))
print('preserved',len(rows),'old files; source files',len(source),'fresh classified',len(observations),flush=True)
