from pathlib import Path
import subprocess,json,hashlib,shutil
S=Path(__file__).parent;R=Path.cwd();T=S/'dtd-scratch';T.mkdir(exist_ok=True);text=(R/'crates/rustuml/tests/pipe_mode.rs').read_text();start=text.index('const STANDARD_SVG_DOCTYPE:');end=text.index('\n#[test]',start);helper=text[start:end];src=T/'parse.rs';src.write_text(helper+'\nfn main() { for arg in std::env::args().skip(1) { let s=std::fs::read_to_string(&arg).unwrap(); println!("{}\\t{:?}",arg,parse_cli_svg(&s)); } }\n')
deps=S/'target-after/release/deps';dep=next(p for p in deps.glob('roxmltree-*.d') if '/roxmltree-0.20.0/' in p.read_text());argv=['rustc','--edition=2024',str(src),'-L','dependency='+str(deps),'--extern','roxmltree='+str(deps/('lib'+dep.stem+'.rlib')),'-o',str(S/'xml-probe')];subprocess.run(argv,check=True)
std='<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"\n "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">';root='<svg/>';cases={
'bare':(std+root,True),'xml':('<?xml version="1.0"?>'+std+root,True),'xml_space':('<?xml version="1.0"?> \r\n\t'+std+root,True),'leading_space':(' \r\n\t'+std+root,True),
'comment_decoy':('<!--'+std+'--><!DOCTYPE svg [<!ENTITY x "bad">]><svg>&x;</svg>',False),
'pi_decoy':('<?x '+std+'?><!DOCTYPE svg [<!ENTITY x "bad">]><svg>&x;</svg>',False),
'comment_prefix':('<!--x-->'+std+root,False),'pi_prefix':('<?x y?>'+std+root,False),'bom':('\ufeff'+std+root,False),'bom_xml':('\ufeff<?xml version="1.0"?>'+std+root,False),'space_xml':(' <?xml version="1.0"?>'+std+root,False),
'newline_collapsed':(std.replace('\n ',' ')+root,False),'crlf':(std.replace('\n','\r\n')+root,False),'double_space':(std.replace('\n ','\n  ')+root,False),'public_altered':(std.replace('SVG 1.1','SVG 1.0')+root,False),'system_altered':(std.replace('svg11.dtd','svg10.dtd')+root,False),'system_only':('<!DOCTYPE svg SYSTEM "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">'+root,False),'subset_empty':(std[:-1]+' []>'+root,False),'subset_entity':(std[:-1]+' [<!ENTITY x SYSTEM "file:///nonexistent-checker-entity">]><svg>&x;</svg>',False),'two':(std+std+root,False),'after_root':(root+std,False),'external_entity_ref':(std+'<svg>&external;</svg>',False),'comment_only':('<!--'+std+'-->'+root,True),'pi_only':('<?x '+std+'?>'+root,True),'normal':(root,True)}
results=[]
for name,(value,expected) in cases.items():
 p=T/(name+'.svg');p.write_text(value);q=subprocess.run([S/'xml-probe',p],capture_output=True);out=q.stdout.decode().strip();passed='\tOk(' in out;results.append(dict(name=name,expected_accept=expected,accepted=passed,result=out.split('\t',1)[1],input_sha256=hashlib.sha256(value.encode()).hexdigest()));assert passed==expected,(name,out)
# All real DOT CLI sources, not simulated strings.
actual=[]
for p in sorted((R/'test-diagrams/golden').rglob('*.puml')):
 if b'@startdot' not in p.read_bytes():continue
 q=subprocess.run([S/'after-rustuml','-pipe','-tsvg'],input=p.read_bytes(),capture_output=True)
 if b'<!DOCTYPE' not in q.stdout:continue
 out=T/'real.svg';out.write_bytes(q.stdout);v=subprocess.check_output([S/'xml-probe',out]).decode();assert '\tOk(true)' in v;actual.append(dict(source=str(p.relative_to(R)),sha256=hashlib.sha256(q.stdout).hexdigest(),exit=q.returncode))
assert len(actual)==26
old=subprocess.check_output(['git','show','741d1785a:crates/rustuml/tests/pipe_mode.rs']).decode();a=old[old.index('const EXPECTED_MALFORMED'):old.index('    fn collect',old.index('const EXPECTED_MALFORMED'))];b=text[text.index('const EXPECTED_MALFORMED'):text.index('    fn collect',text.index('const EXPECTED_MALFORMED'))];assert a==b
(S/'dtd-results.json').write_text(json.dumps(dict(compile_argv=argv,exact_helper_sha256=hashlib.sha256(helper.encode()).hexdigest(),mutations=results,actual_dot=actual,malformed_ratchet_unchanged=True,mutation_inputs_discarded=True),indent=2));shutil.rmtree(T);print(len(results),'mutations correct;',len(actual),'actual DOT pass')
