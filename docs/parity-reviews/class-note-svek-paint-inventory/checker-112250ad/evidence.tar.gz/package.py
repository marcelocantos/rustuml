# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
s=Path(__file__).resolve().parent;root=Path.cwd();dest=root/'docs/parity-reviews/class-note-svek-paint-inventory/checker-112250ad';sha=lambda b:hashlib.sha256(b).hexdigest()
# Validate every registered fixture and schema field without repeating product gates.
registration=json.loads((s/'registration.json').read_text())
for r in registration:
 assert sha((root/r['source']).read_bytes())==r['source_sha256'];assert sha((root/r['golden']).read_bytes())==r['java_svg_sha256'];assert Path(r['source']).with_suffix('.svg')==Path(r['golden'])
for mechanism in sorted({Path(r['source']).parts[2] for r in registration}):
 p=root/'docs/parity-reviews'/mechanism/'review.json';d=json.loads(p.read_text());assert d['verdict']=='rejected';assert d['schema_version']==1;assert d['mechanism']==mechanism
 for k in ['account_commit','implementation_commit','java_revision']:assert len(d[k])==40
 assert len({axis for r in d['perturbations'] for axis in r['axes']})>=2
 for r in d['perturbations']:assert r['result'] in ['pass','fail']
 # Record supplemental validation command explicitly without touching old records.
 cmd='uv run --no-project python '+str(s/'validate_refs.py')+' supplement-'
 if cmd not in d['commands']:d['commands'].append(cmd);p.write_text(json.dumps(d,indent=2)+'\n')
# Verify all original tracked files against the exact candidate after registration.
tracked=subprocess.check_output(['git','ls-tree','-r','68ab512be964e243ae1943f7a9fefd3537091401'],text=True).splitlines();mismatches=[];checked=0
for line in tracked:
 meta,p=line.split('\t',1);mode,kind,blob=meta.split()
 if kind!='blob':continue
 b=(root/p).read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();checked+=1
 if actual!=blob:mismatches.append(p)
assert not mismatches
validation={'registered_pairs':len(registration),'new_reviews':3,'candidate_tracked_blobs_checked':checked,'candidate_tracked_mismatches':mismatches,'broad_gate_repeats_for_packaging':0};(s/'registration-validation.json').write_text(json.dumps(validation,indent=2)+'\n');shutil.copy2(s/'registration-validation.json',dest/'registration-validation.json')
# Include full new captures and immutable source/reference blobs, not build trees or binaries.
files=[]
for p in s.iterdir():
 if p.is_file() and (p.suffix in ['.py','.json','.md','.log','.gz','.txt']) and p.name not in ['evidence.tar.gz','archive-manifest.json','archive-integrity.json']:
  files.append((p,p.name))
for directory in ['fresh','supplement','replay-historical','replay-fresh','post-gates-cli','no-local-jvm']:
 for p in sorted((s/directory).rglob('*')):
  if p.is_file():files.append((p,str(p.relative_to(s))))
for p in sorted((s/'maker-archive/input-reference-blobs').iterdir()):files.append((p,'frozen/input-reference-blobs/'+p.name))
for name in ['input-reference-snapshot.json','all1826.json','fresh25.json']:
 files.append((s/'maker-archive'/name,'frozen/'+name))
manifest=[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p,name in files];(s/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=dest/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p,name in files:t.add(p,arcname=name,recursive=False)
 t.add(s/'archive-manifest.json',arcname='archive-manifest.json')
with tarfile.open(archive,'r:gz') as t:
 for r in manifest:
  b=t.extractfile(r['path']).read();assert len(b)==r['bytes'] and sha(b)==r['sha256']
r={'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files_verified':len(manifest),'excluded':['before-source','target-before','target-after','before-rustuml','replay-rustuml','post-gates-rustuml'],'historical_maker_archive_sha256':'8fb7eb16f32bc0fea14a891ab8e5b84744e1fa7e5268cc38c0b596f60943f072','interpretation':'Integrity only; all three mechanism verdicts are rejected.'};(dest/'archive-integrity.json').write_text(json.dumps(r,indent=2)+'\n');print(validation);print(r)
