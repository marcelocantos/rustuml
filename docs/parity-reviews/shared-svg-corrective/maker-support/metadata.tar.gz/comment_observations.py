# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,re,hashlib
S=Path(__file__).parent;rows=[]
for cohort in json.loads((S/'cohorts.json').read_text())+['corrective16','full-golden']:
 for m in json.loads((S/(cohort+'-membership.json')).read_text()):
  a=(S/'replay/after'/m['id']/'svg.stdout').read_bytes();b=(S/'replay/before'/m['id']/'svg.stdout').read_bytes()
  if a==b and cohort!='corrective16':continue
  ref=Path(m['golden_capture']).read_bytes()
  def comments(x):return [t.decode('utf8','replace') for t in re.findall(rb'<!--(.*?)-->',x,re.S)]
  aa=comments(a);bb=comments(b);jj=comments(ref)
  if aa==bb and cohort!='corrective16':continue
  # Ignore generated SRC tail only when comparing producer comments; keep raw full lists.
  def producer(xs):return [x for x in xs if x.startswith(('class ','entity ','cluster ','link ','reverse link '))]
  p,q,j=map(producer,[bb,aa,jj]);rows.append(dict(id=m['id'],cohort=cohort,source=m['source_capture'],reference=m['golden_capture'],before_comments=bb,after_comments=aa,java_comments=jj,producer_comments_before_match_java=p==j,producer_comments_after_match_java=q==j,comment_body_change=p!=q))
(S/'comment-observations.json').write_text(json.dumps(rows,indent=2)+'\n');print('changed golden comment producers',sum(r['cohort']=='full-golden' for r in rows),'after exact Java',sum(r['cohort']=='full-golden' and r['producer_comments_after_match_java'] for r in rows))
