from pathlib import Path
import json,hashlib,subprocess,urllib.request,xml.etree.ElementTree as ET,collections,re
S=Path(__file__).parent;R=Path.cwd();J=Path('/Users/marcelo/work/github.com/plantuml/plantuml');pin='71806a23780b04a5ccde2f8ceb5121edad5eb711';sha=lambda b:hashlib.sha256(b).hexdigest();out=[]
for path in ['utils/CharHidder.java','klimt/creole/legacy/AtomText.java']:
 p=J/'src/main/java/net/sourceforge/plantuml'/path;b=subprocess.check_output(['git','-C',str(J),'show',pin+':'+str(p.relative_to(J))]);assert b==p.read_bytes();out.append(dict(path=str(p),sha256=sha(b),pin=pin));(S/'jdk-source'/p.name).write_bytes(b)
for path in ['sun/nio/cs/Surrogate.java','java/nio/charset/Charset-X-Coder.java.template']:
 url='https://raw.githubusercontent.com/openjdk/jdk21u/jdk-21.0.5-ga/src/java.base/share/classes/'+path;b=urllib.request.urlopen(url).read();(S/'jdk-source'/Path(path).name).write_bytes(b);out.append(dict(url=url,sha256=sha(b)))
(S/'additional-source-provenance.json').write_text(json.dumps(out,indent=2))
rows=json.loads((S/'fresh-outcomes.json').read_bytes())+json.loads((S/'unicode-followup/fresh-outcomes.json').read_bytes());summ={}
for mechanism in ['all','comments','state-fill']:
 subset=[x for x in rows if mechanism=='all' or x['mechanism']==mechanism];summ[mechanism]=dict(entries=len(subset),valid=sum(x['membership']['reference_valid'] for x in subset),phases={p:dict(passes=sum(x[p]['svg_match'] for x in subset),errors=sum(x[p]['svg']['exit']!=0 for x in subset),panics=sum(x[p]['panic'] for x in subset),emitted=sum((S/'replay'/p/x['id']/'svg.stdout').stat().st_size>0 for x in subset),malformed=sum(x[p]['malformed'] is not None for x in subset)) for p in ['before','after']},lost_passes=[x['id'] for x in subset if x['before']['svg_match'] and not x['after']['svg_match']],new_errors=[x['id'] for x in subset if x['before']['svg']['exit']==0 and x['after']['svg']['exit']!=0],new_panics=[x['id'] for x in subset if not x['before']['panic'] and x['after']['panic']])
(S/'fresh-summary.json').write_text(json.dumps(summ,indent=2))
# Retain full shape paint projections, including fill=none and unknown/defaults.
paints=[]
for x in rows:
 if x['mechanism']!='state-fill':continue
 item=dict(id=x['id'])
 for phase,path in [('java',Path(x['golden_capture']))]+[(p,S/'replay'/p/x['id']/'svg.stdout') for p in ['before','after']]:
  item[phase]=[dict(tag=n.tag.rsplit('}',1)[-1],attributes=dict(n.attrib)) for n in ET.fromstring(path.read_bytes()).iter() if n.tag.rsplit('}',1)[-1] in ['rect','path','ellipse','polygon']]
 paints.append(item)
(S/'state-paint-observations.json').write_text(json.dumps(paints,indent=2))
# Source-byte proof for every initial disagreement.
neg=[]
for x in rows:
 if x['java_classification']=='valid_diagram':continue
 b=Path(x['source']).read_bytes();neg.append(dict(id=x['id'],java_classification=x['java_classification'],java_exit=x['java_exit'],source_sha256=sha(b),source_has_nul=b'\0' in b,source_invalid_c0=[n for n in b if n<32 and n not in (9,10,13)],contains_private_U_E000='\ue000' in b.decode(),observed_java_text=x['java_text']))
(S/'java-negative-classification.json').write_text(json.dumps(neg,indent=2));print(json.dumps(summ,indent=2))
