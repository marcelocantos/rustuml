from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as ET,yaml,collections
S=Path(__file__).parent;R=Path.cwd();cohorts=json.loads((S/'metadata/cohorts.json').read_bytes())+['corrective16','full-golden'];sha=lambda b:hashlib.sha256(b).hexdigest();summary=[];changed=[];ym=[]
def canon(n):
 if n is None:return None
 if isinstance(n,yaml.ScalarNode):return (n.tag,n.value)
 if isinstance(n,yaml.SequenceNode):return (n.tag,tuple(canon(x) for x in n.value))
 return (n.tag,tuple(sorted(((canon(k),canon(v)) for k,v in n.value),key=repr)))
def xml(b,comments=False):
 root=ET.fromstring(b,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=comments,insert_pis=True)))
 return [(str(n.tag),sorted(n.attrib.items()),n.text,n.tail) for n in root.iter()]
for c in cohorts:
 before=json.loads((S/(c+'-before.json')).read_bytes());after=json.loads((S/(c+'-after.json')).read_bytes());rows=json.loads((S/(c+'-membership.json')).read_bytes());assert len(before)==len(after)==len(rows)
 stat=dict(cohort=c,entries=len(rows),valid=sum(x['reference_valid'] for x in after),before_pass=sum(x['svg_match'] for x in before),after_pass=sum(x['svg_match'] for x in after),lost=[],gained=[],new_errors=[],new_panics=[],before_errors=sum(x['svg']['exit']!=0 for x in before),after_errors=sum(x['svg']['exit']!=0 for x in after),before_panics=sum(x['panic'] for x in before),after_panics=sum(x['panic'] for x in after))
 for row,b,a in zip(rows,before,after):
  assert b['id']==a['id']==row['id'];id=a['id']
  if b['svg_match'] and not a['svg_match']:stat['lost'].append(id)
  if a['svg_match'] and not b['svg_match']:stat['gained'].append(id)
  if b['svg']['exit']==0 and a['svg']['exit']!=0:stat['new_errors'].append(id)
  if not b['panic'] and a['panic']:stat['new_panics'].append(id)
  bd=S/'replay/before'/id;ad=S/'replay/after'/id;bb=(bd/'svg.stdout').read_bytes();ab=(ad/'svg.stdout').read_bytes()
  if bb!=ab:
   rec=dict(cohort=c,id=id,before_pass=b['svg_match'],after_pass=a['svg_match'],before_sha256=sha(bb),after_sha256=sha(ab))
   if c=='full-golden':
    rec.update(outside_comments_byte_identical=re.sub(rb'<!--.*?-->',b'',bb,flags=re.S)==re.sub(rb'<!--.*?-->',b'',ab,flags=re.S),decoded_noncomments_equal=xml(bb)==xml(ab),xml_equivalent=xml(bb,True)==xml(ab,True),before_comments=re.findall(r'<!--(.*?)-->',bb.decode(),re.S),after_comments=re.findall(r'<!--(.*?)-->',ab.decode(),re.S),java_comments=re.findall(r'<!--(.*?)-->',Path(row['golden_capture']).read_text(),re.S));rec['comments_match_java']=rec['after_comments']==rec['java_comments'];assert rec['outside_comments_byte_identical'] and rec['decoded_noncomments_equal'] and not rec['xml_equivalent']
   changed.append(rec)
  by=(bd/'yaml.stdout').read_bytes();ay=(ad/'yaml.stdout').read_bytes()
  if by!=ay:
   same=canon(yaml.compose(by))==canon(yaml.compose(ay));ym.append(dict(cohort=c,id=id,byte_identical=False,semantic_equal=same,before_sha256=sha(by),after_sha256=sha(ay)));assert same
 summary.append(stat)
(S/'replay-summary.json').write_text(json.dumps(summary,indent=2));(S/'changed-outputs.json').write_text(json.dumps(changed,indent=2));(S/'yaml-deltas.json').write_text(json.dumps(dict(entries=sum(x['entries'] for x in summary),identical=sum(x['entries'] for x in summary)-len(ym),map_order_only=ym,semantic_changes=0),indent=2));print(json.dumps(summary,indent=2));print('golden byte changes',sum(x['cohort']=='full-golden' for x in changed),'yaml deltas',len(ym))
