// Copyright 2026 Marcelo Cantos
// SPDX-License-Identifier: Apache-2.0
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    let source = std::fs::read_to_string(&args[1])?;
    let golden = std::fs::read_to_string(&args[2])?;
    let diagram = rustuml_parser::parse::parse_auto_with_base(&source, None)?;
    let oracle = rustuml_oracle::extract::extract_oracle_layout(&golden);
    print!("{}", rustuml_render::render_svg_with_oracle(&diagram, oracle.as_ref()));
    Ok(())
}
