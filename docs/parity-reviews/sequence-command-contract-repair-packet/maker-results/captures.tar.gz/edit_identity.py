from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/sequence.rs');s=p.read_text();start=s.index('        // Allow optional color (#xxx) after participant list.');end=s.index('            // Bare "note left"',start)
s=s[:start]+'''        // FactorySequenceNoteCommand requires its PARTICIPANT after the optional
        // prefix. Keep it required, so `of` can itself be the identity. Single-line
        // prefix uses [%s] once; multiline uses [%s]+. OverSeveral has exactly two
        // required identities and no prefix. OnArrow is a separate, unnamed form.
        static NAMED: LazyLock<Vec<Regex>> = LazyLock::new(|| {
            let identity = r#"[\\p{L}\\p{N}_.@]+|"[^"]+""#;
            let mut patterns = Vec::new();
            for inline in [true, false] {
                let suffix = if inline { r"[%s]*:[%s]*(?P<text>.*)$" } else { "$" };
                let color = r"[%s]*(?P<color>#[^%s:]+)?[%s]*";
                let prefix = if inline { r"(?:of[%s])?" } else { r"(?:of[%s]+)?" };
                patterns.push(sequence_regex(&format!(
                    r"^(?P<shape>h|r)?note[%s]+(?P<position>left|right|over)[%s]+{prefix}(?P<p1>{identity}){color}{suffix}"
                )).unwrap());
                patterns.push(sequence_regex(&format!(
                    r"^(?P<shape>h|r)?note[%s]+(?P<position>over)[%s]+(?P<p1>{identity})[%s]*,[%s]*(?P<p2>{identity}){color}{suffix}"
                )).unwrap());
            }
            patterns
        });
        static ATTACHED: LazyLock<Regex> = LazyLock::new(|| {
            sequence_regex(r"^(?P<shape>h|r)?note[%s]+(?P<position>left|right)[%s]*(?P<color>#[^%s:]+)?[%s]*(?::[%s]*(?P<text>.*))?$").unwrap()
        });
        static BARE_OVER: LazyLock<Regex> = LazyLock::new(|| {
            sequence_regex(r"^(?:h|r)?note[%s]+over[%s]*(?:#[^%s:]+)?[%s]*(?::.*)?$").unwrap()
        });
        let captures = NAMED.iter().find_map(|pattern| pattern.captures(line))
            .or_else(|| ATTACHED.captures(line));
        if let Some(caps) = captures {
            let shape = match caps.name("shape").map(|m| m.as_str()) {
                Some("h") => NoteShape::Hexagonal,
                Some("r") => NoteShape::Rectangular,
                _ => NoteShape::Note,
            };
            let position = match caps.name("position").unwrap().as_str() {
                "left" => NotePosition::Left,
                "right" => NotePosition::Right,
                "over" => NotePosition::Over,
                _ => unreachable!(),
            };
            let inline_text = caps.name("text");
            let participant_source_line = if inline_text.is_some() {
                self.current_line
            } else {
                self.current_line + 1
            };
            let mut participants: Vec<String> = ["p1", "p2"].iter()
                .filter_map(|name| caps.name(name))
                .map(|m| self.ensure_participant_at(m.as_str().trim_matches('"'), participant_source_line))
                .collect();
''' +s[end:]
s=s.replace('let color = caps.get(4).map(|m| m.as_str().to_string());\n\n            if let Some(text_match)', 'let color = caps.name("color").map(|m| m.as_str().to_string());\n\n            if let Some(text_match)',1)
needle='''            Ok(true)
        } else {
            Ok(false)
        }
    }

    fn try_group'''
s=s.replace(needle,'''            Ok(true)
        } else if BARE_OVER.is_match(line) {
            // Neither standalone factory accepts a missing participant; the
            // OnArrow factory does not include `over` in POSITION.
            Err(ParseError {
                line: self.current_line,
                message: "A note over command requires a participant".into(),
            })
        } else {
            Ok(false)
        }
    }

    fn try_group''',1)
p.write_text(s)
