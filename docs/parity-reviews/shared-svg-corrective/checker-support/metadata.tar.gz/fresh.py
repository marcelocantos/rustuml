# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,gzip,base64,unicodedata
S=Path(__file__).parent; N=S/'new';N.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
def add(name,body,mechanism,axes):
 p=N/(name+'.puml');p.write_bytes(('@startuml\n'+body+'\n@enduml\n').encode());rows.append(dict(source=str(p),mechanism=mechanism,axes=axes,cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=False,intended_validity='intended_valid; classify fresh Java independently'))
# Dash lengths/boundaries are isolated, unlike prior single combined fixture.
for i,name in enumerate(['-','--','---','----','-leading','trailing-','-->','<!--',']]>','Amp&Angle<>Quote\'']):
 add('dash_%02d'%i,'class "'+name+'"','comments',['single dash boundary/delimiter token','unaliased class'])
# One representative of every Unicode general category with a valid non-ASCII scalar.
# Surrogates are not Unicode scalar values and cannot occur in UTF-8 PlantUML.
points=[0x00c5,0x00e5,0x01c5,0x02b0,0x4e2d,0x0301,0x0903,0x20dd,0x0661,0x2167,0x00b2,0x203f,0x2014,0x3008,0x3009,0x00ab,0x00bb,0x203d,0x2211,0x20ac,0x00a8,0x2603,0x00a0,0x2028,0x2029,0x0085,0x200d,0xe000,0x0378,0x1d11e,0x10400,0x1f9ed,0x20000,0xe0100,0xf0000]
chars=''.join(chr(x) for x in points)
(S/'unicode-axis.json').write_text(json.dumps([dict(codepoint=hex(x),category=unicodedata.category(chr(x))) for x in points],indent=2))
for family,keyword in [('class','class'),('description','rectangle'),('component','component'),('state','state'),('deployment','node'),('object','object'),('usecase','usecase')]:
 body=keyword+' "Quartz'+chars+'--"'
 if family=='state':body+=' as Q\nQ : detail'
 add('unicode_'+family,body,'comments',['all scalar general categories + supplementary planes','consumer '+family])
add('unicode_activity','(*) --> "Quartz'+chars+'--"\n"Quartz'+chars+'--" --> (*)','comments',['Unicode categories','legacy activity link endpoints'])
add('scalar_supplementary','class "X𝄞Y"\nclass "XéY"\n"X𝄞Y" <|-- "XéY"','comments',['one supplementary versus BMP scalar','reverse link'])
add('link_runs','class "--A-"\nclass "B----"\n"--A-" <|-- "B----"','comments',['endpoint dash runs','reverse link direction'])
add('state_named_links','state "Reed--" as R\nstate "Stone-" as S\nR --> S','comments',['valid state aliases','label versus endpoint name'])
add('cluster_comment','package "Shelf<!--]]>--" {\nclass "--Box"\n}\nclass Outside\n"--Box" --> Outside','comments',['cluster delimiters','nested cross-boundary link'])
for description in [False,True]:
 for color in ['#7a3c9100','#7a3c9101','#7a3c917f','#7a3c91fe','#7a3c91ff','#9b4','RebeccaPurple','transparent']:
  name='fill_'+('body_' if description else 'empty_')+color.replace('#','').lower()
  add(name,('' if description else 'hide empty description\n')+'skinparam stateBackgroundColor '+color+'\nstate Cypress'+(' : sap\nCypress : root' if description else ''),'state-fill',['empty/description rectangle','RGB alpha or named/short/transparent '+color])
for shape,body in {
'composite':'state Copse {\nstate Fern\nFern : leaf\n}',
'concurrent':'state Copse {\nstate Fern\n--\nstate Moss\n}',
'history':'state Copse {\n[*] --> [H]\nstate Fern\n[H] --> Fern\n}',
'choice':'state Branch <<choice>>\nstate Fern\nBranch --> Fern',
'fork':'state Split <<fork>>\nstate Fern\nSplit --> Fern',
'join':'state Merge <<join>>\nstate Fern\nFern --> Merge',
'deep_history':'state Copse {\n[*] --> [H*]\nstate Fern\n[H*] --> Fern\n}',
'round':'state End <<end>>\nstate Start <<start>>\nStart --> End',
}.items():add('shape_'+shape,'skinparam stateBackgroundColor #7a3c917f\n'+body,'state-fill',['unrouted state shape '+shape,'partial alpha'])
(S/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
resources=[dict(local_path=str(p),remote_relative_path='new/'+p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(N.glob('*.puml'))]
request=json.loads((S/'metadata/request.json').read_bytes());request.update(manifest_path=str(S/'manifest.json'),manifest_sha256=sha((S/'manifest.json').read_bytes()),case_count=len(rows),resources=resources,case_contracts=[dict(source=x['source'],source_sha256=sha(Path(x['source']).read_bytes()),cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']) for x in rows])
(S/'request.json').write_text(json.dumps(request,indent=2)+'\n')
files=[dict(local_path=x['local_path'],remote_relative_path=x['remote_relative_path'],sha256=x['sha256'],base64=base64.b64encode(Path(x['local_path']).read_bytes()).decode()) for x in resources]
(S/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=request,manifest=rows,files=files)).encode(),mtime=0))
for p in list(N.glob('*.puml'))+[S/'request.json',S/'manifest.json',S/'input-bundle.json.gz']:p.chmod(0o444)
print(len(rows),{p.name:sha(p.read_bytes()) for p in [S/'request.json',S/'manifest.json',S/'input-bundle.json.gz']})
