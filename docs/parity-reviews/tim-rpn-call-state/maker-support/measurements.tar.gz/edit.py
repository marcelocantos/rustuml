from pathlib import Path
p=Path('crates/rustuml-parser/src/preprocess/mod.rs');s=p.read_text()
s=s.replace('collecting_sub: Option<String>,','collecting_sub: Option<(String, usize)>,')
s=s.replace('if let Some(name) = self.collecting_sub.clone() {','if let Some((name, origin)) = self.collecting_sub.clone() {')
s=s.replace('''            if directive_argument(trimmed, "!endsub").is_some() {
                self.collecting_sub = None;''','''            // CodeIteratorSub.peek rejects nesting at the outer declaration,
            // before replay can execute effects or consume following model lines.
            if directive_argument(trimmed, "!startsub").is_some() {
                let previous = self.source_line_override.replace(origin);
                self.fail("Cannot nest sub".into());
                self.source_line_override = previous;
            } else if directive_argument(trimmed, "!endsub").is_some() {
                self.collecting_sub = None;''')
s=s.replace('self.collecting_sub = Some(name.to_string());','self.collecting_sub = Some((name.to_string(), self.current_diagram_source_line()));')
s=s.replace("name: name.trim().trim_start_matches('$').to_string(),",'name: name.trim().to_string(),')
s=s.replace("named.insert(key.trim_start_matches('$').to_string(), value);",'named.insert(key.to_string(), value);')
s=s.replace('self.fail(format!("Bad number of arguments for {name}"));','self.fail(format!("Unknown built-in function ${name}"));',1)
s=s.replace('''        let mut positional = positional.into_iter();
        let mut scope''','''        // TFunctionImpl.executeReturnFunction checks kind after signature lookup.
        if expression_call && func.kind == FunctionKind::Procedure {
            self.fail("Illegal call here. Is there a return directive in your function?".into());
            return (None, Vec::new());
        }
        let mut positional = positional.into_iter();
        let mut scope''',1)
s=s.replace('scope.overrides.insert(param.name.clone(), value);','''// Exact Java key matching occurs above. Only the Rust memory index
            // omits the leading dollar, as do get_var and assignment storage.
            scope.overrides.insert(param.name.strip_prefix('$').unwrap_or(&param.name).to_string(), value);''')
a=s.index('    fn execute_expression(');b=s.index('    // ------------------------------------------------------------------\n    // Boolean evaluation',a)
s=s[:a]+'''    fn execute_expression(&mut self, expression: &Expression) -> Value {
        // ReversePolishInterpretor owns ONE stack/map for a whole prepared
        // expression. A called function's body evaluates its own expressions.
        // Account: tim-rpn-call-state (precommitted c91103f9).
        let mut stack = Vec::new();
        let mut named = HashMap::new();
        self.execute_expression_into(expression, &mut stack, &mut named);
        stack.pop().unwrap_or_else(|| Value::Str(String::new()))
    }

    fn expression_pop(&mut self, stack: &mut Vec<Value>) -> Value {
        // Java ArrayDeque.removeFirst throws on malformed RPN stack state.
        // Preserve fatality through the existing preprocessing error channel.
        stack.pop().unwrap_or_else(|| {
            self.fail("Expression operand stack underflow".into());
            Value::Str(String::new())
        })
    }

    fn execute_expression_into(
        &mut self,
        expression: &Expression,
        stack: &mut Vec<Value>,
        named: &mut HashMap<String, Value>,
    ) {
        if self.error.is_some() {
            return;
        }
        match expression {
            Expression::Value(value) => stack.push(value.clone()),
            Expression::Number(text) => match text.parse::<i32>() {
                Ok(number) => stack.push(Value::Int(number)),
                Err(_) => self.fail("Integer literal outside signed 32-bit range".into()),
            },
            Expression::Not(inner) => {
                self.execute_expression_into(inner, stack, named);
                if self.error.is_none() {
                    let value = self.expression_pop(stack);
                    stack.push(Value::Int(i32::from(!value.truth())));
                }
            }
            Expression::Binary(left, op, right) => {
                self.execute_expression_into(left, stack, named);
                self.execute_expression_into(right, stack, named);
                if self.error.is_none() {
                    let right = self.expression_pop(stack);
                    let left = self.expression_pop(stack);
                    if self.error.is_none() {
                        stack.push(self.apply_operator(left, right, op));
                    }
                }
            }
            Expression::Call(name, args) => {
                for (key, expression) in args {
                    if let Some(key) = key {
                        self.execute_expression_into(key, stack, named);
                    }
                    self.execute_expression_into(expression, stack, named);
                    if self.error.is_some() {
                        return;
                    }
                    if key.is_some() {
                        let value = self.expression_pop(stack);
                        let key = self.expression_pop(stack).to_display();
                        if self.error.is_some() {
                            return;
                        }
                        named.insert(key, value);
                    }
                }
                // RPN OPEN_PAREN_FUNC subtracts the current DISTINCT named keys,
                // including those assigned before a nested call in this expression.
                let count = args.len().checked_sub(named.len());
                let function_name = name.strip_prefix('$').unwrap_or(name);
                let covered = count.is_some_and(|count| {
                    if let Some(builtin) = name.strip_prefix('%') {
                        builtin_arity(builtin).is_some_and(|arity| arity.contains(&count))
                    } else {
                        self.functions.get(function_name).is_some_and(|function| {
                            count <= function.params.len()
                                && count >= function.params.iter().filter(|p| p.default.is_none()).count()
                        })
                    }
                });
                if !covered {
                    self.fail(format!("Unknown built-in function {name}"));
                    return;
                }
                let count = count.unwrap(); // Successful coverage above requires a count.
                if count > stack.len() {
                    self.fail("Expression operand stack underflow".into());
                    return;
                }
                let positional = stack.split_off(stack.len() - count);
                let value = if let Some(builtin) = name.strip_prefix('%') {
                    self.eval_builtin_values(builtin, &positional)
                } else {
                    let (ret, events) = self.call_function_values(function_name, positional, named.clone(), true);
                    self.expression_events.extend(events);
                    ret.unwrap_or_else(|| Value::Str(String::new()))
                };
                named.clear();
                if self.error.is_none() {
                    stack.push(value);
                }
            }
        }
    }

'''+s[b:]
s=s.replace('''                    if multiline {
                        self.mark_source_lines = true;''','''                    if multiline {
                        // TContext LEGACY_DEFINELONG pendingAdd uses the RAW
                        // caller prefix; PROCEDURE uses the evaluated result.
                        let raw_prefix = &line[..offset];
                        self.mark_source_lines = true;''')
s=s.replace('''                            let text = if index == 0 {
                                format!("{result}{text}")''','''                            let text = if index == 0 {
                                format!("{raw_prefix}{text}")''')
s=s.replace('''                values.push(self.eval_expr_to_value(part));
                if self.error.is_some()''','''                // EaterFunctionCall separates named operands before constructing
                // the positional signature. Builtins ignore the named map, but
                // each RHS still executes, including effects and errors.
                if let Some((_, expression)) = named_argument(part) {
                    self.eval_expr_to_value(expression);
                } else {
                    values.push(self.eval_expr_to_value(part));
                }
                if self.error.is_some()''')
s=s.replace('''        match func {
            "upper" | "lower" => {''','''        match func {
            "intval" => {
                // IntVal.executeReturnFunction uses Integer.parseInt on TValue's
                // complete display, not numeric coercion or floating truncation.
                let text = values[0].to_display();
                return match text.parse::<i32>() {
                    Ok(value) => Value::Int(value),
                    Err(_) => {
                        self.fail(format!("Cannot convert {text} to integer."));
                        Value::Str(String::new())
                    }
                };
            }
            "hsl_color" => {
                return Value::Str(tim_hsl_color(values));
            }
            "upper" | "lower" => {''',1)
a=s.index('            "intval" => args');b=s.index('            "darken" =>',a);s=s[:a]+s[b:]
a=s.index('            "hsl_color" => {',s.index('    fn eval_one_builtin_args'));b=s.index('            "is_dark" =>',a);s=s[:a]+s[b:]
s=s.replace('"strlen" | "strpos" | "true" | "false" | "intval" | "hex2dec" | "variable_exists" =>','"strlen" | "strpos" | "true" | "false" | "hex2dec" | "variable_exists" =>')
p.write_text(s)
