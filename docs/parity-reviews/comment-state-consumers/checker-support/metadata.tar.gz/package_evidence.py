# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,tarfile,gzip,hashlib,io,subprocess,re,shutil
S=Path(__file__).parent;R=Path.cwd();D=R/'docs/parity-reviews/comment-state-consumers/checker-support';sha=lambda b:hashlib.sha256(b).hexdigest()
# Preserve setup diagnostics that were returned directly by command tools.
setup=[dict(action='git submodule update --init test-diagrams/golden',error="fatal: transport 'file' not allowed",log='logs/submodule-setup.log',resolution='Command-scoped git -c protocol.file.allow=always submodule update --init; exact pinned commit checked.'),dict(action='prepare_replay.py initial attempt',error="KeyError: ('retained', 'collateral/1289-checker2_raw_blank_crlf', 'reference_source')",resolution='Frozen archive contains source and golden only; optional expanded-source diagnostic omitted, actual source/reference hashes unchanged. Full CLI/YAML output retained.'),dict(action='target context at a42acf204',error="KeyError: 'T14.21'",resolution='Read target context from 9874a537e3bf18628377f525692103815f429982; parent confirmed integration-ledger context.'),dict(action='json dump of YAML target context',error='TypeError: Object of type date is not JSON serializable',resolution='Metadata dates serialized with default=str; target YAML untouched.'),dict(action='assisted probe link selection',error='AssertionError: two rustuml_render rlibs exist',resolution='Select exact oracle-layout rlib via Cargo fingerprint; record hash and successful rustc argv in assisted-probe-build.json.')]
(S/'setup-failures.json').write_text(json.dumps(setup,indent=2)+'\n');shutil.copy2(S/'setup-failures.json',D/'setup-failures.json')
# Independent standing-name census, without a second broad gate run.
text=(S/'logs/standing.log').read_text();names=re.findall(r'^  (test-diagrams/perturbations/[^\n]+?\.puml):',text,re.M);assert len(names)==1209
standing=dict(stable_candidate_pairs=2139,failures=len(names),passes=2139-len(names),failure_names=names,broad_runs=1,reviewer_pairs_added_after_broad_run=100,reviewer_pair_verification='actual CLI individually + unchanged compare_svg_strict + XML/comments; no second broad run')
(S/'standing-census.json').write_text(json.dumps(standing,indent=2)+'\n');shutil.copy2(S/'standing-census.json',D/'standing-census.json')
# Every frozen golden byte must correspond to the independently hydrated exact submodule.
rows=json.loads((S/'replay-membership.json').read_text());count=0
for row in rows:
 if row['cohort']!='full-golden':continue
 stem=row['id'].removeprefix('full-golden/');p=R/'test-diagrams/golden'/stem
 assert sha(Path(str(p)+'.puml').read_bytes())==row['source_sha256']
 assert sha(Path(str(p)+'.svg').read_bytes())==row['golden_sha256'];count+=1
assert count==12550
(S/'golden-membership-validation.json').write_text(json.dumps(dict(submodule_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R/'test-diagrams/golden').decode().strip(),pairs=count,all_source_and_reference_bytes_match=True),indent=2)+'\n');shutil.copy2(S/'golden-membership-validation.json',D/'golden-membership-validation.json')
# Read all archived raw streams and save lossless archives with independent manifests.
groups={
 'metadata':[p for p in S.iterdir() if p.is_file() and p.suffix in ['.json','.py','.rs','.txt','.gz']]+[p for p in (S/'supplement').iterdir() if p.is_file()],
 'logs':list((S/'logs').rglob('*')),
 'fresh':[p for folder in ['new','fresh-reference','assisted','supplement/new','supplement/fresh-reference'] for p in (S/folder).rglob('*')],
 'cli-before':list((S/'replay/before').rglob('*')),
 'cli-after':list((S/'replay/after').rglob('*')),
}
archives=[]
for name,paths in groups.items():
 paths=sorted(set(p for p in paths if p.is_file()));entries=[];target=D/(name+'.tar.gz')
 with target.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
  for p in paths:
   b=p.read_bytes();rel=str(p.relative_to(S));info=tarfile.TarInfo(rel);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b));entries.append(dict(path=rel,bytes=len(b),sha256=sha(b)))
 manifest=D/(name+'.entries.json.gz');manifest.write_bytes(gzip.compress(json.dumps(entries).encode(),mtime=0));expected={r['path']:r for r in entries}
 with tarfile.open(target) as tar:
  for m in tar:
   b=tar.extractfile(m).read();r=expected.pop(m.name);assert sha(b)==r['sha256'] and len(b)==r['bytes']
 assert not expected
 archives.append(dict(archive=target.name,sha256=sha(target.read_bytes()),bytes=target.stat().st_size,entries=len(entries),manifest=manifest.name,manifest_sha256=sha(manifest.read_bytes()),readback_verified=True));print(name,len(entries),target.stat().st_size,flush=True)
(D/'archives.json').write_text(json.dumps(archives,indent=2)+'\n')
