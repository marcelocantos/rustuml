# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,subprocess,shutil
S=Path(__file__).parent;d=S/'iteration2';d.mkdir(exist_ok=True)
for p in S.glob('*-after.json'):shutil.copy2(p,d/p.name)
shutil.move(S/'replay/after',d/'replay-after');(d/'binary-source-provenance.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256((S/'after-rustuml').read_bytes()).hexdigest(),production_diff=subprocess.check_output(['git','diff','--','crates'],text=True)),indent=2)+'\n')
p=Path('crates/rustuml-render/src/creole.rs');s=p.read_text();start=s.index('fn walk_segments(');end=s.index('fn handle_tag(',start);w=s[start:end]
for char,field,next_marker in [('~','wavy_underline',"            '~' =>"),('*','bold',"            '/' if"),('-','line_through',"            '<' =>")]:
 a=w.index(f"            '{char}' if chars.peek() == Some(&'{char}') => {{");b=w.index(next_marker,a)
 w=w[:a]+f'''            '{char}' if chars.peek() == Some(&'{char}') => {{
                if let Some(content) = take_style_delimiter(&mut chars, "{char}{char}") {{
                    flush_buf!();
                    let mut nested = style.clone();
                    nested.{field} = true;
                    out.push(Segment {{ text: String::new(), style: style.clone() }});
                    walk_segments(&content, &nested, skip_underline, out);
                    out.push(Segment {{ text: String::new(), style: style.clone() }});
                    last_char = content.chars().last();
                }} else {{
                    buf.push('{char}');
                    last_char = Some('{char}');
                }}
            }}
'''+w[b:]
a=w.index("            '/' if");b=w.index("            '_' if",a)
w=w[:a]+'''            '/' if chars.peek() == Some(&'/') => {
                // Preserve the existing caller's URL-scheme exclusion.
                if last_char == Some(':') {
                    buf.push_str("//");
                    chars.next();
                    last_char = Some('/');
                } else if let Some(content) = take_style_delimiter(&mut chars, "//") {
                    flush_buf!();
                    let mut nested = style.clone();
                    nested.italic = true;
                    out.push(Segment { text: String::new(), style: style.clone() });
                    walk_segments(&content, &nested, skip_underline, out);
                    out.push(Segment { text: String::new(), style: style.clone() });
                    last_char = content.chars().last();
                } else {
                    buf.push('/');
                    last_char = Some('/');
                }
            }
'''+w[b:]
a=w.index("            '_' if");b=w.index("            '_' =>",a)
w=w[:a]+'''            '_' if chars.peek() == Some(&'_') => {
                if skip_underline {
                    chars.next();
                    buf.push_str("__");
                    last_char = Some('_');
                } else if let Some(content) = take_style_delimiter(&mut chars, "__") {
                    flush_buf!();
                    let mut nested = style.clone();
                    nested.underline = true;
                    out.push(Segment { text: String::new(), style: style.clone() });
                    walk_segments(&content, &nested, skip_underline, out);
                    out.push(Segment { text: String::new(), style: style.clone() });
                    last_char = content.chars().last();
                } else {
                    buf.push('_');
                    last_char = Some('_');
                }
            }
'''+w[b:];s=s[:start]+w+s[end:];at=s.index('fn walk_segments(')
s=s[:at]+'''/// CommandCreoleStyle.createCreole requires at least one captured character
/// before a closing delimiter. A failed candidate leaves input unconsumed so
/// StripeSimple's literal-character fallback can reach subsequent commands.
fn take_style_delimiter(
    chars: &mut std::iter::Peekable<std::str::Chars>,
    delimiter: &str,
) -> Option<String> {
    // The first opener character was read by walk_segments; the second is
    // still pending. Delimiters are existing two-character ASCII commands.
    let remaining: String = chars.clone().skip(1).collect();
    let mut scan = remaining.char_indices().peekable();
    while let Some((offset, c)) = scan.next() {
        if c == '~' && delimiter != "~~"
            || (c == '\\\\' && scan.peek().is_some_and(|(_, c)| *c == '~'))
        {
            scan.next();
            continue;
        }
        if offset > 0 && remaining[offset..].starts_with(delimiter) {
            chars.next();
            for _ in remaining[..offset + delimiter.len()].chars() {
                chars.next();
            }
            return Some(remaining[..offset].to_string());
        }
    }
    None
}

'''+s[at:];p.write_text(s)
