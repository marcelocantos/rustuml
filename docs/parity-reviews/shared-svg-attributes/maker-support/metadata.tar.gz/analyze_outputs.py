# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,collections,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent
COHORTS=['retained','maker18','sprites50','checker38','fresh15','fresh26','new15','delimiters4','focused2','checker30','supplement8','fresh12','checker28','fresh16','golden-regressions','checker36','fallback16','checker32','shared22','full-golden']
def parse(b):
 return ET.fromstring(b,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)))
def projection(n):
 return (str(n.tag),sorted(n.attrib.items()),n.text,n.tail,[projection(c) for c in n])
results=[];changed=[]
for cohort in COHORTS:
 before=json.loads((S/(cohort+'-before.json')).read_bytes());after=json.loads((S/(cohort+'-after.json')).read_bytes());members=json.loads((S/(cohort+'-membership.json')).read_bytes())
 assert len(before)==len(after)==len(members)
 losses=[];gains=[];new_errors=[];new_panics=[];modelbytes=[];counts=collections.Counter()
 for b,a,m in zip(before,after,members):
  assert b['id']==a['id']==m['id'];id=a['id'];old=S/'replay/before'/id;new=S/'replay/after'/id
  if b['svg_match'] and not a['svg_match']:losses.append(id)
  if not b['svg_match'] and a['svg_match']:gains.append(id)
  if b['svg']['exit']==0 and a['svg']['exit']!=0:new_errors.append(id)
  if not b['panic'] and a['panic']:new_panics.append(id)
  if (old/'yaml.stdout').read_bytes()!=(new/'yaml.stdout').read_bytes():modelbytes.append(id)
  x=(old/'svg.stdout').read_bytes();y=(new/'svg.stdout').read_bytes()
  if x==y:continue
  row=dict(id=id,cohort=cohort,before_pass=b['svg_match'],after_pass=a['svg_match'],source=m['source_capture'],reference=m['golden_capture'],before_sha=b['svg']['stdout_sha256'],after_sha=a['svg']['stdout_sha256'])
  try:
   xr=parse(x);yr=parse(y);same=projection(xr)==projection(yr);row['decoded_xml_equivalent']=same
   if same:row['cause']='XML-equivalent attribute encoding'
   else:
    xe=list(xr.iter());ye=list(yr.iter());row['element_count_before']=len(xe);row['element_count_after']=len(ye)
    if len(xe)==len(ye):
     changes=[]
     for i,(u,v) in enumerate(zip(xe,ye)):
      if u.tag!=v.tag or u.text!=v.text or u.tail!=v.tail:changes.append(dict(index=i,kind='tag/text/tail',before=[str(u.tag),u.text,u.tail],after=[str(v.tag),v.text,v.tail]))
      for k in sorted(u.attrib.keys()|v.attrib.keys()):
       if u.get(k)!=v.get(k):changes.append(dict(index=i,kind='attribute',attribute=k,before=u.get(k),after=v.get(k)))
     row['decoded_changes']=changes
     attrs={v.get('attribute') for v in changes}
     row['cause']='color serialization' if attrs <= {'fill','stroke','fill-opacity','flood-color','style'} else 'font-family normalization' if attrs <= {'font-family'} else 'mixed decoded changes: inspect'
    else:row['cause']='element count change: inspect'
  except ET.ParseError as e:row['cause']='XML parse transition';row['parse_error']=str(e)
  counts[row['cause']]+=1;changed.append(row)
 results.append(dict(cohort=cohort,entries=len(before),valid=sum(a['reference_valid'] for a in after),before_pass=sum(b['svg_match'] for b in before),after_pass=sum(a['svg_match'] for a in after),losses=losses,gains=gains,new_errors=new_errors,new_panics=new_panics,before_panics=sum(b['panic'] for b in before),after_panics=sum(a['panic'] for a in after),yaml_byte_changes=modelbytes,byte_change_categories=dict(counts)))
 print(cohort,results[-1]['before_pass'],results[-1]['after_pass'],'losses',len(losses),'changes',dict(counts),'models',len(modelbytes),flush=True)
(S/'comparison-summary.json').write_text(json.dumps(results,indent=2)+'\n');(S/'changed-outputs.json').write_text(json.dumps(changed,indent=2)+'\n')
