# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,subprocess,shutil,hashlib
S=Path(__file__).parent;R=Path.cwd();D=R/'docs/parity-reviews/shared-svg-corrective/maker-support';D.mkdir(parents=True,exist_ok=True)
prod=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();rows=json.loads((S/'comparison-summary.json').read_text());fresh=json.loads((S/'fresh-outcomes.json').read_text())
for n in ['comparison-summary.json','golden-byte-summary.json','changed-outputs-classified.json','fresh-outcomes.json','fresh-classification.json','failure-set-comparison.json','binary-provenance.json','production-source-hashes.json','gates.json','xml-by-cohort.json','xml-parser-provenance.json','dtd-mutation-results.json','scope-audit.json','comment-observations.json','model-observations.json','reference-validation.json','process-notes.json','build-commands.json','java-source-provenance.json']:
 shutil.copyfile(S/n,D/n)
residual={'not_waivers':True,'production':prod,'targets':{'T14.15':['automatic active/default-background selection remains absent: AtomText.drawU → FontConfiguration.adjustColorForBackground → HColorAutomagic.getAppropriateColor → HColorSimple.opposite','font logical names, padded aliases/metrics coupling, transparent-text whole-output failures remain'],'T14.16':['No sequence files touched; prior sequence escaper handoff remains against Java decimal LF/CR/TAB/non-ASCII serialization','Existing comment label-versus-entity-name selection differs for six creole stereotype goldens and deployment aliases; serializer cannot repair consumer naming','Only approved45comment producers measured; no broad claim for unowned comments or arbitrary consumers'],'T14.18':['background gradients DriverTextSvg:164–173'],'T14.19':['consumer TextBase bold/italic OR'],'T14.20':['Exactly7C0malformed outputs remain; source-hash and both-direction ratchet holds','font-color throws, size zero/overflow, malformed DOT, VT/FF and all negative diagnostics remain'],'T14.12':['warning chrome wbs_shape_color'],'T14.13':['sequence SECTION_HEADER and ASTERISK_PREFIXED_LINE controls'],'T14.14':['plain/code hide_raw_regions'],'T14.17':['unconsumed lines'],'T14.6.6':['1sprite-map and6DOT-attribute-map YAML order changes only; no semantic delta']},'other_visible_failures':['sequence mixed-size baselines93.6777 vs106.2461/105.2793 and note_rendered_height; no compensation','forced alignment','unknown/guillemet, Unicode/font/Omega/PLAIN, note resolver, URL/italic/legacy tspan, welcome','class markup_literal/markup_scan/style_nested combined-integration obligations; no sibling candidate import, no combined claim','source-line-zero fallback','defined class/sequence/scale-color-note registry owners; never classified as missing sprites','32retained sequence panics','checker87 family_salt/family_json exit1 empty-output errors'],'nonpositive':['malformed_dot','two shape_direction syntax errors','Batik-limited html_url_math/display_raw_math/s_display_latex_valid, no math claim','font-color/size-zero/overflow runtime error SVGs','7C0Java crashSVG controls','comment_state_links intended-valid disagreement: Java syntax error exit200'], 'fresh_whole_failures':[r for r in fresh if not r['after_pass']]}
(D/'residuals.json').write_text(json.dumps(residual,indent=2)+'\n')
table='\n'.join(f"| {r['cohort']} | {r['entries']} | {r['valid']} | {r['before_pass']} | {r['after_pass']} |" for r in rows)
xml=json.loads((S/'xml-by-cohort.json').read_text());xt='\n'.join(f"| {r['cohort']} | {r['phase']} | {r['inputs']} | {r['emitted']} | {r['malformed']} | {r['process_errors']} | {r['panics']} |" for r in xml)
text=f'''# Shared SVG correction — maker evidence, not acceptance

Production `{prod}`. Stop for a NEW independent checker; no maker-authored review or attestation. Exact starting evidence `a2167f93695497e49b8ae71c4830bac96309023b`, production `a33dccc8e94dc44b5bafdc756fc1b88c42823a7d`. Rejection `4931481fd495ffff9da55a0c7514f43a487b087e` was imported unchanged as `2ed88eb55ec5f0974ec2830deccfcc401f6d9885`. All **11,325** prior review/account/perturbation files, including that rejection, are byte-identical. No sequence, parser/model, font/metric, layout/native, TIM, comparator, baseline, target, skip or allowlist production edits. No push, PR or release.

## Precommitted causal scope

- `741d1785a`: exact four approved C0 addendum entries plus proposal. Seven total; these remain malformed Rust outputs owned by T14.20, not XML passes.
- `4157ec70f`: DOCTYPE oracle account, before test draft. `47dece176` implements prolog-position eligibility, exact standard SVG1.1 PUBLIC bytes and internal-subset rejection. The exact checker comment-decoy is a standing negative test.
- `db8955411`: comment account, exact45file/line/macros and state-fill account before production drafts. Nine production files are named there. The mechanical audit verifies all45outside-comment templates and all non-comment arguments unchanged. Five macros also contain SVG elements; those attributes and geometry are unchanged. No comment was removed.
- `346f6b3f6`: implementation and all16fresh pairs. Shared whole-comment writer separates adjacent dashes, pads a terminal dash and reproduces Java's US-ASCII scalar replacement. Two ordinary state rectangle fills use the existing shared RGB/alpha serializer; other state shape paths were not expanded.

Java trace: EntityImageClass/EntityImageDescription/Cluster/SvekEdge→Link producers → UGraphicSvg.drawComment → SvgGraphics DOMComment → OpenJDK21.0.5 ToStream.comment:2312–2333. SvgGraphics.getTransformer uses lowercase us-ascii; Encodings.getWriter/StreamEncoder supplies replacement `?` for unmappable scalars. Literal ASCII &, angle brackets and quotes are retained inside comments. The state fill trace follows EntityImageStateEmptyDescription/EntityImageState → DriverRectangleSvg → shared fillMe serialization. Exact source files/hashes, accounts and raw captures are retained.

## Actual CLI comparisons

All commands use source-only `-pipe -tsvg`, separate `-pipe -tyaml`, unchanged comparator, private before/after binaries and jobs4. Denominators retain duplicates and every nonpositive. These are CLI observations, not library counts.

| Cohort | Entries | Valid references | Before passes | After passes |
|---|---:|---:|---:|---:|
{table}

The20retained cohorts total **2,191 entries / 2,042 valid**, **1,027→1,029**. Including compact16 gives **2,207 / 2,057 valid**, **1,028→1,040**. Zero lost comparator passes, zero new errors and zero new panics across every membership and full golden corpus. The six monospace regression controls remain6/6. Existing32sequence panics and salt/json process errors remain failures.

Fullgolden: **11,179→11,179/11,251 eligible**, all12,550sources measured;12,470emitSVG and80existingprocesserrors. **39byte changes**, all semantic comment-body serialization, **zero XML-equivalent re-encodings in this correction**. Of these37staypassing and2(Hindi/Thai Java-negative references)staynonpositive; no newlypassing/failing golden. Every filename, complete decoded delta and source/reference path is in golden-byte-summary.json and changed-outputs-classified.json. Attributes, painted text and geometry are unchanged in all39. Thirty changed producer-comment lists now exactly match Java; seven retain existing label/alias selection differences and two have Java-negative references without comments. These semantic differences were investigated; none are disguised as equivalent encodings.

YAML:14,757captured entries including duplicates (12,550golden+2,207cohort).14,750byte-identical; one sprite-map and six DOT attribute-map order changes. **Zero semantic model, identity, UID, object or content changes**. Full before/after YAML and parsed tagged comparisons remain under model-observations.json/archives. Map order is T14.6.6.

## Strict XML and oracle fault injection

The standing CLI test parses every emitted golden and registered perturbation SVG with roxmltree0.20. All other parser options and internal entity limits stay default. No external DTD/entity is fetched or resolved. Only the exact declaration at the eligible prolog position enables DTD parsing; a comment or PI decoy does not. Twenty-six actual DOT outputs pass. Before guard: real control and decoy both exit0. After guard: real control exit0, decoy exit101. Both malformed-ratchet directions remain unchanged, with exact source hashes and owner/reason data.

Registered perturbations: before2,053pairs emits1,942SVG,8malformed; fresh16before emits16,8malformed. Combined same2,069inputs therefore have16malformed before. After2,069pairs emits1,958SVG, **7malformed**,111processerrors including32panics. Only the exact seven approved C0cases remain malformed; all nine measured malformed comments are repaired. No expected-failure expansion beyond the approved seven. Strict standing gate passes17/17; passing the ratchet does not relabel those seven outputs as wellformed.

| Corpus | Phase | Inputs | Emitted | Malformed | Process errors | Panics |
|---|---|---:|---:|---:|---:|---:|
{xt}

## Compact16 reference provenance and residuals

All16resources/streams/memberships/cwd/TZ/env/pins were independently validated. Pinned Java71806a23780b04a5ccde2f8ceb5121edad5eb711, JARaa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053. Wrapper `/Users/marcelo/rustuml-reference/bin/reference --cwd <worker>/new --timezone GMT+11:00 -- -pipe -tsvg`, env{{}}. Worker`/Users/marcelo/rustuml-reference/scratch/worker.OREQPPhm`; Java argv derived, not process-traced. No assets added;0timeouts. Returned gzipSHA25696b90f464957fdd3b8b82e58dddd7e8f588b3ebb7bbe8cdab91d595240e7c05e; transportSHA256193bbe995671ffaaab3cbfe9b29e86704082cec5c774112fe931c108cdbd79dc. Original envelope unchanged; lossless parent mapping and original embedded metadata bytes preserved. No local Java/javac/SSH/runner or historical reference rerun.

Fifteen valid diagrams. `comment_state_links` was intended-valid but Java exits200 with `ERROR / 3 / Syntax Error? (Assumed diagram type: state)` and a syntax-error SVG. It is executable and nonpositive, not evidence about comment serialization. All other15exit0with empty stderr; validity was independently classified from SVG content.

Fresh valid whole outcomes1→11/15. Remaining failures: Unicode metrics(comment_class_unicode), empty object consumer(comment_object_links), Archimate welcome dispatch(comment_archimate), and empty-state geometry(state_alpha_empty). The latter's RGB/opacity is exact(#2468AC,0.00392), but dimensions50x40Java versus59.7578x50Rust remain wrong. No compensation or geometry edit. Every outcome/comment projection is retained in fresh-outcomes.json. Checker87comment_double_hyphen andshape_alpha pass; its83valid total34→36, with all other failures retained.

## One stable broad gate run

Workspace library: parser624/624; renderer797/799 (new comment test green, known plain-theme and filter-identity tests fail); other library suites pass. CLI17/17. Product library diagnostic11,179/11,251 and assisted10,497/11,251 retain exact baseline72/754failure-name files, no gained or lost passes. These diagnostics are separate from actualCLI truth. Standing library898/2,069 remainsred; guards4/6remainred. Clippy stops at existing parser parse/component.rs:72deadcode. Fmt reports only existing parser/class and renderer/class residue. Diff checkpasses. Gates.json records exactargv/env/cwd/status/timing; rawlogs retained. No thresholds, baselines or unrelated redunits were changed. Initial evidence-tool errors and their resolution are retained in process-notes.json and rawlogs.

## Reproduction and handoff

Extract archive groups listed in archives.json into a private directory. Every archive has a SHA256, entry manifest and readback verification. Metadata includes all immutable memberships, exactcommands, source/binary hashes, scripts, parentrequest/manifest/transport validation, observations and complete losses/errors/panics. Captures retain every source/ref/SVG/YAML/stderr/comparator outcome before and after. Binary/targetbuild trees are private and excluded; rebuild the named revisions with jobs4. Scripts retain original absolute capture paths for provenance; relocate those paths consistently when replaying elsewhere. No self-authored checkerattestation is included.

The durable residuals.json carries all explicit failures: automatic/background context, fonts/logical aliases/metrics, transparent-text wholes, gradientsT14.18, base-styleT14.19, crashpropagationT14.20, warningsT14.12, stripesT14.13, plain/codeT14.14, unconsumedlinesT14.17, sequence baselines/noteheight, forcedalignment, unknown/guillemet/URL/italic/legacytspan/Unicode/welcome and remaining negative diagnostics. Class sibling candidate remainsunintegrated; no combined correctness claim. Batik-limited math remainsnonpositive, with no math claim. Prior reviewer verdicts remain rejected. This packet awaits a new independent checker.
'''
(D/'README.md').write_text(text)
print('report',D,'production',prod)
