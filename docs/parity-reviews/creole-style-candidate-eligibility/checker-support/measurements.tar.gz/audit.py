# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,subprocess,tarfile,re
S=Path(__file__).parent;R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-3f18003d');M=S/'maker';J=Path('/Users/marcelo/work/github.com/plantuml/plantuml')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=R):return subprocess.check_output(['git',*a],cwd=cwd)
def dump(n,x):(S/n).write_text(json.dumps(x,indent=2)+'\n')
p=R/'docs/parity-reviews/creole-style-candidate-eligibility/maker-support'
rows=json.loads((p/'archive-files.json').read_bytes());bad=[]
for x in rows:
 b=(M/x['path']).read_bytes()
 if sha(b)!=x['sha256'] or len(b)!=x['bytes']:bad.append(x['path'])
dump('archive-audit.json',dict(files=len(rows),bad=bad,sha256=sha((p/'measurements.tar.gz').read_bytes())))
java=[]
for x in json.loads((p/'java-source-provenance.json').read_bytes())['files']:
 f=Path(x['path']);raw=git('show','71806a23780b04a5ccde2f8ceb5121edad5eb711:'+str(f.relative_to(J)),cwd=J)
 java.append(dict(path=x['path'],sha256=sha(raw),matches_record=sha(raw)==x['sha256'],checkout_matches_pin=f.read_bytes()==raw))
dump('java-audit.json',java)
base='a84856637adcd8e8d4e78fd2ee00658c9c612feb';prod='8df6bb53fac4fdf364a1a9aeea0b203cb6dab8e6';tip='a3afe487a66ae26c73e2f1853d6c26fc2d228875'
files=git('diff','--name-only',base,prod,'--','crates').decode().splitlines()
b=git('show',base+':crates/rustuml-render/src/creole.rs');a=git('show',prod+':crates/rustuml-render/src/creole.rs')
scope=dict(production_files=files,legacy_prefix_equal=b[:b.index(b'pub struct Style')]==a[:a.index(b'pub struct Style')],public_signatures_before=re.findall(rb'pub fn [^\{]+',b),public_signatures_after=re.findall(rb'pub fn [^\{]+',a),tip_production_equal=not git('diff',prod,tip,'--','crates'),text_render_equal=not git('diff',base,prod,'--','crates/rustuml-render/src/text_render.rs'))
scope['public_signatures_equal']=scope.pop('public_signatures_before')==scope.pop('public_signatures_after');dump('scope-audit.json',scope)
chron=[]
for rev in ['829154e5bdd2c0a919410bbff46c2c3168a6991e','52203dbe7a0dec3d24472c698758d7657a266f58','3da7456655edffc1f3fc1e4236d832c490c4432e',prod]:
 chron.append(dict(commit=rev,metadata=git('show','-s','--format=%H%n%aI%n%cI%n%B',rev).decode(),paths=git('diff-tree','--no-commit-id','--name-only','-r',rev).decode().splitlines(),ancestor_of_production=subprocess.run(['git','merge-base','--is-ancestor',rev,prod],cwd=R).returncode==0))
with tarfile.open(p/'measurements.tar.gz') as t:
 stamps=[dict(path=x.name,mtime=x.mtime) for x in t if x.isfile() and (x.name.endswith('.py') or x.name.startswith('logs/'))]
dump('chronology.json',dict(commits=chron,archived_file_mtimes=stamps,limitation='Git ancestry proves accounts precede committed implementation. Archive mtimes and logs corroborate draft ordering but are maker-controlled, not independently timestamped draft snapshots.'))
# Every base-tracked historical artifact is independently compared by git blob, not just maker inventory.
history=[]
for rev,paths in [(base,git('ls-tree','-r','--name-only',base,'--','docs/parity-reviews','test-diagrams/perturbations').decode().splitlines())]+[(x['revision'],x['paths']) for x in json.loads((M/'historical-integrity.json').read_bytes())['imports']]:
 bad=[]
 for path in paths:
  if git('rev-parse',rev+':'+path)!=git('rev-parse',tip+':'+path):bad.append(path)
 history.append(dict(revision=rev,files=len(paths),changed=bad))
# Upstream packet includes a frozen inventory for the 9731 preexisting entries.
dump('historical-audit.json',history)
print('archive',len(rows),'bad',bad,'java',len(java),'scope',scope,'history',[(x['files'],len(x['changed'])) for x in history])
