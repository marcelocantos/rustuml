from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/class.rs');s=p.read_text();at=s.index('    #[test]\n    fn url_command_consumes')
s=s[:at]+r'''    #[test]
    fn checked_quarks_preserve_root_and_local_data_and_uid_order() {
        let d = parse("class Ledger\npackage Harbor {\nclass Ledger\nurl Ledger [[https://example.org/local]]\n}");
        assert_eq!(d.entities.iter().map(|e| e.id.as_str()).collect::<Vec<_>>(), ["Ledger", "Harbor.Ledger"]);
        assert_eq!(d.entities[0].url, None);
        assert_eq!(d.entities[1].url.as_deref(), Some("https://example.org/local"));
        assert_eq!(format!("{:?}", d.uid_events), "[Entity(\"Ledger\"), Package(\"Harbor\"), Entity(\"Harbor.Ledger\")]");
        let d = parse("class Ledger\npackage Harbor {\nnote \"receipt\" as Ledger\nurl Ledger [[https://example.org/note]]\n}");
        assert_eq!(d.entities.len(), 1);
        assert_eq!(d.notes.len(), 1);
        assert_eq!(d.notes[0].alias.as_deref(), Some("Harbor.Ledger"));
        assert_eq!(d.notes[0].owner_package.as_deref(), Some("Harbor"));
        assert_eq!(d.notes[0].url.as_deref(), Some("https://example.org/note"));
        assert_eq!(d.entities[0].url, None);
        assert_eq!(format!("{:?}", d.uid_events), "[Entity(\"Ledger\"), Package(\"Harbor\"), Note(0)]");
    }

    #[test]
    fn checked_quarks_reject_bad_separators_and_current_group_reuse() {
        for source in [
            "class Harbor.Dock\nurl Harbor..Dock [[https://example.org/bad]]",
            "class Harbor.Dock\nurl Harbor.Dock. [[https://example.org/bad]]",
            "set namespaceSeparator ::\nclass Harbor::Dock\nurl \"Harbor::::Dock\" [[https://example.org/bad]]",
            "package Harbor {\nclass Dock\nurl Harbor [[https://example.org/bad]]\n}",
            "class Harbor\nclass Harbor.Dock",
        ] {
            let lines = source.lines().map(str::to_owned).collect::<Vec<_>>();
            assert!(parse_class(&lines).is_err(), "{source}");
            assert!(super::super::parse(&format!("@startuml\n{source}\n@enduml")).is_err(), "{source}");
        }
        let d = parse("package Harbor {\nclass Harbor\nurl Harbor [[https://example.org/child]]\n}");
        assert_eq!(d.entities[0].id, "Harbor.Harbor");
        assert_eq!(d.entities[0].url.as_deref(), Some("https://example.org/child"));
        assert_eq!(d.packages[0].url, None);
    }

    #[test]
    fn command_url_owns_pattern2_quotes_without_changing_url_content() {
        for (left, right) in [('"', '"'), ('“', '”'), ('”', '“'), ('\u{e121}', '\u{e121}')] {
            let d = parse(&format!("note \"receipt\" as Ledger\nurl {left}Ledger{right} [[{left}doc with spaces{right}{{Hint}}]]"));
            assert_eq!(d.notes[0].url.as_deref(), Some("doc with spaces"));
            assert_eq!(d.notes[0].url_tooltip.as_deref(), Some("Hint"));
            assert_eq!(d.uid_events.len(), 1);
        }
    }

    #[test]
    fn attached_note_command_form_owns_url_assignment() {
        for position in ["left", "right", "top", "bottom"] {
            for (body, expected) in [(" : receipt", None), ("\nreceipt\nend note", Some("https://example.org/note")), (" {\nreceipt\n}", Some("https://example.org/note"))] {
                let d = parse(&format!("class Dock\nnote {position} of Dock [[https://example.org/note{{Hint}}]]{body}"));
                assert_eq!(d.entities.len(), 1);
                assert_eq!(d.notes.len(), 1);
                assert_eq!(d.notes[0].target.as_deref(), Some("Dock"));
                assert_eq!(d.notes[0].url.as_deref(), expected);
                assert_eq!(d.notes[0].url_tooltip.as_deref(), expected.map(|_| "Hint"));
                assert_eq!(d.notes[0].lines, ["receipt"]);
            }
        }
    }

'''+s[at:];p.write_text(s)
p=Path('crates/rustuml-render/src/class.rs');s=p.read_text();at=s.index('    #[test]\n    fn note_entity_group_owns_url')
s=s[:at]+r'''    #[test]
    fn fashion_shadow_preserves_style_and_legacy_conversion_boundaries() {
        // Values follow ValueImpl#extractDigitsAndDot and Style#getShadowing;
        // this also exercises the raw-style/skinparam origin distinction.
        for (value, expected) in [("-2.5", 2.5), ("1e2", 12.0), ("bad", 1.5), ("1.2.3", 1.5), ("true", 1.5), ("0", 0.0)] {
            for kind in ["actor", "boundary"] {
                let source = format!("@startuml\nallowmixing\n<style>\n{kind} {{\nShadowing {value}\n}}\n</style>\n{kind} Clerk\nclass Dock\nClerk --> Dock\n@enduml");
                let rustuml_parser::diagram::Diagram::Class(d) = rustuml_parser::parse::parse(&source).unwrap() else { panic!("class model expected") };
                let style = ClassFontOverrides::from_diagram_entity(&d, Some(&d.entities[0])).description.unwrap();
                let expected = if kind == "boundary" && expected != 0.0 { 4.0 } else { expected };
                assert_eq!(style.shadow, expected, "{source}");
            }
        }
        assert_eq!(parse_shadowing_delta("yes"), 3.0);
        assert_eq!(parse_shadowing_delta("no"), 0.0);
        assert_eq!(parse_shadowing_delta("-2.5"), 2.5);
    }

    #[test]
    fn lone_named_note_keeps_last_model_url_inside_entity_group() {
        let source = "@startuml\nnote \"receipt\" as Ledger\nurl Ledger [[https://example.org/old]]\nurl Ledger [[https://example.org/new{Hint}]]\n@enduml";
        let diagram = rustuml_parser::parse::parse(source).unwrap();
        let svg = crate::render_svg(&diagram);
        assert_eq!(svg.matches("<a href=").count(), 1);
        assert!(!svg.contains("https://example.org/old"));
        let (before, after) = svg.split_once("<a href=").unwrap();
        assert_eq!(before.rsplit_once("<g class=\"entity\"").unwrap().1.matches('>').count(), 1);
        assert!(after.contains("https://example.org/new"));
        assert!(after.contains("title=\"Hint\""));
        assert!(after.contains("</a></g>"));
    }

'''+s[at:];p.write_text(s)
