# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,hashlib,subprocess,collections
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest()
summary={}
for cohort in ['retained','maker18','sprites50','checker38','fresh15','fresh26','new15','delimiters4','focused2','checker30','supplement8']:
 if not (S/(cohort+'-after.json')).exists():continue
 before=json.loads((S/(cohort+'-before.json')).read_bytes());after=json.loads((S/(cohort+'-after.json')).read_bytes());members=json.loads((S/(cohort+'-membership.json')).read_bytes());pairs=list(zip(before,after));assert all(b['id']==a['id'] for b,a in pairs)
 v=dict(entries=len(pairs),distinct_pairs=len({(sha(Path(x['source_capture']).read_bytes()),sha(Path(x['golden_capture']).read_bytes())) for x in members}),valid=sum(x['reference_valid'] for x in before),before=sum(x['svg_match'] for x in before),after=sum(x['svg_match'] for x in after),gains=[b['id'] for b,a in pairs if not b['svg_match'] and a['svg_match']],losses=[b['id'] for b,a in pairs if b['svg_match'] and not a['svg_match']],failures=[a['id'] for a in after if a['reference_valid'] and not a['svg_match']],nonpositive=[x['id'] for x in after if not x['reference_valid']],before_panics=[b['id'] for b in before if b['panic']],after_panics=[a['id'] for a in after if a['panic']],changed_svg=[b['id'] for b,a in pairs if b['svg']['stdout_sha256']!=a['svg']['stdout_sha256']],changed_yaml=[b['id'] for b,a in pairs if b['yaml']['stdout_sha256']!=a['yaml']['stdout_sha256']],changed_projection=[b['id'] for b,a in pairs if b['model']!=a['model']],exact_source_available=sum('exact_source' in a and a['reference_valid'] for a in after),exact_source_equal=sum(a.get('exact_source',False) and a['reference_valid'] for a in after),exits={phase:{mode:dict(collections.Counter(str(x[mode]['exit']) for x in result)) for mode in ['svg','yaml']} for phase,result in [('before',before),('after',after)]})
 summary[cohort]=v;print(cohort,{k:v[k] for k in ['entries','valid','before','after','gains','losses']},flush=True)
(S/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
