from pathlib import Path
import re
p=Path('crates/rustuml-parser/src/parse/class.rs'); s=p.read_text()
a=s.index('    fn split_identity('); b=s.index('    fn unique_quark_path_named',a)
s=s[:a]+'''    fn split_identity(&self, raw: &str) -> Result<(bool, Vec<String>), ParseError> {
        let raw = raw.trim();
        let Some(separator) = self.namespace_sep.as_deref() else {
            return Ok((false, vec![raw.to_string()]));
        };
        // CucaDiagram#badName validates before quark allocation: empty
        // components are errors, not aliases for a collapsed path.
        if raw.ends_with(separator) || raw.contains(&separator.repeat(2)) {
            return Err(ParseError {
                line: self.current_line,
                message: format!("bad name since {separator} is a separator: {raw}"),
            });
        }
        let rooted = raw.starts_with(separator);
        let raw = raw.strip_prefix(separator).unwrap_or(raw);
        Ok((rooted, raw.split(separator).map(str::to_string).collect()))
    }

'''+s[b:]
a=s.index('    fn resolve_quark_path(');b=s.index('    fn register_entity_path',a)
s=s[:a]+'''    fn resolve_quark_path(
        &self,
        raw: &str,
        lookup: QuarkLookup,
    ) -> Result<Vec<String>, ParseError> {
        let raw = raw.trim();
        if self.namespace_sep.is_none() {
            // CucaDiagram#quarkInContextSafe delegates both lookup modes to
            // creation-ordered Plasma#firstWithName when the separator is null.
            if let Some(path) = self.first_quark_path_named(raw) {
                return Ok(path);
            }
            let mut path = self.current_group_path().to_vec();
            path.push(raw.to_string());
            return Ok(path);
        }

        let (rooted, parts) = self.split_identity(raw)?;
        if rooted {
            return Ok(parts);
        }
        if parts.len() == 1 {
            // CucaDiagram#quarkInContextSafe excludes the current group from
            // unique reuse. Current-context declarations never short-circuit
            // to an existing root leaf with the same short name.
            if matches!(lookup, QuarkLookup::ReuseUnique)
                && let Some(path) = self.unique_quark_path_named(&parts[0])
                && path != self.current_group_path()
            {
                return Ok(path);
            }
        } else {
            let first = vec![parts[0].clone()];
            if self.quark_creation_order.contains(&first) {
                // The Java root child may exist without data; only existing
                // non-group data rejects a qualified path at this stage.
                let first_id = self.path_id(&first);
                if self.entity_by_path.contains_key(&first)
                    || self.notes.iter().any(|note| note.alias.as_deref() == Some(&first_id))
                {
                    return Err(ParseError {
                        line: self.current_line,
                        message: format!("not a package: {}", parts[0]),
                    });
                }
                return Ok(parts);
            }
        }
        let mut path = self.current_group_path().to_vec();
        path.extend(parts);
        Ok(path)
    }

    fn resolve_group_path(&self, raw: &str) -> Result<Vec<String>, ParseError> {
        // CommandPackage uses quarkInContext(false), the same checked resolver
        // as native declarations, including null-separator firstWithName.
        self.resolve_quark_path(raw, QuarkLookup::CurrentContext)
    }

'''+s[b:]
# Propagate the checked identity result through its existing command owners.
for name in ['ensure_entity','ensure_entity_kind','resolve_relationship_endpoint']:
 a=s.index('    fn '+name+'('); b=s.index('\n    fn ',a+5)
 block=s[a:b].replace('-> String {','-> Result<String, ParseError> {')
 block=re.sub(r'return (self\.entities\[idx\]\.id\.clone\(\)|self\.packages\[index\]\.name\.clone\(\)|id);',r'return Ok(\1);',block)
 block=re.sub(r'^(        self\.create_entity_at_path\([^\n]+\))$',r'        Ok(\1)',block,flags=re.M)
 s=s[:a]+block+s[b:]
for name in ['try_enum_decl','try_association_class','try_relationship','try_inline_member','try_package']:
 a=s.index('    fn '+name+'('); b=s.index('\n    fn ',a+5)
 block=s[a:b].replace('-> bool {','-> Result<bool, ParseError> {')
 block=re.sub(r'return (true|false);',r'return Ok(\1);',block)
 block=re.sub(r'^(\s+)(true|false)$',r'\1Ok(\2)',block,flags=re.M)
 s=s[:a]+block+s[b:]
 s=s.replace('if self.'+name+'(line) {','if self.'+name+'(line)? {')
a=s.index('    fn parse_supertypes(');b=s.index('    fn attribute_multiline',a)
block=s[a:b].replace('child_id: &str) {','child_id: &str) -> Result<(), ParseError> {')
block=block.rstrip(); assert block.endswith('    }'); block=block[:-5]+'        Ok(())\n    }\n\n'
s=s[:a]+block+s[b:]
# All assignment call sites end in a semicolon; final resolver expression is already Result.
s=re.sub(r'(self\.(?:resolve_quark_path|resolve_group_path|ensure_entity|ensure_entity_kind|resolve_relationship_endpoint|parse_supertypes)\([^;\n]+\));',r'\1?;',s)
# CommandUrl owns Pattern2 %g quote characters, without normalizing opaque URL content.
a=s.index('    fn try_url(');b=s.index('    fn try_note',a);block=s[a:b]
block=block.replace('(?P<code>[\\p{L}\\p{N}_.]+|"[^"]+")','(?P<code>[\\p{L}\\p{N}_.]+|["“”\\u{e121}][^"“”\\u{e121}]+["“”\\u{e121}])')
block=block.replace("trim_matches('\"')", "trim_matches(['\"', '“', '”', '\\u{e121}'])")
block=block.replace('r#"^\\[\\[\\s*"(?P<link>[^"]+)"', 'r#"^\\[\\[\\s*["“”\\u{e121}](?P<link>[^"“”\\u{e121}]+)["“”\\u{e121}]')
block=block.replace('[^\\s"', '[^\\s"“”\\u{e121}')
block=block.replace('        static URL:', '        // Pattern2 expands %g to ASCII, curly and Jaws invisible quotes.\n        static URL:')
s=s[:a]+block+s[b:]
# Single-line attached notes recognize but do not assign URL (Java passes null).
s=s.replace('            let url_text = caps.name("url").map_or("", |value| value.as_str());', '''            // CommandFactoryNoteOnEntity#createSingleLine passes null to
            // executeInternal; only its multiline command constructs a Url.
            let url_text = if attached && caps.name("text").is_some() {
                ""
            } else {
                caps.name("url").map_or("", |value| value.as_str())
            };''')
p.write_text(s)
