# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

S=Path(__file__).resolve().parent
R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-0423fc37')
J=Path('/Users/marcelo/work/github.com/plantuml/plantuml')
E=R/'docs/parity-reviews/class-quark-context-checked-identity/checker-0423fc37'
E.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
summary=read(S/'summary.json');after=read(S/'replay-after.json');before=read(S/'replay-before.json');fresh=read(S/'fresh-manifest.json')['inputs'];validation=read(S/'reference-validation.json')
new_by_name={Path(r['source']).name:r for r in after['results'] if r['cohort']=='checker33'}

# Recompute constituent denominators from the frozen order, checking disjointness
# and duplicate provenance rather than treating old overlapping inventories as new.
slices=[('preserved1559',0,1559),('maker36',1559,1595),('maker20',1595,1615),('checker34',1615,1649),('maker26',1649,1675),('checker86',1675,1761),('fresh32',1761,1793),('checker33',1793,1826)]
cohorts={};seen=set()
for name,start,end in slices:
    rows=after['results'][start:end];sources={r['source_sha256'] for r in rows}
    assert not seen.intersection(sources),name
    seen.update(sources)
    cohorts[name]=dict(entries=len(rows),unique_sources=len(sources),before=dict(Counter(r['status'] for r in before['results'][start:end])),after=dict(Counter(r['status'] for r in rows)),members=[dict(source=r['source'],source_sha256=r['source_sha256'],reference_sha256=r['reference_sha256']) for r in rows])
(S/'denominator-provenance.json').write_text(json.dumps(cohorts,indent=2)+'\n')

java_paths=read(R/'docs/parity-reviews/class-quark-context-checked-identity/maker-evidence/packet7/source-and-revision-provenance.json')['java_source_files']
paths=[r['path'] for r in java_paths]+['src/main/java/net/sourceforge/plantuml/url/UrlBuilder.java','src/main/java/net/sourceforge/plantuml/classdiagram/ClassDiagramFactory.java','src/main/java/net/sourceforge/plantuml/abel/Entity.java','src/main/java/net/sourceforge/plantuml/command/note/CommandFactoryNote.java','src/main/java/net/sourceforge/plantuml/svek/EntityImageDegenerated.java']
source_records=[]
for path in paths:
    frozen=subprocess.check_output(['git','show','71806a23780b04a5ccde2f8ceb5121edad5eb711:'+path],cwd=J)
    assert (J/path).read_bytes()==frozen,path
    source_records.append(dict(path=path,sha256=sha(frozen),bytes=len(frozen)))
historical_import=[]
for path in subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','157cc571ce99714d41e28d41bd56084b53b8f36d'],cwd=R,text=True).splitlines():
    original=subprocess.check_output(['git','rev-parse','157cc571ce99714d41e28d41bd56084b53b8f36d:'+path],cwd=R,text=True).strip()
    imported=subprocess.check_output(['git','rev-parse','154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc:'+path],cwd=R,text=True).strip()
    assert original==imported,path
    historical_import.append(dict(path=path,git_blob=original))
failures={}
for name in ['no_oracle_failure_names.txt','golden_failure_names.txt']:
    current=S/'after-source/test-diagrams'/name
    old=S/'maker-archive'/name
    failures[name]=dict(current_sha256=sha(current.read_bytes()),maker_sha256=sha(old.read_bytes()),identical=current.read_bytes()==old.read_bytes())
tracked_diff=subprocess.check_output(['git','diff','--name-status','154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc'],cwd=R,text=True)
assert not tracked_diff,tracked_diff
gate_summaries={}
for gate in read(S/'gates.json'):
    log=(S/gate['log']).read_text()
    gate_summaries[gate['name']]=dict(exit=gate['exit'],test_results=re.findall(r'^test result:.*$',log,re.M),tier_summary=re.findall(r'^golden_(?:no_oracle|pairs):.*$',log,re.M))
(S/'supplemental-integrity.json').write_text(json.dumps(dict(java_sources=source_records,prior_rejection_import=historical_import,main_failure_files=failures,tracked_candidate_files_unchanged=True,gate_summaries=gate_summaries),indent=2)+'\n')

reviewer=dict(task_id='thread:delegated-task:command%3Amcp%3A7a6e5142-c330-4dbe-941b-87119bcc7cef%3Adelegate-task%3Ae2f29cc5-3e83-4de2-b1ba-2a018aac45e0',model='gpt-6-astra, high reasoning effort; Codex harness in T3 Code',tool='functions.exec / exec_command; parent T3 relay only for Java reference generation',independence='Separate checker task, no implementation or account authorship; no child agents. Same model family as maker is not model diversity.')
accounts={
 'class-quark-context-checked-identity':('b3c510e605fb39393d61e0700ac47f1b256cbb49',[
  'Checked resolver branches have direct CucaDiagram.quarkInContextSafe/badName provenance; whole SVGs improve for enum root/local declarations, current-group inline members and supertype lookup. Exact models, package membership, links, UID stream and owners are retained in captures.',
  'Q1: q_rootclass_localnote and q_root_note_local_note retain correct object identity, UID and URL owners but emit root before local note; Java GraphvizImageBuilder/Bibliotekon paints group leaves first. Reversed declaration order passes. Whole-case failures reject the claim.',
  'Q2: q_null_note_first retains an empty package in YAML but render_notes_only drops its painted image: Java251x73 versus Rust159x45. The existing single-note fast path does not exclude packages. This is a preexisting sibling defect, not an additional parsed object-count loss.',
  'Q3: q_curly_url_mixed passes and q_invisible_url_target rejects correctly. Java-valid q_curly_note_target is still a Rust process error because try_note only trims ASCII target quotes; Java uses cleanId. Preexisting failure, not new regression.',
  'Retained root_class_local_note, root_note_local_class and null_separator_lookup remain explicit whole-case failures. Rooted CommandLinkClass multipass side-effect allocation remains unresolved; no synthetic fix or waiver.'
 ]),
 'class-note-url-command-lifecycle':('d3dc83434df9ad36f7c0a505eb341b53807db1b6',[
  'Single-line attached-note URL discard and multiline creation follow CommandFactoryNoteOnEntity; lone note anchor follows EntityImageNote.drawU and Entity.addUrl replacement. Fresh implicit targets, note target, end-note/braced form, topurl/target/tooltip replacement controls pass as whole cases.',
  'N1: n_multiline_quoted_url retains href “docs rather than Java docs with spaces. The note keeps the right UID and tooltip, but try_note calls the old split-on-space parse/mod.rs::extract_link_url rather than UrlBuilder grammar. This preexisting sibling lifecycle defect remains a whole-SVG failure.',
  'N2: n_group_single and n_group_multi have correct absence/presence of anchors but remain305x199 versus301x199 with different cluster/edge geometry. Retained group_single/group_multi also fail. Bounded ownership cannot waive whole-case geometry; no graph/native work was attempted.',
  'Named-note duplicate and missing-owner controls remain exact error references and are correctly rejected. They are negative validation outcomes, not parity successes.'
 ]),
 'class-fashion-value-digit-semantics':('4bbe21b6ad4428b7dc1166f4081bed4729dfc29d',[
  'ASCII digit/dot extraction, missing0 and present-invalid1.5 follow Style.getShadowing and ValueImpl. Nine of eleven fresh whole cases pass, spanning raw-style booleans, legacy note yes/no, fractional units, malformed spelling, zero, actor/boundary and origin precedence.',
  'F1: f_actor_legacy_yes disproves unconditional legacy yes/no conversion. Java addMagic maps actorShadowing through the knowledge-table branch; convertNow converts only true/false there, bypassing getShadowingValue yes/no fallback, so yes yields1.5. Rust style_shadowing_delta sees only skinparam origin and yields3. Java Reader baseline80.5352 versus82.0352 and viewport102x206 versus102x207. This preexisting defect falsifies the account generalization; it is not labeled a new regression.',
  'F2: f_actor_legacy_negative now aligns actor geometry but lacks Java native-class filter and has102x206 versus102x205 canvas. The retained -2.5 control still fails92x211 versus88x207. has_shadowing_skinparam still tests literal true. Whole-case rejection stands; native scope is not broadened.',
  'No fixture-keyed branch or unexplained new layout constant was found in the scoped diff. That bounded audit and partial gains do not provide acceptance.'
 ])}
commands=['/Users/marcelo/rustuml-reference/bin/reference --cwd PRIVATE_CWD --timezone GMT+11:00 -- -pipe -tsvg',
 'uv run --no-project python /Users/marcelo/Library/Caches/rustuml-review-0423fc37/build.py',
 'uv run --no-project python /Users/marcelo/Library/Caches/rustuml-review-0423fc37/replay.py before',
 'uv run --no-project python /Users/marcelo/Library/Caches/rustuml-review-0423fc37/replay.py after']+[' '.join(g['command']) for g in read(S/'gates.json')]
for mechanism,(account,findings) in accounts.items():
    perturbations=[]
    for row in fresh:
        if row['mechanism']!=mechanism:continue
        outcome=new_by_name[row['name']]
        valid=next(v for v in validation['observations'] if v['name']==row['name'])
        relative=Path('test-diagrams/perturbations')/mechanism/'checker-0423fc37'/row['name']
        perturbations.append(dict(source=str(relative),golden=str(relative.with_suffix('.svg')),axes=row['axes'],result='pass' if outcome['status']=='pass' else 'fail',whole_case_status=outcome['status'],expected_java_valid=row['expected_java_valid'],observed_java_valid=valid['observed_java_valid'],java_exit=valid['exit'],rust_exit=outcome['cli']['exit'],comparison_exit=outcome['comparison']['exit'],invalid_rejected=not valid['observed_java_valid'] and outcome['cli']['exit']!=0,source_sha256=outcome['source_sha256'],java_svg_sha256=outcome['reference_sha256'],evidence_capture=outcome['cli']['capture']))
    record=dict(schema_version=1,mechanism=mechanism,reviewer=reviewer,account_commit=account,implementation_commit='17a3705e17cc79640a1bcfea241b61f9b762d957',candidate_commit='154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc',before_commit='eb09cecbc90f5690c4a09bf49118f2feff8c1c12',java_revision='71806a23780b04a5ccde2f8ceb5121edad5eb711',jar_sha256=validation['environment']['jar_sha256'],commands=commands,command_results=dict(builds=read(S/'build-records.json'),gates=read(S/'gates.json'),replays=[dict(variant=r['variant'],exit=0,binary=r['binary'],binary_sha256=r['binary_sha256'],cohorts=r['cohorts']) for r in [before,after]],remote_reference_exits={r['name']:r['exit'] for r in validation['observations']}),perturbations=perturbations,findings=findings,verdict='rejected',evidence='docs/parity-reviews/class-quark-context-checked-identity/checker-0423fc37',denominators=summary['new_mechanisms'][mechanism],residue=['Whole-case failures reject; bounded DOM/model success never waives geometry.','Logical fonts, rooted CommandLinkClass multipass, TIM nested-quote and o-->>o factory dependencies remain unresolved.','Historical fonts/Graphviz equivalence is not claimed. Separate blocked native review was not retried/replaced.','Earlier chronology defects and original rejection remain unchanged. Git verifies committed ordering, not absence of uncommitted pre-account drafts.','Broad gates ran once before these new records. Red guards are not relabeled as post-record execution. Negative references remain explicit standing failures.'])
    path=R/'docs/parity-reviews'/mechanism/'review.json'
    assert not path.exists()
    path.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')

# Archive only new checker evidence. Existing maker archive is already preserved
# by immutable path/hash in the candidate and is not duplicated or modified.
names=['build.py','fresh.py','integrity.py','validate_reference.py','replay.py','summarize.py','gates.py','package.py','audit.md','build-records.json','integrity.json','supplemental-integrity.json','denominator-provenance.json','summary.json','gates.json','reference-validation.json','reference-results.json','reference-results.json.gz','reference-transport.json','parent-relay-validation.json','fresh-manifest.json','fresh-manifest.json.gz','replay-before.json','replay-after.json','before-build.log','after-build.log']
names += [p.name for p in S.glob('gate-*.log')]
files=[S/n for n in names]
for directory in ['fresh','retained-inputs','replay-before','replay-after']:
    files.extend(p for p in (S/directory).rglob('*') if p.is_file())
files=sorted(files)
manifest=[dict(path=str(p.relative_to(S)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in files]
(S/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=E/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path in files+[S/'evidence-manifest.json']:tar.add(path,arcname=str(path.relative_to(S)),recursive=False)
with tarfile.open(archive) as tar:
    for row in manifest:
        data=tar.extractfile(row['path']).read()
        assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
for name in ['audit.md','summary.json','integrity.json','supplemental-integrity.json','gates.json','reference-validation.json','fresh-manifest.json']:
    shutil.copyfile(S/name,E/name)
(E/'archive-integrity.json').write_text(json.dumps(dict(sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,files_verified=len(manifest),artifact='evidence.tar.gz',maker_archive='docs/parity-reviews/class-quark-context-checked-identity/maker-evidence/packet7/packet7-evidence.tar.gz',maker_archive_sha256='72972d5b8b2033091dc317d23ebb869936c6cd4ab186c12478a9fcdc4927576f',excluded='Private build targets, binary artifacts and git archives; exact build commands/hashes retained. All own capture streams, inputs, references and full models are included.'),indent=2)+'\n')
print('archive',archive.stat().st_size,'members',len(manifest),'hash',sha(archive.read_bytes()))
print('new reviews',len(accounts),'sources',len(fresh),'prior rejection files checked',len(historical_import),'failure files',failures)
