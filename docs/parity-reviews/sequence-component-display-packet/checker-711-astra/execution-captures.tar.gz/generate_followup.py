# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import base64,hashlib,json,pathlib
O=pathlib.Path(__file__).parent; orig=json.loads((O/'relay-manifest.json').read_text()); cases=[]
a='sequence-dressing-owned-parts';c='sequence-created-image-event-ownership';d='sequence-complete-participant-display'
bodies=[('ordinary_forward',r'''participant Juniper
participant Mica
Juniper <-/ Mica: half normal
Juniper <<-\\ Mica: open mix
Juniper o<-/o Mica: circles''',[a],['normal/open/circle/half','ordinary forward']),('ordinary_reverse',r'''participant Mica
participant Juniper
Juniper <-/ Mica: half normal
Juniper <<-\\ Mica: open mix
Juniper o<-/o Mica: circles''',[a],['normal/open/circle/half','declaration reversal']),('blank_stripes',r'''participant "\n\n" as P
queue "\n" as Q
P -> Q: blank stripe controls''',[d],['present blank stripes','participant/queue']),('space_display',r'''participant " " as P
queue " " as Q
P -> Q: whitespace display''',[d],['single whitespace stripe','participant/queue']),('firststripe_size',r'''queue "<size:25>First</size>\nsecond" as Q
actor "<size:21>First</size>\nsecond" as A
participant "<size:18>First</size>\nsecond" as P
Q -> A: relay
A -> P: forward''',[d],['large first stripe/baseline','mixed queue/actor/participant']),('pending_overwrite',r'''participant Sender
participant Lost
participant Kept
create Lost
create Kept
Sender -> Kept: attached
Sender -> Lost: ordinary''',[c],['two different pending CREATEs','overwrite/order'])]
for stem,body,mechanisms,axes in bodies:
 for engine in ['legacy','teoz']:
  name='review711b_'+stem+'_'+engine;data=('@startuml\n'+('!pragma teoz true\n' if engine=='teoz' else '')+body+'\n@enduml\n').encode();p=O/'fresh-inputs'/(name+'.puml');p.write_bytes(data)
  cases.append(dict(name=name,path=str(p),source='test-diagrams/perturbations/sequence-component-display-review711/'+name+'.puml',golden='test-diagrams/perturbations/sequence-component-display-review711/'+name+'.svg',source_sha256=hashlib.sha256(data).hexdigest(),source_b64=base64.b64encode(data).decode(),source_bytes=len(data),mechanisms=mechanisms,axes=axes+['engine='+engine],intended_validity='valid',resources=[]))
m={k:v for k,v in orig.items() if k!='cases'};m['request_id']='sequence-review711b-5c023380';m['cases']=cases;p=O/'relay-followup-manifest.json';p.write_text(json.dumps(m,separators=(',',':'))+'\n');p.chmod(0o444);print(len(cases),hashlib.sha256(p.read_bytes()).hexdigest())
