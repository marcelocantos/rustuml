# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,collections,re,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent
COHORTS=json.loads((S/'cohorts.json').read_text())+['consumer16','full-golden']
def parse(b):
 return ET.fromstring(b,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)))
def projection(n):
 return (str(n.tag),sorted(n.attrib.items()),n.text,n.tail,[projection(c) for c in n])
results=[];changed=[]
for cohort in COHORTS:
 before=json.loads((S/(cohort+'-before.json')).read_bytes());after=json.loads((S/(cohort+'-after.json')).read_bytes());members=json.loads((S/(cohort+'-membership.json')).read_bytes())
 assert len(before)==len(after)==len(members)
 losses=[];gains=[];new_errors=[];new_panics=[];modelbytes=[];counts=collections.Counter()
 for b,a,m in zip(before,after,members):
  assert b['id']==a['id']==m['id'];id=a['id'];old=S/'replay/before'/id;new=S/'replay/after'/id
  if b['svg_match'] and not a['svg_match']:losses.append(id)
  if not b['svg_match'] and a['svg_match']:gains.append(id)
  if b['svg']['exit']==0 and a['svg']['exit']!=0:new_errors.append(id)
  if not b['panic'] and a['panic']:new_panics.append(id)
  if (old/'yaml.stdout').read_bytes()!=(new/'yaml.stdout').read_bytes():modelbytes.append(id)
  x=(old/'svg.stdout').read_bytes();y=(new/'svg.stdout').read_bytes()
  if x==y:continue
  row=dict(id=id,cohort=cohort,before_pass=b['svg_match'],after_pass=a['svg_match'],source=m['source_capture'],reference=m['golden_capture'],before_sha=b['svg']['stdout_sha256'],after_sha=a['svg']['stdout_sha256'])
  def elements(data):return ET.fromstring(re.sub(rb'<!--[\s\S]*?-->',b'',data))
  try:
   xr=parse(x);yr=parse(y);same=projection(xr)==projection(yr);row['decoded_xml_equivalent']=same
   xe=list(elements(x).iter());ye=list(elements(y).iter());row['element_count_before']=len(xe);row['element_count_after']=len(ye)
   row['comments_before']=[v.decode('utf8','replace') for v in re.findall(rb'<!--(.*?)-->',x,re.S)];row['comments_after']=[v.decode('utf8','replace') for v in re.findall(rb'<!--(.*?)-->',y,re.S)]
   changes=[]
   if len(xe)==len(ye):
    for i,(u,v) in enumerate(zip(xe,ye)):
     if u.tag!=v.tag or u.text!=v.text or u.tail!=v.tail:changes.append(dict(index=i,kind='tag/text/tail',before=[str(u.tag),u.text,u.tail],after=[str(v.tag),v.text,v.tail]))
     for k in sorted(u.attrib.keys()|v.attrib.keys()):
      if u.get(k)!=v.get(k):changes.append(dict(index=i,kind='attribute',attribute=k,before=u.get(k),after=v.get(k)))
   row['decoded_changes']=changes
   if same:row['cause']='XML-equivalent re-encoding'
   elif len(xe)!=len(ye):row['cause']='element count change: inspect'
   elif not changes:row['cause']='comment consumer identity/producer'
   elif all(v['kind']=='attribute' and v['attribute'] in ['fill','fill-opacity'] for v in changes):row['cause']='state fill selection/serialization'
   else:row['cause']='other decoded change: inspect'
   ref=Path(m['golden_capture']).read_bytes();row['before_bytes_match_java']=x==ref;row['after_bytes_match_java']=y==ref
  except ET.ParseError as e:
   row['cause']='malformed output retained; comment-only delta' if re.sub(rb'<!--[\s\S]*?-->',b'',x)==re.sub(rb'<!--[\s\S]*?-->',b'',y) else 'XML parse transition: inspect';row['parse_error']=str(e)
  counts[row['cause']]+=1;changed.append(row)
 results.append(dict(cohort=cohort,entries=len(before),valid=sum(a['reference_valid'] for a in after),before_pass=sum(b['svg_match'] for b in before),after_pass=sum(a['svg_match'] for a in after),losses=losses,gains=gains,new_errors=new_errors,new_panics=new_panics,before_panics=sum(b['panic'] for b in before),after_panics=sum(a['panic'] for a in after),yaml_byte_changes=modelbytes,byte_change_categories=dict(counts)))
 print(cohort,results[-1]['before_pass'],results[-1]['after_pass'],'losses',len(losses),'changes',dict(counts),'models',len(modelbytes),flush=True)
(S/'comparison-summary.json').write_text(json.dumps(results,indent=2)+'\n');(S/'changed-outputs.json').write_text(json.dumps(changed,indent=2)+'\n')
