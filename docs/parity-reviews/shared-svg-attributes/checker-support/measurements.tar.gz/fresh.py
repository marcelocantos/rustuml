# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import base64, gzip, hashlib, json
from pathlib import Path
S=Path(__file__).parent
N=S/'new'; N.mkdir(exist_ok=True)
sha=lambda b: hashlib.sha256(b).hexdigest()
def wrap(fam,label,config=''):
    bodies={
      'activity':('uml',f'start\n:{label};\nstop'),
      'class':('uml',f'class Vault {{\n{label}\n}}'),
      'state':('uml',f'state Chamber\nChamber : {label}'),
      'deployment':('uml',f'node "{label}" as Hub\nartifact Store\nHub --> Store'),
      'component':('uml',f'component "{label}" as Core\ncomponent Tail\nCore --> Tail'),
      'usecase':('uml',f'usecase "{label}" as Goal\nactor Visitor\nVisitor --> Goal'),
      'object':('uml',f'object Vault {{\nslot = {label}\n}}'),
      'archimate':('uml',f'archimate #Business "{label}" as Ledger'),
      'gantt':('gantt',f'Project starts 2025-02-03\n[{label}] lasts 3 days'),
      'timing':('uml',f'robust "{label}" as Track\n@0\nTrack is low\n@30\nTrack is high'),
      'mindmap':('mindmap',f'* Root\n** {label}'),
      'wbs':('wbs',f'* Root\n**_ {label}\n*** Leaf'),
      'salt':('salt',f'{{\n{label}\n[Confirm]\n}}'),
      'json':('json',json.dumps({'slot':label},ensure_ascii=False)),
      'nwdiag':('nwdiag',f'nwdiag {{\nnetwork bridge {{\naddress = "{label}";\nnode1;\n}}\n}}'),
      'regex':('regex',f'(?<probe>{label})+')}
    kind,body=bodies[fam]
    return f'@start{kind}\n{config}{body}\n@end{kind}\n'
families=['activity','class','state','deployment','component','usecase','object','archimate','gantt','timing','mindmap','wbs','salt','json','nwdiag','regex']
rows=[]
def add(name,source,mechanism,axes,negative=False):
    p=N/(name+'.puml'); p.write_bytes(source.encode('utf-8'))
    rows.append(dict(source=str(p),mechanism=mechanism,axes=axes,cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=negative,intended_validity='negative character/export probe' if negative else 'intended_valid'))
for i,f in enumerate(families):
    family=['"Quill & Reed"','  Quill\'"Reed"\'  ','Quill<Reed>é𐐀'][i%3]
    add('family_'+f,wrap(f,'Beacon','skinparam defaultFontName '+family+'\n'),'shared-svg-attributes',[f,'skinparam font-family quoting/padding/non-ASCII'])
    label='L<color:#3579bd00><back:#e73>Veil</back></color>R'
    add('transparent_'+f,wrap(f,label),'transparent-text-emission',[f,'zero alpha inside mixed runs with background'])
    label='L<back:transparent>Mist</back>R'
    add('back_'+f,wrap(f,label),'shared-svg-color',[f,'transparent background with opaque foreground'])
# Shared and family-direct hyperlink emitters, whitespace and entity spellings.
chars={'ascii':'&<>\"\'','tab':'\t','cr':'\r','lf':'\n','nbsp':'\u00a0','bmp':'éΩ','scalar':'𐐀🦋','entity':'&amp;&#34;'}
for (axis,ch),fam in zip(chars.items(),['activity','class','state','object','mindmap','wbs','salt','usecase']):
    # The <U+...> path deliberately creates LF/CR in the model rather than breaking a source command.
    value=''.join(f'<U+{ord(c):04X}>' if c in '\r\n' else c for c in ch)
    add('link_'+axis,wrap(fam,'[[https://example.invalid/p?x=2&y=3{Glow'+value+'Dusk}Link]]'),'shared-svg-attributes',[fam,'tooltip '+axis])
for axis,ch in [('amp','&'),('angles','<>'),('quote','"'),('tab','\t'),('c0','\x02'),('unicode','é𐐀')]:
    label=f'[[https://example.invalid/a{ch}b{{Hint}}Link]]'
    add('href_'+axis,wrap('activity',label),'shared-svg-attributes',['activity','URL '+axis],axis=='c0')
for fam,decl in [('class','class'),('state','state'),('component','component'),('deployment','node'),('usecase','usecase'),('object','object')]:
    add('identity_'+fam,f'@startuml\n{decl} "Delta & <Q> é𐐀"\n@enduml\n','shared-svg-attributes',[fam,'unaliased entity name to IDs/data-qualified-name/comments'])
add('comment_double_hyphen','@startuml\nclass "Double--Tail-"\n@enduml\n','shared-svg-attributes',['class','comment delimiter inside entity name'])
for name,color in [('nibble','d'),('short','#9e2'),('full','#a1B2c3'),('named','BUSINESS'),('hashnamed','#red'),('alpha01','#3579bd01'),('alpha80','#3579bd80'),('alphaff','#3579bdff'),('background','background'),('transparent','transparent')]:
    add('paint_'+name,wrap('activity',f'A<color:{color}>Bee</color>C<back:{color}>Dee</back>E'),'shared-svg-color',['activity','foreground/background '+name])
add('paint_nested',wrap('class','A<color:#3579bd80>B<color:#red>C</color>D<font color=#3579bd01>E</font>F</color>G'),'shared-svg-color',['class member','nested alpha restoration and combined font'])
add('shape_alpha','@startuml\nskinparam stateBackgroundColor #3579bd80\nskinparam stateBorderColor #9e2\nstate Quartz\n@enduml\n','shared-svg-color',['state shape','alpha fill plus short stroke'])
add('shape_quoted','@startuml\nskinparam stateBackgroundColor "&é\nstate Quartz\n@enduml\n','shared-svg-attributes',['state shape','invalid raw skinparam attribute'],True)
for col in ['#000000','#ffffff']:
    add('automatic_'+col[1:],wrap('activity','A<color:automatic>Bee</color>C','skinparam backgroundColor '+col+'\n'),'shared-svg-color',['activity','automatic background inversion'])
for n,ch in [('zero','\x00'),('escape','\x1b'),('one','\x01')]:
    add('raw_c0_'+n,wrap('activity','[[https://example.invalid/p{Glow'+ch+'Dusk}Link]]'),'shared-svg-attributes',['activity','raw control tooltip '+n],True)
manifest=json.dumps(rows,indent=2)+'\n'; (S/'manifest.json').write_text(manifest)
resources=[dict(local_path=r['source'],remote_relative_path='new/'+Path(r['source']).name,sha256=sha(Path(r['source']).read_bytes()),bytes=Path(r['source']).stat().st_size) for r in rows]
request=dict(manifest_path=str(S/'manifest.json'),manifest_sha256=sha(manifest.encode()),case_count=len(rows),resources=resources,wrapper='/Users/marcelo/rustuml-reference/bin/reference',java_revision='71806a23780b04a5ccde2f8ceb5121edad5eb711',jar_sha256='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053',case_contracts=[dict(source=r['source'],source_sha256=q['sha256'],cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']) for r,q in zip(rows,resources)],output_contract='All raw stdout/stderr/statuses including invalids, exceptions, welcome and zero bytes; exact cwd/TZ/env/wrapper argv, pinned environment, Java argv derived from wrapper, not process traced. SVG only; do not normalize source.')
(S/'request.json').write_text(json.dumps(request,indent=2)+'\n')
files=[dict(local_path=r['local_path'],remote_relative_path=r['remote_relative_path'],sha256=r['sha256'],base64=base64.b64encode(Path(r['local_path']).read_bytes()).decode()) for r in resources]
(S/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=request,manifest=rows,files=files)).encode(),mtime=0))
for p in [S/'request.json',S/'manifest.json',S/'input-bundle.json.gz']:
    print(str(p),sha(p.read_bytes()))
print('cases',len(rows))
