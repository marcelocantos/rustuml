# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import base64, gzip, hashlib, json
from pathlib import Path
S=Path(__file__).parent
M=S.parent/'rustuml-comment-state-consumers-maker'
N=S/'new';N.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
def add(name,body,mechanism,axes):
    p=N/(name+'.puml');data=('@startuml\n'+body+'\n@enduml\n').encode()
    assert not p.exists()
    assert not any(0xe000<=ord(c)<=0xe0ff or (ord(c)<32 and c not in '\n\t\r') for c in data.decode())
    p.write_bytes(data)
    rows.append(dict(source=str(p),mechanism=mechanism,axes=axes,cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=False,intended_validity='intended_valid; classify raw Java independently'))
comments={
'class_alias_bidirectional':'class "Copper Lantern" as Lantern\ninterface "Glass Beacon" as Beacon\nLantern --> Beacon\nLantern <.. Beacon',
'class_quoted_spaces':'class "North Atrium"\nclass "South Gallery"\n"North Atrium" --> "South Gallery"',
'class_namespace_default':'namespace Observatory {\nclass "Bright Star" as Sirius\nnamespace Dome {\nclass "Night Lens" as Lens\n}\nSirius --> Dome.Lens\n}',
'class_groups_bidirectional':'package "Silver Hall" as Hall {\nclass Seat\n}\npackage "Bronze Wing" as Wing {\nclass Desk\n}\nHall --> Wing\nHall <.. Wing',
'class_nested_default':'package "Upper Place" as Upper {\npackage "Middle Place" as Middle {\nclass "Hidden Leaf" as Leaf\n}\nclass "Visible Branch" as Branch\nMiddle.Leaf --> Branch\n}',
'class_custom_separator_residue':'set namespaceSeparator ::\npackage "West Roof" as West {\npackage "Inner Bay" as Bay {\nclass "Copper Tile" as Tile\n}\n}',
'class_object_mixed':'class "Drawn Class" as Cobalt\nobject "Stored Value" as Value\ninterface "Drawn Port" as Port\nCobalt --> Value\nValue --> Port',
'object_quoted_admission':'object "North Fixture"\nobject "South Fixture"\n"North Fixture" --> "South Fixture"',
'deploy_alias_collision':'node "Copper Bay" as Copper_Bay\nnode "Far Pier" as Pier\nCopper_Bay --> Pier\nCopper_Bay <.. Pier',
'deploy_raw_spaces':'node "Copper Bay"\nnode "Far Pier"\n"Copper Bay" --> "Far Pier"',
'deploy_nested_groups':'node "Upper Vault" as Vault {\nnode "Inner Cage" as Cage {\nartifact "Glass Key" as Key\n}\n}\nnode "Remote Pier" as Pier {\nartifact Lock\n}\nVault --> Pier\nCage <.. Pier',
'description_kinds':'actor "Sea Pilot" as Pilot\nusecase "Read Compass" as Compass\ncomponent "Signal Box" as Signal\nPilot --> Compass\nCompass <.. Signal',
'description_namespace':'package "Radio Rooms" as Radio {\ncomponent "North Dial" as Dial\npackage "Quiet Room" as Quiet {\ncomponent "Long Wave" as Wave\n}\nDial --> Quiet.Wave\n}',
'state_root_nested_identity':'state "Public Harbor" as Harbor {\nstate "Inner Dock" as Dock {\nstate "Private Berth" as Berth\n}\nstate "Open Water" as Water\nDock --> Water\n}\nstate "Other Harbor" as Other {\nstate Pier\n}\nHarbor --> Other',
'state_history_nested_identity':'state "Top Display" as Top {\nstate "Lower Display" as Lower {\n[*] --> [H]\n[H] --> First\nFirst --> [H*]\n[H*] --> Last\n}\n}',
'activity_alias_linear':'(*) --> "Check copper" as Check\nCheck --> "Release silver" as Release\nRelease --> (*)',
'activity_unicode_right':'(*) --> "Étage Nord"\n-right-> "Übung Süd"\n--> (*)',
'activity_unicode_left':'(*) --> "Étage Nord"\n-left-> "Übung Süd"\n--> (*)',
'activity_unicode_up':'(*) -up-> "Étage Nord"\n-up-> "Übung Süd"\n-up-> (*)',
'activity_partition':'partition "Copper Room" {\n(*) --> "Weigh brass"\n--> "Polish silver"\n--> (*)\n}',
'activity_named_end':'(*) --> "Inspect amber"\n--> (*Z)',
'activity_groups':'partition "West Bench" {\n(*) --> "Turn wheel"\n}\npartition "East Bench" {\n--> "Read gauge"\n--> (*)\n}',
}
for name,body in comments.items():
    mechanism='missing-comments' if name.startswith('activity_') else 'comment-identity'
    if name.startswith('state_'):mechanism='missing-comments'
    add(name,body,mechanism,['identifier provenance/alias collision/quoted local name','namespace depth/group endpoints/direction/producer document position'])
colors={'transparent':'transparent','named':'DarkSlateBlue','unknown':'NoSuchHarborColor','a00':'#7a3c9100','a01':'#7a3c9101','a7f':'#7a3c917f','afe':'#7a3c91fe','aff':'#7a3c91ff','short':'#7c9'}
shapes={
'simple':'state "Harbor Empty" as Empty\nstate "Harbor Body" as Body\nBody : cargo manifest\nEmpty --> Body',
'composite':'state "Harbor Box" as Harbor {\nstate Empty\nstate Body : cargo manifest\nEmpty --> Body\n}\nHarbor : port authority',
'concurrent':'state "Twin Harbor" as Harbor {\nstate West\n--\nstate East : cargo manifest\n}\nHarbor : port authority',
'choice':'state Empty <<choice>>\nstate Body <<choice>>\nBody : choose berth\nEmpty --> Body',
'fork':'state Empty <<fork>>\nstate Body <<fork>>\nBody : split cargo\nEmpty --> Body',
'join':'state Empty <<join>>\nstate Body <<join>>\nBody : merge cargo\nEmpty --> Body',
'history':'state Empty <<history>>\nstate Body <<history>>\nBody : resume berth\nEmpty --> Body',
'deep_history':'state Empty <<history*>>\nstate Body <<history*>>\nBody : resume deep berth\nEmpty --> Body',
}
for color,value in colors.items():
    for shape,body in shapes.items():
        add('paint_'+shape+'_'+color,'skinparam stateBackgroundColor '+value+'\n'+body,'state-paint',['fill '+color+' across state kind '+shape,'paired description presence and alias/display mismatch'])
manifest=json.dumps(rows,indent=2).encode()+b'\n';(S/'manifest.json').write_bytes(manifest)
resources=[dict(local_path=str(p),remote_relative_path='new/'+p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(N.glob('*.puml'))]
request=json.loads((M/'request.json').read_bytes())
request.update(manifest_path=str(S/'manifest.json'),manifest_sha256=sha(manifest),case_count=len(rows),resources=resources,case_contracts=[dict(source=r['source'],source_sha256=sha(Path(r['source']).read_bytes()),cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']) for r in rows])
(S/'request.json').write_text(json.dumps(request,indent=2)+'\n')
files=[dict(local_path=r['local_path'],remote_relative_path=r['remote_relative_path'],sha256=r['sha256'],base64=base64.b64encode(Path(r['local_path']).read_bytes()).decode()) for r in resources]
(S/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=request,manifest=rows,files=files)).encode(),mtime=0))
prior={sha(p.read_bytes()) for p in Path.cwd().glob('test-diagrams/perturbations/**/*.puml')}
assert not any(r['sha256'] in prior for r in resources)
for p in [S/'manifest.json',S/'request.json',S/'input-bundle.json.gz']:
    p.chmod(0o444);print(str(p),sha(p.read_bytes()))
for p in N.glob('*.puml'):p.chmod(0o444)
print('cases',len(rows),'prior exact-source overlaps',0)
