# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
import yaml
s=Path(__file__).resolve().parent;a=s/'maker-archive';root=Path.cwd();mode=sys.argv[1];sha=lambda b:hashlib.sha256(b).hexdigest();env=dict(os.environ,PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib',RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100');comparator=Path('/Users/marcelo/Library/Caches/rustuml-class-cff4/check_svg');assert sha(comparator.read_bytes())=='0e368102f36bfbc59efe141286df5935b785535db6c0cf537bdbadc9350f21cd'
class Loader(yaml.SafeLoader):pass
Loader.add_multi_constructor('',lambda loader,suffix,node:{suffix:loader.construct_scalar(node)} if isinstance(node,yaml.ScalarNode) else loader.construct_sequence(node) if isinstance(node,yaml.SequenceNode) else loader.construct_mapping(node))
if mode=='historical':
 snap=json.loads((a/'input-reference-snapshot.json').read_text());after=json.loads((a/'final1826.json').read_text())['results']+json.loads((a/'final25.json').read_text())['results'];before=json.loads((a/'before1826.json').read_text())['results']+json.loads((a/'fresh25before.json').read_text())['results'];models=json.loads((a/'model-retention.json').read_text())['cases'];cwd=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-cff2cd0e');items=[]
 for i,(r,exp,m) in enumerate(zip(snap,after,models)):
  source=Path(exp['commands'][0][2]);ref=source.with_suffix('.svg');assert sha(source.read_bytes())==r['source_blob']==exp['source_sha256'];assert sha(ref.read_bytes())==r['reference_blob']==exp['java_sha256'];items.append(dict(index=i,source=str(source),cohort=r['cohort'],before=before[i],after=exp,model=m))
else:
 manifests=[json.loads((s/'fresh-manifest.json').read_text()),json.loads((s/'supplement-manifest.json').read_text())];items=[dict(index=i,**r,cohort='checker33') for i,r in enumerate([r for m in manifests for r in m['inputs']])];cwd=root
out=s/('replay-'+mode);out.mkdir(exist_ok=True)
def run(cmd):
 try:
  p=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,timeout=60);return p.returncode,p.stdout,p.stderr
 except subprocess.TimeoutExpired as e:return 124,e.stdout or b'',(e.stderr or b'')+b'CHECKER_TIMEOUT'
def dom(raw):
 try:r=ET.fromstring(raw)
 except ET.ParseError:return None
 objs=[]
 def visit(e,owner=None):
  if e.get('class') in ['entity','cluster']:
   owner=e.get('id');objs.append({'class':e.get('class'),'id':owner,'name':e.get('data-qualified-name'),'source_line':e.get('data-source-line'),'urls':[]})
  if e.tag.endswith('}a'):
   link={k:v for k,v in e.attrib.items()};link['owner']=owner
   if owner:
    for ob in reversed(objs):
     if ob['id']==owner:ob['urls'].append(link);break
  for child in e:visit(child,owner)
 visit(r);return {'width':r.get('width'),'height':r.get('height'),'objects':objs}
def one(item):
 i=item['index'];p=Path(item['source']);ref=p.with_suffix('.svg');row={k:v for k,v in item.items() if k not in ['before','after','model','source_base64']};row.update(source_sha256=sha(p.read_bytes()),java_sha256=sha(ref.read_bytes()),java_dom=dom(ref.read_bytes()));
 for variant in ['before','after']:
  binary=s/('target-'+variant)/'release/rustuml';stem=out/f'{i:04d}-{p.stem}.{variant}';cmds=[[str(binary),'-tsvg',str(p)],[str(binary),'--yaml',str(p)]];v={}
  for label,cmd,ext in zip(['cli','yaml'],cmds,['svg','yaml']):
   code,stdout,stderr=run(cmd);capture=Path(str(stem)+'.'+ext);capture.write_bytes(stdout);Path(str(capture)+'.stderr').write_bytes(stderr);v[label]={'command':cmd,'exit':code,'sha256':sha(stdout),'stderr_sha256':sha(stderr),'capture':str(capture.relative_to(s))}
   if label=='cli':v['dom']=dom(stdout)
   if label=='yaml' and code==0:
    data=yaml.load(stdout,Loader=Loader);d=data['diagram'];v['model']={'type':data['type'],'counts':{k:len(d.get(k,[])) for k in ['entities','packages','notes','relationships','uid_events']},'objects':{k:d.get(k,[]) for k in ['entities','packages','notes','relationships']},'uid_events':d.get('uid_events',[])}
  cmd=[str(comparator),str(ref),str(stem)+'.svg'];code,stdout,stderr=run(cmd);Path(str(stem)+'.diff.txt').write_bytes(stdout);Path(str(stem)+'.diff.stderr').write_bytes(stderr);v['comparison']={'command':cmd,'exit':code,'sha256':sha(stdout),'stderr_sha256':sha(stderr)};v['status']='invalid_reference' if code==2 else 'process_error' if v['cli']['exit'] else 'pass' if code==0 else 'mismatch' if code==1 else 'comparison_error'
  if mode=='historical':
   expected=item[variant];v['maker_status_agrees']=v['status']==expected['status'] and v['cli']['exit']==expected['cli']['exit'] and code==expected['comparison']['exit'];e=item['model'][variant];v['maker_yaml_agrees']=v['yaml']['sha256']==e['sha256'] and v['yaml']['exit']==e['exit']
   old_cli=Path(expected['commands'][2][2]);v['maker_svg_sha256']=sha(old_cli.read_bytes()) if old_cli.exists() else None;v['maker_svg_agrees']=v['cli']['sha256']==v['maker_svg_sha256']
  row[variant]=v
 return row
start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(one,items))
from collections import Counter
report={'mode':mode,'cwd':str(cwd),'environment':{k:env[k] for k in ['PLANTUML_STDLIB','RUSTUML_DEBUG']},'seconds':time.time()-start,'binary_hashes':{v:sha((s/('target-'+v)/'release/rustuml').read_bytes()) for v in ['before','after']},'comparator_sha256':sha(comparator.read_bytes()),'counts':{v:dict(Counter(r[v]['status'] for r in rows)) for v in ['before','after']},'results':rows};(s/('replay-'+mode+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(report['counts'],flush=True)
