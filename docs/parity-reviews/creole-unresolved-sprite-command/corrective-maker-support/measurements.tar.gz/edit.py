# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
p=Path('crates/rustuml-render/src/creole.rs');s=p.read_text();old='''                let (tag, found_close) = collect_until_char_checked(&mut chars, '>');
                if !found_close {
                    // No matching `>` — treat the `<` and the rest as literal
                    // characters (e.g. `[count < 3]` guard expressions).
                    buf.push('<');
                    buf.push_str(&tag);
                    last_char = tag.chars().last().or(Some('<'));
                } else {
                    flush_buf!();
                    handle_tag(&tag, &mut chars, style, skip_underline, out);
                    last_char = None; // tag content already emitted
                }''';new='''                // StripeSimple.searchCommand/modifyStripe: an unrecognized
                // candidate consumes only one literal character. In particular,
                // an outer unknown `<` must not hide an inner sprite command.
                let mut candidate = chars.clone();
                let (tag, found_close) = collect_until_char_checked(&mut candidate, '>');
                if found_close {
                    flush_buf!();
                }
                if found_close && handle_tag(&tag, &mut candidate, style, skip_underline, out) {
                    chars = candidate;
                    last_char = None;
                } else {
                    buf.push('<');
                    last_char = Some('<');
                }''';assert old in s;s=s.replace(old,new)
start=s.index('fn handle_tag(');end=s.index('/// Helper that pushes',start);piece=s[start:end];piece=piece.replace(') {\n    match tag {',') -> bool {\n    match tag {',1);piece=piece.replace('''        _ => {
            // Unknown tag — emit literally.
            push_literal(out, &format!("<{tag}>"), style);
        }
    }
}''','''        _ => return false,
    }
    true
}''');s=s[:start]+piece+s[end:];p.write_text(s)
p=Path('crates/rustuml-render/src/text_render.rs');s=p.read_text();s=s.replace('''    let segments = if base.skip_underline {
        creole::parse_segments_no_underline(&content)
    } else {
        creole::parse_segments(&content)
    };''','''    let segments = line_segments(&content, base.skip_underline);''');s=s.replace('''    let mut segments = if base.skip_underline {
        creole::parse_segments_no_underline(&content)
    } else {
        creole::parse_segments(&content)
    };''','''    let mut segments = line_segments(&content, base.skip_underline);''');s=s.replace('let segments = creole::parse_segments(content);','let segments = line_segments(content, false);')
pos=s.index('/// Emit one or more')
s=s[:pos]+'''/// Project an actual text line, including a present empty line. Absent
/// displays are handled by callers before asking to measure or paint a line;
/// lexical `creole::parse_segments` deliberately keeps its zero-atom result.
fn line_segments(content: &str, skip_underline: bool) -> Vec<Segment> {
    let mut segments = if skip_underline {
        creole::parse_segments_no_underline(content)
    } else {
        creole::parse_segments(content)
    };
    if segments.is_empty() {
        // StripeSimple.getAtoms inserts a space after recursive commands have
        // restored the surrounding configuration, also for an ordinary blank.
        segments.push(Segment {
            text: " ".to_string(),
            style: Style::default(),
        });
    }
    segments
}

'''+s[pos:];p.write_text(s)
p=Path('crates/rustuml-render/src/wbs.rs');s=p.read_text();a=s.index('const PAD_X:');b=s.index('const MARGIN:',a);s=s[:a]+'''// plantuml.skin wbsDiagram Padding 10; SheetBlock1 uses the same padding
// for preferred dimensions and painting (FtileBoxOld.createWbs).
const PAD_X: f64 = 10.0;
'''+s[b:];s=s.replace('    text_w: f64,\n    main_w: f64,','    main_w: f64,\n    main_h: f64,\n    text_baseline: f64,');s=s.replace('''    let text_w = pm::text_width(&node.label, FONT_SIZE, false);
    let main_w = text_w + PAD_X * 2.0;''','''    // FtileBoxOld measures and draws the same Creole SheetBlock. Keep the
    // semantic run projection identical to emit_box, including consumed
    // commands and styled font sizes; layout only sees its preferred size.
    let main_w = text_render::measure(&node.label, FONT_SIZE, false) + PAD_X * 2.0;
    let main_h = text_render::label_height(&node.label, FONT_SIZE) + PAD_X * 2.0;
    let text_baseline = PAD_X
        + text_render::label_first_baseline_ascent_with_family(
            &node.label,
            FONT_SIZE,
            "sans-serif",
        );''');s=s.replace('(main_w, BOX_H)','(main_w, main_h)').replace('let h = BOX_H +','let h = main_h +');s=s.replace('        text_w,\n        main_w,','        main_w,\n        main_h,\n        text_baseline,');s=s.replace('h = pm::fmt_coord(BOX_H)','h = pm::fmt_coord(node.main_h)').replace('    let _ = node.text_w; // width is recomputed inside emit_text via the segmenter\n','').replace('y: y + TEXT_BASELINE','y: y + node.text_baseline');s=s.replace('let mut last_y1 = BOX_H','let mut last_y1 = node.main_h').replace('let mut last_y2 = BOX_H','let mut last_y2 = node.main_h').replace('let mut y = BOX_H','let mut y = node.main_h').replace('y = BOX_H','y = node.main_h').replace('oy + BOX_H','oy + node.main_h').replace('        BOX_H / 2.0','        self.main_h / 2.0').replace('let y0 = BOX_H','let y0 = root.main_h');assert 'BOX_H' not in s and 'TEXT_BASELINE' not in s;p.write_text(s)
