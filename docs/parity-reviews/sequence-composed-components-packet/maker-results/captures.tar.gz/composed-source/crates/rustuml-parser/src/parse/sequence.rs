// Copyright 2026 Marcelo Cantos
// SPDX-License-Identifier: Apache-2.0

//! Sequence diagram parser.
//!
//! Parses preprocessed lines into a `SequenceDiagram` model.

use std::sync::LazyLock;

use regex::{Match, Regex};

use super::ParseError;
use crate::diagram::DiagramMeta;
use crate::diagram::sequence::*;

static INLINE_ARROW_STYLE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r"\[((?:#\w+|(?i:dashed|dotted|hidden|bold))(?:,(?:#\w+|(?i:dashed|dotted|hidden|bold)))*)\]",
    )
    .unwrap()
});

static MESSAGE_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r#"^("(?:[^"]+)"|\w+)\s*([-<>.\\/ox]*(?:\[(?:(?:#\w+|(?i:dashed|dotted|hidden|bold))(?:,(?:#\w+|(?i:dashed|dotted|hidden|bold)))*)\])?[-<>.\\/ox]+)\s*("(?:[^"]+)"|\w+)\s*(?:((?:\+\+|--|!!))\s*(#\S+)?\s*)?(?::\s*(.*))?$"#,
    )
    .unwrap()
});

static EXTERNAL_MESSAGE_IN_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r"^([\[\]])([-<>.\\/ox]*(?:\[(?:(?:#\w+|(?i:dashed|dotted|hidden|bold))(?:,(?:#\w+|(?i:dashed|dotted|hidden|bold)))*)\])?[-<>.\\/ox]+)\s*(\w+)\s*(?:((?:\+\+|--|!!))\s*(#\S+)?\s*)?(?::\s*(.*))?$",
    )
    .unwrap()
});

static EXTERNAL_MESSAGE_OUT_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(
        r"^(\w+)\s*([-<>.\\/ox]*(?:\[(?:(?:#\w+|(?i:dashed|dotted|hidden|bold))(?:,(?:#\w+|(?i:dashed|dotted|hidden|bold)))*)\])?[-<>.\\/ox]+)([\[\]])\s*(?:((?:\+\+|--|!!))\s*(#\S+)?\s*)?(?::\s*(.*))?$",
    )
    .unwrap()
});

/// Parse preprocessed lines into a sequence diagram.
pub fn parse_sequence(lines: &[String]) -> Result<SequenceDiagram, ParseError> {
    let mut parser = SeqParser::new();

    for (i, line) in lines.iter().enumerate() {
        let (source_line, trimmed) = super::source_line_and_trimmed(i + 1, line);
        let in_note = parser.note_buffer.is_some();
        if trimmed.is_empty() && !in_note {
            continue;
        }
        let text = if in_note {
            super::source_text(line)
        } else {
            trimmed
        };
        parser.parse_line(source_line, text)?;
    }

    validate_return_destinations(&parser.events)?;
    Ok(parser.finish())
}

/// Bounded factory viability for recognized decorated messages. Java's
/// PSystemBuilder tries Sequence before Class; PSystemCommandFactory rejects a
/// candidate on its first unconsumed command. Reuse the actual sequence parser
/// and retain the existing fallback for unsupported commands (account 5b45a172).
pub(super) fn consumes_decorated_sequence(lines: &[String]) -> bool {
    let mut parser=SeqParser::new();
    let mut decorated=false;
    for (index,line) in lines.iter().enumerate() {
        let (number,text)=super::source_line_and_trimmed(index+1,line);
        if text.is_empty() || text.starts_with('@') || text.starts_with('\'') {continue;}
        let before=parser.events.len();
        if parser.parse_line(number,text).is_err() || parser.unconsumed {return false;}
        if let Some(Event::Message(message))=parser.events.get(before) {
            // CommandArrow requires a head/cross dressing; bare class/object
            // aggregation has no viable sequence command, even though our
            // historical permissive message regex recognizes its body.
            let text=text.strip_prefix('&').unwrap_or(text).trim_start();
            let Some(caps)=MESSAGE_RE.captures(text)
                .or_else(||EXTERNAL_MESSAGE_IN_RE.captures(text))
                .or_else(||EXTERNAL_MESSAGE_OUT_RE.captures(text)) else {return false;};
            let (_,arrow)=strip_arrow_style_annotation(&caps[2]);
            if !arrow.contains(['<','>','/','\\','x']) {return false;}
            decorated |= message.arrow.source_circle || message.arrow.target_circle;
        }
    }
    decorated && parser.note_buffer.is_none() && parser.ref_buffer.is_none()
        && !parser.in_legend && parser.skinparam_block_prefix.is_none()
        && validate_return_destinations(&parser.events).is_ok()
}

// CommandReturn#executeArg calls HColorSet#getColor; an unknown name is a
// command error, not label text or an SVG color. Account ea313c62.
fn validate_return_destinations(events: &[Event]) -> Result<(), ParseError> {
    for event in events {
        if let Event::Return(ret) = event
            && let Some(color) = &ret.color
            && !valid_return_color(color)
        {
            return Err(ParseError {
                line: ret.source_line,
                message: "No such color".to_owned(),
            });
        }
    }
    resolve_sequence_returns(events)
        .map(|_| ())
        .map_err(|(line, message)| ParseError { line, message })
}

// Display#getWithNewlines expands inline note escapes before the component
// measures or draws them. Raw math/link bodies retain their backslashes.
// Block commands use Display.create and do not run this inline conversion.
fn inline_note_display(text: &str) -> String {
    let mut result = String::with_capacity(text.len());
    let mut chars = text.char_indices().peekable();
    let mut raw = false;
    while let Some((index, c)) = chars.next() {
        let rest = &text[index..];
        if rest.starts_with("<math>") || rest.starts_with("<latex>") || rest.starts_with("[[") {
            raw = true;
        } else if rest.starts_with("</math>")
            || rest.starts_with("</latex>")
            || rest.starts_with("]]")
        {
            raw = false;
        }
        if !raw && c == '\\' {
            match chars.peek().map(|(_, c)| *c) {
                Some('n') => {
                    chars.next();
                    result.push('\n');
                }
                Some('t') => {
                    chars.next();
                    result.push('\t');
                }
                Some('\\') => {
                    chars.next();
                    result.push('\\');
                }
                _ => result.push(c),
            }
        } else {
            result.push(c);
        }
    }
    result
}

fn valid_return_color(color: &str) -> bool {
    let color = color.strip_prefix('#').unwrap_or(color);
    // HColorSet#parseSimpleColor accepts 1/3/6/8 hexadecimal digits.
    if matches!(color.len(), 1 | 3 | 6 | 8) && color.bytes().all(|b| b.is_ascii_hexdigit()) {
        return true;
    }
    // ColorTrieNode's registered names, case-insensitive, plus HColorSet's
    // transparent/background/automatic symbolic colors. Pinned Java 71806a23.
    matches!(
        color.to_ascii_lowercase().as_str(),
        "aliceblue"
            | "antiquewhite"
            | "application"
            | "aqua"
            | "aquamarine"
            | "automatic"
            | "azure"
            | "background"
            | "beige"
            | "bisque"
            | "black"
            | "blanchedalmond"
            | "blue"
            | "blueviolet"
            | "brown"
            | "burlywood"
            | "business"
            | "cadetblue"
            | "chartreuse"
            | "chocolate"
            | "coral"
            | "cornflowerblue"
            | "cornsilk"
            | "crimson"
            | "cyan"
            | "darkblue"
            | "darkcyan"
            | "darkgoldenrod"
            | "darkgray"
            | "darkgreen"
            | "darkgrey"
            | "darkkhaki"
            | "darkmagenta"
            | "darkolivegreen"
            | "darkorange"
            | "darkorchid"
            | "darkred"
            | "darksalmon"
            | "darkseagreen"
            | "darkslateblue"
            | "darkslategray"
            | "darkslategrey"
            | "darkturquoise"
            | "darkviolet"
            | "deeppink"
            | "deepskyblue"
            | "dimgray"
            | "dimgrey"
            | "dodgerblue"
            | "firebrick"
            | "floralwhite"
            | "forestgreen"
            | "fuchsia"
            | "gainsboro"
            | "ghostwhite"
            | "gold"
            | "goldenrod"
            | "gray"
            | "green"
            | "greenyellow"
            | "grey"
            | "honeydew"
            | "hotpink"
            | "implementation"
            | "indianred"
            | "indigo"
            | "ivory"
            | "khaki"
            | "lavender"
            | "lavenderblush"
            | "lawngreen"
            | "lemonchiffon"
            | "lightblue"
            | "lightcoral"
            | "lightcyan"
            | "lightgoldenrodyellow"
            | "lightgray"
            | "lightgreen"
            | "lightgrey"
            | "lightpink"
            | "lightsalmon"
            | "lightseagreen"
            | "lightskyblue"
            | "lightslategray"
            | "lightslategrey"
            | "lightsteelblue"
            | "lightyellow"
            | "lime"
            | "limegreen"
            | "linen"
            | "magenta"
            | "maroon"
            | "mediumaquamarine"
            | "mediumblue"
            | "mediumorchid"
            | "mediumpurple"
            | "mediumseagreen"
            | "mediumslateblue"
            | "mediumspringgreen"
            | "mediumturquoise"
            | "mediumvioletred"
            | "midnightblue"
            | "mintcream"
            | "mistyrose"
            | "moccasin"
            | "motivation"
            | "navajowhite"
            | "navy"
            | "oldlace"
            | "olive"
            | "olivedrab"
            | "orange"
            | "orangered"
            | "orchid"
            | "palegoldenrod"
            | "palegreen"
            | "paleturquoise"
            | "palevioletred"
            | "papayawhip"
            | "peachpuff"
            | "peru"
            | "physical"
            | "pink"
            | "plum"
            | "powderblue"
            | "purple"
            | "red"
            | "rosybrown"
            | "royalblue"
            | "saddlebrown"
            | "salmon"
            | "sandybrown"
            | "seagreen"
            | "seashell"
            | "sienna"
            | "silver"
            | "skyblue"
            | "slateblue"
            | "slategray"
            | "slategrey"
            | "snow"
            | "springgreen"
            | "steelblue"
            | "strategy"
            | "tan"
            | "teal"
            | "technology"
            | "thistle"
            | "tomato"
            | "transparent"
            | "turquoise"
            | "violet"
            | "wheat"
            | "white"
            | "whitesmoke"
            | "yellow"
            | "yellowgreen"
    )
}

struct SeqParser {
    meta: DiagramMeta,
    participants: Vec<Participant>,
    events: Vec<Event>,
    autonumber: Option<AutoNumber>,
    participant_ids: Vec<String>,
    /// Multiline note accumulator.
    note_buffer: Option<NoteBuffer>,
    /// Multiline ref accumulator.
    ref_buffer: Option<RefBuffer>,
    /// Last message source and target (for bare "note left"/"note right").
    last_message: Option<(String, String)>,
    /// Whether we are inside a `legend ... endlegend` block.
    in_legend: bool,
    /// Whether `hide footbox` was specified.
    hide_footbox: bool,
    /// Whether `!pragma teoz true` was specified.
    teoz: bool,
    /// Whether `autoactivate on` is active for subsequent messages.
    autoactivate: bool,
    /// Current 1-based source line number (set before each parse_line call).
    current_line: usize,
    /// PSystemCommandFactory viability: an unknown command rejects a candidate.
    unconsumed: bool,
    /// Named participant boxes (`box ... end box`).
    boxes: Vec<ParticipantBox>,
    /// Index into `boxes` of the box currently being collected, if any.
    current_box: Option<usize>,
    /// Prefix of an open `skinparam X { ... }` block.
    skinparam_block_prefix: Option<String>,
}

struct NoteBuffer {
    position: NotePosition,
    participants: Vec<String>,
    lines: Vec<String>,
    shape: NoteShape,
    color: Option<String>,
    on_message: bool,
    source_line: usize,
}

struct RefBuffer {
    participants: Vec<String>,
    lines: Vec<String>,
    source_line: usize,
}

impl SeqParser {
    fn new() -> Self {
        Self {
            meta: DiagramMeta::default(),
            participants: Vec::new(),
            events: Vec::new(),
            autonumber: None,
            participant_ids: Vec::new(),
            note_buffer: None,
            ref_buffer: None,
            last_message: None,
            in_legend: false,
            hide_footbox: false,
            teoz: false,
            autoactivate: false,
            current_line: 0,
            unconsumed: false,
            boxes: Vec::new(),
            current_box: None,
            skinparam_block_prefix: None,
        }
    }

    fn finish(self) -> SequenceDiagram {
        SequenceDiagram {
            meta: self.meta,
            participants: self.participants,
            events: self.events,
            autonumber: self.autonumber,
            hide_footbox: self.hide_footbox,
            teoz: self.teoz,
            boxes: self.boxes,
        }
    }

    fn ensure_participant(&mut self, id: &str) -> String {
        self.ensure_participant_at(id, self.current_line)
    }

    fn ensure_participant_at(&mut self, id: &str, source_line: usize) -> String {
        let id = id.trim().to_string();
        if !self.participant_ids.contains(&id) {
            self.participant_ids.push(id.clone());
            self.participants.push(Participant {
                id: id.clone(),
                label: id.clone(),
                kind: ParticipantKind::default(),
                order: Some(self.participants.len()),
                stereotype: None,
                url: None,
                color: None,
                source_line,
            });
        }
        id
    }

    fn parse_line(&mut self, line_num: usize, line: &str) -> Result<(), ParseError> {
        self.current_line = line_num;

        if let Some(prefix) = self.skinparam_block_prefix.clone() {
            if line == "}" {
                self.skinparam_block_prefix = None;
            } else if let Some((key, value)) = line.split_once(char::is_whitespace) {
                let key = key.trim();
                let value = value.trim();
                if !key.is_empty() && !value.is_empty() {
                    self.meta.skinparams.push(crate::diagram::SkinParam {
                        key: format!("{prefix}{key}"),
                        value: value.to_string(),
                    });
                }
            }
            return Ok(());
        }

        // Handle multiline ref buffering.
        if self.ref_buffer.is_some() {
            if line == "end ref" {
                let buf = self.ref_buffer.take().unwrap();
                let text = buf.lines.join("\n");
                self.events.push(Event::Ref(Ref {
                    participants: buf.participants,
                    text,
                    source_line: buf.source_line,
                }));
            } else if let Some(buf) = &mut self.ref_buffer {
                buf.lines.push(line.trim().to_string());
            }
            return Ok(());
        }

        // Handle multiline note buffering.
        if self.note_buffer.is_some() {
            let trimmed = line.trim();
            if trimmed == "endnote" || trimmed == "end note" {
                let buf = self.note_buffer.take().unwrap();
                let text = note_text_from_lines(&buf.lines);
                self.events.push(Event::Note(Note {
                    position: buf.position,
                    participants: buf.participants,
                    text,
                    shape: buf.shape,
                    color: buf.color,
                    on_message: buf.on_message,
                    source_line: buf.source_line,
                }));
            } else if let Some(buf) = &mut self.note_buffer {
                buf.lines.push(line.to_string());
            }
            return Ok(());
        }

        // Keywords that could be confused with participant names must be
        // checked before the message regex.
        if self.try_autonumber(line) {
            return Ok(());
        }
        if self.try_return(line) {
            return Ok(());
        }
        if self.try_activate_deactivate(line) {
            return Ok(());
        }
        if self.try_autoactivate(line) {
            return Ok(());
        }
        if self.try_create_destroy(line) {
            return Ok(());
        }
        if self.try_participant_decl(line) {
            return Ok(());
        }
        if self.try_group(line) {
            return Ok(());
        }
        if self.try_note(line) {
            return Ok(());
        }
        if self.try_divider(line) {
            return Ok(());
        }
        if self.try_delay(line) {
            return Ok(());
        }
        if self.try_space(line) {
            return Ok(());
        }
        // try_box must come before try_message: "box" would otherwise be parsed
        // as a message b -[o]-> x because 'o' and 'x' are valid arrow chars.
        if self.try_box(line) {
            return Ok(());
        }
        // try_meta before try_message: `title <back:cyan>...</back>` would
        // otherwise be parsed as a "title <- back" message because the
        // arrow regex accepts `<` and `>` as arrow characters. Title /
        // header / footer / caption / legend all start with explicit
        // keywords, so checking them first cannot conflict with anything
        // a message line is allowed to look like.
        if self.try_meta(line) {
            return Ok(());
        }
        if self.try_pragma(line) {
            return Ok(());
        }
        let message_line = line.strip_prefix('&').unwrap_or(line).trim_start();
        if let Some(caps) = MESSAGE_RE
            .captures(message_line)
            .or_else(|| EXTERNAL_MESSAGE_IN_RE.captures(message_line))
            .or_else(|| EXTERNAL_MESSAGE_OUT_RE.captures(message_line))
        {
            let (_, arrow) = strip_arrow_style_annotation(&caps[2]);
            // CommandArrow ARROW_DRESSING1/2 and CommandExoArrowLeft/Right:
            // circles surround the head; `->o` is valid, `-o>` is not.
            if let (Some(first), Some(last)) = (arrow.find('-'), arrow.rfind('-')) {
                let left = arrow[..first].trim_start_matches(['o', 'x']);
                let right = arrow[last + 1..].trim_end_matches(['o', 'x']);
                if left.contains('o') || right.contains('o') {
                    return Err(ParseError {
                        line: line_num,
                        message: "Illegal sequence arrow decoration".into(),
                    });
                }
            }
        }
        if self.try_message(line) {
            return Ok(());
        }
        if self.try_ref(line) {
            return Ok(());
        }
        if self.try_newpage(line) {
            return Ok(());
        }
        if self.try_skinparam(line) {
            return Ok(());
        }
        if self.try_hide(line) {
            return Ok(());
        }
        if self.try_external_message(line) {
            return Ok(());
        }

        // Preserve permissive sequence parsing, but never count ignored text as
        // successful command consumption in factory competition.
        self.unconsumed = true;
        Ok(())
    }

    fn try_participant_decl(&mut self, line: &str) -> bool {
        let (url, clean_line) = super::extract_link_url(line);
        let line = clean_line.as_str();
        // Matches these forms (label = display text, id = entity key):
        //   1. keyword "Long Label" as alias  <<stereotype>>
        //   2. keyword alias as "Long Label"  <<stereotype>>
        //   3. keyword Label as alias         <<stereotype>>  (both unquoted)
        //   4. keyword SimpleName             <<stereotype>>
        //   5. keyword "Long Label"           <<stereotype>>  (no alias; id = label)
        static RE: LazyLock<Regex> = LazyLock::new(|| {
            Regex::new(
                r#"^(participant|actor|boundary|control|entity|database|collections|queue)\s+(?:"([^"]+)"\s+as\s+(\w+)|(\w+)\s+as\s+"([^"]+)"|(\w+)\s+as\s+(\w+)|"([^"]+)"|(\w+))(?:\s+<<([^>]+)>>)?(?:\s+(#\S+))?(?:\s+order\s+(\d+))?"#,
            )
            .unwrap()
        });

        if let Some(caps) = RE.captures(line) {
            let kind = parse_participant_kind(&caps[1]);
            // `quoted` tracks whether the display text came from a `"..."` form.
            // PlantUML's grammar matches the stereotype (`STEREO`) only OUTSIDE the
            // quoted display string (`FULL` = `[%g]([^%g]+)[%g]`), so a `<<...>>`
            // that appears WITHIN a quoted label is literal display text, not a
            // stereotype (see CommandParticipantA). We therefore only mine an
            // inline stereotype from UNQUOTED labels.
            let (raw_label, id, quoted) = if let Some(quoted) = caps.get(2) {
                // Form 1: "Long Label" as alias
                (quoted.as_str().to_string(), caps[3].to_string(), true)
            } else if let Some(alias) = caps.get(4) {
                // Form 2: alias as "Long Label"
                let lbl = caps.get(5).map_or("", |m| m.as_str()).to_string();
                (lbl, alias.as_str().to_string(), true)
            } else if let Some(label) = caps.get(6) {
                // Form 3: Label as alias (both unquoted) — id is the alias.
                (label.as_str().to_string(), caps[7].to_string(), false)
            } else if let Some(quoted) = caps.get(8) {
                // Form 5: "Long Label" (no alias; id = label)
                let lbl = quoted.as_str().to_string();
                (lbl.clone(), lbl, true)
            } else {
                // Form 4: SimpleName
                let name = caps[9].to_string();
                (name.clone(), name, false)
            };
            // Extract `<<stereotype>>` from within the label text (e.g.
            // `Service 1 <<internal>>`) only for unquoted labels — a quoted
            // display string keeps `<<...>>` as literal text.
            let (label, label_stereotype) = if quoted {
                (raw_label, None)
            } else {
                extract_stereotype_from_label(&raw_label)
            };
            let stereotype = caps
                .get(10)
                .map(|m| m.as_str().to_string())
                .or(label_stereotype);

            let color = caps.get(11).map(|m| m.as_str().to_string());

            // Explicit `order N` sets the layout sort key; otherwise it defaults
            // to the declaration index. Implicit participants (created by a
            // message) also default to their declaration index, so a participant
            // declared with a large `order N` can be positioned to the right of a
            // later, implicitly-created one (matching Java PlantUML).
            let explicit_order = caps.get(12).and_then(|m| m.as_str().parse::<usize>().ok());

            if !self.participant_ids.contains(&id) {
                self.participant_ids.push(id.clone());
                let idx = self.participants.len();
                self.participants.push(Participant {
                    id: id.clone(),
                    label,
                    kind,
                    order: Some(explicit_order.unwrap_or(idx)),
                    stereotype,
                    url,
                    color,
                    source_line: self.current_line,
                });
                if let Some(bi) = self.current_box {
                    self.boxes[bi].members.push(idx);
                }
            }
            true
        } else {
            false
        }
    }

    fn try_message(&mut self, line: &str) -> bool {
        // CommandArrow#getRegexConcat PARALLEL precedes the first participant.
        let parallel = line.starts_with('&');
        let line = line.strip_prefix('&').unwrap_or(line).trim_start();
        if let Some(caps) = MESSAGE_RE.captures(line) {
            // Strip surrounding quotes from quoted participant names.
            let unquote = |s: &str| -> String {
                if s.starts_with('"') && s.ends_with('"') && s.len() >= 2 {
                    s[1..s.len() - 1].to_string()
                } else {
                    s.to_string()
                }
            };
            let from_raw = unquote(&caps[1]);
            let (arrow_style, arrow_str) = strip_arrow_style_annotation(&caps[2]);
            let to_raw = unquote(&caps[3]);
            let activation_str = caps.get(4).map(|m| m.as_str());
            let activation_color = caps.get(5).map(|m| m.as_str().to_string());
            let label = message_label(line, caps.get(6));

            let mut arrow = parse_arrow(&arrow_str);
            apply_inline_arrow_style(&mut arrow, arrow_style);
            let activation = activation_str
                .map(parse_activation)
                .or_else(|| self.autoactivation_for(&arrow));

            // Ensure participants in textual order (left-to-right as written)
            // so the participant list preserves declaration order.
            let left_id = self.ensure_participant(&from_raw);
            let right_id = self.ensure_participant(&to_raw);

            // For left-pointing arrows (Alice <- Bob), swap from/to so that
            // from=sender(Bob), to=receiver(Alice), matching PlantUML semantics.
            let (from_id, to_id) = if arrow.direction == ArrowDirection::RightToLeft {
                (right_id, left_id)
            } else {
                (left_id, right_id)
            };

            self.last_message = Some((from_id.clone(), to_id.clone()));
            self.events.push(Event::Message(Message {
                parallel,
                from: from_id,
                to: to_id,
                label,
                arrow,
                activation,
                activation_color,
                source_line: self.current_line,
            }));
            true
        } else {
            false
        }
    }

    fn try_external_message(&mut self, line: &str) -> bool {
        let (caps, boundary_first) = if let Some(caps) = EXTERNAL_MESSAGE_IN_RE.captures(line) {
            (caps, true)
        } else if let Some(caps) = EXTERNAL_MESSAGE_OUT_RE.captures(line) {
            (caps, false)
        } else {
            return false;
        };
        let (arrow_style, arrow_str) = strip_arrow_style_annotation(&caps[2]);
        let mut arrow = parse_arrow(&arrow_str);
        apply_inline_arrow_style(&mut arrow, arrow_style);
        let (left, right) = if boundary_first {
            (caps[1].to_string(), self.ensure_participant(&caps[3]))
        } else {
            (self.ensure_participant(&caps[1]), caps[3].to_string())
        };
        // CommandExoArrowLeft/Right#getMessageExoType select FROM/TO from
        // the dressing, independently of which side contains the border token.
        let (from, to) = if arrow.direction == ArrowDirection::RightToLeft {
            (right, left)
        } else {
            (left, right)
        };
        let activation = caps
            .get(4)
            .map(|m| parse_activation(m.as_str()))
            .or_else(|| self.autoactivation_for(&arrow));
        self.events.push(Event::Message(Message {
            parallel: false,
            from,
            to,
            label: message_label(line, caps.get(6)),
            arrow,
            activation,
            activation_color: caps.get(5).map(|m| m.as_str().to_string()),
            source_line: self.current_line,
        }));
        true
    }

    fn try_note(&mut self, line: &str) -> bool {
        // `note : text` — Java PlantUML creates a participant named "note" with
        // a note box above/beside it showing the text.  We declare the "note"
        // participant and emit a Note event.
        if let Some(text) = line.strip_prefix("note :").map(|s| s.trim()) {
            if !text.is_empty() {
                let participant_id = self.ensure_participant("note");
                self.events.push(Event::Note(Note {
                    position: NotePosition::Over,
                    participants: vec![participant_id],
                    text: inline_note_display(text),
                    shape: NoteShape::Note,
                    color: None,
                    on_message: false,
                    source_line: self.current_line,
                }));
            }
            return true;
        }

        // Note on link (attaches to previous message).
        if let Some(rest) = line.strip_prefix("note on link") {
            let text = rest.trim().trim_start_matches(':').trim().to_string();
            self.events.push(Event::NoteOnLink(text));
            return true;
        }

        // Also handle "note across" (with optional color)
        if let Some(rest) = line.strip_prefix("note across") {
            // Parse optional color: "note across #color : text" or "note across #color"
            let rest = rest.trim();
            let (color, rest) = if rest.starts_with('#') {
                let end = rest
                    .find(|c: char| c.is_whitespace() || c == ':')
                    .unwrap_or(rest.len());
                (Some(rest[..end].to_string()), rest[end..].trim())
            } else {
                (None, rest)
            };
            let text = inline_note_display(rest.trim_start_matches(':').trim());
            if text.is_empty() {
                self.note_buffer = Some(NoteBuffer {
                    position: NotePosition::Over,
                    participants: Vec::new(),
                    lines: Vec::new(),
                    shape: NoteShape::Note,
                    color,
                    on_message: false,
                    source_line: self.current_line,
                });
            } else {
                self.events.push(Event::Note(Note {
                    position: NotePosition::Over,
                    participants: Vec::new(),
                    text,
                    shape: NoteShape::Note,
                    color,
                    on_message: false,
                    source_line: self.current_line,
                }));
            }
            return true;
        }

        // Allow optional color (#xxx) after participant list.
        // Capture shape prefix (h/r/note), position, participants, color, inline text.
        static RE: LazyLock<Regex> = LazyLock::new(|| {
            Regex::new(r"^(h|r)?note\s+(left|right|over)\s*(?:of\s+)?(\w+(?:\s*,\s*\w+)*)?\s*(#\S+)?\s*(?::\s*(.*))?$").unwrap()
        });

        if let Some(caps) = RE.captures(line) {
            let shape = match caps.get(1).map(|m| m.as_str()) {
                Some("h") => NoteShape::Hexagonal,
                Some("r") => NoteShape::Rectangular,
                _ => NoteShape::Note,
            };
            let position = match &caps[2] {
                "left" => NotePosition::Left,
                "right" => NotePosition::Right,
                "over" => NotePosition::Over,
                _ => NotePosition::Right,
            };
            let inline_text = caps.get(5);
            let participant_source_line = if inline_text.is_some() {
                self.current_line
            } else {
                self.current_line + 1
            };
            let mut participants: Vec<String> = caps.get(3).map_or(Vec::new(), |m| {
                m.as_str()
                    .split(',')
                    .map(|s| self.ensure_participant_at(s.trim(), participant_source_line))
                    .collect()
            });
            // Bare "note left" / "note right" (no participant) attaches to the
            // last message and straddles its arrow band (on_message). PlantUML
            // anchors such notes to the message's leftmost/rightmost endpoint by
            // screen position, so store BOTH endpoints and let the renderer pick.
            // "note left"  → left of the leftmost endpoint
            // "note right" → right of the rightmost endpoint
            let mut on_message = false;
            if participants.is_empty()
                && position != NotePosition::Over
                && let Some((from, to)) = &self.last_message
            {
                participants = vec![from.clone(), to.clone()];
                on_message = true;
            }
            let color = caps.get(4).map(|m| m.as_str().to_string());

            if let Some(text_match) = inline_text {
                if participants.is_empty() && position != NotePosition::Over && !on_message {
                    return true;
                }
                // Inline note: note right : text
                let text = inline_note_display(text_match.as_str().trim());
                self.events.push(Event::Note(Note {
                    position,
                    participants,
                    text,
                    shape,
                    color,
                    on_message,
                    source_line: self.current_line,
                }));
            } else {
                // Multiline note: note right\n...\nendnote
                self.note_buffer = Some(NoteBuffer {
                    position,
                    participants,
                    lines: Vec::new(),
                    shape,
                    color,
                    on_message,
                    source_line: self.current_line,
                });
            }
            true
        } else {
            false
        }
    }

    fn try_group(&mut self, line: &str) -> bool {
        static RE_START: LazyLock<Regex> = LazyLock::new(|| {
            Regex::new(r"^(alt|opt|loop|par|break|critical|group)\s*(.*)$").unwrap()
        });
        static RE_ELSE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"^else\s*(.*)$").unwrap());

        if line == "end" {
            self.events.push(Event::GroupEnd);
            return true;
        }

        if let Some(caps) = RE_START.captures(line) {
            let kind = match &caps[1] {
                "alt" => GroupKind::Alt,
                "opt" => GroupKind::Opt,
                "loop" => GroupKind::Loop,
                "par" => GroupKind::Par,
                "break" => GroupKind::Break,
                "critical" => GroupKind::Critical,
                "group" => GroupKind::Group,
                _ => GroupKind::Group,
            };
            let label = {
                let l = caps[2].trim();
                if l.is_empty() {
                    None
                } else {
                    Some(l.to_string())
                }
            };
            self.events.push(Event::GroupStart(GroupStart {
                kind,
                label,
                source_line: self.current_line,
            }));
            return true;
        }

        if let Some(caps) = RE_ELSE.captures(line) {
            let label = {
                let l = caps[1].trim();
                if l.is_empty() {
                    None
                } else {
                    Some(l.to_string())
                }
            };
            self.events.push(Event::GroupElse(GroupElse {
                label,
                source_line: self.current_line,
            }));
            return true;
        }

        false
    }

    fn try_divider(&mut self, line: &str) -> bool {
        static RE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"^==\s*(.*?)\s*==$").unwrap());

        if let Some(caps) = RE.captures(line) {
            self.events.push(Event::Divider(caps[1].trim().to_string()));
            true
        } else {
            false
        }
    }

    fn try_delay(&mut self, line: &str) -> bool {
        static RE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"^\.\.\.(.*?)\.\.\.$").unwrap());

        if line == "..." {
            self.events.push(Event::Delay(None));
            return true;
        }
        if let Some(caps) = RE.captures(line) {
            // CommandDelay#executeArg passes LABEL verbatim to Display.
            // Spacer atoms still contribute to the component preferred width
            // (account a21a0275); only the undelimited `...` has no label.
            self.events.push(Event::Delay(Some(caps[1].to_string())));
            true
        } else {
            false
        }
    }

    fn try_space(&mut self, line: &str) -> bool {
        static RE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"^\|\|(\d+)\|\|$").unwrap());

        if line == "|||" {
            self.events.push(Event::Space(None));
            return true;
        }
        if let Some(caps) = RE.captures(line) {
            let px: u32 = caps[1].parse().unwrap_or(20);
            self.events.push(Event::Space(Some(px)));
            true
        } else {
            false
        }
    }

    fn try_autonumber(&mut self, line: &str) -> bool {
        static RE_START: LazyLock<Regex> = LazyLock::new(|| {
            Regex::new(r#"^autonumber(?:\s+(\d+))?(?:\s+(\d+))?(?:\s+"([^"]*)")?$"#).unwrap()
        });
        static RE_RESUME: LazyLock<Regex> = LazyLock::new(|| {
            Regex::new(r#"^autonumber\s+resume(?:\s+(\d+))?(?:\s+"([^"]*)")?$"#).unwrap()
        });

        if line == "autonumber stop" {
            self.push_autonumber(AutonumberCmd::Stop);
            return true;
        }
        if line.starts_with("autonumber resume")
            && let Some(caps) = RE_RESUME.captures(line)
        {
            let step = caps.get(1).and_then(|m| m.as_str().parse().ok());
            let format = caps.get(2).map(|m| m.as_str().to_string());
            self.push_autonumber(AutonumberCmd::Resume { step, format });
            return true;
        }
        if let Some(caps) = RE_START.captures(line) {
            let start = caps.get(1).map_or(1, |m| m.as_str().parse().unwrap_or(1));
            let step = caps.get(2).map_or(1, |m| m.as_str().parse().unwrap_or(1));
            let format = caps.get(3).map(|m| m.as_str().to_string());
            self.push_autonumber(AutonumberCmd::Start {
                start,
                step,
                format,
            });
            return true;
        }
        false
    }

    /// Record an autonumber directive: keep the first `Start` in the legacy
    /// `self.autonumber` field (so initial layout still sees it) and always emit
    /// an event so mid-stream changes (stop/resume/restart) take effect.
    fn push_autonumber(&mut self, cmd: AutonumberCmd) {
        if self.autonumber.is_none()
            && let AutonumberCmd::Start {
                start,
                step,
                format,
            } = &cmd
        {
            self.autonumber = Some(AutoNumber {
                start: *start,
                step: *step,
                format: format.clone(),
            });
        }
        self.events.push(Event::Autonumber(cmd));
    }

    fn try_activate_deactivate(&mut self, line: &str) -> bool {
        static RE: LazyLock<Regex> =
            LazyLock::new(|| Regex::new(r"^(activate|deactivate)\s+(\w+)(?:\s+(#\S+))?").unwrap());

        if let Some(caps) = RE.captures(line) {
            let id = self.ensure_participant(&caps[2]);
            let color = caps.get(3).map(|m| m.as_str().to_string());
            match &caps[1] {
                "activate" => self.events.push(Event::Activate(id, color)),
                "deactivate" => self.events.push(Event::Deactivate(id)),
                _ => {}
            }
            true
        } else {
            false
        }
    }

    fn try_autoactivate(&mut self, line: &str) -> bool {
        let Some(rest) = line.strip_prefix("autoactivate") else {
            return false;
        };
        match rest.trim() {
            state if state.eq_ignore_ascii_case("on") => {
                self.autoactivate = true;
                true
            }
            state if state.eq_ignore_ascii_case("off") => {
                self.autoactivate = false;
                true
            }
            _ => false,
        }
    }

    fn autoactivation_for(&self, arrow: &Arrow) -> Option<ActivationChange> {
        if !self.autoactivate || arrow.head_half.is_some() || arrow.source_cross {
            return None;
        }
        match (arrow.line, arrow.head) {
            (LineStyle::Dotted, ArrowHead::Filled | ArrowHead::Open) => {
                Some(ActivationChange::Deactivate)
            }
            (LineStyle::Solid | LineStyle::Hidden, ArrowHead::Filled | ArrowHead::Open) => {
                Some(ActivationChange::Activate)
            }
            _ => None,
        }
    }

    fn try_create_destroy(&mut self, line: &str) -> bool {
        static KW: LazyLock<Regex> =
            LazyLock::new(|| Regex::new(r"^(create|destroy)\s+(.*)$").unwrap());
        // Identifier extraction from a participant declaration tail. Mirrors the
        // forms in `try_participant_decl`; the id is the alias when `as` is
        // present, otherwise the simple name (or quoted label).
        static REST: LazyLock<Regex> = LazyLock::new(|| {
            Regex::new(
                r#"^(?:participant|actor|boundary|control|entity|database|collections|queue)?\s*(?:"[^"]+"\s+as\s+(\w+)|(\w+)\s+as\s+(?:"[^"]+"|\w+)|"([^"]+)"|(\w+))"#,
            )
            .unwrap()
        });

        let Some(kw) = KW.captures(line) else {
            return false;
        };
        let rest = kw[2].trim();
        let Some(caps) = REST.captures(rest) else {
            return false;
        };
        let id = caps
            .get(1)
            .or_else(|| caps.get(2))
            .or_else(|| caps.get(3))
            .or_else(|| caps.get(4))
            .map(|m| m.as_str().to_string());
        let Some(id) = id else {
            return false;
        };

        match &kw[1] {
            "create" => {
                // Register with the declared kind/alias/label if a full declaration
                // was given; otherwise ensure a plain participant exists.
                if !self.try_participant_decl(rest) {
                    self.ensure_participant(&id);
                }
                self.events.push(Event::Create(id));
            }
            "destroy" => self.events.push(Event::Destroy(id)),
            _ => {}
        }
        true
    }

    fn try_return(&mut self, line: &str) -> bool {
        let parallel = line.starts_with('&');
        let line = line.strip_prefix('&').unwrap_or(line).trim_start();
        if let Some(rest) = line.strip_prefix("return") {
            // CommandReturn#getRegexConcat captures COLOR only when #\w+
            // is followed by whitespace; a terminal #word remains label text.
            static COLOR: LazyLock<Regex> =
                LazyLock::new(|| Regex::new(r"^(#\w+)\s+(.*)$").unwrap());
            let rest = rest.trim_start();
            let (color, label) = if let Some(caps) = COLOR.captures(rest) {
                (Some(caps[1].to_owned()), caps[2].to_owned())
            } else {
                (None, rest.to_owned())
            };
            self.events.push(Event::Return(ReturnMessage {
                parallel,
                label,
                color,
                source_line: self.current_line,
            }));
            true
        } else {
            false
        }
    }

    fn try_ref(&mut self, line: &str) -> bool {
        // Inline: ref over A, B : text
        static RE_INLINE: LazyLock<Regex> = LazyLock::new(|| {
            Regex::new(r"^ref\s+over\s+(\w+(?:\s*,\s*\w+)*)\s*:\s*(.+)$").unwrap()
        });
        // Multiline start: ref over A, B  (no colon)
        static RE_START: LazyLock<Regex> =
            LazyLock::new(|| Regex::new(r"^ref\s+over\s+(\w+(?:\s*,\s*\w+)*)\s*$").unwrap());

        if let Some(caps) = RE_INLINE.captures(line) {
            let participants: Vec<String> = caps[1]
                .split(',')
                .map(|s| self.ensure_participant(s.trim()))
                .collect();
            let text = caps[2].trim().to_string();
            self.events.push(Event::Ref(Ref {
                participants,
                text,
                source_line: self.current_line,
            }));
            return true;
        }
        if let Some(caps) = RE_START.captures(line) {
            let participants: Vec<String> = caps[1]
                .split(',')
                .map(|s| self.ensure_participant(s.trim()))
                .collect();
            self.ref_buffer = Some(RefBuffer {
                participants,
                lines: Vec::new(),
                source_line: self.current_line,
            });
            return true;
        }
        false
    }

    fn try_meta(&mut self, line: &str) -> bool {
        if let Some(rest) = line.strip_prefix("title ") {
            self.meta.title = Some(super::strip_title_quotes(rest).to_string());
            self.meta.title_line = Some(self.current_line);
            return true;
        }
        if let Some(rest) = line.strip_prefix("header ") {
            self.meta.header = Some(rest.trim().to_string());
            self.meta.header_line = Some(self.current_line);
            return true;
        }
        if let Some(rest) = line.strip_prefix("footer ") {
            self.meta.footer = Some(rest.trim().to_string());
            self.meta.footer_line = Some(self.current_line);
            return true;
        }
        if let Some(rest) = line.strip_prefix("caption ") {
            self.meta.caption = Some(rest.trim().to_string());
            self.meta.caption_line = Some(self.current_line);
            return true;
        }
        // Legend block: `legend` / `legend right` / `legend left` ... `endlegend`
        if line == "legend" || line.starts_with("legend ") {
            self.in_legend = true;
            self.meta.legend_line = Some(self.current_line);
            return true;
        }
        if self.in_legend {
            if line == "endlegend" || line == "end legend" {
                self.in_legend = false;
            } else {
                let l = self.meta.legend.get_or_insert_with(String::new);
                if !l.is_empty() {
                    l.push('\n');
                }
                l.push_str(line);
            }
            return true;
        }
        false
    }

    fn try_box(&mut self, line: &str) -> bool {
        // `box ["Title"] [#color] ... end box` groups consecutive participant
        // declarations into a titled, optionally coloured rectangle.
        if line == "end box" {
            self.current_box = None;
            return true;
        }
        if line == "box" || line.starts_with("box ") {
            let rest = line[3..].trim();
            // Title is an optional quoted string; colour is an optional #token.
            let (title, after_title) = if let Some(stripped) = rest.strip_prefix('"') {
                match stripped.find('"') {
                    Some(end) => (stripped[..end].to_string(), stripped[end + 1..].trim()),
                    None => (stripped.to_string(), ""),
                }
            } else {
                // CommandBoxStart#getRegexConcat NAME2 captures the unquoted
                // title up to the optional color (account 55e88b2a).
                let end = rest.find('#').unwrap_or(rest.len());
                (rest[..end].to_string(), &rest[end..])
            };
            let color = after_title
                .split_whitespace()
                .find(|tok| tok.starts_with('#'))
                .map(|tok| tok.to_string());
            self.boxes.push(ParticipantBox {
                title,
                color,
                members: Vec::new(),
            });
            self.current_box = Some(self.boxes.len() - 1);
            return true;
        }
        false
    }

    fn try_newpage(&mut self, line: &str) -> bool {
        if line == "newpage" {
            self.events.push(Event::NewPage(None));
            return true;
        }
        if let Some(rest) = line.strip_prefix("newpage ") {
            self.events
                .push(Event::NewPage(Some(rest.trim().to_string())));
            return true;
        }
        false
    }

    fn try_skinparam(&mut self, line: &str) -> bool {
        if let Some(rest) = line.strip_prefix("skinparam ") {
            let rest = rest.trim();
            if let Some(prefix) = rest.strip_suffix('{') {
                let prefix = prefix.trim();
                if !prefix.is_empty() {
                    self.skinparam_block_prefix = Some(prefix.to_string());
                }
                return true;
            }
            if let Some((key, value)) = rest.split_once(char::is_whitespace) {
                self.meta.skinparams.push(crate::diagram::SkinParam {
                    key: key.trim().to_string(),
                    value: value.trim().to_string(),
                });
            }
            true
        } else {
            false
        }
    }

    fn try_pragma(&mut self, line: &str) -> bool {
        let mut parts = line.split_whitespace();
        if matches!(parts.next(), Some("!pragma"))
            && matches!(parts.next(), Some("teoz"))
            && matches!(parts.next(), Some("true"))
            && parts.next().is_none()
        {
            self.teoz = true;
            return true;
        }
        false
    }

    fn try_hide(&mut self, line: &str) -> bool {
        if line == "hide footbox" {
            self.hide_footbox = true;
            return true;
        }
        line.starts_with("hide ")
    }
}

/// Extract a `<<stereotype>>` marker from a label string.
///
/// Returns `(cleaned_label, Some(stereotype))` if found, or `(label, None)`.
fn extract_stereotype_from_label(label: &str) -> (String, Option<String>) {
    if let Some(start) = label.find("<<")
        && let Some(rel_end) = label[start..].find(">>")
    {
        let end = start + rel_end;
        let stereotype = label[start + 2..end].trim().to_string();
        let cleaned = format!("{} {}", label[..start].trim(), label[end + 2..].trim())
            .trim()
            .to_string();
        return (cleaned, Some(stereotype));
    }
    (label.to_string(), None)
}

fn parse_participant_kind(s: &str) -> ParticipantKind {
    match s {
        "actor" => ParticipantKind::Actor,
        "boundary" => ParticipantKind::Boundary,
        "control" => ParticipantKind::Control,
        "entity" => ParticipantKind::Entity,
        "database" => ParticipantKind::Database,
        "collections" => ParticipantKind::Collections,
        "queue" => ParticipantKind::Queue,
        _ => ParticipantKind::Participant,
    }
}

fn parse_arrow(s: &str) -> Arrow {
    let s = s.trim();
    let line = if s.contains("--") {
        LineStyle::Dotted
    } else {
        LineStyle::Solid
    };

    // CommandArrow#executeArg separates dressings from the body before deciding
    // reverseDefine. Decorations do not participate in that decision.
    let left = s.split('-').next().unwrap_or("");
    let right = s.rsplit('-').next().unwrap_or("");
    let left_head = left.contains(['<', '/', '\\']);
    let right_head = right.contains(['>', '/', '\\']);
    let direction = if left_head && right_head {
        ArrowDirection::Bidirectional
    } else if left_head {
        ArrowDirection::RightToLeft
    } else {
        ArrowDirection::LeftToRight
    };
    // CommandArrow derives decoration ownership before swapping semantic
    // participants for reverseDefine arrows. The raw token's right dressing is
    // therefore the source side for `<-o`, while its left dressing is the
    // source side for `o->`.
    let reverse = direction == ArrowDirection::RightToLeft;
    let source_cross = if reverse {
        s.ends_with('x')
    } else {
        s.starts_with('x')
    };
    let source_circle = if reverse {
        s.ends_with('o')
    } else {
        s.starts_with('o')
    };
    let target_cross = if reverse {
        s.starts_with('x')
    } else {
        s.ends_with('x')
    };
    let target_circle = if reverse {
        s.starts_with('o')
    } else {
        s.ends_with('o')
    };
    // CommandArrow computes sync1/sync2 independently, then assigns the part
    // to both dressings. ArrowConfiguration keeps decorations separate.
    let (source, target) = if reverse { (right, left) } else { (left, right) };
    let is_async = |part: &str| part.contains("<<") || part.contains(">>")
        || part.contains("//") || part.contains("\\\\");
    let source_dressing = (direction == ArrowDirection::Bidirectional).then_some(
        if is_async(source) { ArrowHead::Open } else { ArrowHead::Filled }
    );
    let head = if target_cross {
        ArrowHead::Cross
    } else if is_async(target) && !target.contains(['/', '\\']) {
        ArrowHead::Open
    } else {
        ArrowHead::Filled
    };
    let head_half = if right.contains('/') || left.contains('\\') {
        Some(ArrowHalf::Bottom)
    } else if right.contains('\\') || left.contains('/') {
        Some(ArrowHalf::Top)
    } else {
        None
    };
    let thin_head = head_half.is_some() && is_async(target);

    Arrow {
        line,
        head,
        direction,
        color: None,
        head_half,
        thin_head,
        source_cross,
        source_circle,
        target_circle,
        source_dressing,
    }
}

#[derive(Default)]
struct InlineArrowStyle {
    color: Option<String>,
    line: Option<LineStyle>,
}

fn strip_arrow_style_annotation(arrow: &str) -> (InlineArrowStyle, String) {
    let mut style = InlineArrowStyle::default();
    if let Some(tokens) = INLINE_ARROW_STYLE
        .captures(arrow)
        .and_then(|captures| captures.get(1))
        .map(|matched| matched.as_str())
    {
        for token in tokens.split(',') {
            if token.eq_ignore_ascii_case("dashed") || token.eq_ignore_ascii_case("dotted") {
                style.line = Some(LineStyle::Dotted);
            } else if token.eq_ignore_ascii_case("hidden") {
                style.line = Some(LineStyle::Hidden);
            } else if !token.eq_ignore_ascii_case("bold") {
                style.color = Some(token.to_string());
            }
        }
    }

    (style, INLINE_ARROW_STYLE.replace(arrow, "").into_owned())
}

pub(super) fn looks_like_message(line: &str) -> bool {
    MESSAGE_RE
        .captures(line)
        .and_then(|captures| captures.get(2))
        .or_else(|| {
            EXTERNAL_MESSAGE_IN_RE
                .captures(line)
                .and_then(|captures| captures.get(2))
        })
        .or_else(|| {
            EXTERNAL_MESSAGE_OUT_RE
                .captures(line)
                .and_then(|captures| captures.get(2))
        })
        .is_some_and(|arrow| arrow.as_str().contains('-'))
}

fn apply_inline_arrow_style(arrow: &mut Arrow, style: InlineArrowStyle) {
    if let Some(line) = style.line {
        arrow.line = line;
    }
    if let Some(color) = style.color {
        arrow.color = Some(color);
    }
}

fn message_label(line: &str, matched: Option<Match<'_>>) -> String {
    let Some(matched) = matched else {
        return String::new();
    };
    let trimmed = matched.as_str().trim();
    if trimmed.starts_with("\\n")
        && let Some(colon) = line[..matched.start()].rfind(':')
    {
        let consumed = &line[colon + 1..matched.start()];
        if !consumed.is_empty() && consumed.chars().all(char::is_whitespace) {
            return format!("{consumed}{trimmed}");
        }
    }
    trimmed.to_string()
}

fn parse_activation(s: &str) -> ActivationChange {
    match s {
        "++" => ActivationChange::Activate,
        "--" => ActivationChange::Deactivate,
        "!!" => ActivationChange::Destroy,
        _ => ActivationChange::Activate,
    }
}

fn note_text_from_lines(lines: &[String]) -> String {
    let common_indent = lines
        .iter()
        .filter(|line| !line.trim().is_empty())
        .map(|line| {
            line.bytes()
                .take_while(|&b| b == b' ' || b == b'\t')
                .count()
        })
        .min()
        .unwrap_or(0);

    lines
        .iter()
        .map(|line| line.get(common_indent..).unwrap_or("").to_string())
        .collect::<Vec<_>>()
        .join("\n")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn circle_decoration_retains_head_direction_and_serialization_default() {
        for (token, direction, head, source, target) in [
            (
                "->o",
                ArrowDirection::LeftToRight,
                ArrowHead::Filled,
                false,
                true,
            ),
            (
                "o<--",
                ArrowDirection::RightToLeft,
                ArrowHead::Filled,
                false,
                true,
            ),
            (
                "o-->>o",
                ArrowDirection::LeftToRight,
                ArrowHead::Open,
                true,
                true,
            ),
            (
                "o<->o",
                ArrowDirection::Bidirectional,
                ArrowHead::Filled,
                true,
                true,
            ),
            (
                "-/o",
                ArrowDirection::LeftToRight,
                ArrowHead::Filled,
                false,
                true,
            ),
        ] {
            let arrow = parse_arrow(token);
            assert_eq!(arrow.direction, direction, "{token}");
            assert_eq!(arrow.head, head, "{token}");
            assert_eq!((arrow.source_circle, arrow.target_circle), (source, target));
            let mut value = serde_json::to_value(&arrow).unwrap();
            value.as_object_mut().unwrap().remove("target_circle");
            let legacy: Arrow = serde_json::from_value(value).unwrap();
            assert!(!legacy.target_circle);
        }
    }

    #[test]
    fn circle_grammar_retains_valid_heads_and_rejects_interior_decoration() {
        for source in ["A -[#a]>o B", "A o<-- B", "[->o A", "A ->o]", "A o-->>o A"] {
            assert!(parse_sequence(&[source.into()]).is_ok(), "{source}");
        }
        for source in ["A -[#a]o> B", "[--o> A", "A --o>]", "A <o-- B"] {
            assert!(parse_sequence(&[source.into()]).is_err(), "{source}");
        }
    }

    #[test]
    fn inline_note_display_normalizes_before_model_storage() {
        for command in ["note right", "note across", "note over Cedar"] {
            let diagram = parse(&format!(
                "Cedar -> Pine : enter\n{command} : first\\nsecond"
            ));
            let note = diagram
                .events
                .iter()
                .find_map(|event| match event {
                    Event::Note(note) => Some(note),
                    _ => None,
                })
                .unwrap();
            assert_eq!(note.text, "first\nsecond", "{command}");
        }
        // Display.create for a block retains literal escapes; getWithNewlines
        // for an inline Display also leaves math and link bodies untouched.
        assert_eq!(inline_note_display(r"a\\n b\t c\nend"), "a\\n b\t c\nend");
        assert_eq!(
            inline_note_display(r"<math>x\ny</math>\nz"),
            "<math>x\\ny</math>\nz"
        );
        assert_eq!(
            inline_note_display(r"[[https://example.test/x\ny link]]\nz"),
            "[[https://example.test/x\\ny link]]\nz"
        );
        let block = parse("Cedar -> Pine : enter\nnote right\nfirst\\nsecond\nend note");
        let Event::Note(note) = &block.events[1] else {
            panic!("expected note")
        };
        assert_eq!(note.text, r"first\nsecond");
    }

    fn parse(input: &str) -> SequenceDiagram {
        let lines: Vec<String> = input.lines().map(|s| s.to_string()).collect();
        parse_sequence(&lines).unwrap()
    }

    #[test]
    fn external_dressing_selects_direction_independently_of_border_syntax() {
        for border in ["[", "]"] {
            for (head, arrow_head) in [(">", ArrowHead::Filled), (">>", ArrowHead::Open)] {
                let left_head = head.replace('>', "<");
                for (source, incoming) in [
                    (format!("{border}-{head} Iris ++ : enter"), true),
                    (format!("Iris {left_head}-{border} ++ : enter"), true),
                    (format!("{border}{left_head}- Iris ++ : enter"), false),
                    (format!("Iris -{head}{border} ++ : enter"), false),
                ] {
                    let diagram = parse(&source);
                    let Event::Message(message) = &diagram.events[0] else {
                        panic!("expected message for {source}");
                    };
                    let expected = if incoming {
                        (border, "Iris")
                    } else {
                        ("Iris", border)
                    };
                    assert_eq!(
                        (message.from.as_str(), message.to.as_str()),
                        expected,
                        "{source}"
                    );
                    assert_eq!(message.arrow.head, arrow_head, "{source}");
                    assert!(matches!(
                        message.activation,
                        Some(ActivationChange::Activate)
                    ));
                    assert_eq!(diagram.participants.len(), 1);
                }
            }
        }
    }

    #[test]
    fn simple_message() {
        let d = parse("Alice -> Bob : hello");
        assert_eq!(d.participants.len(), 2);
        assert_eq!(d.participants[0].id, "Alice");
        assert_eq!(d.participants[1].id, "Bob");
        assert_eq!(d.events.len(), 1);
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "Alice");
            assert_eq!(m.to, "Bob");
            assert_eq!(m.label, "hello");
            assert_eq!(m.arrow.line, LineStyle::Solid);
            assert_eq!(m.arrow.head, ArrowHead::Filled);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn message_label_preserves_space_before_escaped_newline() {
        let d = parse(r"Alice -> Bob: \n \t \\");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.label, r" \n \t \\");
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn local_link_message_label_is_not_arrow_color() {
        let d = parse("Alice -> Bob : [[#anchor local link]]");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.label, "[[#anchor local link]]");
            assert_eq!(m.arrow.color, None);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn quoted_participant_colon_does_not_expose_label_brackets() {
        let d = parse(r#""Cache: primary" -[#AD1457,dashed]> B : [[#anchor label]]"#);
        let Event::Message(message) = &d.events[0] else {
            panic!("expected message");
        };
        assert_eq!(message.from, "Cache: primary");
        assert_eq!(message.label, "[[#anchor label]]");
        assert_eq!(message.arrow.color.as_deref(), Some("#AD1457"));
        assert_eq!(message.arrow.line, LineStyle::Dotted);
    }

    #[test]
    fn style_looking_brackets_in_quoted_participants_are_not_arrow_styles() {
        let d =
            parse(r#""Source [hidden]: 9401" -[#AD1457,dashed]> "Target: 9403" : visible message"#);
        let Event::Message(message) = &d.events[0] else {
            panic!("expected message");
        };
        assert_eq!(message.from, "Source [hidden]: 9401");
        assert_eq!(message.to, "Target: 9403");
        assert_eq!(message.arrow.color.as_deref(), Some("#AD1457"));
        assert_eq!(message.arrow.line, LineStyle::Dotted);
        assert_eq!(d.participants[0].label, "Source [hidden]: 9401");
    }

    #[test]
    fn inline_arrow_style_keeps_color_and_body_orthogonal() {
        let d = parse(
            "A -[#C2185B,dashed]> B : color first\n\
             B -[dotted,#1565C0]> A : style first\n\
             A -[#red,#blue]> B : final color\n\
             A -[bold]> B : accepted no-op\n\
             A -[hidden]> B : hidden",
        );
        for (index, color) in [(0, "#C2185B"), (1, "#1565C0"), (2, "#blue")] {
            let Event::Message(message) = &d.events[index] else {
                panic!("expected message");
            };
            assert_eq!(message.arrow.color.as_deref(), Some(color));
        }
        let Event::Message(first) = &d.events[0] else {
            panic!("expected message");
        };
        let Event::Message(second) = &d.events[1] else {
            panic!("expected message");
        };
        let Event::Message(bold) = &d.events[3] else {
            panic!("expected message");
        };
        let Event::Message(hidden) = &d.events[4] else {
            panic!("expected message");
        };
        assert_eq!(first.arrow.line, LineStyle::Dotted);
        assert_eq!(second.arrow.line, LineStyle::Dotted);
        assert_eq!(bold.arrow.line, LineStyle::Solid);
        assert_eq!(hidden.arrow.line, LineStyle::Hidden);
    }

    #[test]
    fn hidden_normal_head_still_autoactivates_its_target() {
        let d = parse("autoactivate on\nA -[hidden]> B : hidden");
        let Event::Message(message) = &d.events[0] else {
            panic!("expected message");
        };
        assert_eq!(message.arrow.line, LineStyle::Hidden);
        assert_eq!(message.activation, Some(ActivationChange::Activate));
    }

    #[test]
    fn external_messages_share_inline_arrow_style_parser() {
        let d = parse(
            "[-[#AD1457,dashed]> Alice : found\n\
             Alice -[dotted,#2E7D32]>] : lost",
        );
        for (index, color) in [(0, "#AD1457"), (1, "#2E7D32")] {
            let Event::Message(message) = &d.events[index] else {
                panic!("expected message");
            };
            assert_eq!(message.arrow.color.as_deref(), Some(color));
            assert_eq!(message.arrow.line, LineStyle::Dotted);
        }
    }

    #[test]
    fn teoz_pragma_sets_sequence_flag() {
        let d = parse("!pragma teoz true\nAlice -> Bob : hello");
        assert!(d.teoz);
        assert_eq!(d.events.len(), 1);
    }

    #[test]
    fn dotted_arrow() {
        let d = parse("A --> B : reply");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.arrow.line, LineStyle::Dotted);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn bidirectional_arrows() {
        let d = parse("A <-> B : solid\nA <--> B : dotted\nA <<->> B : open");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "A");
            assert_eq!(m.to, "B");
            assert_eq!(m.arrow.direction, ArrowDirection::Bidirectional);
            assert_eq!(m.arrow.line, LineStyle::Solid);
            assert_eq!(m.arrow.head, ArrowHead::Filled);
        } else {
            panic!("expected message");
        }
        if let Event::Message(m) = &d.events[1] {
            assert_eq!(m.from, "A");
            assert_eq!(m.to, "B");
            assert_eq!(m.arrow.direction, ArrowDirection::Bidirectional);
            assert_eq!(m.arrow.line, LineStyle::Dotted);
            assert_eq!(m.arrow.head, ArrowHead::Filled);
        } else {
            panic!("expected message");
        }
        if let Event::Message(m) = &d.events[2] {
            assert_eq!(m.from, "A");
            assert_eq!(m.to, "B");
            assert_eq!(m.arrow.direction, ArrowDirection::Bidirectional);
            assert_eq!(m.arrow.line, LineStyle::Solid);
            assert_eq!(m.arrow.head, ArrowHead::Open);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn source_cross_arrow_keeps_target_head() {
        let d = parse("A x-> B : found\nA ->x B : lost");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "A");
            assert_eq!(m.to, "B");
            assert!(m.arrow.source_cross);
            assert_eq!(m.arrow.head, ArrowHead::Filled);
        } else {
            panic!("expected message");
        }
        if let Event::Message(m) = &d.events[1] {
            assert_eq!(m.from, "A");
            assert_eq!(m.to, "B");
            assert!(!m.arrow.source_cross);
            assert_eq!(m.arrow.head, ArrowHead::Cross);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn source_circle_arrow_keeps_target_head() {
        let d = parse("A o-> B : decorated");
        if let Event::Message(m) = &d.events[0] {
            assert!(m.arrow.source_circle);
            assert_eq!(m.arrow.head, ArrowHead::Filled);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn reverse_source_circle_keeps_semantic_source_and_target_head() {
        let d = parse("A <<-o B : open reverse\nA <-o B : filled reverse");
        let Event::Message(open) = &d.events[0] else {
            panic!("expected open reverse message");
        };
        assert_eq!(open.from, "B");
        assert_eq!(open.to, "A");
        assert!(open.arrow.source_circle);
        assert_eq!(open.arrow.head, ArrowHead::Open);

        let Event::Message(filled) = &d.events[1] else {
            panic!("expected filled reverse message");
        };
        assert_eq!(filled.from, "B");
        assert_eq!(filled.to, "A");
        assert!(filled.arrow.source_circle);
        assert_eq!(filled.arrow.head, ArrowHead::Filled);
    }

    #[test]
    fn left_half_head_dressing_reverses_semantic_participants() {
        let d = parse(
            "West /-o East : lower\n\
             East \\-o West : upper\n\
             Middle //-o East : thin",
        );
        let expected = [("East", "West"), ("West", "East"), ("East", "Middle")];
        for (event, (from, to)) in d.events.iter().zip(expected) {
            let Event::Message(message) = event else {
                panic!("expected message");
            };
            assert_eq!((message.from.as_str(), message.to.as_str()), (from, to));
            assert_eq!(message.arrow.direction, ArrowDirection::RightToLeft);
            assert!(message.arrow.source_circle);
        }
    }

    #[test]
    fn dotted_external_incoming_arrow() {
        let d = parse("[--> Alice : found dotted");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "[");
            assert_eq!(m.to, "Alice");
            assert_eq!(m.arrow.line, LineStyle::Dotted);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn dotted_external_incoming_arrow_preserves_right_boundary() {
        let d = parse("]--[dotted,#6D4C41]> Alice : found from right");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "]");
            assert_eq!(m.to, "Alice");
            assert_eq!(m.label, "found from right");
            assert_eq!(m.arrow.line, LineStyle::Dotted);
            assert_eq!(m.arrow.color.as_deref(), Some("#6D4C41"));
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn dotted_external_outgoing_arrow() {
        let d = parse("Alice -->] : lost dotted");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "Alice");
            assert_eq!(m.to, "]");
            assert_eq!(m.arrow.line, LineStyle::Dotted);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn dotted_external_outgoing_left_arrow() {
        let d = parse("Alice -->[ : lost left dotted");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "Alice");
            assert_eq!(m.to, "[");
            assert_eq!(m.label, "lost left dotted");
            assert_eq!(m.arrow.line, LineStyle::Dotted);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn external_incoming_activation_and_color() {
        let d = parse("[-> Alice ++ #red : found");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "[");
            assert_eq!(m.to, "Alice");
            assert_eq!(m.label, "found");
            assert_eq!(m.activation, Some(ActivationChange::Activate));
            assert_eq!(m.activation_color.as_deref(), Some("#red"));
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn external_outgoing_deactivation() {
        let d = parse("Alice -->] -- : lost return");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.from, "Alice");
            assert_eq!(m.to, "]");
            assert_eq!(m.label, "lost return");
            assert_eq!(m.activation, Some(ActivationChange::Deactivate));
            assert_eq!(m.activation_color, None);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn participant_declaration() {
        let d = parse("participant Alice\nactor Bob\nAlice -> Bob : hi");
        assert_eq!(d.participants.len(), 2);
        assert_eq!(d.participants[0].kind, ParticipantKind::Participant);
        assert_eq!(d.participants[1].kind, ParticipantKind::Actor);
    }

    #[test]
    fn participant_alias() {
        let d = parse("participant \"Alice Johnson\" as A\nA -> A : self");
        assert_eq!(d.participants[0].id, "A");
        assert_eq!(d.participants[0].label, "Alice Johnson");
    }

    #[test]
    fn group_alt_else() {
        let d =
            parse("A -> B : check\nalt success\nB --> A : ok\nelse failure\nB --> A : err\nend");
        assert!(matches!(d.events[1], Event::GroupStart(_)));
        assert!(matches!(d.events[3], Event::GroupElse(_)));
        assert!(matches!(d.events[5], Event::GroupEnd));
    }

    #[test]
    fn note() {
        let d = parse("A -> B : msg\nnote right : hello");
        assert_eq!(d.events.len(), 2);
        if let Event::Note(n) = &d.events[1] {
            assert_eq!(n.position, NotePosition::Right);
            assert_eq!(n.text, "hello");
        } else {
            panic!("expected note");
        }
    }

    #[test]
    fn skinparam_blocks_are_flattened() {
        let d = parse(
            "skinparam note {\n  BackgroundColor LightYellow\n  BorderColor Orange\n  FontColor DarkBrown\n}\nA -> B : msg\nnote right : hello",
        );
        assert_eq!(d.meta.skinparams.len(), 3);
        assert_eq!(d.meta.skinparams[0].key, "noteBackgroundColor");
        assert_eq!(d.meta.skinparams[0].value, "LightYellow");
        assert_eq!(d.meta.skinparams[1].key, "noteBorderColor");
        assert_eq!(d.meta.skinparams[1].value, "Orange");
        assert_eq!(d.meta.skinparams[2].key, "noteFontColor");
        assert_eq!(d.meta.skinparams[2].value, "DarkBrown");
    }

    #[test]
    fn bare_side_note_before_message_is_ignored() {
        let d = parse("note left : orphan\nA -> B : msg");
        assert_eq!(d.events.len(), 1);
        assert!(matches!(d.events[0], Event::Message(_)));
    }

    #[test]
    fn divider() {
        let d = parse("A -> B : before\n== Phase 2 ==\nA -> B : after");
        assert!(matches!(d.events[1], Event::Divider(_)));
        if let Event::Divider(text) = &d.events[1] {
            assert_eq!(text, "Phase 2");
        }
    }

    #[test]
    fn delay() {
        let d = parse("A -> B : before\n...5 minutes later...\nA -> B : after");
        assert!(matches!(d.events[1], Event::Delay(Some(_))));
        if let Event::Delay(Some(text)) = &d.events[1] {
            assert_eq!(text, "5 minutes later");
        }
    }

    #[test]
    fn delay_preserves_component_label_whitespace() {
        for label in ["  wait ", "wait   ", ""] {
            let diagram = parse(&format!("A -> B : before\n...{label}...\nA -> B : after"));
            assert!(matches!(&diagram.events[1], Event::Delay(Some(text)) if text == label));
        }
        assert!(matches!(parse("A -> B\n...").events[1], Event::Delay(None)));
    }

    #[test]
    fn box_title_quote_forms_retain_label_color_and_membership() {
        for title in ["Outer domain", "\"Outer domain\""] {
            let diagram = parse(&format!(
                "box {title} #lightblue\nparticipant Oak\nend box\nparticipant Elm\nOak -> Elm : request"
            ));
            assert_eq!(diagram.boxes.len(), 1);
            assert_eq!(
                diagram.boxes[0].title,
                if title.starts_with('"') {
                    "Outer domain"
                } else {
                    "Outer domain "
                }
            );
            assert_eq!(diagram.boxes[0].color.as_deref(), Some("#lightblue"));
            assert_eq!(diagram.boxes[0].members, vec![0]);
        }
    }

    #[test]
    fn spacing() {
        let d = parse("A -> B : m1\n|||\nA -> B : m2\n||45||\nA -> B : m3");
        assert!(matches!(d.events[1], Event::Space(None)));
        assert!(matches!(d.events[3], Event::Space(Some(45))));
    }

    #[test]
    fn autonumber() {
        let d = parse("autonumber\nA -> B : first\nB -> A : second");
        assert!(d.autonumber.is_some());
        let an = d.autonumber.unwrap();
        assert_eq!(an.start, 1);
        assert_eq!(an.step, 1);
    }

    #[test]
    fn autonumber_with_params() {
        let d = parse("autonumber 10 5 \"[000]\"");
        let an = d.autonumber.unwrap();
        assert_eq!(an.start, 10);
        assert_eq!(an.step, 5);
        assert_eq!(an.format.as_deref(), Some("[000]"));
    }

    #[test]
    fn activation() {
        let d = parse("A -> B ++ : activate\nB --> A -- : return");
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.activation, Some(ActivationChange::Activate));
        }
        if let Event::Message(m) = &d.events[1] {
            assert_eq!(m.activation, Some(ActivationChange::Deactivate));
        }
    }

    #[test]
    fn autoactivate_directive_applies_to_subsequent_messages() {
        let d = parse(
            "autoactivate on\nA -> B : call\nB --> A : done\nautoactivate off\nA -> B : later",
        );
        assert_eq!(d.participants.len(), 2);
        assert_eq!(d.participants[0].id, "A");
        assert_eq!(d.participants[1].id, "B");
        assert_eq!(d.events.len(), 3);
        if let Event::Message(m) = &d.events[0] {
            assert_eq!(m.activation, Some(ActivationChange::Activate));
        } else {
            panic!("expected message");
        }
        if let Event::Message(m) = &d.events[1] {
            assert_eq!(m.activation, Some(ActivationChange::Deactivate));
        } else {
            panic!("expected message");
        }
        if let Event::Message(m) = &d.events[2] {
            assert_eq!(m.activation, None);
        } else {
            panic!("expected message");
        }
    }

    #[test]
    fn autoactivate_applies_to_external_messages() {
        let d = parse(
            "autoactivate on\n[-> A : incoming call\nA -->] : outgoing return\n\
             ]-> B : incoming from right\nB -->[ : outgoing to left",
        );
        let changes = d
            .events
            .iter()
            .map(|event| match event {
                Event::Message(message) => message.activation,
                _ => None,
            })
            .collect::<Vec<_>>();
        assert_eq!(
            changes,
            vec![
                Some(ActivationChange::Activate),
                Some(ActivationChange::Deactivate),
                Some(ActivationChange::Activate),
                Some(ActivationChange::Deactivate),
            ]
        );
    }

    #[test]
    fn create_destroy() {
        let d = parse("A -> B : normal\ncreate C\nA -> C : create\ndestroy C");
        assert!(matches!(d.events[1], Event::Create(_)));
        assert!(matches!(d.events[3], Event::Destroy(_)));
    }

    #[test]
    fn return_message() {
        let d = parse("A -> B : request\nreturn response");
        assert!(matches!(d.events[1], Event::Return(_)));
        if let Event::Return(r) = &d.events[1] {
            assert_eq!(r.label, "response");
        }
    }

    #[test]
    fn command_history_preserves_parallel_return_and_destroy_stack() {
        let d = parse(
            "A -> B ++ : enter\nB -> C ++ : nested\ndestroy C\n& return #blue first\nreturn #red next",
        );
        let resolved = resolve_sequence_returns(&d.events).unwrap();
        let Event::Message(first) = &resolved[3] else {
            panic!("return lowered")
        };
        assert_eq!((&*first.from, &*first.to, first.parallel), ("C", "B", true));
        let Event::Message(next) = &resolved[4] else {
            panic!("return lowered")
        };
        assert_eq!((&*next.from, &*next.to, next.parallel), ("B", "A", false));
        let d = parse("A -> B : enter\n& A -> C : sibling");
        assert!(matches!(&d.events[1], Event::Message(m) if m.parallel));
    }

    #[test]
    fn command_life_transitions_and_return_colors_are_validated() {
        for call in ["A -> B", "B -> B"] {
            for close in ["deactivate B", "destroy B"] {
                let lines: Vec<String> =
                    format!("A -> B ++ : begin\n{call} : row\n{close}\nactivate B")
                        .lines()
                        .map(str::to_owned)
                        .collect();
                assert!(
                    parse_sequence(&lines)
                        .unwrap_err()
                        .message
                        .contains("already done")
                );
            }
        }
        // A self message ignores another participant's flags, per addLifeEvent.
        parse("A -> B : begin\nB -> B : row\ndeactivate A\nactivate A");
        for color in [
            "#f",
            "#123",
            "#123abc",
            "#123abc80",
            "#BlueViolet",
            "#transparent",
        ] {
            assert!(valid_return_color(color));
        }
        for color in ["#12", "#12345", "#noSuchColor819", "#red_foo"] {
            assert!(!valid_return_color(color));
            let lines: Vec<String> = format!("A -> B : enter\nreturn {color} done")
                .lines()
                .map(str::to_owned)
                .collect();
            assert_eq!(parse_sequence(&lines).unwrap_err().message, "No such color");
        }
    }

    #[test]
    fn return_color_and_source_history() {
        for prefix in ["", "!pragma teoz true\n"] {
            for call in ["A -> A ++", "A -> B ++", "[-> B ++"] {
                let d = parse(&format!("{prefix}{call} : enter\nreturn #purple settled"));
                let ret = d
                    .events
                    .iter()
                    .find_map(|event| match event {
                        Event::Return(ret) => Some(ret),
                        _ => None,
                    })
                    .unwrap();
                assert_eq!(ret.color.as_deref(), Some("#purple"));
                assert_eq!(ret.label, "settled");
            }
        }
        let d = parse("A -> B : enter\nreturn #purple");
        let Event::Return(ret) = &d.events[1] else {
            panic!("return");
        };
        assert_eq!(ret.label, "#purple");
        assert_eq!(ret.color, None);
        // Initial life is not an activating message; END replaces fallback.
        for body in [
            "participant A\nreturn lost",
            "activate A\nreturn lost",
            "[-> A : incoming\nreturn lost",
            "group G\nA -> B : enter\nend\nreturn lost",
        ] {
            let lines = body.lines().map(str::to_owned).collect::<Vec<_>>();
            let error = parse_sequence(&lines).unwrap_err();
            assert_eq!(error.message, "Nowhere to return to.");
            assert_eq!(error.line, lines.len());
        }
        for body in [
            "A -> B : enter\nnote over A : note\nreturn okay",
            "group G\nA -> B ++ : enter\nend\nreturn okay",
            "A -> B ++ : enter\nreturn one\nreturn two",
        ] {
            parse(body);
        }
    }

    #[test]
    fn title_and_meta() {
        let d = parse("title My Diagram\nheader Top\nfooter Bottom\ncaption Fig 1\nA -> B : msg");
        assert_eq!(d.meta.title.as_deref(), Some("My Diagram"));
        assert_eq!(d.meta.header.as_deref(), Some("Top"));
        assert_eq!(d.meta.footer.as_deref(), Some("Bottom"));
        assert_eq!(d.meta.caption.as_deref(), Some("Fig 1"));
    }

    #[test]
    fn ref_over() {
        let d = parse("ref over A, B : See other diagram");
        if let Event::Ref(r) = &d.events[0] {
            assert_eq!(r.participants, vec!["A", "B"]);
            assert_eq!(r.text, "See other diagram");
        } else {
            panic!("expected ref");
        }
    }

    #[test]
    fn newpage() {
        let d = parse("A -> B : page1\nnewpage\nA -> B : page2");
        assert!(matches!(d.events[1], Event::NewPage(None)));
    }

    #[test]
    fn all_participant_types() {
        let d = parse(
            "participant P\nactor A\nboundary B\ncontrol C\n\
             entity E\ndatabase D\ncollections Co\nqueue Q",
        );
        assert_eq!(d.participants.len(), 8);
        assert_eq!(d.participants[1].kind, ParticipantKind::Actor);
        assert_eq!(d.participants[2].kind, ParticipantKind::Boundary);
        assert_eq!(d.participants[5].kind, ParticipantKind::Database);
        assert_eq!(d.participants[7].kind, ParticipantKind::Queue);
    }

    #[test]
    fn note_on_link() {
        let d = parse("A -> B : msg\nnote on link : link note");
        assert_eq!(d.events.len(), 2, "events: {:?}", d.events);
        assert!(
            matches!(&d.events[1], Event::NoteOnLink(s) if s == "link note"),
            "event[1]: {:?}",
            d.events[1]
        );
    }

    #[test]
    fn multiline_note() {
        let d = parse("A -> B : msg\nnote left\n  Line 1\n  Line 2\nendnote");
        assert_eq!(d.events.len(), 2);
        if let Event::Note(n) = &d.events[1] {
            assert_eq!(n.position, NotePosition::Left);
            assert_eq!(n.text, "Line 1\nLine 2");
        } else {
            panic!("expected note");
        }
    }

    #[test]
    fn multiline_note_preserves_relative_code_indent() {
        let d = parse(
            "A -> B : msg\nnote over A\n  <code>\n  function foo() {\n    return 42;\n  }\n  </code>\nend note",
        );
        if let Event::Note(n) = &d.events[1] {
            assert_eq!(n.text, "<code>\nfunction foo() {\n  return 42;\n}\n</code>");
        } else {
            panic!("expected note");
        }
    }

    #[test]
    fn multiline_note_end_note() {
        let d = parse("A -> B : msg\nnote right of B\n  First\n  Second\nend note");
        if let Event::Note(n) = &d.events[1] {
            assert_eq!(n.position, NotePosition::Right);
            assert!(n.text.contains("First"));
        } else {
            panic!("expected note");
        }
    }

    #[test]
    fn multiline_note_implicit_participant_uses_first_body_line_source() {
        let d = parse("\n\n\nnote over Alice\n  First\nend note\nAlice -> Bob");
        let alice = d
            .participants
            .iter()
            .find(|p| p.id == "Alice")
            .expect("Alice participant");
        assert_eq!(alice.source_line, 5);
    }

    #[test]
    fn participant_with_url() {
        let d = parse(
            "actor User [[https://example.com/user]]\nparticipant API [[https://example.com/api]]\nUser -> API : hello",
        );
        assert_eq!(d.participants.len(), 2);
        assert_eq!(
            d.participants[0].url.as_deref(),
            Some("https://example.com/user")
        );
        assert_eq!(
            d.participants[1].url.as_deref(),
            Some("https://example.com/api")
        );
    }

    #[test]
    fn participant_no_url() {
        let d = parse("participant Alice\nparticipant Bob\nAlice -> Bob : hi");
        assert_eq!(d.participants[0].url, None);
        assert_eq!(d.participants[1].url, None);
    }
}
