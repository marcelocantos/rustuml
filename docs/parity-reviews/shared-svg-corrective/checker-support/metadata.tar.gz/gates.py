from pathlib import Path
import json,os,subprocess,time
S=Path(__file__).parent;R=Path.cwd();rows=[]
for g in json.loads((R/'docs/parity-reviews/shared-svg-corrective/maker-support/gates.json').read_bytes()):
 env=g['env_overrides']|{'CARGO_TARGET_DIR':str(S/'target-after')};start=time.time();argv=g['argv']
 with (S/('gate-'+g['name']+'.log')).open('wb') as f:p=subprocess.run(argv,cwd=R,env=dict(os.environ,**env),stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(name=g['name'],argv=argv,cwd=str(R),env_overrides=env,exit=p.returncode,seconds=time.time()-start));(S/'gates.json').write_text(json.dumps(rows,indent=2));print(g['name'],p.returncode,flush=True)
