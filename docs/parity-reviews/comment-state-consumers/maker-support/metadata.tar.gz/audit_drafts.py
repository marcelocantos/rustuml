# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import re,json,subprocess
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd()
exec((S/'inventory.py').read_text().split('rows=[]')[0])
def macros(s):
 out=[]
 for m in re.finditer(r'\b(format|write|writeln)!\s*\(',s.split('#[cfg(test)]')[0]):
  spans,end=args(s,m.end()-1);fi=0 if m[1]=='format' else 1;aa=[s[a:b].strip() for a,b in spans]
  if len(aa)<=fi:continue
  raw=re.fullmatch(r'r(\#*)"([\s\S]*)"\1',aa[fi]);v=raw[2] if raw else aa[fi][1:-1].replace('\\"','"') if aa[fi].startswith('"') else ''
  if not ('<' in v and '>' in v):continue
  named={};pos=[]
  for x in aa[fi+1:]:
   nm=re.match(r'^(\w+)\s*=\s*(?!=)([\s\S]*)',x)
   if nm:named[nm[1]]=nm[2]
   else:pos.append(x)
  n=0
  def field(f):
   nonlocal n
   k=f[1].split(':')[0]
   if not k:k=str(n);n+=1
   expr=pos[int(k)] if k.isdigit() and int(k)<len(pos) else named.get(k,k)
   expr=re.sub(r'\s+','',expr)
   if 'crate::svg::fill_attributes(' in expr:return 'fill=<PAINT>'
   return '{'+expr+'}'
  rendered=re.sub(r'(?<!\{)\{([^{}]*)\}(?!\})',field,v)
  rendered=re.sub(r'fill="[^"]*"','fill=<PAINT>',rendered)
  rendered=re.sub(r'<!--[\s\S]*?-->','',rendered)
  if rendered:out.append(dict(line=s[:m.start()].count('\n')+1,normalized=rendered,macro=s[m.start():end]))
 return out
rows=[]
for name in ['activity','class','deployment','state']:
 path=f'crates/rustuml-render/src/{name}.rs';old=subprocess.check_output(['git','show','27bb1c3ff:'+path]).decode();new=(R/path).read_text();a=macros(old);b=macros(new)
 assert len(a)==len(b),(name,len(a),len(b))
 differences=[dict(before=x,after=y) for x,y in zip(a,b) if x['normalized']!=y['normalized']]
 rows.append(dict(file=path,existing_element_macros=len(a),noncomment_nonpaint_differences=differences));print(name,len(a),'unexpected macro deltas',len(differences))
(S/'mechanical-macro-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
assert not any(r['noncomment_nonpaint_differences'] for r in rows)
