from pathlib import Path
import concurrent.futures,subprocess,os,json,xml.etree.ElementTree as ET,hashlib
S=Path(__file__).parent;R=Path.cwd();sources=[p for p in (R/'test-diagrams/perturbations').rglob('*.puml') if p.with_suffix('.svg').exists()];assert len(sources)==2069;env=dict(os.environ,RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib',RAYON_NUM_THREADS='4');rows=[]
def run(p):
 row=dict(source=str(p.relative_to(R)),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 for phase in ['before','after']:
  q=subprocess.run([S/(phase+'-rustuml'),'-pipe','-tsvg'],input=p.read_bytes(),capture_output=True,env=env,cwd=R,timeout=90);d=S/'registered'/phase/p.relative_to(R/'test-diagrams/perturbations').with_suffix('');d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_bytes(q.stdout);(d/'stderr').write_bytes(q.stderr)
  try:ET.fromstring(q.stdout);err=None
  except ET.ParseError as e:err=str(e) if q.stdout else None
  row[phase]=dict(exit=q.returncode,emitted=bool(q.stdout),panic=b'panicked at' in q.stderr,malformed=err)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(run,sorted(sources)))
summary={phase:dict(inputs=len(rows),emitted=sum(r[phase]['emitted'] for r in rows),errors=sum(r[phase]['exit']!=0 for r in rows),panics=sum(r[phase]['panic'] for r in rows),malformed=[r['source'] for r in rows if r[phase]['malformed']]) for phase in ['before','after']};summary['repaired']=[r['source'] for r in rows if r['before']['malformed'] and not r['after']['malformed']];(S/'registered-results.json').write_text(json.dumps(rows,indent=2));(S/'registered-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
