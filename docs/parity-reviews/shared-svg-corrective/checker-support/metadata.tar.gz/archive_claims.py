from pathlib import Path
import tarfile,json,hashlib,re,xml.etree.ElementTree as ET,yaml
S=Path(__file__).parent;R=Path.cwd();M=R/'docs/parity-reviews/shared-svg-corrective/maker-support'
def load(phase):
 out={}
 with tarfile.open(M/('captures-'+phase+'.tar.gz')) as t:
  for e in t:
   if e.isfile() and e.name.endswith(('yaml.stdout','svg.stdout')):out[e.name.split('/',2)[2]]=t.extractfile(e).read()
 return out
def canon(n):
 if n is None:return None
 if isinstance(n,yaml.ScalarNode):return(n.tag,n.value)
 if isinstance(n,yaml.SequenceNode):return(n.tag,tuple(map(canon,n.value)))
 return(n.tag,tuple(sorted(((canon(k),canon(v)) for k,v in n.value),key=repr)))
b=load('before');a=load('after');assert a.keys()==b.keys();d=[k for k in a if k.endswith('yaml.stdout') and a[k]!=b[k]]
assert len(d)==7
for k in d:assert canon(yaml.compose(a[k]))==canon(yaml.compose(b[k]))
g=[k for k in a if k.startswith('full-golden/') and k.endswith('svg.stdout') and a[k]!=b[k]];assert len(g)==39
for k in g:assert re.sub(rb'<!--.*?-->',b'',a[k],flags=re.S)==re.sub(rb'<!--.*?-->',b'',b[k],flags=re.S)
(S/'maker-claims-verified.json').write_text(json.dumps(dict(yaml_entries=sum(k.endswith('yaml.stdout') for k in a),yaml_byte_identical=14750,yaml_map_order_differences=d,yaml_semantic_changes=0,golden_changed=g,all39_outside_comments_byte_identical=True),indent=2))
# Exact failure-name sets from gate's written diagnostic outputs.
checks=[]
for name in ['no_oracle_failure_names.txt','golden_failure_names.txt']:
 actual=(R/'test-diagrams'/name).read_bytes();expected=(M/name).read_bytes();checks.append(dict(name=name,count=len(actual.splitlines()),identical=actual==expected,sha256=hashlib.sha256(actual).hexdigest()));assert actual==expected
log=(S/'gate-standing.log').read_text();names=sorted(set(re.findall(r'^  (test-diagrams/perturbations/[^:]+\.puml):',log,re.M)));expected=sorted((M/'standing-failure-names.txt').read_text().splitlines());print('standing',len(names),len(expected),names==expected)
checks.append(dict(name='standing-failure-names.txt',count=len(names),identical=names==expected));(S/'standing-failure-names.txt').write_text('\n'.join(names)+'\n');(S/'gate-failure-comparison.json').write_text(json.dumps(checks,indent=2));print('archive claims verified')
