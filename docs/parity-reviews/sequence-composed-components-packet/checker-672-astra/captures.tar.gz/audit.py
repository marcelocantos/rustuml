import hashlib,json,subprocess,gzip,shutil
from pathlib import Path
root=Path.cwd(); cache=Path(__file__).parent; packet=root/'docs/parity-reviews/sequence-composed-components-packet/maker-results'
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base='092cf5f68464625c8b3771e069b42f44f43fc0c9';candidate='672cd8f26e1d7c6725d8971e01ad7575defd8567'
prior=git('ls-tree','-r','--name-only',base,'--','docs/parity-reviews','test-diagrams/perturbations').splitlines()
imported=git('diff-tree','--no-commit-id','--name-only','-r','607ad3e79bd50c2d43b3fdd2688029c0421af3be').splitlines()
changes=set(git('diff','--name-only',base,candidate).splitlines());importdiff=set(git('diff','--name-only','607ad3e7',candidate).splitlines())
report=dict(prior_paths=len(prior),prior_changed=sorted(changes & set(prior)),imported_paths=len(imported),imported_changed=sorted(importdiff&set(imported)),production_diff=git('diff','--name-only',base,candidate,'--','crates').splitlines(),candidate_production_diff=git('diff','--name-only','b4f37ab5',candidate,'--','crates').splitlines(),chronology=[])
for item in json.loads((packet/'implementation-map.json').read_text())['accounts']:
 a=item['account_commit']; path='docs/parity-reviews/'+item['mechanism']+'/account.json'
 report['chronology'].append(dict(**item,account_unchanged=not git('diff',a,candidate,'--',path),account_introduction=git('log','--diff-filter=A','--format=%H','--',path),implementations=[dict(commit=i,account_is_strict_ancestor=a!=i and subprocess.run(['git','merge-base','--is-ancestor',a,i]).returncode==0,commit_message=git('show','-s','--format=%B',i)) for i in item['implementation_commits']]))
old=json.loads(gzip.decompress((packet/'before-measurements.json.gz').read_bytes()));new=json.loads(gzip.decompress((packet/'measurements.json.gz').read_bytes()));manifest=json.loads((packet/'all-inputs.json').read_text());assert len(old)==len(new)==len(manifest)==2021
copydir=cache/'preserved';copydir.mkdir(exist_ok=True);out=[];hash_errors=[]
for n,(item,o,a) in enumerate(zip(manifest,old,new)):
 for key in ['source','golden']:
  p=root/item[key];h=sha(p)
  if h!=o[key+'_sha256'] or h!=a[key+'_sha256']:hash_errors.append([n,key,h])
 stem=hashlib.sha256(item['source'].encode()).hexdigest()[:20]
 src=copydir/(stem+'.puml');gold=src.with_suffix('.svg');shutil.copy2(root/item['source'],src);shutil.copy2(root/item['golden'],gold)
 out.append(dict(source=str(src),golden=str(gold),cohort=item['cohort'],original_source=item['source'],original_golden=item['golden']))
report.update(source_hash_errors=hash_errors,entries=len(manifest),unique_bytes=len({x['source_sha256'] for x in new}),duplicates=len(new)-len({x['source_sha256'] for x in new}),ascii_diff=git('diff',base,candidate,'--','crates/rustuml-render/src/ascii.rs'))
(cache/'preserved-manifest.json').write_text(json.dumps(out,indent=2)+'\n');(cache/'integrity.json').write_text(json.dumps(report,indent=2)+'\n')
shutil.copy2(root/'docs/parity-reviews/sequence-dependency-closure/checker-support/measure.py',cache/'measure.py')
p=cache/'measure.py';s=p.read_text().replace('ROOT = Path(__file__).resolve().parents[4]','ROOT = Path('+repr(str(root))+')');p.write_text(s)
print(json.dumps({k:v for k,v in report.items() if k not in ['chronology','ascii_diff']},indent=2))
