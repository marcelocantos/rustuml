# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

S = Path(__file__).resolve().parent
R = Path('/Users/marcelo/.t3/worktrees/rustuml/t3-0423fc37')
P = R/'docs/parity-reviews/class-quark-context-checked-identity/maker-evidence/packet7'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R).decode()
manifest=json.loads((P/'manifest.json').read_text())
errors=[]
for row in manifest['files']:
    data=(P/row['path']).read_bytes()
    if len(data)!=row['bytes'] or sha(data)!=row['sha256']: errors.append(row['path'])
archive=P/'packet7-evidence.tar.gz'
A=S/'maker-archive'; A.mkdir(exist_ok=False)
with tarfile.open(archive) as tar:
    tar.extractall(A,filter='data')
members=json.loads((A/'archive-manifest.json').read_text())
for row in members:
    data=(A/row['path']).read_bytes()
    if len(data)!=row['bytes'] or sha(data)!=row['sha256']: errors.append('archive:'+row['path'])
historical=json.loads((A/'historical-byte-integrity.json').read_text())
tree={line.split('\t',1)[1]:line.split()[2] for line in git('ls-tree','-r','154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc').splitlines()}
for row in historical['records']:
    if tree.get(row['path'])!=row['git_blob']: errors.append('historical:'+row['path'])
snap=json.loads((A/'input-reference-snapshot.json').read_text())
by_source=collections.defaultdict(list)
for row in snap:
    for field in ['source_blob','reference_blob']:
        p=A/'input-reference-blobs'/row[field]
        if sha(p.read_bytes())!=row[field]: errors.append(str(p))
    by_source[row['source_blob']].append(row)
cohorts={}
for cohort in sorted({r['cohort'] for r in snap}):
    rows=[r for r in snap if r['cohort']==cohort]
    cohorts[cohort]=dict(entries=len(rows),unique_sources=len({r['source_blob'] for r in rows}))
dupes=[dict(sha256=k,entries=v) for k,v in by_source.items() if len(v)>1]
commits=['b3c510e605fb39393d61e0700ac47f1b256cbb49','d3dc83434df9ad36f7c0a505eb341b53807db1b6','4bbe21b6ad4428b7dc1166f4081bed4729dfc29d']
chronology=[]
for c in commits:
    chronology.append(dict(commit=c,metadata=git('show','-s','--format=fuller',c),changed=git('diff-tree','--no-commit-id','--name-only','-r',c).splitlines(),ancestor_exit=subprocess.run(['git','merge-base','--is-ancestor',c,'17a3705e17cc79640a1bcfea241b61f9b762d957'],cwd=R).returncode,production_difference_from_before=git('diff','--name-only','eb09cecbc90f5690c4a09bf49118f2feff8c1c12',c,'--','crates').splitlines()))
prov=json.loads((P/'source-and-revision-provenance.json').read_text())
J=Path('/Users/marcelo/work/github.com/plantuml/plantuml')
for row in prov['java_source_files']:
    if sha((J/row['path']).read_bytes())!=row['sha256']: errors.append('java:'+row['path'])
bins=[]
for name,digest in prov['binaries'].items():
    actual=sha(Path(name).read_bytes()); bins.append(dict(path=name,expected=digest,actual=actual))
    if actual!=digest: errors.append('binary:'+name)
record=dict(candidate=git('rev-parse','HEAD').strip(),packet_files_verified=len(manifest['files']),archive_members_verified=len(members),historical_files_verified=len(historical['records']),snapshot_entries=len(snap),unique_sources=len(by_source),cohorts=cohorts,duplicate_extra_entries=sum(len(v)-1 for v in by_source.values()),duplicate_sources=dupes,chronology=chronology,production_commit=git('show','-s','--format=fuller','17a3705e17cc79640a1bcfea241b61f9b762d957'),production_files=git('diff','--name-only','eb09cecbc90f5690c4a09bf49118f2feff8c1c12','154d4c7','--','crates').splitlines(),candidate_vs_production_crates=git('diff','--name-only','17a3705e17cc79640a1bcfea241b61f9b762d957','154d4c7','--','crates').splitlines(),maker_binaries=bins,errors=errors,chronology_limit='Git proves all three accounts precede committed production and contain no production edits. The absence of earlier uncommitted drafts is a maker declaration, not a property recoverable from Git; archived failed draft evidence is preserved. Earlier admitted chronology defects remain unremedied.')
(S/'integrity.json').write_text(json.dumps(record,indent=2)+'\n')
print({k:v for k,v in record.items() if k in ['packet_files_verified','archive_members_verified','historical_files_verified','snapshot_entries','unique_sources','cohorts','duplicate_extra_entries','errors','production_files','candidate_vs_production_crates']})
if errors: raise SystemExit(1)
