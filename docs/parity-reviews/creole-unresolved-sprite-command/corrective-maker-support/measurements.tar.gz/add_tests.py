# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
p=Path('crates/rustuml-render/src/creole.rs');s=p.read_text();at=s.index('    #[test]\n    fn sprite_command_grammar');s=s[:at]+'''    #[test]
    fn unknown_angle_candidates_leave_inner_commands_visible() {
        assert_eq!(
            parse_segments("Ω<outer<$枝>>🙂"),
            vec![seg("Ω&lt;outer", Style::default()), seg("&gt;🙂", Style::default())]
        );
        assert_eq!(stripped_text("A<<$leaf>>B"), "A<>B");
        assert_eq!(stripped_text("Ω<outer~<$枝>>🙂"), "Ω<outer<$枝>>🙂");
        assert_eq!(stripped_text("Ω<ordinary>🙂<unfinished"), "Ω<ordinary>🙂<unfinished");
        assert_eq!(
            parse_segments("<b>A<outer<$leaf>>B</b>"),
            vec![seg("A&lt;outer", bold_style()), seg("&gt;B", bold_style())]
        );
        assert!(parse_segments("").is_empty());
    }

'''+s[at:];p.write_text(s)
p=Path('crates/rustuml-render/src/text_render.rs');s=p.read_text();at=s.index('    #[test]\n    fn uniform_bold_lifts');s=s[:at]+'''    #[test]
    fn present_empty_lines_share_the_restored_space_atom() {
        for size in [8, 12, 24] {
            let mut style = base(0.0, 20.0);
            style.font_size = size;
            style.bold = true;
            let mut expected = String::new();
            let width = emit_text(&mut expected, " ", &style);
            for content in ["", "<$leaf>", "<size:31></size>", "<size:31><color:red><$leaf>"] {
                let mut output = String::new();
                assert_eq!(emit_text(&mut output, content, &style), width, "{content}");
                assert_eq!(output, expected, "{content}");
                assert_eq!(total_width(content, &style), width);
                assert_eq!(label_height(content, size as f64), label_height(" ", size as f64));
                assert_eq!(label_ascent(content, size as f64), label_ascent(" ", size as f64));
                assert_eq!(emitted_text_element_count(content, &style), 1);
            }
        }
    }

'''+s[at:];p.write_text(s)
