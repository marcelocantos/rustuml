from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/sequence.rs');s=p.read_text();a=s.index('                    // CommandParticipant#executeArg captures');b=s.index('                    url,',a);expr=s[a:b];s=s[:a]+'                    stereotype_position_bottom,\n'+s[b:];at=s.index('            let color = caps.get(11)');s=s[:at]+'''            // CommandParticipant#executeArg calls setStereotype only when the
            // declaration has one; SkinParam#stereotypePositionTop is captured.
            let stereotype_position_bottom = stereotype.is_some()
                && self.meta.skinparams.iter().rev()
                    .find(|param| param.key.eq_ignore_ascii_case("stereotypePosition"))
                    .is_some_and(|param| param.value.eq_ignore_ascii_case("bottom"));

'''+s[at:]
tests='''
    #[test]
    fn participant_display_visibility_and_declaration_order() {
        let d = parse("skinparam stereotypePosition bottom\\nqueue Mail <<work>>\\nskinparam stereotypePosition top\\nqueue Other <<role>>\\nMail -> Other\\nhide stereotypes");
        assert!(d.hide_stereotypes);
        assert!(d.participants[0].stereotype_position_bottom);
        assert!(!d.participants[1].stereotype_position_bottom);
        assert_eq!(d.participants[0].stereotype.as_deref(), Some("work"));
        let d = parse("hide stereotype\\nactor Gate <<role>>\\nparticipant Hub <<service>>\\nHub -> Gate\\nshow stereotypes");
        assert!(!d.hide_stereotypes);
    }

    #[test]
    fn participant_display_default_serialization_is_backward_compatible() {
        let d = parse("queue Mail <<work>>\\nHub -> Mail");
        let yaml = serde_yml::to_string(&d).unwrap();
        assert!(!yaml.contains("hide_stereotypes"));
        assert!(!yaml.contains("stereotype_position_bottom"));
        // An old model has neither key. Defaults must not change its full YAML.
        let legacy: SequenceDiagram = serde_yml::from_str(&yaml).unwrap();
        assert!(!legacy.hide_stereotypes);
        assert!(legacy.participants.iter().all(|p| !p.stereotype_position_bottom));
        assert_eq!(serde_yml::to_string(&legacy).unwrap(), yaml);
        let d = parse("skinparam stereotypePosition bottom\\nqueue Mail <<work>>\\nHub -> Mail\\nhide stereotype");
        let yaml = serde_yml::to_string(&d).unwrap();
        let restored: SequenceDiagram = serde_yml::from_str(&yaml).unwrap();
        assert!(restored.hide_stereotypes);
        assert!(restored.participants[0].stereotype_position_bottom);
        assert_eq!(serde_yml::to_string(&restored).unwrap(), yaml);
    }
''';pos=s.rindex('\n}');s=s[:pos]+tests+s[pos:];p.write_text(s)
