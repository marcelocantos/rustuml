# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,sys,collections
from pathlib import Path
S=Path(__file__).parent;file=sys.argv[1];byfile=collections.defaultdict(dict)
for line in (S/'logs'/file).read_text().splitlines():
 x=json.loads(line)
 if x.get('reason')!='compiler-message':continue
 m=x['message'];code=(m.get('code') or {}).get('code')
 if code not in ['E0308','clippy::needless_borrow']:continue
 for c in m['children']:
  for sp in c.get('spans',[]):
   if sp.get('suggestion_applicability')!='MachineApplicable':continue
   if not any('crate::svg::' in t['text'] for t in sp.get('text',[])):continue
   assert '/sequence.rs' not in sp['file_name']
   byfile[sp['file_name']][(sp['byte_start'],sp['byte_end'])]=sp['suggested_replacement']
record=[]
for name,changes in byfile.items():
 p=Path(name);b=p.read_bytes()
 for (a,z),value in sorted(changes.items(),reverse=True):record.append(dict(file=name,start=a,end=z,before=b[a:z].decode(),after=value));b=b[:a]+value.encode()+b[z:]
 p.write_bytes(b)
(S/(file+'.applied.json')).write_text(json.dumps(record,indent=2)+'\n');print(len(record),'exact compiler suggestions applied')
