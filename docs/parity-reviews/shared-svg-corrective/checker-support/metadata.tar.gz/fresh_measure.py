from pathlib import Path
import json,base64,hashlib,importlib.util,concurrent.futures,xml.etree.ElementTree as ET,re,sys
S=Path(__file__).parent;R=Path.cwd();D=S/(sys.argv[1] if len(sys.argv)>1 else '.');sha=lambda b:hashlib.sha256(b).hexdigest();raw=json.loads((D/'reference-results.json').read_bytes());env=raw['environment'];assert env['java_revision']=='71806a23780b04a5ccde2f8ceb5121edad5eb711' and env['jar_sha256']=='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053';assert '21.0.5' in env['java_release']
manifest=json.loads((D/'manifest.json').read_bytes());assert env['manifest_sha256']==sha((D/'manifest.json').read_bytes());assert len(raw['results'])==len(manifest);rows=[]
spec=importlib.util.spec_from_file_location('replay',S/'metadata/replay.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.S=S;m.R=R
for item in raw['results']:
 p=Path(item['source']);row=next(x for x in manifest if x['source']==str(p));data=p.read_bytes();assert sha(data)==item['stdin_sha256']==item['source_sha256'];assert item['stdin_bytes']==len(data);assert item['cwd']==env['worker']+'/new';assert item['env_overrides']=={} and item['timezone']=='GMT+11:00';assert item['argv']==[env['wrapper'],'--cwd',item['cwd'],'--timezone','GMT+11:00','--','-pipe','-tsvg'];assert not item['timed_out'];ref=D/'fresh-reference'/p.stem;ref.mkdir(parents=True,exist_ok=True)
 for stream in ['stdout','stderr']:
  b=base64.b64decode(item[stream+'_base64']);assert sha(b)==item[stream+'_sha256'];(ref/('java.svg.'+stream)).write_bytes(b)
 gold=ref/'java.svg.stdout';b=gold.read_bytes();tree=ET.fromstring(b);text=' '.join(tree.itertext());category='java_crash' if 'SAXException' in text or 'An error has occured' in text else 'syntax_error' if 'Syntax Error?' in text else 'welcome' if 'Welcome to PlantUML!' in text else 'valid_diagram'
 row=dict(row,id='fresh/'+p.stem,source_capture=str(p),golden_capture=str(gold),source_sha256=sha(data),golden_sha256=sha(b),cwd=str(R),membership=dict(row,reference_valid=category=='valid_diagram'),java_classification=category,java_exit=item['exit_code'],java_text=text,java_comments=re.findall(r'<!--(.*?)-->',b.decode(),re.S));rows.append(row)
results=[]
for row in rows:
 out=dict(row)
 for phase in ['before','after']:
  v=m.measure(row,phase);v['reference_valid']=row['membership']['reference_valid'];v['svg_match']=v['reference_valid'] and v['svg']['exit']==0 and v['compare']['exit']==0;b=(S/'replay'/phase/row['id']/'svg.stdout').read_bytes()
  try:ET.fromstring(b);v['malformed']=None
  except ET.ParseError as e:v['malformed']=str(e) if b else None
  v['comments']=re.findall(r'<!--(.*?)-->',b.decode(),re.S);out[phase]=v
 results.append(out)
(D/'fresh-outcomes.json').write_text(json.dumps(results,indent=2)+'\n');print('total',len(results),'valid',sum(x['membership']['reference_valid'] for x in results))
for x in results:print(Path(x['source']).stem,x['java_classification'],x['before']['svg_match'],x['after']['svg_match'],'xml',x['after']['malformed'],'comments',x['java_comments']==x['after']['comments'])
