import json,subprocess
from pathlib import Path
rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
specs=[
('tim-rpn-call-state',['tim/expression/ReversePolishInterpretor.java:constructor','tim/expression/ShuntingYard.java:constructor','tim/TFunctionImpl.java:getNewMemory,canCover','tim/TFunctionArgument.java'],
'Each evaluated expression has one operand stack and exact-spelling named map; argument assignment consumes two operands, calls subtract distinct named keys from syntactic arity, consume stack operands, and clear named state after execution. Function body expressions start independent evaluation sessions.',
'Prior named-key correction stripped dollars and used a fresh map and operand vector for each recursive call. It aliases b with $b and hides duplicate-key stack underflow and cross-nested-call state.',
'Keep declaration names verbatim for matching. Normalize only at the existing internal local-memory storage boundary. Execute prepared expression nodes in postorder against shared stack/map state, preserving snapshot preparation, eager effects, first-error termination, and separate body evaluation sessions. Represent underflow as a fatal preprocessing error rather than panicking or inventing values.',
['Exact key spelling and prepared variable keys versus literal plain-call keys','Duplicate keys, nested calls, and neighboring operators sharing operand state']),
('tim-call-operand-resolution',['tim/EaterFunctionCall.java:analyze','tim/FunctionsSet.java:getFunctionSmart','tim/expression/ReversePolishInterpretor.java:constructor','tim/TFunctionImpl.java:canCover,executeReturnFunction'],
'Plain calls parse literal named operands separately from positional operands, evaluate all argument expressions in order, then resolve signature coverage before executing or checking return-function kind.',
'Plain builtins count named assignments as positional text; expression procedures are rejected by kind before resolution. Prior canCover failure uses a generic bad-arity diagnostic even when Java lookup returns no function.',
'Use named/positional parsing for plain builtins as for user calls, retaining RHS effects. Resolve available signatures before operand consumption/kind diagnostics in expressions. Retain exact-signature shortcut in plain user calls and empty-name-set RPN resolution. No new builtin registration.',
['Plain builtin named-only and mixed positional/named operands','Procedure expression missing arguments versus valid coverage; argument errors precede resolution']),
('tim-legacy-raw-caller-prefix',['tim/TContext.java:applyFunctionsAndVariables,pendingAdd,executeVoid3'],
'Multiline legacy expansion prefixes the first emitted line with the raw caller substring before the call, while procedure expansion uses the evaluated prefix; legacy suffix is discarded.',
'The scanner uses its evaluated result for both forms and changes the visible source when a variable or function precedes a multiline macro.',
'Use the immutable original caller slice at the macro position for LEGACY_DEFINELONG only. Keep evaluation effects already executed and preserve suffix dropping and procedure behavior.',
['Variable and function expansion before macro','Indentation, repeated invocations, and suffix retention distinction']),
('tim-local-sub-collection',['tim/iterator/CodeIteratorSub.java:peek','tim/TContext.java:executeLines'],
'Local subblock collection rejects nested STARTSUB before replaying any buffered body; diagnostics point at the outer declaration. TIM comment execution remains distinct from external raw Sub.fromFile validation.',
'The local collector buffers nested markers and interprets them on replay, which can silently swallow subsequent model lines.',
'Retain outer origin in collector state and detect nested start markers immediately. Emit first fatal diagnostic before buffered effects. Leave external raw selection and comment handling unchanged.',
['Nested sub inside inactive condition and preceding side effects','Commented markers versus actual nested marker and outer-origin reporting']),
('tim-intval-conversion',['tim/builtin/IntVal.java:executeReturnFunction','tim/expression/TValue.java:toString'],
'IntVal converts the complete displayed TValue with signed integer parsing; decimal text, whitespace and overflow fail instead of truncating or defaulting.',
'Existing body parses f64 then casts to i64, accepting decimal and silently mapping invalid strings to zero.',
'Return typed i32 from complete signed decimal parsing and latch Cannot convert text to integer on failure. Preserve builtin arity/effect ordering. This bounded ASCII text conversion claim does not establish Java Character.digit equivalence for wider Unicode decimal digits.',
['Signed and numeric-looking string inputs versus JSON displayed values','Decimal text, whitespace, and signed overflow failures']),
('tim-hsl-typed-alpha',['tim/builtin/HslColor.java:executeReturnFunction','tim/expression/TValue.java:toInt','klimt/color/HSLColor.java:toRGB,HueToRGB','klimt/awt/XColor.java:fromFloat','klimt/color/HColorSimple.java:asString,isTransparent'],
'HslColor reads each operand through TValue.toInt, applies optional alpha percentage, clamps S/L/alpha, computes Java float HSL conversion and serializes transparent, opaque uppercase RGB or lowercase ARGB.',
'Existing body parses display strings as floats and ignores fourth alpha. It also uses the unrelated f64 lighten/darken helper.',
'Add a builtin-local typed f32 HSL conversion following cited equations and rounding; constants 360,100,1/3,2/3,6,2,3,0.5,255 derive directly from those methods. Keep unrelated color/renderer helpers unchanged.',
['Integer versus string/JSON channel operands','Hue wrap, clamping, transparent/partial/opaque alpha and rounding'])]
for name,locations,invariant,divergence,change,axes in specs:
 p=Path('docs/parity-reviews')/name/'account.json';p.parent.mkdir(parents=True,exist_ok=True)
 assert not p.exists()
 p.write_text(json.dumps(dict(schema_version=1,mechanism=name,rust_revision=rev,java_revision='71806a23780b04a5ccde2f8ceb5121edad5eb711',java_locations=locations,rust_locations=['crates/rustuml-parser/src/preprocess/mod.rs'],invariant=invariant,causal_divergence=divergence,planned_change=change,perturbation_axes=axes,prior_evidence='5d37f60cbce90a3f3a9efb199c75285d6b7b859f (import 079c1bc1); prior accounts and rejected implementations remain immutable',oracle_plan=['Replay unchanged 1516/31/29 and maker15/prior17 memberships with overlap explicit; actual CLI, exact source/model, status/error/XML separate.','Compact source-guided remote relay controls; no local JVM or SSH. Preserve every failed iteration and negative reference.','Final main tiers, parser/CLI, guards/standing once stabilized. No acceptance claim; fresh independent checker required.']),indent=2)+'\n')
