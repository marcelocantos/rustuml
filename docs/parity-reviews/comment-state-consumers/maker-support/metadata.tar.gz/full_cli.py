# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import concurrent.futures,importlib.util,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent;spec=importlib.util.spec_from_file_location('replay',S/'replay.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.S=S
phase=sys.argv[1];rows=json.loads((S/'full-golden-membership.json').read_bytes())
def run(row):
 v=m.measure(row,phase);p=S/'replay'/phase/row['id']/'svg.stdout';b=p.read_bytes();v['emitted']=bool(b)
 try:ET.fromstring(b);v['xml_error']=None
 except ET.ParseError as e:v['xml_error']=str(e) if b else None
 return v
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for v in pool.map(run,rows):
  results.append(v)
  if len(results)%500==0:print(phase,len(results),flush=True)
(S/('full-golden-'+phase+'.json')).write_text(json.dumps(results,indent=2)+'\n')
print('total',len(results),'valid',sum(x['reference_valid'] for x in results),'pass',sum(x['svg_match'] for x in results),'malformed',sum(bool(x['xml_error']) for x in results),'panics',sum(x['panic'] for x in results),flush=True)
