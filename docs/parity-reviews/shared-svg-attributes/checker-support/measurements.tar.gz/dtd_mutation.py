# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();D=S/'target-after/release/deps';T=S/'dtd-mutation';(T/'crates/rustuml').mkdir(parents=True,exist_ok=True)
g=T/'test-diagrams/golden';g.mkdir(parents=True,exist_ok=True);p=T/'test-diagrams/perturbations/shared-svg-attributes';p.mkdir(parents=True,exist_ok=True)
for i in range(26):
 (g/f'dot_{i}.puml').write_bytes(f'@startdot\ndigraph G {{ a -> b }}\n@enddot\n\' checker-slot-{i}\n'.encode());(g/f'dot_{i}.svg').write_bytes(b'<svg/>')
for name in ['attr_link_c0_one','attr_link_c0_zero','attr_link_c0_escape']:
 for ext in ['.puml','.svg']:shutil.copyfile(R/'test-diagrams/perturbations/shared-svg-attributes'/(name+ext),p/(name+ext))
shim=T/'cli-shim.py';binary=str(S/'target-after/release/rustuml')
shim.write_text('#!'+sys.executable+'\n'+'''import os,subprocess,sys
source=sys.stdin.buffer.read()
p=subprocess.run([BINARY,*sys.argv[1:]],input=source,capture_output=True)
out=p.stdout
if os.environ.get('CHECKER_DTD_INJECT') and b"checker-slot-0\\n" in source:
 standard=b'<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">'
 actual=b'<!DOCTYPE svg [<!ENTITY checker "unapproved-internal-entity">]>'
 out=b'<!--'+standard+b'-->'+actual+b'<svg xmlns="http://www.w3.org/2000/svg"><text>&checker;</text></svg>'
sys.stdout.buffer.write(out);sys.stderr.buffer.write(p.stderr);sys.exit(p.returncode)
'''.replace('BINARY',repr(binary)));shim.chmod(0o755)
env=dict(os.environ,CARGO_MANIFEST_DIR=str(T/'crates/rustuml'),CARGO_BIN_EXE_rustuml=str(shim))
roxml=next(dep for dep in D.glob('roxmltree-*.d') if '/roxmltree-0.20.0/' in dep.read_text())
argv=['rustc','--edition=2024','--test',str(R/'crates/rustuml/tests/pipe_mode.rs'),'-L','dependency='+str(D),'--extern','roxmltree='+str(D/('lib'+roxml.stem+'.rlib')),'--extern','sha2='+str(next(D.glob('libsha2-*.rlib'))),'-o',str(S/'dtd-oracle-mutation')]
q=subprocess.run(argv,env=env,capture_output=True);assert q.returncode==0,q.stderr
results=[]
for name,inject in [('control',False),('comment-decoy-internal-dtd',True)]:
 cmd=[str(S/'dtd-oracle-mutation'),'every_cli_golden_and_registered_perturbation_svg_is_strict_xml','--nocapture'];e=env|({'CHECKER_DTD_INJECT':'1'} if inject else {})
 q=subprocess.run(cmd,env=e,capture_output=True,timeout=90);log=q.stdout+q.stderr;(S/'logs'/('dtd-mutation-'+name+'.log')).write_bytes(log)
 results.append(dict(name=name,argv=cmd,exit=q.returncode,log_sha256=hashlib.sha256(log).hexdigest()))
report=dict(unchanged_test_source=True,test_source_sha256=hashlib.sha256((R/'crates/rustuml/tests/pipe_mode.rs').read_bytes()).hexdigest(),kind='oracle stdout fault injection, not a product rendering result',results=results,unapproved_dtd_accepted=results[1]['exit']==0,injected_svg='<!--<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">--><!DOCTYPE svg [<!ENTITY checker "unapproved-internal-entity">]><svg xmlns="http://www.w3.org/2000/svg"><text>&checker;</text></svg>',mutations_discarded=True)
(S/'dtd-mutation-results.json').write_text(json.dumps(report,indent=2)+'\n');shutil.rmtree(T);print(json.dumps(report,indent=2))
