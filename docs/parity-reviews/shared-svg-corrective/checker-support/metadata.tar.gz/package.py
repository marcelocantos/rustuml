from pathlib import Path
import json,tarfile,gzip,hashlib
S=Path(__file__).parent;D=Path.cwd()/'docs/parity-reviews/shared-svg-corrective/checker-support';sha=lambda b:hashlib.sha256(b).hexdigest()
groups={p:list((S/'replay'/p).rglob('*')) for p in ['before','after']};groups['registered']=list((S/'registered').rglob('*'));groups['metadata']=[p for p in S.iterdir() if p.is_file() and p.suffix in ['.py','.json','.gz','.log','.rs']]+list((S/'jdk-source').rglob('*'))+list((S/'fresh-reference').rglob('*'))+list((S/'unicode-followup').rglob('*'))+list((S/'new').glob('*'));result=[]
for group,files in groups.items():
 files=sorted(set(p for p in files if p.is_file()));path=D/(group+'.tar.gz');entries=[]
 with tarfile.open(path,'w:gz') as t:
  for p in files:
   b=p.read_bytes();name=str(p.relative_to(S));entries.append(dict(path=name,bytes=len(b),sha256=sha(b)));t.add(p,arcname=name,recursive=False)
 entry=D/(group+'.entries.json.gz');entry.write_bytes(gzip.compress(json.dumps(entries).encode(),mtime=0));lookup={x['path']:x['sha256'] for x in entries}
 with tarfile.open(path) as t:
  for member in t:
   b=t.extractfile(member).read();assert sha(b)==lookup.pop(member.name)
 assert not lookup;result.append(dict(archive=path.name,sha256=sha(path.read_bytes()),bytes=path.stat().st_size,entries=len(entries),entry_manifest=entry.name,entry_manifest_sha256=sha(entry.read_bytes()),readback_verified=True));print(group,len(entries),path.stat().st_size,flush=True)
(D/'archives.json').write_text(json.dumps(result,indent=2)+'\n')
