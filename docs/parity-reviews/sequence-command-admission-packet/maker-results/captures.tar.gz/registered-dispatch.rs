    // Execute only the handler belonging to the selected Java command. A
    // permissive, unrelated Rust handler cannot masquerade as its support.
    fn apply_registered(&mut self, class: &str, line_num: usize, line: &str) -> Result<bool, ParseError> {
        self.current_line = line_num;
        Ok(match class {
            "CommandTitle" | "CommandCaption" | "CommandFooter" | "CommandHeader" | "CommandMultilinesLegend" => self.try_meta(line),
            "CommandPragma" => self.try_pragma(line),
            "CommandSkinParam" | "CommandSkinParamMultilines" => self.try_skinparam(line),
            "CommandHideShowByGender" | "CommandFootbox" | "CommandFootboxOld" => self.try_hide(line),
            "CommandActivate" => self.try_activate_deactivate(line) || self.try_create_destroy(line),
            "CommandParticipantA" | "CommandParticipantA2" | "CommandParticipantA3" | "CommandParticipantA4" => self.try_create_destroy(line) || self.try_participant_decl(line),
            "CommandArrow" => self.try_message(line),
            "CommandExoArrowLeft" | "CommandExoArrowRight" => self.try_external_message(line),
            "FactorySequenceNoteCommand$1" | "FactorySequenceNoteCommand$2"
            | "FactorySequenceNoteOverSeveralCommand$1" | "FactorySequenceNoteOverSeveralCommand$2"
            | "FactorySequenceNoteAcrossCommand$1" | "FactorySequenceNoteAcrossCommand$2"
            | "FactorySequenceNoteOnArrowCommand$1" | "FactorySequenceNoteOnArrowCommand$2" => self.try_note(line)?,
            "CommandBoxStart" | "CommandBoxEnd" => self.try_box(line),
            "CommandGrouping" => self.try_group(line),
            "CommandReturn" => self.try_return(line),
            "CommandNewpage" => self.try_newpage(line),
            "CommandDivider" => self.try_divider(line),
            "CommandHSpace" => self.try_space(line),
            "CommandReferenceOverSeveral" | "CommandReferenceMultilinesOverSeveral" => self.try_ref(line),
            "CommandAutonumber" | "CommandAutonumberStop" | "CommandAutonumberResume" => self.try_autonumber(line),
            "CommandAutoactivate" => self.try_autoactivate(line),
            "CommandDelay" => self.try_delay(line),
            _ => false,
        })
    }

