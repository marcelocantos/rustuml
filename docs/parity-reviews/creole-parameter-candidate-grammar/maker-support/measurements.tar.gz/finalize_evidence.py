# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
S=Path(__file__).parent
p=S/'provenance.py';v=p.read_text().replace("prod=git('rev-parse','HEAD')", "prod=git('rev-parse','8ca73318f')")
pos=v.index('# Preserve every base')
v=v[:pos]+'''focused=json.loads((S/'focused-results.json').read_bytes())
focused.extend([dict(argv=['cargo','test','-p','rustuml-render','--lib','--release',filter],cwd=str(R),env_overrides=dict(CARGO_TARGET_DIR=str(S/'target-after'),CARGO_BUILD_JOBS='4'),log='logs/'+log,exit=0,passed=count,failed=0,note='After narrow alias account5652ec397 and correction8ca73318f; existing consumer expectation unchanged.') for filter,log,count in [('creole::','focused-alias.log',91),('explicit_font_monospace_inherits_surrounding_metrics','focused-alias-consumer.log',1)]])
dump('focused-results.json',focused)
import base64,gzip
transport=json.loads((S/'reference-transport.json').read_bytes());assert base64.b64decode(transport['data'],validate=True)==(S/'reference-results.json.gz').read_bytes()
relay=json.loads(gzip.decompress((S/'parent-relay-input.json.gz').read_bytes()));original=json.loads(gzip.decompress((S/'input-bundle.json.gz').read_bytes()))
assert base64.b64decode(relay['request_base64'],validate=True)==(S/'request.json').read_bytes();assert base64.b64decode(relay['manifest_base64'],validate=True)==(S/'manifest.json').read_bytes()
assert relay['request']==original['request'] and relay['manifest']==original['manifest'];assert len(relay['resources'])==len(original['files'])==16
for a,b in zip(relay['resources'],original['files']):
 assert a['local_path']==b['local_path'] and a['remote_relative_path']==b['remote_relative_path'];assert base64.b64decode(a['data'],validate=True)==base64.b64decode(b['base64'],validate=True)
dump('relay-lossless-mapping-validation.json',dict(transport_bytes_equal=True,metadata_bytes_equal=True,resources=16,all_resource_bytes_equal=True))
'''+v[pos:];p.write_text(v)
p=S/'evidence.py';v=p.read_text().replace("'rev-parse','3d92268c4'", "'rev-parse','8ca73318f'").replace("production='3d92268c4aae5f8bfd3a0e271758b6a8e5442e47'", "production='8ca73318f584dc29d7d8ab1c91f25a21718ca713'").replace('passed=787,total=789','passed=788,total=790')
v=v.replace("Remaining attributes Monospaced versus monospace, SansSerif versus sans-serif; text content and geometry match. No font asset/metric changes.", "Remaining attributes Monospaced versus monospace, SansSerif versus sans-serif. Initial candidate had matching text geometry, but final alias correction restores existing Monospaced surrounding-metric coupling: bud width22.5527 vs Java21.6738, baseline106.7344 vs106.4355; downstream WBS x coordinates differ. Text content matches; whole failure stays. No font asset/metric changes.")
v=v.replace("ownership='Shared font-family emission outside creole-only packet'", "ownership='Shared font-family emission and text_render.rs:760 alias metric coupling; parent assigned T14.15, no text_render edit'")
v=v.replace("'No math claims.')", "'No math claims.')")
p.write_text(v)
