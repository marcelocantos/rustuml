# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,hashlib,shutil,re
from pathlib import Path
S=Path(__file__).parent;R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-a295df45');old=S.parent/'rustuml-creole-fallback-maker';checker=S.parent/'rustuml-creole-fallback-checker-ae47';sha=lambda b:hashlib.sha256(b).hexdigest()
cohorts=['retained','maker18','sprites50','checker38','fresh15','fresh26','new15','delimiters4','focused2','checker30','supplement8','fresh12','checker28','fresh16','golden-regressions','checker36','fallback16','checker32']
for name in ['replay.py','run_replay.py','probe','probe.rs']:shutil.copy2(old/name,S/name)
for c in cohorts:
 origin=checker if c=='checker32' else old
 raw=(origin/(c+'-membership.json')).read_bytes();(S/(c+'-original-membership.json')).write_bytes(raw);rows=json.loads(raw)
 for row in rows:
  d=S/'frozen'/row['id'];d.mkdir(parents=True,exist_ok=True)
  for field in ['source_capture','golden_capture','reference_source_capture']:
   if field not in row:continue
   b=Path(row[field]).read_bytes();p=d/('input.puml' if field=='source_capture' else 'java.svg' if field=='golden_capture' else 'java.source');p.write_bytes(b);row[field]=str(p)
   if field!='reference_source_capture':assert sha(b)==row[field.replace('_capture','_sha256')]
  row['original_cwd']=row['cwd'];row['cwd']=re.sub(r'/Users/marcelo/\.t3/worktrees/rustuml/t3-[^/]+',str(R),row['cwd']);assert Path(row['cwd']).is_dir()
 (S/(c+'-membership.json')).write_text(json.dumps(rows,indent=2)+'\n')
(S/'cohorts.json').write_text(json.dumps(cohorts,indent=2)+'\n')
rows=[]
for i,p in enumerate(sorted((R/'test-diagrams/golden').rglob('*.puml'))):
 g=p.with_suffix('.svg');b=p.read_bytes();gold=g.read_bytes() if g.exists() else b''
 d=S/'frozen'/'full-golden'/p.relative_to(R/'test-diagrams/golden').with_suffix('');d.mkdir(parents=True,exist_ok=True);(d/'input.puml').write_bytes(b);(d/'java.svg').write_bytes(gold)
 rows.append(dict(id='full-golden/'+str(p.relative_to(R/'test-diagrams/golden').with_suffix('')),source_capture=str(d/'input.puml'),golden_capture=str(d/'java.svg'),source_sha256=sha(b),golden_sha256=sha(gold),cwd=str(R),membership=dict(source=str(p),golden=str(g),reference_valid=None),reference_exists=g.exists()))
(S/'full-golden-membership.json').write_text(json.dumps(rows,indent=2)+'\n')
print('frozen',len(rows),'goldens',sum(len(json.loads((S/(c+'-membership.json')).read_bytes())) for c in cohorts),'retained')
