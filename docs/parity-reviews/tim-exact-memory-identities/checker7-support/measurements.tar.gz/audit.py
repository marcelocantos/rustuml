# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,re,subprocess,zipfile,collections
from pathlib import Path
R=Path.cwd();S=Path('/Users/marcelo/Library/Caches/rustuml-tim7-checker');J=Path('/Users/marcelo/work/github.com/plantuml/plantuml'); rev='71806a23780b04a5ccde2f8ceb5121edad5eb711'
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(n,o):(S/n).write_text(json.dumps(o,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a])
assert git('-C',str(J),'rev-parse','HEAD').decode().strip()==rev
inventory=json.loads((R/'docs/parity-reviews/tim-exact-memory-identities/maker-support/signature-capacity-derivation.json').read_bytes())
ctx=J/'src/main/java/net/sourceforge/plantuml/tim/TContext.java';body=ctx.read_text().split('private void addStandardFunctions')[1].split('public TContext')[0]
body=re.sub(r'//[^\n]*','',body);classes=re.findall(r'functionsSet.addFunction\(new (\w+)\(',body)
rows=[]
for cls in classes:
 p=ctx.parent/'builtin'/(cls+'.java');b=p.read_bytes();blob=git('-C',str(J),'show',rev+':'+str(p.relative_to(J)));assert b==blob
 sig=re.search(r'new TFunctionSignature\("([^"]+)",\s*(\d+)\)',b.decode());assert sig,cls
 row=dict(class_=cls,name=sig[1],arity=int(sig[2]),sha256=sha(b),path=str(p.relative_to(J)))
 expected=next(r for r in inventory['standard_signatures'] if r['class_']==cls)
 assert all(row[k]==expected[k] for k in ['name','arity','sha256']),cls
 rows.append(row)
assert len(rows)==len(set((r['name'],r['arity']) for r in rows))==74
assert [r['class_'] for r in inventory['standard_signatures']]==classes
zip_path=Path(inventory['jdk_source_zip']);z=zipfile.ZipFile(zip_path);b=z.read('java.base/java/util/HashMap.java');assert sha(b)==inventory['jdk_hashmap_source_sha256'];(S/'HashMap.java.txt').write_bytes(b)
dump('signature-audit.json',dict(java_revision=rev,count=74,ordered_inventory_exact=True,entries=rows,jdk_zip=str(zip_path),jdk_hashmap_sha256=sha(b),portability='HashMap traversal is not a Java Map ordering contract. Ordinary list bins match the pinned OpenJDK implementation; tree root moves/tieBreakOrder can depend on identityHashCode. No claim across JVM implementations, Java21.0.5 versus21.0.13, or tree bins. Capacity may also be influenced by treeification-triggered resize below capacity64; current 74 standard signatures imply capacity128 under ordinary registration.',java_constants={'hash_initial':1,'hash_multiplier':31,'spread_shift':16,'initial_capacity':16,'load_numerator':3,'load_denominator':4,'resize_multiplier':2}))
# Verify every historical evidence blob independently, including the candidate maker packet.
entries=git('ls-tree','-rz','2cf6c7ee','--','docs/parity-reviews','test-diagrams/perturbations').split(b'\0');bad=[];count=0
for ent in entries:
 if not ent:continue
 meta,path=ent.split(b'\t');mode,kind,blob=meta.split();b=(R/path.decode()).read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();count+=1
 if actual!=blob.decode():bad.append(path.decode())
assert not bad
dump('historical-integrity-initial.json',dict(candidate='2cf6c7eeebae7354e7a3b7e53b86fb3754883e67',files=count,changed=bad,golden=git('-C','test-diagrams/golden','rev-parse','HEAD').decode().strip()))
# All touched production files, chronology, no changes between final production and candidate.
dump('revisions.json',dict(candidate=git('rev-parse','HEAD').decode().strip(),final='55de7dd6cb090d86febc1e5e3f57804134429a19',before='4a288dd47fe925a792f7cb672ca294f6ef6fdcf3',account='4652860936464f02d80584ef158a29a4a1c13cd1',production_diff=git('diff','--name-only','4a288dd','2cf6c7ee','--','crates').decode(),candidate_after_final_diff=git('diff','--name-only','55de7dd6','2cf6c7ee','--','crates').decode(),chronology=git('log','-5','--format=%H %aI %s').decode(),binaries={phase:sha((S/('target-'+phase)/'release/rustuml').read_bytes()) for phase in ['before','after']},comparator=sha((S/'probe').read_bytes())))
# Filename branch restored byte for byte, including prior comments.
texts={rev:git('show',rev+':crates/rustuml-parser/src/preprocess/mod.rs').decode() for rev in ['4a288dd','329c39f4','55de7dd6']}
def block(t):return t.split('            "filename" => {')[1].split('            "file_exists" => {')[0]
assert block(texts['4a288dd'])==block(texts['55de7dd6']);assert '            "filename" => {' not in texts['329c39f4']
dump('filename-source-audit.json',dict(restored_verbatim=True,before_and_after_block='            "filename" => {'+block(texts['55de7dd6']),intermediate_absent=True))
# Verify old and new ordinary unit blocks directly against pinned revisions.
units=json.loads((R/'docs/parity-reviews/tim-exact-memory-identities/maker-support/unit-expectation-corrections.json').read_bytes());new=(R/'crates/rustuml-parser/src/preprocess/mod.rs').read_text();out=[]
for u in units:
 name=u['test'];old=texts['4a288dd']; oldblock=old.split('    fn '+name+'() {',1)[1].split('    #[test]',1)[0];newblock=new.split('    fn '+name+'() {',1)[1].split('    #[test]',1)[0]
 assert u['old_block']=='    fn '+name+'() {'+oldblock
 expected=re.sub(r'\s+','',u['new_block']);actual=re.sub(r'\s+','','    fn '+name+'() {'+newblock);assert expected==actual
 oldinput=re.search(r'let input = (".*");',oldblock)[1];newinput=re.search(r'let input = (".*");',newblock)[1];assert oldinput==newinput
 out.append(dict(test=name,unchanged_original_input_expression=oldinput,old_assertion=u['previous_assertion'],new_assertion=u['corrected_assertion'],input=json.loads(oldinput),old_block_verified=True,new_block_verified=True,derivation='EaterAffectationDefine stores exact bare key globally. VariableManager scans original characters and retains a literal dollar when no matching dollar key exists. ShuntingYard instead resolves the full dollar key or keeps its name as a literal. Included lines share memory; foreach only binds its own exact key.'))
dump('ordinary-units-audit.json',out)
print('verified inventory',len(rows),'historical',count,'unit blocks',len(out))
