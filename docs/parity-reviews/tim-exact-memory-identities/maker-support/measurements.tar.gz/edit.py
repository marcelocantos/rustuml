# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
p=Path('crates/rustuml-parser/src/preprocess/mod.rs');s=p.read_text()
s=s.replace('    /// `!define TOKEN value` style macros.\n    token_defines: HashMap<String, Value>,\n','')
s=s.replace('            token_defines: HashMap::new(),\n','')
s=s.replace('functions: HashMap<String, FunctionDef>,','functions: HashMap<String, Vec<FunctionDef>>,').replace('collecting_function: Option<String>,','collecting_function: Option<(String, FunctionDef)>,')
s=s.replace('/// `!$var = value` style variables.','/// Exact Java variable keys (both `name` and `$name`), including !define.')
# Exact variable ingress and a single memory namespace.
s=s.replace(r'^!define\s+(\w+)(?:\s+(.+))?$',r'^!define\s+(\$?\w+)(?:\s+(.+))?$')
s=s.replace(r'^!\$(\w+)\s*=\s*(.+)$',r'^!(\$?\w+)\s*=\s*(.+)$')
s=s.replace('''        static RE_LEGACY_VAR: LazyLock<Regex> =
            LazyLock::new(|| Regex::new(r"^!(\w+)\s*=\s*(.+)$").unwrap());
''','')
s=s.replace('self.token_defines.insert(name, Value::Str(value));','self.defines.insert(name, Value::Str(value));')
a=s.index('        if let Some(caps) = RE_LEGACY_VAR');b=s.index('        false',a);s=s[:a]+s[b:]
s=s.replace(r'^!(local|global)\s+\$(\w+)\s*=\s*(.+)$',r'^!(local|global)\s+(\$?\w+)\s*=\s*(.+)$')
s=s.replace(r'^!foreach\s+\$(\w+)\s+in\s+(.+)$',r'^!foreach\s+(\$?\w+)\s+in\s+(.+)$')
s=s.replace(r'^!undef(?:ine)?\s+\$?(\w+)$',r'^!undef(?:ine)?\s+(\$?\w+)$').replace('                self.token_defines.remove(name);\n','')
s=s.replace(r'^!ifndef\s+\$?(\w+)$',r'^!ifndef\s+(\$?\w+)$')
s=s.replace('''                let name = symbol.strip_prefix('$').unwrap_or(symbol);
                self.get_var(name).is_some()
                    || self.token_defines.contains_key(name)
                    || self.functions.contains_key(name)''','''                self.get_var(symbol).is_some() || self.functions.contains_key(symbol)''')
s=s.replace('''            let defined = self.defines.contains_key(name)
                || self.token_defines.contains_key(name)
                || self.get_var(name).is_some();''','''            let defined = self.get_var(name).is_some();''')
a=s.index('        if let Some(value) = expr\n');b=s.index('        {\n            return Expression::Value(value.clone());',a);s=s[:a]+'''        if let Some(value) = self.get_var(expr)'''+s[b:]
s=s.replace('''.get_var(name)
                        .cloned()
                        .or_else(|| self.token_defines.get(name).cloned())''','''.get_var(&line[offset..name_end])
                        .cloned()''')
s=s.replace('self.token_defines.get(name).cloned()','self.get_var(name).cloned()')
a=s.index('                return name\n',s.index('            "get_variable_value" =>'));b=s.index('            "str2json" =>',a)
s=s[:a]+'''                return self.get_var(name).cloned().unwrap_or_else(|| Value::Str(String::new()));
            }
            "set_variable_value" if values.len() >= 2 => {
                // SetVariableValue explicitly uses GLOBAL, preserving its exact key.
                self.defines.insert(args[0].clone(), values[1].clone());
                return Value::Str(String::new());
            }
'''+s[b:]
a=s.index('            "variable_exists" => {',s.index('fn eval_one_builtin_args'));b=s.index('            "file_exists" =>',a)
s=s[:a]+'''            "variable_exists" => {
                // VariableExists delegates the exact name to TMemory.getVariable.
                let name = args.first().copied().unwrap_or("");
                if self.get_var(name).is_some() { "1" } else { "0" }.to_string()
            }
            "is_defined" => {
                let name = args.first().copied().unwrap_or("");
                if self.get_var(name).is_some() { "true" } else { "false" }.to_string()
            }
            "function_exists" => {
                // FunctionsSet.doesFunctionExist indexes the exact declared name.
                let name = args.first().copied().unwrap_or("");
                if self.functions.contains_key(name) { "true" } else { "false" }.to_string()
            }
'''+s[b:]
a=s.index('            // Exact Java key matching occurs above.');b=s.index('\n        }',a);s=s[:a]+'''            // TFunctionImpl.getNewMemory preserves the parameter's complete key.
            scope.overrides.insert(param.name.clone(), value);'''+s[b:]
# Sub iterator upstream of both existing and entering body collection.
a=s.index('        // Collecting definelong body.');b=s.index('        // CodeIteratorSub',a);dl=s[a:b];s=s[:a]+s[b:]
a=s.index('        // Startsub.');b=s.index('        // Definelong.',a);start=s[a:b];s=s[:a]+s[b:]
i=s.index('        // Function definition collection.');s=s[:i]+start+dl+s[i:]
# Complete signatures, pending definition separate from available set.
a=s.index('        // Currently collecting a function body?');b=s.index('        // TIM also accepts',a)
s=s[:a]+'''        // FunctionsSet publishes a definition only at executeEndfunction.
        if let Some((name, mut function)) = self.collecting_function.take() {
            if trimmed == "!endfunction" || trimmed == "!endprocedure" {
                self.register_function(name, function);
            } else {
                if trimmed.starts_with("!return ") && function.kind == FunctionKind::Legacy {
                    function.kind = FunctionKind::Return;
                }
                function.body.push(self.current_buffered_line(line));
                self.collecting_function = Some((name, function));
            }
            return true;
        }

'''+s[b:]
s=s.replace(r'function\s+\$?(\w+)',r'function\s+(\$?\w+)').replace(r'(?:function|procedure)\s+\$?(\w+)',r'(?:function|procedure)\s+(\$?\w+)')
s=s.replace('''            self.functions.insert(
                name,
                FunctionDef {''','''            self.register_function(
                name,
                FunctionDef {''',1)
s=s.replace('''            self.functions.insert(
                name.clone(),
                FunctionDef {''','''            self.collecting_function = Some((
                name,
                FunctionDef {''',1)
s=s.replace('''            );
            self.collecting_function = Some(name);
            return true;''','''            ));
            return true;''',1)
s=s.replace(r'^\$?(\w+)\s*\((.*)\)$',r'^(\$?\w+)\s*\((.*)\)$')
a=s.index('        let Some(func) = self.functions.get(name).cloned()');b=s.index('        // TFunctionImpl.executeReturnFunction checks kind',a)
s=s[:a]+'''        let keys = if expression_call { None } else { Some(&named) };
        let Some(func) = self.resolve_function(name, positional.len(), keys).cloned() else {
            self.fail(format!("Unknown built-in function {name}"));
            return (None, Vec::new());
        };
        // RPN canCover checks an empty named set even after an exact lookup.
        if expression_call && !func.can_cover(positional.len(), None) {
            self.fail(format!("Bad number of arguments for {name}"));
            return (None, Vec::new());
        }
'''+s[b:]
s=s.replace('''                let function_name = name.strip_prefix('$').unwrap_or(name);
''','')
a=s.index('                        self.functions.get(function_name)');b=s.index('\n                    }',a)
s=s[:a]+'''                        self.resolve_function(name, count, None).is_some()'''+s[b:]
s=s.replace('self.call_function_values(function_name, positional, named.clone(), true)','self.call_function_values(name, positional, named.clone(), true)')
# Dollar scanner uses exact function identity. Bare whole-line calls already do.
s=s.replace("(ch == '$' && self.functions.contains_key(name))","(ch == '$' && self.functions.contains_key(&line[offset..name_end]))")
s=s.replace('let (value, mut events) = self.call_function(name, &args);','let (value, mut events) = self.call_function(&line[offset..name_end], &args);')
# Existing internal tests now address exact TIM keys too.
s=s.replace('ctx.get_var("n")','ctx.get_var("$n")')
print([line for line in s.splitlines() if 'token_defines' in line])
p.write_text(s)
