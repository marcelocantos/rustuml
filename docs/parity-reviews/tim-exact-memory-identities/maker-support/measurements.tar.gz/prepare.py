# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,hashlib
from pathlib import Path
S=Path('/Users/marcelo/Library/Caches/rustuml-tim7-maker');N=S/'new';N.mkdir(exist_ok=True)
cases=[
('memory_dual','tim-exact-memory-identities',False,'!function $mix(b="007",$b="08")\n!return b+2+"/"+$b+3+"/"+%get_variable_value("b")\n!endfunction\n!$v=$mix()\nclass "$v/$mix(b="oak",$b="ash")" as Dual'),
('memory_mutate','tim-exact-memory-identities',False,'!b="global"\n!$b="dollar"\n!function $mix(b="local",$b="over")\n!b="changed"\n!local $b="leaf"\n!return b+"/"+$b+"/"+%variable_exists("b")\n!endfunction\n!$v=$mix()\nclass "$v / b / $b" as Scope'),
('memory_sibling','tim-exact-memory-identities',False,'!b="global"\n!$b="dollar"\n!function $inner()\n!return b+"/"+$b\n!endfunction\n!function $outer(b="local",$b="override")\n!return $inner()+"/"+b+"/"+$b\n!endfunction\n!$v=$outer()\nclass "$v" as Frames'),
('memory_remove','tim-exact-memory-identities',False,'!b="birch"\n!$b="beech"\n!function $drop(b="local",$b="locald")\n!undef b\n!return b+"/"+$b\n!endfunction\n!$v=$drop()\n!undef $b\nclass "$v / b / %variable_exists("$b")" as Removed'),
('overload_order','tim-function-signature-availability',False,'!function $pick($a,$b)\n!return $a+"/"+$b\n!endfunction\n!procedure $pick($a)\nclass "$a" as First\n!endprocedure\n$pick("elm")\n!$v=$pick("fir","yew")\nclass "$v" as Second'),
('overload_defaults','tim-function-signature-availability',False,'!function $pick($a,$b="old")\n!return $a+"/"+$b\n!endfunction\n!function $pick($a)\n!return "one "+$a\n!endfunction\n!$v=$pick("oak")\nclass "$v/$pick($a="ash",$b="new")" as Defaults'),
('overload_replace','tim-function-signature-availability',False,'!function $pick($a)\n!return "old "+$a\n!endfunction\n!function $pick($a,$b="two")\n!return $a+"/"+$b\n!endfunction\n!function $pick($a)\n!return "new "+$a\n!endfunction\n!$v=$pick("birch")+"/"+$pick("ash","fir")\nclass "$v" as Replaced'),
('overload_pending','tim-function-signature-availability',False,'!function $pick($a="seed")\n!return $a\n!endfunction\n!function $pick($a=$pick())\n!return "new "+$a\n!endfunction\n!$v=$pick()\nclass "$v" as Captured'),
('overload_overlap','tim-function-signature-availability',False,'!function $choose($a="one",$b="two",$c="three")\n!return "three"\n!endfunction\n!function $choose($a="one",$b="two")\n!return "two"\n!endfunction\n!$v=$choose()\nclass "$v" as Overlap'),
('overload_bare','tim-function-signature-availability',False,'!function read($a)\n!return "bare "+$a\n!endfunction\n!function $read($a)\n!return "dollar "+$a\n!endfunction\n!$v=read("oak")+"/"+$read("ash")\nclass "$v/%function_exists("read")/%function_exists("$read")" as Names'),
('sub_uncalled_return','tim-sub-before-function-buffering',False,'!function $unused()\n!startsub saved\nclass Cedar\n!endsub\n!return 1\n!endfunction\n!includesub saved'),
('sub_called_counts','tim-sub-before-function-buffering',False,'!$n=0\n!procedure $tick()\n!startsub saved\n!$n=$n+1\n!endsub\n!endprocedure\n!includesub saved\n$tick()\n!includesub saved\nclass "$n" as Count'),
('sub_uncalled_nested','tim-sub-before-function-buffering',True,'!function $unused()\n!startsub outer\n!$v=%intval("bad")\n!startsub inner\n!endsub\n!return 1\n!endfunction\nclass Lost'),
('sub_comments_origin','tim-sub-before-function-buffering',False,"!procedure $unused()\n!startsub saved\n/' !startsub ignored '/\nclass Elm\n!endsub\n!endprocedure\n!includesub saved\nclass Ash\nElm --> Ash"),
('sub_defaults_effect','tim-sub-before-function-buffering',False,'!$n=0\n!procedure $tick()\n!startsub saved\n!$n=$n+1\n!endsub\n!endprocedure\nclass "before $n" as Before\n$tick()\nclass "after $n" as After')]
rows=[]
for name,mech,negative,body in cases:
 p=N/(name+'.puml');assert not p.exists();p.write_text('@startuml\n'+body+'\n@enduml\n');rows.append(dict(source=str(p),mechanism=mech,negative=negative,cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={}))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=S/'new-manifest.json';m.write_text(json.dumps(rows,indent=2)+'\n');old=json.loads(Path('docs/parity-reviews/tim-rpn-call-state/maker-support/remote-request.json').read_bytes());probe=Path.cwd()/'docs/parity-reviews/tim-corrective-execution-maker/SourceProbe.java'
resources=[dict(local_path=str(p),remote_relative_path='new/'+p.name,sha256=h(p),bytes=p.stat().st_size) for p in sorted(N.iterdir())]+[dict(local_path=str(probe),remote_relative_path=probe.name,sha256=h(probe),bytes=probe.stat().st_size)]
contracts=[]
for row in rows:
 p=Path(row['source']);c=dict(old['case_contracts'][0]);c.update(source=str(p),source_sha256=h(p));c['probe_argv']=c['probe_argv'][:-2]+['<worker>/new/'+p.name,'<worker>/new'];contracts.append(c)
r=S/'remote-request.json';r.write_text(json.dumps(dict(old,manifest_path=str(m),manifest_sha256=h(m),case_count=len(rows),resources=resources,case_contracts=contracts),indent=2)+'\n');print('request',h(r),'manifest',h(m),'cases',len(rows),'resources',len(resources))
