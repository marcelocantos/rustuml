# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,yaml
from pathlib import Path
S=Path(__file__).parent
def convert(n):
 if isinstance(n,yaml.MappingNode):return (n.tag,{k.value:convert(v) for k,v in n.value})
 if isinstance(n,yaml.SequenceNode):return (n.tag,[convert(v) for v in n.value])
 if isinstance(n,yaml.ScalarNode):return (n.tag,n.value)
 return None
rows=[]
for row in json.loads((S/'comparison-summary.json').read_bytes()):
 changes=[]
 for id in row['yaml_byte_changes']:
  a=(S/'replay/before'/id/'yaml.stdout').read_bytes();b=(S/'replay/after'/id/'yaml.stdout').read_bytes()
  changes.append(dict(id=id,semantic_equal=convert(yaml.compose(a))==convert(yaml.compose(b)),before_bytes=a.decode(),after_bytes=b.decode()))
 rows.append(dict(cohort=row['cohort'],entries=row['entries'],byte_changes=len(changes),semantic_changes=sum(not c['semantic_equal'] for c in changes),changes=changes))
(S/'model-observations.json').write_text(json.dumps(rows,indent=2)+'\n')
print([(r['cohort'],r['byte_changes'],r['semantic_changes']) for r in rows])
