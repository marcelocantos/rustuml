# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,xml.etree.ElementTree as E,hashlib
S=Path(__file__).parent;cohorts=['retained','maker18','sprites50','checker38','fresh15','fresh26','new15','delimiters4','focused2'];allrows=[]
for co in cohorts:
 members=json.loads((S/(co+'-membership.json')).read_bytes());b=json.loads((S/(co+'-before.json')).read_bytes());a=json.loads((S/(co+'-after.json')).read_bytes())
 for m,x,y in zip(members,b,a):allrows.append(dict(cohort=co,id=m['id'],membership=m,before=x,after=y))
wanted=['present_bold_empty','style_parameter_contrast','wbs_shape_color','malformed_dot','markup_scan','markup_literal','style_nested','missing_size','nested_unknown','nested_unicode','note_undefined','note_defined_scale','class_defined','seq_defined','defined_class','defined_scale_color','url_label','url_after','empty_link']
res=[]
for r in allrows:
 if r['id'].split('/')[-1] in wanted or r['cohort']=='delimiters4' or any(n in r['id'] for n in ['markup_scan','markup_literal','welcome','surrogate','property']):
  m=r['membership'];x=r['before'];y=r['after'];res.append(dict(cohort=r['cohort'],id=r['id'],source=m['source_capture'],source_sha256=m['source_sha256'],reference=m['golden_capture'],reference_sha256=m['golden_sha256'],valid=y['reference_valid'],before_pass=x['svg_match'],after_pass=y['svg_match'],before_exit=x['svg']['exit'],after_exit=y['svg']['exit'],before_panic=x['panic'],after_panic=y['panic'],evidence='replay/after/'+r['id']))
# Exact baselines observed rather than copied from report.
baselines=[]
for r in allrows:
 if r['id'] not in ['fresh26/present_bold_empty','new15/style_parameter_contrast']:continue
 entry=dict(id=r['id'])
 for label,p in [('java',Path(r['membership']['golden_capture'])),('rust',S/'replay/after'/r['id']/'svg.stdout')]:
  root=E.fromstring(p.read_bytes());entry[label]=[dict(text=n.text,**n.attrib) for n in root.iter() if n.tag.split('}')[-1]=='text' and n.get('font-size') in ['25','26']]
 baselines.append(entry)
(S/'residuals.json').write_text(json.dumps(dict(cases=res,baselines=baselines,class_candidate='68ab512be964e243ae1943f7a9fefd3537091401',combined_correctness_measured=False),indent=2)+'\n')
print('residual observations',len(res),'valid remaining failures',sum(x['valid'] and not x['after_pass'] for x in res),'unexpected gains',[(x['id']) for x in res if x['after_pass']])
print('baselines', baselines)
