# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import subprocess,json,difflib
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();files=['crates/rustuml-render/src/'+n+'.rs' for n in ['class','deployment','activity','state','creole']];residue=[]
for name in files:
 if not name.endswith('.rs'):continue
 p=R/name;d=S/'format-baseline'/name;d.parent.mkdir(parents=True,exist_ok=True);base=subprocess.check_output(['git','show','27bb1c3ff:'+name]);d.write_bytes(base)
 subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(d)],check=True)
 formatted=d.read_bytes();subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(p)],check=True)
 if base!=formatted:
  old=formatted.decode().splitlines(keepends=True);new=base.decode().splitlines(keepends=True);text=p.read_text()
  for op,a,b,c,e in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
   if op=='equal':continue
   before=''.join(old[max(0,a-2):min(len(old),b+2)]);after=''.join(old[max(0,a-2):a])+''.join(new[c:e])+''.join(old[b:min(len(old),b+2)])
   if text.count(before)==1:text=text.replace(before,after,1);status='restored untouched baseline formatting'
   else:status='overlap requires inspection'
   residue.append(dict(file=name,base_line=c+1,status=status,before=before,after=after))
  p.write_text(text)
(S/'format-baseline-residue.json').write_text(json.dumps(residue,indent=2)+'\n');print(json.dumps(residue,indent=2))
