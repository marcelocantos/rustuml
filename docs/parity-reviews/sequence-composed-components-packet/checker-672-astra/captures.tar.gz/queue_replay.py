import json,subprocess
from pathlib import Path
c=Path(__file__).parent;root=Path.cwd();names=json.loads((c/'queue-loss-names.json').read_text());assert len(names)==4
manifest=[dict(source=str(root/'test-diagrams/golden'/(n+'.puml')),golden=str(root/'test-diagrams/golden'/(n+'.svg')),cohort='queue-regression4',name=n) for n in names];p=c/'queue-manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for label in ['before','intermediate','candidate']:
 with (c/('queue-'+label+'.log')).open('wb') as f:subprocess.run(['uv','run','--no-project','python',str(c/'measure.py'),str(p),str(c/label/'bin'),str(c/('queue-'+label))],check=True,stdout=f,stderr=subprocess.STDOUT)
 print(label,flush=True)
