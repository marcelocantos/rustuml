# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import base64,concurrent.futures,hashlib,json,os,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent; R=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest()
x=json.loads((S/'reference-results.json').read_bytes());man=json.loads((S/'manifest.json').read_bytes());byname={Path(r['source']).stem:r for r in man}
assert len(x['results'])==len(man)==87
assert x['environment']['jar_sha256']=='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053'
assert x['environment']['java_revision']=='71806a23780b04a5ccde2f8ceb5121edad5eb711'
assert x['environment']['manifest_sha256']==sha((S/'manifest.json').read_bytes())
assert sha((S/'reference-results.json.gz').read_bytes())=='c746c0b7e7e26ab19ced61d6b05471e4df742d23cbebcc35bd08780c76501ae6'
assert sha((S/'reference-transport.json').read_bytes())=='5906491941ed2f9f655fcf24ebc7422d62bf4b2b18e1d57ed07b6807206bdcd8'
def inspect(b):
 try:r=ET.fromstring(b);return None,[(n.tag.rsplit('}',1)[-1],n.text,dict(n.attrib)) for n in r.iter()]
 except ET.ParseError as e:return str(e),[]
def run(row):
 name=row['name'];m=byname[name];source=Path(m['source']).read_bytes();assert sha(source)==row['stdin_sha256']==row['source_sha256'];assert len(source)==row['stdin_bytes'];assert row['timezone']=='GMT+11:00' and row['env_overrides']=={} and row['cwd']==x['environment']['worker']+'/new';assert row['argv']==[x['environment']['wrapper'],'--cwd',row['cwd'],'--timezone','GMT+11:00','--','-pipe','-tsvg']
 d=S/'fresh'/name;d.mkdir(parents=True,exist_ok=True)
 out=base64.b64decode(row['stdout_base64']);err=base64.b64decode(row['stderr_base64']);assert sha(out)==row['stdout_sha256'] and sha(err)==row['stderr_sha256']
 (d/'java.svg').write_bytes(out);(d/'java.stderr').write_bytes(err);(d/'source.puml').write_bytes(source)
 xml_error,nodes=inspect(out);text=' '.join(t or '' for _,t,_ in nodes)
 classification='valid diagram'
 if xml_error:classification='malformed Java XML'
 elif b'SAXException' in err or b'SAXException' in out:classification='SAXException crash SVG'
 elif 'Syntax Error' in text or 'Syntax error' in text or 'Error line' in text:classification='syntax-error SVG'
 elif 'Welcome to PlantUML' in text:classification='welcome SVG'
 elif err:classification='stderr requires review'
 result=dict(name=name,mechanism=m['mechanism'],axes=m['axes'],java_classification=classification,java_exit=row['exit_code'],java_xml_error=xml_error,java_text=text,source_sha256=sha(source),java_sha256=sha(out))
 env=dict(os.environ,TZ='GMT+11:00',RUSTUML_DEBUG=m['debug'],RAYON_NUM_THREADS='4',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')
 for phase in ['before','after']:
  p=subprocess.run([str(S/('target-'+phase)/'release/rustuml'),'-pipe','-tsvg'],input=source,capture_output=True,cwd=S/'new',env=env,timeout=90)
  f=d/(phase+'.svg');f.write_bytes(p.stdout);(d/(phase+'.stderr')).write_bytes(p.stderr)
  cmp=subprocess.run([str(S/'probe'),str(d/'java.svg'),str(f)],capture_output=True)
  (d/(phase+'.compare')).write_bytes(cmp.stdout+cmp.stderr)
  error,nodes=inspect(p.stdout)
  if not p.stdout: error=None
  result[phase]=dict(exit=p.returncode,emitted=bool(p.stdout),panic=b'panicked at' in p.stderr,malformed=error,compare_exit=cmp.returncode,whole_pass=classification=='valid diagram' and p.returncode==0 and cmp.returncode==0,text_nodes=[dict(text=t,attributes=a) for tag,t,a in nodes if tag in ['text','tspan']],svg_sha256=sha(p.stdout))
 if classification=='valid diagram' and result['after']['compare_exit']==2:result['java_classification']='harness negative reference marker';result['before']['whole_pass']=False;result['after']['whole_pass']=False
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,x['results']))
(S/'fresh-results.json').write_text(json.dumps(results,indent=2,ensure_ascii=True)+'\n')
for r in results:print(r['name'],r['java_classification'],'pass',r['before']['whole_pass'],r['after']['whole_pass'],'malformed',r['after']['malformed'])
print('TOTAL',len(results),'VALID',sum(r['java_classification']=='valid diagram' for r in results),'PASS',sum(r['before']['whole_pass'] for r in results),sum(r['after']['whole_pass'] for r in results))
