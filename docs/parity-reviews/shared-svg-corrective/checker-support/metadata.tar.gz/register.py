from pathlib import Path
import json,shutil,subprocess,os
S=Path(__file__).parent;R=Path.cwd();P=R/'test-diagrams/perturbations/shared-svg-corrective/checker-independent-astra';P.mkdir(parents=True,exist_ok=True);rows=json.loads((S/'fresh-outcomes.json').read_bytes())+json.loads((S/'unicode-followup/fresh-outcomes.json').read_bytes())
for r in rows:
 p=P/Path(r['source']).name;assert not p.exists();p.write_bytes(Path(r['source']).read_bytes());p.with_suffix('.svg').write_bytes(Path(r['golden_capture']).read_bytes())
# Exact standing no-oracle test, scoped to only this new cohort in scratch.
source=(R/'crates/rustuml-oracle/tests/parity_perturbations.rs').read_text().replace('join("test-diagrams/perturbations")','join("test-diagrams/perturbations/shared-svg-corrective/checker-independent-astra")');src=S/'fresh-standing.rs';src.write_text(source);deps=S/'target-after/release/deps';argv=['rustc','--edition=2024','--test',str(src),'-L','dependency='+str(deps)]
for crate in ['rustuml_parser','rustuml_render','rustuml_oracle']:argv+=['--extern',crate+'='+str(next(deps.glob('lib'+crate+'-*.rlib')))]
argv+=['-o',str(S/'fresh-standing')];env=dict(os.environ,CARGO_MANIFEST_DIR=str(R/'crates/rustuml-oracle'),RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib',RAYON_NUM_THREADS='4');q=subprocess.run(argv,env=env,capture_output=True);(S/'fresh-standing-build.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
run=[str(S/'fresh-standing'),'held_out_perturbations_match_java_without_oracle_layout','--nocapture'];q=subprocess.run(run,env=env,capture_output=True);(S/'fresh-standing.log').write_bytes(q.stdout+q.stderr);(S/'fresh-standing.json').write_text(json.dumps(dict(compile_argv=argv,argv=run,exit=q.returncode,scope='Only54 new registered pairs; original standing test body unchanged; separate library diagnostic from CLI truth'),indent=2));print('fresh standing',q.returncode)
