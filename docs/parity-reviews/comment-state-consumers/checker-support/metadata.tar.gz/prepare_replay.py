# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,gzip,hashlib,tarfile,shutil,re
S=Path(__file__).parent;R=Path.cwd();M=R/'docs/parity-reviews/comment-state-consumers/maker-support';A=S/'maker-archive';A.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
for name in ['metadata','frozen-inputs']:
    entries=json.loads(gzip.decompress((M/(name+'.entries.json.gz')).read_bytes()))
    expected={e['path']:e for e in entries}
    with tarfile.open(M/(name+'.tar.gz')) as t:
        for mem in t.getmembers():
            assert mem.isfile() and not Path(mem.name).is_absolute() and '..' not in Path(mem.name).parts
            b=t.extractfile(mem).read();e=expected.pop(mem.name)
            assert sha(b)==e['sha256'] and len(b)==e['bytes']
            p=A/mem.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    assert not expected
    checks.append(dict(archive=name,entries=len(entries),sha256=sha((M/(name+'.tar.gz')).read_bytes()),verified=True))
(S/'archive-setup.json').write_text(json.dumps(checks,indent=2)+'\n')
cohorts=json.loads((A/'cohorts.json').read_text())+['consumer16','full-golden']
fm={(r['cohort'],r['id'],r['kind']):r for r in json.loads((A/'frozen-inputs-manifest.json').read_text())}
rows=[]
for c in cohorts:
    for r in json.loads((A/(c+'-membership.json')).read_text()):
        r['cohort']=c
        for kind in ['source','golden','reference_source']:
            if kind+'_capture' not in r:continue
            f=fm.get((c,r['id'],kind))
            if f is None:
                assert kind=='reference_source'
                r.pop(kind+'_capture');continue
            p=A/f['frozen'];assert sha(p.read_bytes())==f['sha256'];r[kind+'_capture']=str(p)
        cwd=r['cwd']
        if re.match(r'/Users/marcelo/\.t3/worktrees/rustuml/t3-[^/]+',cwd):cwd=re.sub(r'/Users/marcelo/\.t3/worktrees/rustuml/t3-[^/]+',str(R),cwd)
        assert Path(cwd).is_dir(),cwd
        r['original_cwd']=r['cwd'];r['cwd']=cwd
        rows.append(r)
(S/'replay-membership.json').write_text(json.dumps(rows,indent=2)+'\n')
shutil.copy2(A/'probe.rs',S/'probe.rs')
# Use unchanged comparator executable, independently hash-verified against its archived provenance.
p=S.parent/'rustuml-comment-state-consumers-maker/probe';expected=json.loads((A/'binary-provenance.json').read_text())['binaries'][2]['sha256'];assert sha(p.read_bytes())==expected;shutil.copy2(p,S/'probe')
print('membership',len(rows),'cohorts',len(cohorts),'frozen verified',len(fm),'probe',expected)
