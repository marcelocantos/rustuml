# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,os,shutil,subprocess
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();D=S/'target-after/release/deps';T=S/'mutation';(T/'crates/rustuml').mkdir(parents=True,exist_ok=True)
g=T/'test-diagrams/golden';g.mkdir(parents=True,exist_ok=True);p=T/'test-diagrams/perturbations/shared-svg-attributes';p.mkdir(parents=True,exist_ok=True)
for i in range(26):
 (g/f'dot_{i}.puml').write_bytes(b'@startdot\ndigraph G { a -> b }\n@enddot\n');(g/f'dot_{i}.svg').write_bytes(b'<svg/>')
for name in ['attr_link_c0_one','attr_link_c0_zero','attr_link_c0_escape']:
 for ext in ['.puml','.svg']:shutil.copyfile(R/'test-diagrams/perturbations/shared-svg-attributes'/(name+ext),p/(name+ext))
env=dict(os.environ,CARGO_MANIFEST_DIR=str(T/'crates/rustuml'),CARGO_BIN_EXE_rustuml=str(S/'target-after/release/rustuml'),PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')
argv=['rustc','--edition=2024','--test',str(R/'crates/rustuml/tests/pipe_mode.rs'),'-L','dependency='+str(D),'--extern','roxmltree='+str(next(D.glob('libroxmltree-*.rlib'))),'--extern','sha2='+str(next(D.glob('libsha2-*.rlib'))),'-o',str(S/'xml-oracle-mutant-inputs')]
# Select exactly roxmltree0.20 by locating dependency files containing its source path.
for dep in D.glob('roxmltree-*.d'):
 if '/roxmltree-0.20.0/' in dep.read_text():
  argv[argv.index('--extern')+1]='roxmltree='+str(D/('lib'+dep.stem+'.rlib'));break
build=subprocess.run(argv,env=env,capture_output=True);(S/'logs/xml-mutation-build.log').write_bytes(build.stdout+build.stderr);assert build.returncode==0,build.stderr
results=[]
def run(name,expected):
 cmd=[str(S/'xml-oracle-mutant-inputs'),'every_cli_golden_and_registered_perturbation_svg_is_strict_xml','--nocapture']
 q=subprocess.run(cmd,env=env,capture_output=True,timeout=90);log=q.stdout+q.stderr;(S/'logs'/('xml-mutation-'+name+'.log')).write_bytes(log)
 assert (q.returncode==0)==(not expected),(name,q.returncode,log)
 for marker in expected:assert marker.encode() in log,(name,marker,log)
 results.append(dict(name=name,argv=cmd,exit=q.returncode,required_diagnostics=expected,log_sha256=hashlib.sha256(log).hexdigest()))
run('control',[])
(g/'unlisted.puml').write_bytes((S/'new/comment_double_hyphen.puml').read_bytes());(g/'unlisted.svg').write_bytes(b'<svg/>')
run('unlisted-malformed',['unlisted malformed SVG: test-diagrams/golden/unlisted.puml'])
(g/'unlisted.puml').unlink();(g/'unlisted.svg').unlink()
f=p/'attr_link_c0_one.puml';before=f.read_bytes();f.write_bytes(b'@startuml\nclass Healthy\n@enduml\n')
run('listed-now-valid',['stale source hash:','stale expected malformed output:'])
f.write_bytes(before)
(S/'xml-mutation-results.json').write_text(json.dumps(dict(test_source_sha256=hashlib.sha256((R/'crates/rustuml/tests/pipe_mode.rs').read_bytes()).hexdigest(),unchanged_test_source=True,root=str(T),results=results,mutations_discarded=True),indent=2)+'\n')
shutil.rmtree(T)
print(json.dumps(results,indent=2))
