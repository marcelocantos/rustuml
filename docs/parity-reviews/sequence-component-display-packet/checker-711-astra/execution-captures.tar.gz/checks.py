# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json, os, pathlib, subprocess, time
ROOT=pathlib.Path('/Users/marcelo/.t3/worktrees/rustuml/t3-5c023380'); OUT=pathlib.Path(__file__).parent
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='711dbca7c5e29592395f0927881aabfc2517b217'
assert (OUT/'after-binding.json').exists()
env=dict(os.environ,CARGO_TARGET_DIR=str(OUT/'target-after'),CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='4',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib',RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100')
checks=[('units',['cargo','test','--release','--lib','-p','rustuml-parser','-p','rustuml-render']),('cli',['cargo','test','--release','-p','rustuml','--test','pipe_mode']),('main-tiers-and-guards',['cargo','test','--release','--no-fail-fast','-p','rustuml-oracle','--test','golden_no_oracle','--test','golden_pairs','--test','parity_perturbations','--test','harness_guards','--','--nocapture']),('format-owned',['rustfmt','--check','--edition','2024','--config','skip_children=true','crates/rustuml-parser/src/diagram/sequence.rs','crates/rustuml-parser/src/parse/sequence.rs','crates/rustuml-render/src/sequence.rs']),('format-workspace',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','-p','rustuml-parser','-p','rustuml-render','--','-D','warnings']),('clippy-render',['cargo','clippy','-p','rustuml-render','--no-deps','--','-D','warnings'])]
results=[]
for name,cmd in checks:
    start=time.time()
    with (OUT/(name+'.log')).open('wb') as f:
        p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    results.append(dict(name=name,command=cmd,cwd=str(ROOT),environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','PLANTUML_STDLIB','RUSTUML_DEBUG']},exit=p.returncode,seconds=time.time()-start,log=name+'.log'))
    (OUT/'checks.json').write_text(json.dumps(results,indent=2))
    print(name,p.returncode,flush=True)
