# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import concurrent.futures, hashlib, io, json, os, subprocess, tarfile, time
s=Path(__file__).resolve().parent;root=Path.cwd(); before=s/'before-source';before.mkdir(exist_ok=True)
raw=subprocess.check_output(['git','archive','154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc'])
with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(before,filter='data')
records=[]
def one(variant,cwd):
 env=dict(os.environ,CARGO_TARGET_DIR=str(s/('target-'+variant)),CARGO_BUILD_JOBS='2');cmd=['cargo','build','--release','-p','rustuml'];start=time.time()
 with (s/(variant+'-build.log')).open('wb') as f:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 binary=s/('target-'+variant)/'release/rustuml';r=dict(variant=variant,command=cmd,cwd=str(cwd),exit=p.returncode,seconds=time.time()-start,environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS']},binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest() if binary.exists() else None)
 (s/(variant+'-build.json')).write_text(json.dumps(r,indent=2)+'\n');print(r,flush=True);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:records=list(ex.map(lambda x:one(*x),[('before',before),('after',root)]))
(s/'builds.json').write_text(json.dumps(records,indent=2)+'\n')
