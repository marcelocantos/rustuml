// Pattern2#transform/compileInternal: ASCII case folding and Java's default
// ASCII predefined classes; Unicode identity properties remain Unicode.
fn registered_regex(pattern: &str) -> Regex {
    let expanded = pattern
        .replace("%pLN", r"\p{L}\p{N}")
        .replace("%s", r"\x09-\x0d \u{00a0}")
        .replace("%g", "\"\u{201c}\u{201d}\u{e121}")
        .replace("%q", "'\u{2018}\u{2019}")
        .replace(r"\w", "[A-Za-z_0-9]")
        .replace(r"\d", "[0-9]")
        .replace(r"\s", r"[\x09-\x0d ]")
        .replace(r"\S", r"[^\x09-\x0d ]")
        .replace(r"\b", r"(?-u:\b)")
        .replace(r"\<", "<")
        .replace(r"\>", ">")
        .to_ascii_lowercase()
        .replace(r"\p{l}", r"\p{L}")
        .replace(r"\p{n}", r"\p{N}");
    // Pattern2 does not enable DOTALL. Java dot excludes all five line
    // terminators, whereas Rust's default dot excludes only LF.
    let mut pattern = String::new();
    let mut escaped = false;
    let mut bracket_depth = 0;
    for ch in expanded.chars() {
        if escaped {
            pattern.push(ch);
            escaped = false;
        } else if ch == '\\' {
            pattern.push(ch);
            escaped = true;
        } else if ch == '[' {
            bracket_depth += 1;
            pattern.push(ch);
        } else if ch == ']' {
            bracket_depth -= 1;
            pattern.push(ch);
        } else if ch == '.' && bracket_depth == 0 {
            pattern.push_str(r"[^\r\n\u{0085}\u{2028}\u{2029}]");
        } else {
            pattern.push(ch);
        }
    }
    Regex::new(&format!(r"\A(?:{pattern})\z")).expect("pinned registered sequence grammar")
}

// StringLocated#getTrimmed -> StringUtils#trin, not Unicode str::trim.
fn sequence_command_trim(line: &str) -> &str {
    line.trim_matches([' ', '\t', '\r', '\n', '\0'])
}

// FoxSignature's masks table and getFoxSignatureFromRealString. The required
// masks in the inventory are derived from RegexConcat#foxRegex, not fitted.
fn sequence_fox_signature(line: &str) -> u64 {
    const SYMBOLS: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0!\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~";
    let mut result = 0;
    for ch in line.chars() {
        if matches!(ch, ' ' | '\t' | '\r' | '\n' | '\u{000c}' | '\u{00a0}') {
            result |= 1;
        } else if let Some(index) = SYMBOLS.find(ch.to_ascii_uppercase()) {
            result |= 1u64 << (index + 2);
            if matches!(ch, '.' | '=' | '-' | '~') {
                result |= 2;
            }
        }
    }
    result
}

enum CommandEnd {
    Single,
    End(Regex),
    Brace,
}

enum RegisteredPattern {
    Plain(Regex),
    Color { prefix: Regex, suffix: Regex, absent: Regex },
}

struct RegisteredSequenceCommand {
    class: &'static str,
    pattern: RegisteredPattern,
    signature: u64,
    end: CommandEnd,
    implemented: bool,
}

impl RegisteredSequenceCommand {
    fn new(class: &'static str, pattern: &str, signature: u64, end: CommandEnd, implemented: bool) -> Self {
        let pattern = if let Some((prefix, suffix)) = pattern.split_once("{COLOR}") {
            RegisteredPattern::Color {
                prefix: registered_regex(prefix),
                suffix: registered_regex(suffix),
                absent: registered_regex(&format!("{prefix}{suffix}")),
            }
        } else {
            RegisteredPattern::Plain(registered_regex(pattern))
        };
        Self { class, pattern, signature, end, implemented }
    }

    // ColorParser.PART2 has one lookahead unavailable in regex::Regex. Split
    // the command at its optional color leaf and enumerate its token boundaries.
    // This preserves the language, including fallback to COLOR_REGEXP, without
    // weakening the lookahead or requiring regex backtracking in Rust.
    fn color_match<'a>(&self, line: &'a str) -> Option<Option<&'a str>> {
        if self.signature & sequence_fox_signature(line) != self.signature {
            return None;
        }
        match &self.pattern {
            RegisteredPattern::Plain(regex) => regex.is_match(line).then_some(None),
            RegisteredPattern::Color { prefix, suffix, absent } => {
                static SIMPLE: LazyLock<Regex> = LazyLock::new(|| registered_regex(r"#\w+[-\\|/]?\w+"));
                // PART2: a nonfinal style must consume ';', because the next
                // style begins with a word character. The final style may end
                // without ';' only when the original negative lookahead holds.
                static COMPOSITE: LazyLock<Regex> = LazyLock::new(|| registered_regex(
                    r"#(?:\w+[-\\|/]?\w+;)?(?:(?:text|back|header|line|line\.dashed|line\.dotted|line\.bold|shadowing)(?::\w+[-\\|/]?\w+)?;)*(?:text|back|header|line|line\.dashed|line\.dotted|line\.bold|shadowing)(?::\w+[-\\|/]?\w+)?;?"));
                let boundaries = line.char_indices().map(|(i, _)| i).chain(std::iter::once(line.len())).collect::<Vec<_>>();
                for &start in boundaries.iter().rev() {
                    if !line[start..].starts_with('#') || !prefix.is_match(&line[..start]) {
                        continue;
                    }
                    // ColorParser tries PART2 before the simple alternative.
                    for composite in [true, false] {
                        for &end in boundaries.iter().rev().take_while(|&&end| end > start) {
                            let token = &line[start..end];
                            let matches = if composite {
                                COMPOSITE.is_match(token) && (token.ends_with(';') || !line[end..].chars().next().is_some_and(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | ';' | ':' | '.')))
                            } else { SIMPLE.is_match(token) };
                            if matches && suffix.is_match(&line[end..]) {
                                return Some(Some(token));
                            }
                        }
                    }
                }
                absent.is_match(line).then_some(None)
            }
        }
    }

    fn command_end(&self, lines: &[String], start: usize) -> Option<usize> {
        match &self.end {
            CommandEnd::Single => Some(start),
            CommandEnd::End(regex) => (start + 1..lines.len()).find(|&i| regex.is_match(&sequence_command_trim(super::source_text(&lines[i])).to_ascii_lowercase())),
            CommandEnd::Brace => {
                // CommandMultilinesBracket#isValid / SkinLoader.p1.
                static CONSISTENT: LazyLock<Regex> = LazyLock::new(|| registered_regex(r"^([\w.]*(?:\<\<.*\>\>)?[\w.]*)[%s]+(?:(\{)|(.*))$|^\}?$"));
                let mut level = 1;
                for (index, raw) in lines.iter().enumerate().skip(start + 1) {
                    let text = sequence_command_trim(super::source_text(raw)).to_ascii_lowercase();
                    if !text.starts_with('\'') && !CONSISTENT.is_match(&text) { return None; }
                    if text.ends_with('{') { level += 1; }
                    if text.ends_with('}') { level -= 1; }
                    if level == 0 { return Some(index); }
                }
                None
            }
        }
    }

    fn validate_colors(&self, line: &str, token: Option<&str>, source_line: usize) -> Result<(), ParseError> {
        let bad = |color: &str| ParseError { line: source_line, message: format!("No such color: {color} ({})", self.class) };
        if let Some(token) = token {
            // Colors#Colors removes '#' and splits ';'. Dotted line styles
            // without ':' are styles; shadowing's value is a boolean, not color.
            let data = token.replace('#', "");
            for item in data.split(';').filter(|item| !item.is_empty()) {
                if let Some((name, value)) = item.split_once(':') {
                    if name != "shadowing" && !valid_sequence_color(value) { return Err(bad(value)); }
                } else if !item.contains('.') && !valid_sequence_color(item) { return Err(bad(item)); }
            }
        }
        if let RegisteredPattern::Plain(regex) = &self.pattern
            && let Some(caps) = regex.captures(line)
        {
            for name in regex.capture_names().flatten().filter(|name| name.starts_with("seq_color")) {
                if let Some(color) = caps.name(name)
                    && !valid_sequence_color(color.as_str()) { return Err(bad(color.as_str())); }
            }
        }
        Ok(())
    }
}

// HColorSet#parseColor accepts simple colors and two-color gradients. Command
// color grammars exclude the '?' scheme syntax; return's existing validator is
// retained for its previously supported model input contract.
fn valid_sequence_color(color: &str) -> bool {
    if valid_return_color(color) { return true; }
    color.char_indices().any(|(index, ch)| matches!(ch, '-' | '\\' | '|' | '/')
        && valid_return_color(&color[..index]) && valid_return_color(&color[index + ch.len_utf8()..]))
}
