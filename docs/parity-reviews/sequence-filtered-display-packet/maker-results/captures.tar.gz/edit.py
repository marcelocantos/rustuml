from pathlib import Path
p=Path('crates/rustuml-parser/src/diagram/sequence.rs');s=p.read_text();s=s.replace('    pub hide_footbox: bool,','    pub hide_footbox: bool,\n    /// SequenceDiagram#hiddenPortions: final diagram-wide stereotype visibility.\n    #[serde(default, skip_serializing_if = "std::ops::Not::not")]\n    pub hide_stereotypes: bool,',1);s=s.replace('    pub stereotype: Option<String>,','    pub stereotype: Option<String>,\n    /// CommandParticipant captures SkinParam#stereotypePositionTop at declaration.\n    #[serde(default, skip_serializing_if = "std::ops::Not::not")]\n    pub stereotype_position_bottom: bool,',1);p.write_text(s)
p=Path('crates/rustuml-parser/src/parse/sequence.rs');s=p.read_text();s=s.replace('    hide_footbox: bool,','    hide_footbox: bool,\n    hide_stereotypes: bool,',1);s=s.replace('            hide_footbox: false,','            hide_footbox: false,\n            hide_stereotypes: false,',1);s=s.replace('            hide_footbox: self.hide_footbox,','            hide_footbox: self.hide_footbox,\n            hide_stereotypes: self.hide_stereotypes,',1);s=s.replace('                stereotype: None,','                stereotype: None,\n                stereotype_position_bottom: false,',1);s=s.replace('                    stereotype,\n                    url,','''                    stereotype,
                    // CommandParticipant#executeArg captures the current setting;
                    // SkinParam#stereotypePositionTop is false only for bottom.
                    stereotype_position_bottom: self.meta.skinparams.iter().rev()
                        .find(|param| param.key.eq_ignore_ascii_case("stereotypePosition"))
                        .is_some_and(|param| param.value.eq_ignore_ascii_case("bottom")),
                    url,''',1)
s=s.replace('''        line.starts_with("hide ")
    }
}''','''        // CommandHideShowByGender#executeSequenceDiagram ignores the gender
        // selector and updates SequenceDiagram#hiddenPortions, shared by every
        // Participant#getDisplay. Its PORTION accepts singular and plural.
        static STEREOTYPE_VISIBILITY: LazyLock<Regex> = LazyLock::new(|| {
            Regex::new(r#"(?i)^(hide|show)\\s+(?:(?:[\\p{L}\\p{N}_.]+|"[^"]+"|<<.*>>)\\s+)*?stereotypes?$"#).unwrap()
        });
        if let Some(caps) = STEREOTYPE_VISIBILITY.captures(line) {
            self.hide_stereotypes = caps[1].eq_ignore_ascii_case("hide");
            return true;
        }
        line.starts_with("hide ")
    }
}''',1);p.write_text(s)
for path in ['crates/rustuml-render/src/ascii.rs','crates/rustuml-render/src/sequence.rs']:
 p=Path(path);s=p.read_text();s=s.replace('            hide_footbox: false,','            hide_footbox: false,\n            hide_stereotypes: false,');s=s.replace('                    stereotype: None,','                    stereotype: None,\n                    stereotype_position_bottom: false,');p.write_text(s)
p=Path('crates/rustuml-render/src/sequence.rs');s=p.read_text();s=s.replace('    stereotype: Option<String>,\n    /// Text width','    stereotype: Option<String>,\n    /// Participant#getDisplay after visibility filtering and declaration order.\n    display: Vec<(String, bool)>,\n    /// Text width',1)
s=s.replace('            let st = p.stereotype.clone();','''            // Participant#getDisplay filters the shared hiddenPortions before
            // any component measures or paints the Display (all participant kinds).
            let st = p.stereotype.clone().filter(|_| !diagram.hide_stereotypes);''',1)
s=s.replace('            // Box width must accommodate','''            let mut display = vec![(label.clone(), false)];
            if let Some(text) = &st_display {
                // Participant#getDisplay: addFirst for top, add for bottom.
                let index = usize::from(p.stereotype_position_bottom);
                display.insert(index, (text.clone(), true));
            }
            // Box width must accommodate''',1)
s=s.replace('                stereotype: st,\n                text_width:', '                stereotype: st,\n                display,\n                text_width:',1)
# Single ordered Display passed to every queue head/creation/tail consumer.
a=s.index('    fn queue_shape(');b=s.index('        // Pill shape:',a)
prefix=s[a:b];prefix=prefix.replace('        text_x: f64,\n','').replace('        text_content: &str,\n        text_len: f64,','        display: &[(String, bool)],').replace('        stereo: Option<(&str, f64)>,\n        line_h: f64,\n','')
c=prefix.index('        // Participant#getDisplay');prefix=prefix[:c]+'''        // ComponentRoseQueue passes Participant#getDisplay as one ordered label.
        // Reuse that filtered structure for the pill and every painted stripe.
        let blocks: Vec<_> = display.iter().map(|(text, stereotype)| {
            (ParticipantTextBlock::new(text, self.participant_font_size as f64,
                &self.participant_font_family, !stereotype && self.participant_font_bold), *stereotype)
        }).collect();
''';s=s[:a]+prefix+s[b:];s=s.replace('let pill_h = label.height + stereo_shift + 5.0 + 5.0;','let pill_h = blocks.iter().map(|(block, _)| block.height).sum::<f64>() + 5.0 + 5.0;',1)
a=s.index('        // ComponentRoseQueue supplies the complete Display label');b=s.index('        self.participant_group_close();',a)
s=s[:a]+'''        // USymbolQueue#asSmall translates the complete label by its margin;
        // each child starts at its accumulated top and uses its own ascent.
        let inner_w = box_w - QUEUE_TEXT_H_PAD;
        let mut stripe_top = text_top;
        for (block, stereotype) in &blocks {
            block.draw(&mut self.buf, &TextBase {
                x: box_x + QUEUE_TEXT_X_PAD + (inner_w - block.width) / 2.0,
                y: stripe_top + block.lines[0].2.ascent,
                font_size: self.participant_font_size,
                font_family: &self.participant_font_family,
                fill: if *stereotype { "#000000" } else { &self.participant_font_color },
                bold: !stereotype && self.participant_font_bold,
                italic: *stereotype,
                underline: false,
                skip_underline: false,
            });
            stripe_top += block.height;
        }

'''+s[b:]
a=s.index('        ParticipantKind::Queue => {',s.index('fn render_participant_shape'));b=s.index('        ParticipantKind::Participant =>',a);chunk=s[a:b];chunk=chunk.replace('            let text_x = p.box_x + QUEUE_TEXT_X_PAD;\n','').replace('                text_x,\n','').replace('                &p.label,\n                p.text_width,','                &p.display,');i=chunk.index('                // Participant#getDisplay');chunk=chunk[:i]+'''            );
        }
''';s=s[:a]+chunk+s[b:];p.write_text(s)
