# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
s=Path(__file__).resolve().parent;root=Path.cwd();guard=s/'no-local-jvm';shutil.copytree(s/'maker-archive/no-local-jvm',guard,dirs_exist_ok=True)
env=dict(os.environ,CARGO_TARGET_DIR=str(s/'target-after'),CARGO_BUILD_JOBS='4',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib',RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100');env['PATH']=str(guard)+os.pathsep+env['PATH'];env['JAVA_TOOL_OPTIONS']='-Djava.awt.headless=true'
commands=[('fmt',['cargo','fmt','--check']),('units',['cargo','test','--workspace','--release','--lib','--no-fail-fast']),('cli-errors',['cargo','test','--workspace','--release','--test','pipe_mode','--test','error_paths','--test','doc_claims','--no-fail-fast']),('no_oracle',['cargo','test','--release','--test','golden_no_oracle','--','--nocapture']),('assisted',['cargo','test','--release','--test','golden_pairs','--','--nocapture']),('standing',['cargo','test','--release','--test','parity_perturbations','--','--nocapture']),('guards',['cargo','test','--release','--test','harness_guards','--','--nocapture']),('clippy',['cargo','clippy','--workspace','--release','--','-D','warnings'])]
records=[]
for name,cmd in commands:
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='68ab512be964e243ae1943f7a9fefd3537091401'
 assert not subprocess.check_output(['git','status','--porcelain'])
 start=time.time();log=s/('gate-'+name+'.log')
 with log.open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 r=dict(name=name,command=cmd,exit=p.returncode,seconds=time.time()-start,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest(),cwd=str(root),revision='68ab512be964e243ae1943f7a9fefd3537091401',environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','PLANTUML_STDLIB','RUSTUML_DEBUG','JAVA_TOOL_OPTIONS']},jvm_guard=str(guard));records.append(r);(s/'gates.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True)
