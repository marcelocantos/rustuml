# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
"""Package immutable captures and new checker records; no product execution."""
import hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
S=Path('/Users/marcelo/Library/Caches/rustuml-tim7-checker')
R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-c0d7c6ac')
D=R/'docs/parity-reviews/tim-exact-memory-identities/checker7-support'
D.mkdir(parents=True,exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(p,o): p.write_text(json.dumps(o,indent=2)+'\n')
rows=json.loads((S/'fresh23-results.json').read_bytes())
mechanisms=['tim-exact-memory-identities','tim-function-signature-availability','tim-sub-before-function-buffering']
findings={
mechanisms[0]:[
'Exact-key storage, global/override/local lookup, removal, defaults captured at declaration, sibling frames, bare expressions, and ordinary text boundaries are supported by the traced Java data flow and passing controls; this is bounded evidence, not complete memory equivalence.',
'Valid key_dollar and key_combining fail before and after. SetVariableValue accepts exact names a$b and twig followed by U+0301. Java VariableManager uses the memory trie; Rust substitute_vars consumes alphanumeric/underscore tokens and cannot reach these complete keys. Direct get/existence succeed but text remains literal. Java source is spruce / spruce / 1; Rust source retains a$b or the combining key in the middle.',
'Valid parameter_duplicate fails before and after: Java TFunctionImpl.getNewMemory reads namedArguments without removing it for each formal, then overwrites the duplicate result key. Rust call_function_values removes the named value on the first formal, allowing the second default to overwrite it. Java named / right becomes Rust two / right.',
'Five changed ordinary unit expectations are justified individually by Java exact-key define/text/expression behavior with unchanged original inputs and preserved old failing assertions; green units do not approve this mechanism.',
],
mechanisms[1]:[
'Completed signature publication, pending definition defaults, replacement by name and arity, exact lookup before compatible fallback, named/default coverage, and expression kind after signature selection match all six fresh valid evaluated-source oracles. The kind-negative is rejected but remains a nonpositive oracle.',
'Independent source audit reconstructed all 74 builtin signatures and verified every pinned Java file hash. Hash initial 1, multiplier 31, spread shift 16, capacity 16, load 3/4, doubling, and ordinary-bin insertion order derive from TFunctionSignature and the retained JDK source, not fitted output.',
'Fresh capacity_20 and capacity_21 cross 96/97 total signatures: capacity 128/256 reverses the fallback choice of the two $oak515 overloads. Both match source and SVG. These inputs do not exercise tree bins.',
'Valid select_0 and select_1 have exact evaluated source but fail SVG before and after. The Rust class declaration regex stops at the first inner quote and accepts a prefix, losing the remaining label and alias. Java CommandCreateClass/NameAndCodeParser consumes the full command. This downstream product failure is retained; source equality is not an acceptance waiver.',
'HashMap iteration is not specified by Java Map. Tree-bin root promotion and identity-based ties, differing JVM implementations/versions, legacy overload occupancy/collisions, and legacy declaration syntax remain unproved. The separate Rust legacy registry and function_exists path do not justify unqualified registry equivalence.',
],
mechanisms[2]:[
'Java TContext.buildCodeIterator puts CodeIteratorSub before return-function, procedure, conditional and legacy-definition collectors. Fresh nonempty function/procedure/definelong, side-effect timing, inactive collection, and located comment cases all match source and SVG after correction (six valid cases); nested-sub negative is now rejected.',
'Empty sub cases sub_empty_0 and sub_empty_1 disprove complete iterator equivalence. CodeIteratorSub installs an empty replay iterator; peek returns null, so TContext.executeLines stops before the tail and @enduml. Java emits welcome SVG and truncated source @startuml plus class Anchor. Rust resumes after the empty vector, emits Tail and its edge, and accepts a class diagram.',
'The two empty cases were intended valid-or-empty-truncation probes, not established class positives. SourceProbe exits 0 for both; the SVG process also exits 0 but has no CLASS factory and is rejected by the unchanged comparator. Both complete captures and intended/observed classifications are retained.',
]}
obligations={mechanisms[0]:['Implement memory-driven text matching for all names admitted through builtin assignment, with Java boundary behavior; retain both key counterexamples.','Bind duplicate declared names using nonconsuming named lookup and Java final-key overwrite behavior; retain named and positional controls.'],mechanisms[1]:['Repair the downstream full-command class name/display parse exposed by select_0/select_1 without altering the frozen inputs or comparator.','Establish tree-bin and supported legacy signature occupancy/syntax behavior before making a broader registry-equivalence claim; pin or test the intended JVM ordering contract.'],mechanisms[2]:['Model empty sub replay termination, including the truncated source reaching BlockUml/factory selection, without manufacturing an empty positive diagram.','Preserve nonempty collection ordering, delayed effects, nested rejection and located replay while correcting the empty case.']}
common=['Standing gates are not waived: main product and assisted library diagnostics, standing perturbations, guards and clippy remain failing. Preserve historical class-body, Unicode IntVal, sequence panics, and all 27 environment discrepancies.','No fixture-shaped branches, golden reads, or SVG output surgery were found in the production diff. Candidate production is identical to final production 55de7dd6; filename dispatch is restored verbatim and its original CLI regression passes.']
for mechanism in mechanisms:
 entries=[]
 for row in rows:
  m=row['membership']
  if m['mechanism']!=mechanism:continue
  name=Path(row['input']).stem;dest=R/'test-diagrams/perturbations'/mechanism/'checker7';dest.mkdir(parents=True,exist_ok=True)
  src=dest/(name+'.puml');gold=dest/(name+'.svg');shutil.copyfile(row['input'],src);shutil.copyfile(row['golden'],gold)
  c=row['classification'];a=row['phases']['after']
  entries.append(dict(source=str(src.relative_to(R)),golden=str(gold.relative_to(R)),axes=m['axes'],result='pass' if a['svg_match'] else 'fail',intended_validity=c['intended'],observed_classification=c,exact_source_equal=a.get('exact_source_equal'),svg_match=a['svg_match'],semantic_control_pass=c['semantic_outcome_equal'],source_sha256=sha(src.read_bytes()),golden_sha256=sha(gold.read_bytes())))
 review=dict(schema_version=1,mechanism=mechanism,reviewer=dict(task_id='thread:delegated-task:command%3Amcp%3A7a6e5142-c330-4dbe-941b-87119bcc7cef%3Adelegate-task%3A797285a5-2bc0-46e3-b562-d8c4c8bcf12c',model='gpt-6-astra, high reasoning, Codex in T3',independent=True,children=[]),account_commit='4652860936464f02d80584ef158a29a4a1c13cd1',implementation_commit='55de7dd6cb090d86febc1e5e3f57804134429a19',candidate_commit='2cf6c7eeebae7354e7a3b7e53b86fb3754883e67',before_commit='4a288dd47fe925a792f7cb672ca294f6ef6fdcf3',production_parent_commit='329c39f48eccddfbb4896f1710dd97ddd1c1f2e8',java_revision='71806a23780b04a5ccde2f8ceb5121edad5eb711',java_jar_sha256='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053',commands=['CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR=<private>/target-before cargo build --release -p rustuml (cwd: git archive of exact before)','CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR=<private>/target-after cargo build --release -p rustuml (cwd: isolated candidate checkout)','uv run --no-project python <private>/replay.py','uv run --no-project python <private>/fresh.py','Fresh Java through parent existing Monkey Man runner only: exact wrapper/Java argv, cwd and env in checker7-support/remote-request.json and measurements.tar.gz/fresh-references/*/commands.json','All final gate argv, cwd, env, real exits in checker7-support/gates2.json; executed once before evidence packaging'],perturbations=entries,findings=findings[mechanism]+common,repair_obligations=obligations[mechanism],verdict='rejected',evidence='docs/parity-reviews/tim-exact-memory-identities/checker7-support/README.md',nonpositive_result_policy='result is pass only for a valid Java reference matching the unchanged SVG comparator. Properly rejected negative controls are recorded separately and do not become positive suite passes.')
 dump(R/'docs/parity-reviews'/mechanism/'review.json',review)
# Readable audit results; all unchanged capture bytes also retained in the archive.
for name in ['analysis.json','fresh23-summary.json','gates2.json','revisions.json','signature-audit.json','capacity-design.json','java-provenance.json','ordinary-units-audit.json','filename-source-audit.json','historical-integrity-initial.json','remote-request.json','new-manifest.json']:
 shutil.copyfile(S/name,D/name)
for p in sorted(S.glob('*-summary.json')):shutil.copyfile(p,D/p.name)
# Validate original historical files again after adding only new files.
raw=subprocess.check_output(['git','ls-tree','-rz','2cf6c7ee','--','docs/parity-reviews','test-diagrams/perturbations'],cwd=R);count=0
for ent in raw.split(b'\0'):
 if not ent:continue
 meta,path=ent.split(b'\t');blob=meta.split()[2].decode();b=(R/path.decode()).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==blob,path
 count+=1
dump(S/'historical-integrity-final.json',dict(candidate='2cf6c7eeebae7354e7a3b7e53b86fb3754883e67',files=count,changed=[],production_diff=subprocess.check_output(['git','diff','--name-only','HEAD','--','crates'],cwd=R).decode()))
shutil.copyfile(S/'historical-integrity-final.json',D/'historical-integrity-final.json')
# Freeze all measurements and execution scripts, excluding build products and unused JDK full source.
exclude={'target-before','target-after','build-before-source','probe','HashMap.java.txt','__pycache__','measurements.tar.gz'}
files=[p for p in sorted(S.rglob('*')) if p.is_file() and p.relative_to(S).parts[0] not in exclude]
manifest=[dict(path=str(p.relative_to(S)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in files]
dump(D/'capture-manifest.json',manifest)
with tarfile.open(S/'measurements.tar.gz','w:gz',compresslevel=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(S)),recursive=False)
shutil.copyfile(S/'measurements.tar.gz',D/'measurements.tar.gz')
# Reopen archive and hash every entry; this checks packaging, not product behavior.
with tarfile.open(D/'measurements.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for member,row in zip(members,manifest):
  b=tar.extractfile(member).read();assert member.name==row['path'] and len(b)==row['bytes'] and sha(b)==row['sha256']
dump(D/'archive-integrity.json',dict(archive='measurements.tar.gz',bytes=(D/'measurements.tar.gz').stat().st_size,sha256=sha((D/'measurements.tar.gz').read_bytes()),files=len(manifest),all_unpacked_bytes_verified=True))
print('packaged',len(manifest),'files; archive bytes',(D/'measurements.tar.gz').stat().st_size,'historical preserved',count)
