# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,subprocess,hashlib,gzip,tarfile,re
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();D=R/'docs/parity-reviews/comment-state-consumers';J=Path('/Users/marcelo/work/github.com/plantuml/plantuml');JP='src/main/java/net/sourceforge/plantuml/';PIN='71806a23780b04a5ccde2f8ceb5121edad5eb711';PROD='523a2d89226d764b818b7af2472593d2690e9c4b';TIP='2a791353c998e4c34bbf0f16699c7ffd21d50cea'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=R):return subprocess.check_output(['git',*a],cwd=cwd)
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
index=json.loads((D/'account.json').read_text());chronology=[]
for entry in index['record_chronology']['pre_draft_records']:
    path,rev=entry['path'],entry['commit'];original=git('show',rev+':'+path);current=(R/path).read_bytes();assert current==original and sha(current)==entry['sha256'];ancestor=subprocess.run(['git','merge-base','--is-ancestor',rev,PROD],cwd=R).returncode==0;assert ancestor
    chronology.append(dict(**entry,is_ancestor_of_production=ancestor,unchanged=True,object_rust_locations=any(isinstance(x,dict) for x in json.loads(current)['rust_locations'])))
for name,rev in [('source-boundary-addendum.json','27bb1c3ff'),('state-fill-sites.json','42344228e')]:
    original=git('show',rev+':docs/parity-reviews/comment-state-consumers/'+name);assert original==(D/name).read_bytes();chronology.append(dict(path=name,commit=git('rev-parse',rev).decode().strip(),unchanged=True,is_ancestor_of_production=subprocess.run(['git','merge-base','--is-ancestor',rev,PROD],cwd=R).returncode==0))
allowed={p for e in index['record_chronology']['pre_draft_records'] for p in json.loads((R/e['path']).read_text())['production_files']};changed=git('diff','--name-only',PROD+'^',PROD,'--','crates').decode().splitlines();assert set(changed)==allowed
preservation=[]
for rev in ['3875fee3b164d63d4b39df4bc6c13ca8ace89169','138ca3e5f','075f5095520bb1dc85a32c1f051a98421522419d']:
    trees={}
    for v in [rev,TIP]:
        trees[v]={}
        for row in git('ls-tree','-r',v,'--','docs/parity-reviews','test-diagrams/perturbations').decode().splitlines():
            header,p=row.split('\t');trees[v][p]=header.split()[2]
    mismatch=[p for p,h in trees[rev].items() if trees[TIP].get(p)!=h]
    preservation.append(dict(revision=rev,files=len(trees[rev]),mismatches=mismatch))
# Every explicitly hashed Java source must equal both pinned Git and the read-only checkout.
source_entries=[]
for name in ['source-boundary-addendum.json','follow-on-producers-account.json']:
    x=json.loads((D/name).read_text());source_entries.extend(x.get('files',x.get('source_files',[])))
extra=['svek/image/EntityImageClass.java','svek/image/EntityImageDescription.java','svek/image/EntityImageState.java','svek/image/EntityImageStateEmptyDescription.java','svek/image/EntityImageObject.java','svek/image/EntityImagePseudoState.java','svek/image/EntityImageDeepHistory.java','svek/image/EntityImageSynchroBar.java','svek/image/EntityImageBranch.java','classdiagram/command/CommandCreateClass.java','activitydiagram/command/CommandLinkActivity.java','klimt/drawing/svg/SvgGraphics.java','klimt/color/ColorTrieNode.java']
source_entries.extend(dict(path=str(J/JP/p)) for p in extra)
seen=set();sources=[]
for e in source_entries:
    p=Path(e['path']);rel=str(p.relative_to(J))
    if rel in seen:continue
    seen.add(rel);pinned=git('show',PIN+':'+rel,cwd=J);actual=p.read_bytes();assert pinned==actual
    if 'sha256' in e:assert sha(pinned)==e['sha256']
    out=S/'java-source'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(pinned)
    sources.append(dict(path=rel,sha256=sha(pinned),checkout_matches_pin=True,declared_hash_matches=True if 'sha256' in e else None))
report=dict(chronology=chronology,canonical_index_postproduction=True,index_adds_no_causal_claim=True,format_deviations=index['format_deviations'],production_changed_files=changed,only_accounted_production_files=True,no_sequence_changes=not any('sequence' in p for p in changed),prior_evidence=preservation,java_revision=PIN,java_sources=sources)
dump(S/'source-process-audit.json',report);print('process/source audit',len(sources),'Java files',preservation,flush=True)
# Verify all archives, including initial/intermediate failures, without trusting the maker's verified flag.
archives=[]
for a in json.loads((D/'maker-support/archives.json').read_text()):
    p=D/'maker-support'/a['archive'];mp=D/'maker-support'/a['entry_manifest'];assert sha(p.read_bytes())==a['sha256'] and sha(mp.read_bytes())==a['entry_manifest_sha256'];expected={e['path']:e for e in json.loads(gzip.decompress(mp.read_bytes()))};count=0
    with tarfile.open(p) as t:
        for mem in t:
            assert mem.isfile();b=t.extractfile(mem).read();e=expected.pop(mem.name);assert sha(b)==e['sha256'] and len(b)==e['bytes'];count+=1
    assert not expected and count==a['entries'];archives.append(dict(archive=a['archive'],entries=count,sha256=a['sha256'],all_entries_verified=True));print(a['archive'],count,'verified',flush=True)
dump(S/'all-archive-validation.json',archives)
