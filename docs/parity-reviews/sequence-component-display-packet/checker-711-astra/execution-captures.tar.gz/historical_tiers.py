# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,os,pathlib,subprocess,time
O=pathlib.Path(__file__).parent;R=pathlib.Path('/Users/marcelo/.t3/worktrees/rustuml/t3-5c023380');results=[]
try:
 for name,rev in [('before','672cd8f26e1d7c6725d8971e01ad7575defd8567'),('intermediate','cf3eafb293de2f01699399321d2220c4de9eb28c')]:
  subprocess.run(['git','switch','--detach',rev],cwd=R,check=True)
  env=dict(os.environ,CARGO_TARGET_DIR=str(O/('target-'+name)),CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='4',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')
  cmd=['cargo','test','--release','--no-fail-fast','-p','rustuml-oracle','--test','golden_no_oracle','--test','golden_pairs','--','--nocapture']
  with (O/(name+'-main-tiers.log')).open('wb') as f:p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  results.append(dict(name=name,revision=rev,command=cmd,cwd=str(R),exit=p.returncode,environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','PLANTUML_STDLIB']},reason='One execution per distinct production revision, explicitly testing initial regression and final recovery.'))
  (O/'historical-tiers-commands.json').write_text(json.dumps(results,indent=2));print(name,p.returncode,flush=True)
finally:subprocess.run(['git','switch','review/sequence-711dbca7-5c023380'],cwd=R,check=True)
