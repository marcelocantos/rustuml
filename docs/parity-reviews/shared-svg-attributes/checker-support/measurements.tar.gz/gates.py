# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,os,subprocess,time
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd()
env=dict(os.environ,CARGO_TARGET_DIR=str(S/'target-after'),CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='4',RUST_TEST_THREADS='4',RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')
commands=[('library',['cargo','test','--workspace','--lib','--release','--locked']),('cli',['cargo','test','-p','rustuml','--test','pipe_mode','--release','--locked','--','--nocapture'])]+[(name,['cargo','test','-p','rustuml-oracle','--release','--locked','--test',test,'--','--nocapture']) for name,test in [('main-product','golden_no_oracle'),('main-assisted','golden_pairs'),('standing','parity_perturbations'),('guards','harness_guards')]]+[('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]
results=[]
for name,argv in commands:
 start=time.monotonic()
 with (S/'logs'/('gate-'+name+'.log')).open('wb') as log:p=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,argv=argv,cwd=str(R),exit=p.returncode,seconds=time.monotonic()-start));(S/'gates.json').write_text(json.dumps(results,indent=2)+'\n');print(results[-1],flush=True)
