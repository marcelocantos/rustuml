from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/sequence.rs');s=p.read_text();at=s.index('static INLINE_ARROW_STYLE:')
s=s[:at]+'''// RegexConcat#foxRegex includes only direct RegexLeaf children. A mandatory
// [%s]+ leaf contributes FoxSignature.MASK_SPACES; optional/nested leaves do not.
// FoxSignature#getMask recognizes these characters anywhere in the FULL line,
// deliberately excluding VT even though Pattern2's regex whitespace includes it.
fn has_fox_space(line: &str) -> bool {
    line.chars().any(|c| matches!(c, ' ' | '\\t' | '\\r' | '\\n' | '\\u{000c}' | '\\u{00a0}'))
}

'''+s[at:]
for method,citation in [('try_participant_decl','CommandParticipantA/A2/A3/A4#getRegexConcat'),('try_activate_deactivate','CommandActivate#getRegexConcat'),('try_create_destroy','CommandActivate and CommandParticipantA#getRegexConcat'),('try_ref','CommandReferenceOverSeveral and CommandReferenceMultilinesOverSeveral#getRegexConcat')]:
 needle=f'    fn {method}(&mut self, line: &str) -> bool {{'
 s=s.replace(needle,needle+f'\n        // {citation}: direct spaceOneOrMore leaf.\n        if !has_fox_space(line) {{\n            return false;\n        }}',1)
s=s.replace('let captures = NAMED\n            .iter()\n            .find_map(|pattern| pattern.captures(line))', '''// Both standalone note factories contain a direct required-space leaf;
        // OnArrow has only optional whitespace and must bypass this prefilter.
        let captures = NAMED
            .iter()
            .filter(|_| has_fox_space(line))
            .find_map(|pattern| pattern.captures(line))''')
s=s.replace('''        if line.starts_with("autonumber resume")
            && let Some(caps)''','''        // CommandAutonumberResume#getRegexConcat has a direct required space;
        // CommandAutonumber's optional argument groups do not contribute it.
        if has_fox_space(line)
            && line.starts_with("autonumber resume")
            && let Some(caps)''',1)
s=s.replace('''        if let Some(caps) = STEREOTYPE_VISIBILITY.captures(line) {''','''        // CommandHideShowByGender#getRegexConcat contributes spaceOneOrMore.
        if has_fox_space(line)
            && let Some(caps) = STEREOTYPE_VISIBILITY.captures(line)
        {''',1)
at=s.index('    #[test]\n    fn named_note_identity')
s=s[:at]+'''    #[test]
    fn fox_space_prefilter_checks_the_complete_command() {
        for gap in [' ', '\\t', '\\u{000c}', '\\u{00a0}', '\\u{000b}'] {
            let required = gap != '\\u{000b}';
            let mut parser = SeqParser::new();
            assert_eq!(parser.try_participant_decl(&format!("participant{gap}Birch")), required);
            assert!(parser.try_participant_decl(&format!("participant{gap}\\"Birch Grove\\"")));
            assert_eq!(parser.try_activate_deactivate(&format!("activate{gap}Birch")), required);
            assert_eq!(parser.try_create_destroy(&format!("destroy{gap}Birch")), required);
            assert_eq!(parser.try_hide(&format!("hide{gap}stereotype")), required);
            // CommandArrow and CommandGrouping have no direct mandatory space leaf.
            assert!(parser.try_message(&format!("Birch{gap}->{gap}Elm")));
            assert!(parser.try_group(&format!("group{gap}title")));
        }
        let mut parser = SeqParser::new();
        parser.parse_line(1, "activate\\u{000b}Birch").unwrap();
        assert!(parser.unconsumed); // T14.17 owns the outer failure propagation.
        assert!(parser.events.is_empty());
    }

'''+s[at:];p.write_text(s)
