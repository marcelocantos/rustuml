# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import pathlib,json,hashlib,base64,gzip
S=pathlib.Path(__file__).parent;D=S/'supplement';N=D/'new';N.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
raw=[
('s_display_commands','wbs-display-line-projection','wbs',r'* Crown\nq<size:18></size>r\n\n** Birch\nq<color:navy></color>r\n--_ Twig\n<size:7>Bud</size>', ['multiline blank positions','empty parameter flush']),
('s_display_escapes','wbs-display-line-projection','wbs',r'* Canopy\n<b>a\~</B>c</b>d\n** Ash\n<i>j\~</i>k\n', ['multiline root/child','escaped tilde style boundary']),
('s_leaf_commands','wbs-leaf-component-origin','wbs',r'*_ Crown\n**_ q<size:21></size>r\n***_ <b>i</b>\n--_ q<color:navy></color>r', ['unboxed short leaf/internal','empty parameter flush']),
('s_leaf_escapes','wbs-leaf-component-origin','wbs',r'*_ Ash\n**_ <b>a\~</B>\n***_ i\n--_ <i>j\~</i>', ['short/deep/sided leaf','escaped styles']),
('s_shape_color_literals','wbs-idea-shape-block-selection','wbs',r'* Crown\n**[#pink] _ Birch\n***_[#gold] Elm\n--[#cyan] _ Fir', ['color with whitespace literal','depth and side']),
('s_delimiter_escape_overlap','creole-delimited-style-candidate-eligibility','uml',r'Kestrel -> Otter : q~***x**r\nq~___y__r\nq~---z--r', ['escaped opening overlap','delimiter families']),
('s_html_bold_backslash','creole-style-candidate-eligibility','uml',r'Kestrel -> Otter : q<b>a\~</B>r\nq<i>a\~</i>r',['escaped tilde','bold/italic restoration']),
('s_display_latex_valid','wbs-display-line-projection','wbs',r'* <latex>\nabla x</latex>\nCrown\n** <latex>\nu</latex>\nTwig',['valid raw latex backslash-n prefix','root/child'])]
cases=[]
for name,mech,kind,body,axes in raw:
 if kind=='wbs':
  import re
  body=re.sub(r'\\n(?=[*]|--)', '\n', body)
 p=N/(name+'.puml');p.write_text('@start'+kind+'\n'+body+'\n@end'+kind+'\n');cases.append(dict(source=str(p),mechanism=mech,axes=axes,cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=False,intended_validity='intended_valid'))
def dump(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
dump(D/'manifest.json',cases);req=json.loads((S/'request.json').read_bytes());req.update(manifest_path=str(D/'manifest.json'),manifest_sha256=sha((D/'manifest.json').read_bytes()),case_count=len(cases),resources=[],case_contracts=[]);files=[]
for c in cases:
 p=pathlib.Path(c['source']);b=p.read_bytes();rel='new/'+p.name
 req['resources'].append(dict(local_path=str(p),remote_relative_path=rel,sha256=sha(b),bytes=len(b)))
 req['case_contracts'].append(dict(source=str(p),source_sha256=sha(b),cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']))
 files.append(dict(local_path=str(p),remote_relative_path=rel,sha256=sha(b),base64=base64.b64encode(b).decode()))
dump(D/'request.json',req);(D/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=req,manifest=cases,files=files)).encode(),mtime=0))
for n in ['manifest.json','request.json','input-bundle.json.gz']:print(n,sha((D/n).read_bytes()))
