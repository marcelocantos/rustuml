// Copyright 2026 Marcelo Cantos
// SPDX-License-Identifier: Apache-2.0
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let expected = std::fs::read_to_string(&args[1]).unwrap();
    if rustuml_oracle::harness::golden_has_syntax_error(&expected) {
        eprintln!("invalid Java reference");
        std::process::exit(2);
    }
    let actual = std::fs::read_to_string(&args[2]).unwrap();
    match rustuml_oracle::compare::compare_svg_strict(&expected, &actual) {
        Ok(result) => { println!("{result}"); std::process::exit(if result.is_match() {0} else {1}); }
        Err(error) => { eprintln!("{error}"); std::process::exit(3); }
    }
}
