from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/sequence.rs');s=p.read_text();start=s.index('        // Also handle "note across"');end=s.index('        // FactorySequenceNoteCommand',start)
s=s[:start]+'''        // FactorySequenceNoteAcrossCommand composes STYLE, optional whitespace,
        // ACROSS and color, rather than a literal-space command prefix. Its
        // nested optional stereotype whitespace contributes no required Fox bit.
        static ACROSS: LazyLock<Regex> = LazyLock::new(|| {
            sequence_regex(r"^(h|r)?note[%s]*(accross|across)[%s]*(#[^%s:]+)?[%s]*(?::[%s]*(.*))?$").unwrap()
        });
        if let Some(caps) = ACROSS.captures(line) {
            // FactorySequenceNoteAcrossCommand#executeInternal rejects this
            // recognized grammar alternative, rather than silently dropping it.
            if &caps[2] == "accross" {
                return Err(ParseError {
                    line: self.current_line,
                    message: "Use 'across' instead of 'accross'".into(),
                });
            }
            let shape = match caps.get(1).map(|m| m.as_str()) {
                Some("h") => NoteShape::Hexagonal,
                Some("r") => NoteShape::Rectangular,
                _ => NoteShape::Note,
            };
            let color = caps.get(3).map(|m| m.as_str().to_string());
            if let Some(text) = caps.get(4) {
                self.events.push(Event::Note(Note {
                    position: NotePosition::Over,
                    participants: Vec::new(),
                    text: inline_sequence_display(text.as_str()),
                    shape,
                    color,
                    on_message: false,
                    source_line: self.current_line,
                }));
            } else {
                self.note_buffer = Some(NoteBuffer {
                    position: NotePosition::Over,
                    participants: Vec::new(),
                    lines: Vec::new(),
                    shape,
                    color,
                    on_message: false,
                    source_line: self.current_line,
                });
            }
            return Ok(true);
        }

'''+s[end:]
s=s.replace('''        if has_fox_space(line)
            && line.starts_with("autonumber resume")
            && let Some(caps) = RE_RESUME.captures(line)''','''        if has_fox_space(line)
            && let Some(caps) = RE_RESUME.captures(line)''',1)
start=s.index('        if line == "box" || line.starts_with("box ")');end=s.index('            self.boxes.push(',start)
s=s[:start]+'''        // CommandBoxStart#getRegexConcat: title whitespace is inside an
        // optional RegexOr, so it contributes no required FoxSignature bit.
        // Preserve NAME1/NAME2 order and complete title capture before color.
        static START: LazyLock<Regex> = LazyLock::new(|| {
            sequence_regex(r#"^box(?:[%s]+(?:"(?P<quoted>[^"]+)"|(?P<unquoted>[^#]+)))?[%s]*(?P<color>#[^%s]+)?$"#).unwrap()
        });
        if let Some(caps) = START.captures(line) {
            let title = caps.name("quoted").or_else(|| caps.name("unquoted"))
                .map_or_else(String::new, |m| m.as_str().to_string());
            let color = caps.name("color").map(|m| m.as_str().to_string());
'''+s[end:]
at=s.index('    #[test]\n    fn fox_space_prefilter')
s=s[:at]+'''    #[test]
    fn command_entry_whitespace_follows_java_composition() {
        for gap in [' ', '\\t', '\\u{000c}', '\\u{00a0}', '\\u{000b}'] {
            let mut parser = SeqParser::new();
            assert!(parser.try_box(&format!("box{gap}\\"Northern Shore\\" #pink")));
            assert_eq!(parser.boxes[0].title, "Northern Shore");
            assert_eq!(parser.boxes[0].color.as_deref(), Some("#pink"));
            assert!(parser.try_note(&format!("rnote{gap}across: body")).unwrap());
            assert!(matches!(parser.events.last(), Some(Event::Note(note)) if note.shape == NoteShape::Rectangular));
            assert_eq!(parser.try_autonumber(&format!("autonumber{gap}resume")), gap != '\\u{000b}');
            assert!(parser.try_autonumber(&format!("autonumber{gap}resume \\"Item 00\\"")));
        }
        for shape in ["note", "rnote", "hnote"] {
            let mut parser = SeqParser::new();
            assert!(parser.try_note(&format!("{shape} accross: body")).is_err());
        }
    }

'''+s[at:];p.write_text(s)
p=Path('crates/rustuml-render/src/sequence.rs');s=p.read_text().replace('DrawableSetInitializer#createParticipant passes Participant#getDisplay','DrawableSetInitializer#prepareParticipant passes Participant#getDisplay');p.write_text(s)
