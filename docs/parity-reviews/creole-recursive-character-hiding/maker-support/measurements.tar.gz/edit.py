# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
p=Path('crates/rustuml-render/src/creole.rs');s=p.read_text();pos=s.index('fn push_literal(');a=s[:pos];b=s[pos:];b=b.replace('let escaped = escape_creole_text(text);','let escaped = escape_creole_text(&restore_hidden_characters(text));',1);s=a+b
pos=s.index('/// CommandCreoleStyle.createCreole')
s=s[:pos]+'''// CharHidder.hideChar/unhideChar reserve E000..E0FF for hidden syntax.
// Keep that source-defined representation through matching and recursion;
// AtomText restores it only when constructing a literal text atom.
const HIDDEN_CHARACTER_BASE: u32 = 0xE000;

fn hide_characters(text: &str) -> String {
    let mut result = String::with_capacity(text.len());
    let mut chars = text.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\\\\' && chars.peek() == Some(&'~') {
            chars.next();
            result.push(char::from_u32(HIDDEN_CHARACTER_BASE + '~' as u32).unwrap());
        } else if c == '~' && let Some(next) = chars.next() {
            // CharHidder.isToBeHidden: consume exactly one following character,
            // even when it is the first half of an overlapping delimiter.
            if matches!(next, '_' | '-' | '"' | '#' | ']' | '[' | '*' | '.' | '/' | '<') {
                result.push(char::from_u32(HIDDEN_CHARACTER_BASE + next as u32).unwrap());
            } else {
                result.push(c);
                result.push(next);
            }
        } else {
            result.push(c);
        }
    }
    result
}

fn restore_hidden_characters(text: &str) -> String {
    text.chars()
        .map(|c| {
            if (HIDDEN_CHARACTER_BASE..=HIDDEN_CHARACTER_BASE + u8::MAX as u32).contains(&(c as u32)) {
                char::from_u32(c as u32 - HIDDEN_CHARACTER_BASE).unwrap()
            } else {
                c
            }
        })
        .collect()
}

'''+s[pos:]
start=s.index('    let mut scan = remaining.char_indices().peekable();',s.index('fn take_style_delimiter'))
end=s.index('        if offset > 0',start)
s=s[:start]+'    for (offset, _) in remaining.char_indices() {\n'+s[end:]
start=s.index('fn walk_segments(');a=s[:start];b=s[start:];b=b.replace('    let mut chars = text.chars().peekable();','    // StripeSimple.analyzeAndAdd applies the same hide operation on every\n    // recursive entry. Hidden candidates remain inert until literal emission.\n    let hidden = hide_characters(text);\n    let mut chars = hidden.chars().peekable();',1)
start=b.index("            '~' => {");end=b.index("            '\"' if",start);b=b[:start]+b[end:];s=a+b
start=s.index('    let mut scan = remaining.char_indices().peekable();',s.index('fn walk_style_tag'))
end=s.index("        if c == '<'",start);s=s[:start]+'    for (offset, c) in remaining.char_indices() {\n'+s[end:]
# Parameter commands use existing private barriers around their recursive bodies.
start=s.index('fn handle_tag(');a=s[:start];b=s[start:]
for prefix in ['_ if tag.starts_with("color:")','_ if tag.starts_with("size:")']:
 start=b.index(prefix);end=b.index('\n        }',start);body=b[start:end];body=body.replace('            walk_segments(&content, &nested, skip_underline, out);','''            // StripeSimple.modifyStripe flushes every selected command,
            // including parameter commands with an atomless recursive body.
            out.push(Segment { text: String::new(), style: style.clone() });
            walk_segments(&content, &nested, skip_underline, out);
            out.push(Segment { text: String::new(), style: style.clone() });''');b=b[:start]+body+b[end:]
s=a+b
s=s.replace('assert_eq!(parse_segments("<size:25></size>"), Vec::<Segment>::new());','assert_eq!(parse_segments("<size:25></size>"), vec![seg(" ", Style::default())]);').replace('assert_eq!(parse_segments("<color:red></color>"), Vec::<Segment>::new());','assert_eq!(parse_segments("<color:red></color>"), vec![seg(" ", Style::default())]);')
pos=s.index('    #[test]\n    fn segments_plain_text()')
s=s[:pos]+r'''    #[test]
    fn hidden_characters_share_candidate_and_recursive_text_semantics() {
        assert_eq!(parse_segments(r"q<b>a\~</b>r"), vec![
            seg("q", Style::default()), seg("a~", bold_style()), seg("r", Style::default()),
        ]);
        assert_eq!(parse_segments("q~***x**r"), vec![
            seg("q*", Style::default()), seg("x", bold_style()), seg("r", Style::default()),
        ]);
        assert_eq!(parse_segments(r"q<b><i>a\~</i></b>r")[1].text, "a~");
        assert_eq!(stripped_text(r"~#~.~[~]~<~a~Ω\~"), "#.[]<~a~Ω~");
        assert_eq!(stripped_text(r"q**a\~\~b**r"), "qa~~br");
    }

    #[test]
    fn parameter_commands_flush_empty_and_same_style_bodies() {
        for markup in ["q<size:13></size>r", "q<color:black></color>r",
            "q<size:13><$twig></size>r", "q<color:black><$twig></color>r"] {
            assert_eq!(parse_segments(markup), vec![seg("q", Style::default()), seg("r", Style::default())], "{markup}");
        }
        let segments = parse_segments("<size:13>q<size:13>x</size>r</size>");
        assert_eq!(segments.iter().map(|s| s.text.as_str()).collect::<Vec<_>>(), ["q", "x", "r"]);
        assert!(segments.iter().all(|s| s.style.size == Some(13)));
        assert_eq!(parse_segments("<size:25></size><color:red></color>"), vec![seg(" ", Style::default())]);
        assert!(parse_segments("").is_empty());
    }

'''+s[pos:];p.write_text(s)
