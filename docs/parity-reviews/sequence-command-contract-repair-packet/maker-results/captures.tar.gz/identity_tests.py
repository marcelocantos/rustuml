from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/sequence.rs');s=p.read_text();at=s.index('    #[test]\n    fn note_over_requires_a_named_participant()')
s=s[:at]+'''    #[test]
    fn named_note_identity_is_required_after_optional_prefix() {
        for shape in ["note", "rnote", "hnote"] {
            for (command, identities) in [
                (format!("{shape} over of : body"), vec!["of"]),
                (format!("{shape} over of #pink: body"), vec!["of"]),
                (format!("{shape} over of of : body"), vec!["of"]),
                (format!("{shape} over of, South: body"), vec!["of", "South"]),
                (format!("{shape} left of \\"North Pier\\": body"), vec!["North Pier"]),
                (format!("{shape} over of\\nbody\\nend note"), vec!["of"]),
                (format!("{shape} over of  North\\nbody\\nend note"), vec!["North"]),
            ] {
                let diagram = parse(&command);
                let Event::Note(note) = &diagram.events[0] else { panic!("missing note: {command}") };
                assert_eq!(note.participants, identities, "{command}");
                assert!(!note.on_message);
                assert_eq!(note.text, "body");
            }
        }
    }

'''.replace('\\"','\\"')+s[at:];p.write_text(s)
