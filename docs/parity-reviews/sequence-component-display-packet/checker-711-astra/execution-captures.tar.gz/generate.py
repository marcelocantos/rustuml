# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import base64, hashlib, json, pathlib
OUT=pathlib.Path(__file__).parent
cases=[]
def add(name,body,mechanisms,axes,valid=True):
    for engine in ('legacy','teoz'):
        source='@startuml\n'+('!pragma teoz true\n' if engine=='teoz' else '')+body+'\n@enduml\n'
        name2='review711_'+name+'_'+engine
        path=OUT/'fresh-inputs'/(name2+'.puml'); path.parent.mkdir(exist_ok=True); path.write_text(source)
        data=path.read_bytes()
        cases.append(dict(name=name2,path=str(path),source='test-diagrams/perturbations/sequence-component-display-review711/'+name2+'.puml',golden='test-diagrams/perturbations/sequence-component-display-review711/'+name2+'.svg',source_sha256=hashlib.sha256(data).hexdigest(),source_b64=base64.b64encode(data).decode(),source_bytes=len(data),mechanisms=mechanisms,axes=axes+['engine='+engine],intended_validity='valid' if valid else 'invalid',resources=[]))
a='sequence-dressing-owned-parts'; s='sequence-self-part-consumer'; c='sequence-created-image-event-ownership'; d='sequence-complete-participant-display'; f='sequence-participant-kind-font-consumer'; h='sequence-head-englober-component-height'; e='sequence-englober-member-composition'; t='sequence-empty-rule-title-atom'; n='sequence-unclosed-note-command'
add('ordinary_parts',r'''participant Quartz
participant Larch
Quartz <-> Larch: full
Quartz <-/ Larch: lower
Quartz <-\\ Larch: upper open
Larch <</- Quartz: reversed open
Quartz o<-/o Larch: rings
Larch o<\\-o Quartz: reversed rings''',[a],['normal/open/half/circle','direction/label'])
add('self_parts',r'''participant Quartz
Quartz <-> Quartz: full
Quartz <-/ Quartz: lower
Quartz <-\\ Quartz: upper open
Quartz o<-/o Quartz: rings
Quartz <<-\\ Quartz: asymmetry''',[a,s],['self/dressing asymmetry','half/normal/open/circle'])
add('self_reverse',r'''participant Larch
Larch <- Larch: reverse
Larch /- Larch: lower
Larch \\- Larch: upper open
Larch o<-o Larch: rings
activate Larch
Larch /- Larch: live
 deactivate Larch''',[a,s],['reversed self','activation/half/open/circle'])
add('external_parts',r'''participant Quartz
[-> Quartz: incoming
[->> Quartz: open
[->o Quartz: ring
Quartz ->]: outgoing
Quartz -/]: half
Quartz -\\]: open half''',[a],['external topology','normal/open/circle/half'])
add('create_repeat_actor',r'''participant Mint
actor "Receiver\nthree\nlines" as Roe
create Roe
Mint -> Roe: first
Roe --> Mint: reply
create Roe
Mint -> Roe ++: second
Roe --> Mint --: release
create Roe
Mint -> Roe: third''',[c,d],['three creations/interleaved history','actor/multiline/activation'])
add('create_reverse_queue',r'''queue "Blue\nMailbox" as Box
participant Mint
create Box
Box <- Mint: first
Box --> Mint: acknowledgement
create Box
Box <- Mint ++: second
Box --> Mint --: finish''',[c,d],['reverse declaration/message direction','repeated queue/multiline'])
add('create_group_live',r'''actor Roe
participant Mint
activate Mint
loop renew
create Roe
Mint -> Roe ++: create
Roe --> Mint --: response
end
create Roe
Mint -> Roe ++: renew
Roe --> Mint --: response
deactivate Mint''',[c],['scope/activation','repeated creation/direction'])
add('create_double_pending',r'''participant Mint
participant Roe
create Roe
create Roe
Mint -> Roe: first
Mint -> Roe: second''',[c],['consecutive pending creation','message ownership'],False)
add('display_plain',r'''participant "Tiny\n<size:23>Large</size>\nEnd" as P <<type>>
participant "Middle\n\nFinal" as R
P -> R: relay
R -> P: return''',[d],['per-stripe size/blank','multiline/stereotype/alias/tail'])
add('display_queue',r'''queue "Tiny\n<size:21>Large</size>\nEnd" as Q
queue "Three\nsmall\nrows" as R
Q -> R: relay''',[d],['rich size/queue-only','multiline/alias/tail'])
add('display_figures',r'''actor "Act\nAgain" as A
boundary "Bound\nAgain" as B
control "Ctrl\nAgain" as C
entity "Entity\nAgain" as D
database "Data\nAgain" as E
collections "Coll\nAgain" as F
A -> B: one
B -> C: two
C -> D: three
D -> E: four
E -> F: five''',[d],['six figure kinds','multiline/head/tail'])
add('display_identity',r'''participant "Same\nname" as First
participant "Same\nname" as Second
First -> Second: distinct identities
Second -> First: return''',[d],['same label/distinct aliases','multiline/direction'])
add('font_isolation',r'''skinparam participantFontSize 25
participant "Plain\nhead" as P
queue "Queue\nhead" as Q
actor "Actor\nhead" as A
P -> Q: relay
Q -> A: forward''',[d,f],['kind-specific inherited font','multiline/mixed kinds'])
add('font_each_kind',r'''skinparam participantFontSize 9
skinparam queueFontSize 19
skinparam actorFontSize 22
queue "Queue\nhead" as Q
participant "Plain\nhead" as P
actor "Actor\nhead" as A
A -> Q: route
Q -> P: forward''',[d,f],['unequal explicit sizes','reverse/mixed kinds'])
add('blank_display',r'''participant "\n\n" as P
queue "" as Q
P -> Q: empty labels''',[d],['blank stripes/absent label','participant/queue'])
add('title_space',r'''Quartz -> Larch: request
note right of Larch
first
==   ==
last
end note''',[t],['whitespace title','right-note/multiline'])
add('title_space_styles',r'''skinparam noteFontSize 19
Quartz -> Larch: request
note over Quartz,Larch
above
--   --
below
end note''',[t],['rule style/font size','over topology/whitespace'])
add('note_unclosed',r'''Quartz -> Larch: request
note right of Larch
body
second''',[n],['unclosed note','right topology/multiline'],False)
add('note_closed',r'''Quartz -> Larch: request
note over Quartz,Larch
body
second
end note''',[n],['closure positive','over topology/multiline'])
add('group_unclosed',r'''group still open
Quartz -> Larch: request''',[n],['group closure contrast','renamed labels'])
add('box_unclosed',r'''box "Still open"
participant Quartz
participant Larch
Quartz -> Larch: request''',[n,h,e],['box closure contrast','member composition'])
add('box_queue_actor',r'''actor "Tall\nOutside" as A
box "Mailbox"
queue "Q" as Q
end box
A -> Q: relay''',[d,h,e],['unboxed taller member','queue/englober maxima'])
add('box_actor_queue',r'''queue "Outside" as Q
box "Actors"
actor "Tall\nInside" as A
end box
Q -> A: relay''',[d,h,e],['boxed taller member','actor/queue composition'])
add('box_multiline_title',r'''box "First\nSecond\nThird"
participant P
end box
actor A
A -> P: relay''',[h,e],['multiline title','mixed boxed/unboxed members'])
add('box_nested',r'''box "Outer"
participant P
box "Inner"
queue "Inbox\nHere" as Q
end box
end box
actor A
A -> Q: relay
Q -> P: forward''',[d,h,e],['nested englobers','mixed member kinds/multiline'])
add('box_stereo',r'''box "Members"
queue "Inbox\nHere" as Q <<worker>>
participant "Reply\nThere" as P <<service>>
end box
Q -> P: relay''',[d,h,e],['boxed stereotype','queue/participant multiline'])
manifest=dict(schema_version=1,request_id='sequence-review711-5c023380',java_revision='71806a23780b04a5ccde2f8ceb5121edad5eb711',jar_sha256='aa5262a23e7f1fa50bdf9f6492e8d9f8683b2f18e2f182776966e17bdb282053',cwd='PRIVATE_CWD',timezone='GMT+11:00',resources=[],cases=cases)
p=OUT/'relay-manifest.json'; p.write_text(json.dumps(manifest,separators=(',',':'))+'\n'); p.chmod(0o444)
print(len(cases),hashlib.sha256(p.read_bytes()).hexdigest(),p)
