// Copyright 2026 Marcelo Cantos
// SPDX-License-Identifier: Apache-2.0
use std::io::{self, BufRead};
fn main() {
    for line in io::stdin().lock().lines() {
        let source = line.unwrap();
        println!("SOURCE {source:?}");
        println!("SEGMENTS {:?}", rustuml_render::creole::parse_segments(&source));
        println!("WIDTH {}", rustuml_render::text_render::measure_with_family(&source, 14.0, false, "sans-serif"));
        println!("LEGACY {}", rustuml_render::creole::to_svg_tspans(&source));
    }
}
