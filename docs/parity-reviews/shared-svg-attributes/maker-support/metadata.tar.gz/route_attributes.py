# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
"""Apply the precommitted routing inventory as expression-only replacements."""
import re,json,subprocess,collections
from pathlib import Path
S=Path(__file__).parent;R=Path('/Users/marcelo/.t3/worktrees/rustuml/t3-a295df45')
exec((S/'inventory.py').read_text().split('rows=[]')[0])
rows=json.loads((R/'docs/parity-reviews/shared-svg-attributes/proposed-routing-list.json').read_bytes());byfile=collections.defaultdict(list)
for row in rows:byfile[row['file']].append(row)
log=[];issues=[]
for file,rr in byfile.items():
 current=(R/file).read_text();base=subprocess.check_output(['git','show','d48ed1e7033e5539568a59b63c3d3229d07972db:'+file],cwd=R).decode();s=base;groups=collections.defaultdict(list)
 for row in rr:groups[(row['line'],row['macro'])].append(row)
 changes=[]
 for (line,macro),items in groups.items():
  start=sum(len(x) for x in base.splitlines(keepends=True)[:line-1]);start=base.find(macro,start);assert start>=0,(file,line)
  mm=re.match(r'(format|write|writeln)!\s*\(',macro);spans,end=args(macro,mm.end()-1);fi=0 if mm[1]=='format' else 1
  provided={};position=[]
  for ai,(a,b) in enumerate(spans[fi+1:],fi+1):
   x=macro[a:b].strip();nm=re.match(r'^(\w+)\s*=\s*(?!=)([\s\S]*)',x)
   if nm:provided[nm[1]]=(ai,nm[2])
   else:position.append((ai,x))
  fmt=macro[slice(*spans[fi])].strip();raw=re.fullmatch(r'r(\#*)"([\s\S]*)"\1',fmt);template=raw[2] if raw else fmt[1:-1].replace('\\"','"')
  inputs={}
  for row in items:
   for inp in row['inputs']:
    if inp['classification']!='user-string' or 'existing_encoding_producer' in inp:continue
    expr=inp['expression'];mode='font_family_attribute' if row['attribute']=='font-family' else 'escape_attribute'
    if expr in inputs and inputs[expr]!=mode:issues.append((file,line,'conflicting attribute roles',expr))
    inputs[expr]=mode
  replacements={};new_named={}
  for expr,mode in inputs.items():
   rawexpr=expr;esc=re.fullmatch(r'(?:escape_xml_attr_local|escape_xml_attr|escape_xml|escape_attr|escape_text|svg_attr_escape)\(([\s\S]*)\)',expr)
   if esc:rawexpr=esc[1]
   call='crate::svg::'+mode+'(&('+rawexpr+'))'
   explicit=[(ai,None) for ai,x in position if x==expr]+[(ai,key) for key,(ai,x) in provided.items() if x==expr]
   if explicit:
    for ai,key in explicit:
     a,b=spans[ai];old=macro[a:b];core=old.strip();new=(key+' = ' if key else '')+call
     replacements[ai]=(a,b,old.replace(core,new,1))
   else:
    assert re.fullmatch(r'\w+',expr),(file,line,expr)
    # Do not change any other use of an implicitly captured variable.
    for f in re.finditer(r'\{'+re.escape(expr)+r'(?::[^{}]*)?\}',template):
     if not any(a.start(2)<=f.start()<a.end(2) for a in re.finditer(r'([\w:-]+)="([^"\n]*)"',template)):
      
      if not (file.endswith('/state.rs') and line==8221 and expr in ['from','to']):issues.append((file,line,'non-attribute use of captured string',expr))
    new_named[expr]=call
  out=macro
  if file.endswith('/state.rs') and line==8221:
   pass
   for key in ['from','to']:
    if key in new_named:del new_named[key]
    new_named[key+'_attr']='crate::svg::escape_attribute('+key+')'
  for a,b,new in sorted(replacements.values(),reverse=True):out=out[:a]+new+out[b:]
  if file.endswith('/state.rs') and line==8221:out=out.replace('id="{from}-{to}"','id="{from_attr}-{to_attr}"')
  if new_named:
   close=out.rfind(')');body=out[:close].rstrip();body=body if body.endswith(',') else body+',';out=body+' '+', '.join(k+' = '+v for k,v in new_named.items())+',\n'+out[close:]
  if out!=macro:
   changes.append((start,start+len(macro),out));log.append(dict(file=file,line=line,attribute_sites=len(items),before=macro,after=out))
 if issues:continue
 for a,b,new in sorted(changes,reverse=True):s=s[:a]+new+s[b:]
 if file.endswith('/svg.rs'):
  header=current[current.index('/// Encode a DOM attribute'):current.index('pub(crate) fn normalize_svg_link_title')];s=s.replace('pub(crate) fn normalize_svg_link_title',header+'pub(crate) fn normalize_svg_link_title',1)
 (R/file).write_text(s)
(S/'routing-draft-log.json').write_text(json.dumps(log,indent=2)+'\n');(S/'routing-draft-issues.json').write_text(json.dumps(issues,indent=2)+'\n');print('macro edits',len(log),'issues',issues)
