# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,xml.etree.ElementTree as ET
s=Path(__file__).resolve().parent;a=s/'maker-archive';sha=lambda b:hashlib.sha256(b).hexdigest();rows=json.loads((s/'replay-historical.json').read_text())['results'];out={};cohorts={};start=0
for name,size in [('preserved1559',1559),('maker36',36),('maker20',20),('checker34',34),('maker26',26),('checker86',86),('maker32',32),('previous_checker33',33),('maker_fresh25',25)]:
 rr=rows[start:start+size];cohorts[name]={'range':[start,start+size],'entries':len(rr),'unique_sources':len({r['source_sha256'] for r in rr}),'before':dict(Counter(r['before']['status'] for r in rr)),'after':dict(Counter(r['after']['status'] for r in rr)),'membership':[{'source':r['source'],'source_sha256':r['source_sha256'],'reference_sha256':r['java_sha256']} for r in rr]};start+=size
out['cohort_partition']=cohorts;groups=defaultdict(list)
for r in rows:groups[r['source_sha256']].append({'index':r['index'],'source':r['source'],'reference_sha256':r['java_sha256']})
out['duplicate_source_groups']={k:v for k,v in groups.items() if len(v)>1};out['duplicate_reference_conflicts']={k:v for k,v in out['duplicate_source_groups'].items() if len({x['reference_sha256'] for x in v})>1}
def inventory(path):
 x=ET.fromstring(path.read_bytes());groups=[];anchors=[]
 def walk(e,owner=None,url=None):
  if e.tag.endswith('}a'):url=e.attrib;anchors.append({'owner':owner,'attrs':dict(url)})
  if e.get('class') in ['entity','cluster']:
   owner=e.get('id');groups.append({'kind':e.get('class'),'name':e.get('data-qualified-name'),'uid':owner,'source_line':e.get('data-source-line'),'ancestor_url':url})
  for c in e:walk(c,owner,url)
 walk(x);return {'groups':groups,'anchors':anchors}
doms=[]
for r in rows[1793:]:
 if r['after']['status'] in ['invalid_reference','process_error']:continue
 j=inventory(Path(r['source']).with_suffix('.svg'));v=inventory(s/r['after']['cli']['capture']);doms.append({'source':r['source'],'status':r['after']['status'],'java':j,'rust':v,'equal':j==v})
out['current48_dom']=doms;out['current48_dom_count']=len(doms);out['current48_dom_disagreements']=[r['source'] for r in doms if not r['equal']];out['frozen_invalid_reference_rust_accepts']=sum(r['after']['status']=='invalid_reference' and r['after']['cli']['exit']==0 for r in rows[:1826]);out['preserved_earlier_group_extents']=[{'source':r['source'],'java':[r['java_dom']['width'],r['java_dom']['height']],'rust':[r['after']['dom']['width'],r['after']['dom']['height']],'status':r['after']['status']} for r in rows if Path(r['source']).stem in ['n_group_single','n_group_multi']]
out['final_binary_check']={k:v for k,v in json.loads((s/'post-gates-binary-check.json').read_text()).items() if k!='results'};(s/'supplemental-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('48DOM',len(doms),'disagreements',out['current48_dom_disagreements'],'invalid accepted',out['frozen_invalid_reference_rust_accepts'])
