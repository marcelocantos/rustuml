# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections,hashlib,json,re,subprocess
from pathlib import Path
from replay import S,R,sha,dump
rows=json.loads((S/'all-replay-results.json').read_bytes());suites=collections.defaultdict(list)
for r in rows:suites[r['suite']].append(r)
sets={s:{(r['membership']['source_sha256'],r['membership']['golden_sha256']) for r in rs} for s,rs in suites.items()}
by={r['membership']['source']:r for s in ['collateral','prior31'] for r in suites[s]}
for suite,checker in [('fresh29','checker5'),('fresh6','checker6')]:
 for r in suites[suite]:
  p=R/'test-diagrams/perturbations'/r['membership']['mechanism']/checker/Path(r['input']).name
  assert p.read_bytes()==Path(r['input']).read_bytes() and p.with_suffix('.svg').read_bytes()==Path(r['golden']).read_bytes()
  by[str(p.relative_to(R))]=r
assert len(by)==1605
failures={}
for line in (S/'logs2/standing.log').read_text().splitlines():
 if line.startswith('  test-diagrams/perturbations/'):
  p,msg=line[2:].split(': ',1);failures[p]=msg
assert set(failures)<=set(by)
diffs=[dict(source=p,standing_pass=p not in failures,cli_pass=r['phases']['after']['svg_match'],standing_failure=failures.get(p),cwd=r['phases']['after']['svg']['cwd'],env_overrides=r['env_overrides']) for p,r in by.items() if (p not in failures)!=r['phases']['after']['svg_match']]
assert len(diffs)==27
panics=collections.defaultdict(list);other_errors=[];drops=[];negative=[]
for r in rows:
 a=r['phases']['after'];b=r['phases']['before'];d=S/'replay'/r['suite']/f"{r['index']:04}-{Path(r['input']).stem}"/'after'
 if a['panic']:
  err=(d/'svg.stderr').read_text();sig=err[err.index('panicked at '):].split('\nnote:',1)[0].strip();panics[sig].append(r['input'])
 elif r['membership']['reference_valid'] and a['svg']['exit']:other_errors.append(r['input'])
 bm=b.get('model') or {};am=a.get('model') or {}
 if bm.get('entities') is not None and (am.get('entities') or 0)<bm['entities']:drops.append(dict(source=r['input'],valid=r['membership']['reference_valid'],before=bm,after=am))
 if not r['membership']['reference_valid']:negative.append(dict(source=r['input'],suite=r['suite'],before_exit=b['svg']['exit'],after_exit=a['svg']['exit']))
summary=dict(total_entries=len(rows),unique_pairs=len(set.union(*sets.values())),membership_counts={s:len(rs) for s,rs in suites.items()},unique_pairs_by_cohort={s:len(ss) for s,ss in sets.items()},pair_intersections={a+' & '+b:len(sets[a]&sets[b]) for i,a in enumerate(sets) for b in list(sets)[i+1:]},standing=dict(total=len(by),passed=len(by)-len(failures),failed=len(failures),exit=101),matching_environment_cli=sum(r['phases']['after']['svg_match'] for r in by.values()),environment_discrepancies=diffs,panic_groups=dict(panics),other_valid_errors=other_errors,model_drops=drops,negative_results=negative)
for tag in ['cohort955','cohort1044']:
 rr=[r for r in suites['collateral'] if r['membership'].get(tag)];summary[tag]=dict(total=len(rr),matches=sum(r['phases']['after']['svg_match'] for r in rr))
rr=[r for r in suites['collateral'] if r['membership'].get('cohort')=='frozen'];summary['frozen1449']=dict(total=len(rr),matches=sum(r['phases']['after']['svg_match'] for r in rr))
dump(S/'analysis.json',summary)
# Check every cited Java file against pinned revision and retain hashes, not unneeded full source copies.
J=Path('/Users/marcelo/work/github.com/plantuml/plantuml');rev='71806a23780b04a5ccde2f8ceb5121edad5eb711'
old=json.loads((R/'docs/parity-reviews/tim-exact-memory-identities/maker-support/java-source-provenance.json').read_bytes())
paths=sorted({r['path'] for r in old}|{'src/main/java/net/sourceforge/plantuml/tim/Eater.java','src/main/java/net/sourceforge/plantuml/tim/TrieImpl.java','src/main/java/net/sourceforge/plantuml/preproc/Sub.java','src/main/java/net/sourceforge/plantuml/tim/EaterUndef.java'})
prov=[]
for path in paths:
 b=(J/path).read_bytes();assert b==subprocess.check_output(['git','-C',str(J),'show',rev+':'+path]);prov.append(dict(path=path,revision=rev,sha256=sha(b)))
dump(S/'java-provenance.json',prov)
print('memberships',len(rows),'unique',summary['unique_pairs'],'standing',summary['standing'],'cli',summary['matching_environment_cli'],'env discrepancies',len(diffs),'panics',[(s.splitlines()[:2],len(ps)) for s,ps in panics.items()],'other',other_errors)
