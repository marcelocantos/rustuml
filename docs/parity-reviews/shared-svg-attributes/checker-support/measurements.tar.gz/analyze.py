# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections,gzip,hashlib,json,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
import yaml
S=Path(__file__).parent;R=Path.cwd();A=S/'docs/parity-reviews/shared-svg-attributes/maker-support';sha=lambda b:hashlib.sha256(b).hexdigest()
rs=json.loads((S/'replay-results.json').read_bytes()); summaries=json.loads((S/'replay-summary.json').read_bytes());byid={r['id']:r for r in rs}
def xml(b):
 return ET.fromstring(b,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True,insert_pis=True)))
def proj(n):return (str(n.tag),sorted(n.attrib.items()),n.text,n.tail,[proj(c) for c in n])
def model(n):
 if n is None:return None
 if isinstance(n,yaml.ScalarNode):return ('scalar',n.tag,n.value)
 if isinstance(n,yaml.SequenceNode):return ('seq',n.tag,[model(x) for x in n.value])
 return ('map',n.tag,sorted((model(k),model(v)) for k,v in n.value))
changes=[];yaml_changes=[]
for group in summaries:
 for id in group['yaml_changed']:
  old=(S/'replay/before'/id/'yaml.stdout').read_bytes();new=(S/'replay/after'/id/'yaml.stdout').read_bytes();same=model(yaml.compose(old))==model(yaml.compose(new));assert same,id
  yaml_changes.append(dict(id=id,order_only=same,before_sha256=sha(old),after_sha256=sha(new)))
 if group['cohort']=='full-golden':
  for id in group['svg_changed']:
   old=(S/'replay/before'/id/'svg.stdout').read_bytes();new=(S/'replay/after'/id/'svg.stdout').read_bytes();a=xml(old);b=xml(new);same=proj(a)==proj(b);assert same,id
   changes.append(dict(id=id,decoded_equal=True,before_pass=byid[id]['before']['match'],after_pass=byid[id]['after']['match'],before_sha256=sha(old),after_sha256=sha(new)))
assert len(changes)==16 and sum(r['after_pass'] for r in changes)==14
# Verify archived claims independently using every manifest byte hash, then decode the changed YAMLs.
archived={}
for phase in ['before','after']:
 manifest=json.loads(gzip.decompress((A/('captures-'+phase+'.entries.json.gz')).read_bytes()))
 archived[phase]={r['path'].removeprefix('replay/'+phase+'/'):r for r in manifest}
changed=[p for p in archived['before'] if p.endswith('/yaml.stdout') and archived['before'][p]['sha256']!=archived['after'][p]['sha256']]
assert len(changed)==9 and all(p.startswith('full-golden/') for p in changed)
selected={}
for phase in ['before','after']:
 with tarfile.open(A/('captures-'+phase+'.tar.gz')) as t:
  for entry in t:
   p=entry.name.removeprefix('replay/'+phase+'/')
   if p in changed:selected[(phase,p)]=t.extractfile(entry).read()
archived_yaml=[]
for p in changed:
 old=selected['before',p];new=selected['after',p];same=model(yaml.compose(old))==model(yaml.compose(new));assert same,p
 archived_yaml.append(dict(path=p,order_only=same,before_sha256=sha(old),after_sha256=sha(new)))
# Exact denominator retains memberships even when source/references duplicate.
cohort_counts={g['cohort']:g['entries'] for g in summaries};prior=[g for g in summaries if g['cohort'] not in ['full-golden','shared22']]
report=dict(golden=dict(inputs=12550,eligible=11251,before_pass=11179,after_pass=11179,changes=changes),prior=dict(entries=sum(g['entries'] for g in prior),valid=sum(g['valid'] for g in prior),before_pass=sum(g['before_pass'] for g in prior),after_pass=sum(g['after_pass'] for g in prior)),fresh_maker22=next(g for g in summaries if g['cohort']=='shared22'),replay_losses=[x for g in summaries for x in g['losses']],new_errors=[x for g in summaries for x in g['new_errors']],new_panics=[x for g in summaries for x in g['new_panics']],fresh_yaml_order_only_changes=yaml_changes,maker_archived_yaml_order_only_changes=archived_yaml,archived_2104_yaml_byte_identical=True)
for phase in ['before','after']:
 report['golden'][phase+'_xml']=dict(emitted=sum(r[phase]['emitted'] for r in rs if r['cohort']=='full-golden'),malformed=sum(bool(r[phase]['xml_error']) for r in rs if r['cohort']=='full-golden'),errors=sum(r[phase]['svg']['exit']!=0 for r in rs if r['cohort']=='full-golden'),panics=sum(r[phase]['panic'] for r in rs if r['cohort']=='full-golden'))
# Reproduce identity-domain counts from the same archived census streams.
attrs={'d','points','textLength','rx','ry','font-size'};counts=collections.Counter();bad=[];unparseable=[];files=0;comments=0;malformed_comments=[]
for archive,prefix in [('captures-before.tar.gz','replay/before/full-golden/'),('registered-cli.tar.gz','registered/before/')]:
 with tarfile.open(A/archive) as t:
  for entry in t:
   if not entry.name.startswith(prefix) or not entry.name.endswith('/svg.stdout'):continue
   files+=1;b=t.extractfile(entry).read()
   if not b:continue
   try:root=xml(b)
   except ET.ParseError as e:unparseable.append(dict(path=entry.name,error=str(e)));continue
   for n in root.iter():
    if n.tag==ET.Comment:comments+=1
    for k,v in n.attrib.items():
     if k not in attrs:continue
     counts[k]+=1
     if any(ord(c)<32 or ord(c)>126 or c in '&<>"' for c in v):bad.append(dict(path=entry.name,attribute=k,value=v))
report['identity_domain']=dict(files=files,counts=dict(counts),outside_identity=bad,unparseable=unparseable,parsed_comments=comments)
assert files==14494 and not bad
# Fresh failure-name files vs maker archived immutable hashes.
failsets=[]
for name in ['no_oracle_failure_names.txt','golden_failure_names.txt']:
 actual=(R/'test-diagrams'/name).read_bytes();expected=(S/'maker-extracted'/('final-'+name)).read_bytes();assert actual==expected,name
 (S/name).write_bytes(actual);failsets.append(dict(file=name,count=len(actual.splitlines()),sha256=sha(actual),identical=True))
report['failure_sets']=failsets
assert (S/'production-before.txt').read_bytes()==(S/'production-after.txt').read_bytes();report['production_dependencies_identical']=True
(S/'verified-measurements.json').write_text(json.dumps(report,indent=2)+'\n')
print('prior',report['prior']);print('golden changes',len(changes));print('new YAML changes',len(yaml_changes),'archived',len(archived_yaml));print('domain',files,dict(counts),len(bad),len(unparseable));print('losses/errors/panics',report['replay_losses'],report['new_errors'],report['new_panics'])
