# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
"""Read-only lexical inventory. Context is retained for manual dataflow classification."""
import re,json
from pathlib import Path
S=Path(__file__).parent;root=Path.cwd()
# Raw/ordinary Rust strings, comments and character literals are atomic.
lex=re.compile(r'r(?P<h>\#*)"[\s\S]*?"(?P=h)|"(?:\\[\s\S]|[^"\\])*"|//[^\n]*|/\*[\s\S]*?\*/|\'(?:\\.|[^\'\\])\'|[(){}\[\],]')
def args(s,start):
 depth=1;last=start+1;out=[]
 for m in lex.finditer(s,start+1):
  t=m[0]
  if t in ('(','[','{'):depth+=1
  elif t in (')',']','}'):
   depth-=1
   if depth==0:
    if s[last:m.start()].strip():out.append((last,m.start()))
    return out,m.end()
  elif t==',' and depth==1:out.append((last,m.start()));last=m.end()
 return [],start
rows=[]
for p in sorted((root/'crates/rustuml-render/src').glob('*.rs')):
 s=p.read_text().split('#[cfg(test)]')[0]
 for m in re.finditer(r'\b(format|write|writeln)!\s*\(',s):
  spans,end=args(s,m.end()-1);fi=0 if m[1]=='format' else 1
  if len(spans)<=fi:continue
  a,b=spans[fi];v=s[a:b].strip();raw=re.fullmatch(r'r(\#*)"([\s\S]*)"\1',v)
  if raw:template=raw[2]
  elif v.startswith('"') and v.endswith('"'):template=v[1:-1].replace('\\"','"')
  else:continue
  actual=[s[a:b].strip() for a,b in spans[fi+1:]];named={};pos=[]
  for x in actual:
   nm=re.match(r'^(\w+)\s*=\s*(?!=)([\s\S]*)',x)
   if nm:named[nm[1]]=nm[2]
   else:pos.append(x)
  n=0;fields=[]
  for f in re.finditer(r'(?<!\{)\{([^{}]*)\}(?!\})',template):
   key=f[1].split(':')[0]
   if not key:key=str(n);n+=1
   expr=pos[int(key)] if key.isdigit() and int(key)<len(pos) else named.get(key,key)
   fields.append((f.start(),f.end(),key,expr))
  for attr in re.finditer(r'([\w:-]+)="([^"\n]*)"',template):
   fs=[f for f in fields if attr.start(2)<=f[0]<attr.end(2)]
   if not fs:continue
   line=s.count('\n',0,m.start())+1
   rows.append(dict(file=str(p.relative_to(root)),line=line,attribute=attr[1],template=attr[2],expressions=[f[3] for f in fs],macro=s[m.start():end],context=s[max(0,s.rfind('\n',0,max(0,m.start()-500))):end],sequence=p.name=='sequence.rs'))
(S/'complete-attribute-inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
selected=['font-family','href','xlink:href','title','xlink:title','id','class']
for i,r in enumerate(rows):
 if r['attribute'] in selected or r['attribute'].startswith('data-'):
  print(i,Path(r['file']).name+':'+str(r['line']),r['attribute'],repr(r['expressions']))
print('all',len(rows))
