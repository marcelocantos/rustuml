import collections,gzip,hashlib,json,re,subprocess
from pathlib import Path
c=Path(__file__).parent
def read(p):return json.loads(p.read_text())
def archived(path):return json.loads(gzip.decompress(subprocess.check_output(['git','show','672cd8f:'+path])))
def sha(b):return hashlib.sha256(b).hexdigest()
def stats(rows):
 return dict(entries=len(rows),matches=sum(r['cli_comparison']['exit']==0 for r in rows),valid_mismatches=sum(r['cli_comparison']['exit']==1 for r in rows),invalid_references=sum(r['cli_comparison']['exit']==2 for r in rows),cli_exits=dict(collections.Counter(r['cli']['exit'] for r in rows)),invalid_cli_exits=dict(collections.Counter(r['cli']['exit'] for r in rows if r['cli_comparison']['exit']==2)),cli_panics=[r['source'] for r in rows if 'panicked at' in r['cli']['stderr']],valid_cli_errors=[r['source'] for r in rows if r['cli_comparison']['exit']!=2 and r['cli']['exit']!=0],library_render_panics=[r['source'] for r in rows if r['library_render_exit']==101],mode_exits={m:dict(collections.Counter(r[m]['exit'] for r in rows)) for m in ['cli_comparison','product_library','assisted_library']},comparison_helper_panics={m:[r['source'] for r in rows if r[m]['exit']==101] for m in ['product_library','assisted_library']})
b=read(c/'preserved-before/measurements.json');a=read(c/'preserved-candidate/measurements.json');fb=read(c/'fresh-before/measurements.json')+read(c/'supplement-before/measurements.json');fa=read(c/'fresh-candidate/measurements.json')+read(c/'supplement-candidate/measurements.json');mb=read(c/'models-before.json');ma=read(c/'models-candidate.json')
prior_a=archived('docs/parity-reviews/sequence-composed-components-packet/maker-results/measurements.json.gz');prior_b=archived('docs/parity-reviews/sequence-composed-components-packet/maker-results/before-measurements.json.gz');parent=archived('docs/parity-reviews/sequence-rejection-repair/checker-support/replay1449.json.gz')
summary=dict(candidate='672cd8f26e1d7c6725d8971e01ad7575defd8567',production='b4f37ab5840b8d70bf1246e3659f1902c0952a51',before_revision='092cf5f68464625c8b3771e069b42f44f43fc0c9')
summary['preserved']=dict(before=stats(b),after=stats(a),unique_source_bytes=len({r['source_sha256'] for r in a}),duplicate_entries=len(a)-len({r['source_sha256'] for r in a}),gains=[r['original_source'] for o,r in zip(b,a) if o['cli_comparison']['exit']==1 and r['cli_comparison']['exit']==0],losses_by_mode={m:[r['original_source'] for o,r in zip(b,a) if o[m]['exit']==0 and r[m]['exit']!=0] for m in ['cli_comparison','product_library','assisted_library']})
for label,rows,old in [('after',a,prior_a),('before',b,prior_b)]:
 summary['preserved']['archived_'+label+'_status_or_svg_differences']=[i for i,(r,o) in enumerate(zip(rows,old)) if r['cli']['svg_sha256']!=o['cli']['svg_sha256'] or any(r[m]['exit']!=o[m]['exit'] for m in ['cli','cli_comparison','product_library','assisted_library'])]
summary['fresh']=dict(before=stats(fb),after=stats(fa),by_claim={k:stats([r for r in fa if r['claim']==k]) for k in sorted({r['claim'] for r in fa})})
summary['model_ascii']=dict(entries=len(ma),changed_ascii=[dict(source=r.get('original_source',r['source']),cohort=r['cohort']) for o,r in zip(mb,ma) if o['results']['ascii']['stdout']!=r['results']['ascii']['stdout']],model_statuses=dict(collections.Counter(r['results']['model']['exit'] for r in ma)))

ps={x['source_sha256'] for x in parent};cs={x['source_sha256'] for x in a};summary['parent_overlap']=dict(parent_entries=len(parent),parent_unique_sources=len(ps),overlap=len(ps&cs),parent_only_not_measured=len(ps-cs))
paths={r['original_source'] for r in a}
def original_path(value):
 for marker in ['test-diagrams/','docs/parity-reviews/']:
  if marker in value:return value[value.index(marker):]
 return value
summary['parent_overlap']['path_overlap']=sum(original_path(r['source']) in paths for r in parent)
summary['parent_overlap']['parent_only_paths_not_replayed']=sum(original_path(r['source']) not in paths for r in parent)
summary['parent_overlap']['note']='1123/326 is source-PATH membership. By bytes1141 parent entries share inputs/references,18 additional copied paths; unique byte overlap1097,278 unique parent-only byte strings. No parent-only path is added to measured denominator.'
summary['cohorts']={name:dict(before=stats(b[lo:hi]),after=stats(a[lo:hi])) for name,lo,hi in [('preserved1966',0,1966),('latest_checker31',1966,1997),('maker22',1997,2019),('actor2',2019,2021)]}
summary['main_library']={}
for label,rev,filename in [('before','092cf5f','main-tiers-and-guards.log'),('candidate','672cd8f','initialized-main-guards.log'),('intermediate','c921945a','main-tiers.log')]:
 log=(c/label/filename).read_text();prod=re.search(r'golden_no_oracle: (\d+)/(\d+)',log);assist=re.search(r'golden_pairs: (\d+) total, (\d+) passed, (\d+) failed, (\d+) skipped',log);seq=re.search(r'  sequence\s+(\d+)/(\d+)',log)
 assert prod and assist and seq
 d=dict(revision=rev,product_pass=int(prod[1]),eligible=int(prod[2]),assisted_pass=int(assist[2]),assisted_fail=int(assist[3]),skipped=int(assist[4]),sequence_pass=int(seq[1]),sequence_total=int(seq[2]),log=label+'/'+filename,exit=101)
 if label!='intermediate':
  standing=(c/label/'main-tiers-and-guards.log').read_text();fails=set(re.findall(r'^  (test-diagrams/perturbations/[^\n]+?\.puml):',standing,re.M));files=subprocess.check_output(['git','ls-tree','-r','--name-only',rev,'--','test-diagrams/perturbations'],text=True).splitlines();total=sum(s.endswith('.puml') for s in files);d['standing']=dict(entries=total,failures=len(fails),matches=total-len(fails));d['units']=re.findall(r'test result: ok\. (\d+) passed;', (c/label/'units.log').read_text());d['cli']=re.findall(r'test result: ok\. (\d+) passed;', (c/label/'cli.log').read_text())
 summary['main_library'][label]=d
summary['main_failure_lists_equal']={n:(c/'before'/n).read_bytes()==(c/'candidate'/n).read_bytes() for n in ['no_oracle_failure_names.txt','golden_failure_names.txt']}
summary['fresh_intent_disagreements']=[r for fn in ['reference-classification.json','supplement-reference-classification.json'] for r in read(c/fn)['cases'] if r['disagreement']]
summary['residue']='No acceptance: 19 fresh valid failures,6 invalid references and all historical failures retained; main ratchets/assisted/standing/guards/fmt/Clippy red. Native review not retried. No production/accounts/baselines/comparator/skip/targets/reader/shared style/font edits.'
(c/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k in ['parent_overlap','main_failure_lists_equal','main_library']},indent=2))
