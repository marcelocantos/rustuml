# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import pathlib,json,hashlib,gzip,base64
S=pathlib.Path(__file__).parent; N=S/'new';N.mkdir(exist_ok=True)
cases=[]
def add(name,mechanism,body,axes,kind='uml'):
 p=N/(name+'.puml');p.write_text('@start'+kind+'\n'+body+'\n@end'+kind+'\n')
 cases.append(dict(source=str(p),mechanism=mechanism,axes=axes,cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=False,intended_validity='intended_valid'))
html='creole-style-candidate-eligibility'; delim='creole-delimited-style-candidate-eligibility';disp='wbs-display-line-projection';shape='wbs-idea-shape-block-selection';leaf='wbs-leaf-component-origin'
add('html_nested','%s'%html,r'Kestrel -> Otter : q<b><i></i></B>r<DEL>t</s>u<b><b>v</b>w</B>x',['nesting','closing aliases'])
add('html_restore',html,r'Kestrel -> Otter : q<color:teal><b>r<$cedar>s</B>t</color>u<b></b>v',['flush boundaries','nested color'])
add('html_unicode',html,r'Kestrel -> Otter : é<b>λ~</B>μ</b>終<i></I>z',['Unicode boundaries','escaped close'])
add('html_parameters',html,r'Kestrel -> Otter : q<size:19></size>r<color:navy></color>s<b></B>t\n<size:31><i></I></size>',['size changes','empty parameter/body contrast'])
add('html_escape_pairs',html,r'Kestrel -> Otter : q<b>a~~</b>c</b>d\nq~<i></i>r\nq<b>a\~</B>c</b>d',['escape parity','nesting'])
add('html_activity',html,r'start\n:unused;'.replace('\\n','\n')+'\n:Birch <b></B> Cedar <i>Elm</I>;\nstop',['activity consumer','empty/closed aliases'])
add('html_state',html,'state Finch\nstate Robin\nFinch --> Robin : q<b></B>r<DEL>s</strike>t',['state edge consumer','closing aliases'])
add('html_note',html,'participant Finch\nnote right of Finch\nq<b></B>r<i>spruce</I>s\nend note',['note consumer','empty/closed styles'])
add('html_extended',html,r'Kestrel -> Otter : q<u:blue></u>r<w:red>x</W>s<BaCk:gold>y</back>z',['extended color style','activation variants'])
add('html_url_math',html,r'Kestrel -> Otter : q<b>[[https://example.test/k <i></i>]]</b>r\nq<i><math>x^2</math></i>s',['URL region','math region'])
for d,name in [('**','bold'),('//','italic'),('__','underline'),('--','strike'),('~~','wave')]:
 add('delimiter_'+name,delim,f'Kestrel -> Otter : q{d}{d}r{d}a<$cedar>b<color:teal>c</color>{d}s\\nq{d}λ{d}t{d}u<$cedar>v',['empty/adjacent commands','Unicode/unclosed fallback'])
add('delimiter_escapes',delim,r'Kestrel -> Otter : q**a~**b**c\nq//a~//b//c\nq__a~__b__c\nq--a~--b--c\nq~~a\~~b~~c',['escaped closers','delimiter families'])
add('delimiter_activity',delim,'start\n:q****r**s<$cedar>t**u;\nstop',['activity consumer','empty and nested command'])
add('display_blank_mix',disp,r'* \n<size:23>Canopy</size>\n\n\n** <b>Ash</b>\n<size:8>Bud</size>\n*** \n<i>Elm</i>\n\n-- \n<size:17>Fir</size>\n',['blank placement','sizes/depth/sides'],'wbs')
add('display_escape_depth',disp,r'* Trunk\\nLiteral\nCrown\n** Limb\\\nBud\n*** Tip\\nNeedle\n-- West\n\n',['backslash parity','depth/sides'],'wbs')
add('display_raw_url',disp,r'* [[https://example.test/a\nb Canopy]]\nTail\n** [[https://example.test/c\nd Branch]]\nLeaf',['raw URL','root/child projection'],'wbs')
add('display_raw_math',disp,r'* <math>x\ny</math>\nCrown\n** <latex>z\nt</latex>\nTwig',['raw math/latex','root/child projection'],'wbs')
add('display_forced_alignment',disp,r'* Crown\rEast\lWest\n** Branch\lNeedle',['excluded forced alignment','root/child'],'wbs')
add('shape_colors_new',shape,'*_ Crown\n**_[#cyan] Birch\n***_[#gold] Elm\n--_[#pink] Ash\n---_ Fir\n** _Literal_',['color ordering','depth/sides/literal underscores'],'wbs')
add('shape_colors_old',shape,'*[#cyan]_ Crown\n**[#pink]_ Birch\n***[#gold]_ Elm\n--[#green]_ Ash',['old color ordering','depth/sides'],'wbs')
add('shape_direction_new',shape,'*_ Crown\n**_<[#cyan] Birch\n***_> Elm\n**>_[#gold] Fir',['direction/shape order','color/topology'],'wbs')
add('shape_direction_old',shape,'* Crown\n**[#cyan]<_ Birch\n***[#pink]_> Elm',['old direction/shape order','color/depth'],'wbs')
add('shape_literal',shape,'* _ Crown\n** _ Birch\n*** _ Elm\n-- _ Fir',['whitespace literal underscore','depth/sides'],'wbs')
add('leaf_tiny_many',leaf,r'* Canopy\n**_ i\n**_ j\n**_ .\n**_ W\n--_ l\n--_ t'.replace('\\n','\n'),['branch count','tiny widths/both sides'],'wbs')
add('leaf_deep',leaf,'*_ Cedar\n**_ i\n***_ j\n****_ k\n*****_ l\n--_ m\n---_ n',['depth five','composed versus leaf'],'wbs')
add('leaf_sizes',leaf,r'*_ Cedar\n**_ <size:6>i</size>\n**_ <size:29>W</size>\n--_ <b>j</b>\n---_ <size:9>k</size>'.replace('\\n','\n'),['font sizes','tiny/deep sides'],'wbs')
# Normalize physical node separators only: each WBS case uses source lines beginning stars or minus.
for c in cases:
 p=pathlib.Path(c['source']);s=p.read_text();import re
 if s.startswith('@startwbs'): p.write_text(re.sub(r'\\n(?=[*]|--)', '\n', s))
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,o): p.write_text(json.dumps(o,indent=2)+'\n')
dump(S/'manifest.json',cases)
r=json.loads((S/'maker/request.json').read_bytes());r.update(manifest_path=str(S/'manifest.json'),manifest_sha256=sha((S/'manifest.json').read_bytes()),case_count=len(cases),resources=[],case_contracts=[])
files=[]
for c in cases:
 p=pathlib.Path(c['source']);b=p.read_bytes();rel='new/'+p.name
 r['resources'].append(dict(local_path=str(p),remote_relative_path=rel,sha256=sha(b),bytes=len(b)))
 r['case_contracts'].append(dict(source=str(p),source_sha256=sha(b),cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']))
 files.append(dict(local_path=str(p),remote_relative_path=rel,sha256=sha(b),base64=base64.b64encode(b).decode()))
dump(S/'request.json',r)
(S/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=r,manifest=cases,files=files)).encode(),mtime=0))
for name in ['manifest.json','request.json','input-bundle.json.gz']:print(name,sha((S/name).read_bytes()))
print('case_count',len(cases))
