# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

S = Path(__file__).resolve().parent
REPO = Path('/Users/marcelo/.t3/worktrees/rustuml/t3-0423fc37')
BEFORE = 'eb09cecbc90f5690c4a09bf49118f2feff8c1c12'
AFTER = '154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc'
env = dict(os.environ, CARGO_BUILD_JOBS='4', PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib', RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100')
# Reuse the existing deny-JVM executable wrappers, never launch a JVM here.
env['PATH'] = '/Users/marcelo/Library/Caches/rustuml-class-cff7/no-local-jvm' + os.pathsep + env['PATH']
records = []
for label, revision in [('before', BEFORE), ('after', AFTER)]:
    src = S / (label + '-source')
    src.mkdir(exist_ok=False)
    archive = S / (label + '-source.tar')
    with archive.open('wb') as stream:
        subprocess.run(['git','archive',revision],cwd=REPO,stdout=stream,check=True)
    with tarfile.open(archive) as tar:
        tar.extractall(src, filter='data')
    if label == 'after':
        golden = src / 'test-diagrams/golden'
        golden.mkdir(exist_ok=True)
        archive = S/'golden.tar'
        with archive.open('wb') as stream:
            subprocess.run(['git','-C','/Users/marcelo/.t3/worktrees/rustuml/t3-cff2cd0e/test-diagrams/golden','archive','9efdc12fb057bbfecb6a8e2d25d31ec1e5ead19a'],stdout=stream,check=True)
        with tarfile.open(archive) as tar:
            tar.extractall(golden,filter='data')
    env['CARGO_TARGET_DIR'] = str(S / (label+'-target'))
    cmd=['cargo','build','--release','-p','rustuml','--locked']
    start=time.time()
    with (S/(label+'-build.log')).open('wb') as stream:
        result=subprocess.run(cmd,cwd=src,env=env,stdout=stream,stderr=subprocess.STDOUT)
    binary=Path(env['CARGO_TARGET_DIR'])/'release/rustuml'
    records.append(dict(label=label,revision=revision,cwd=str(src),command=cmd,exit=result.returncode,seconds=time.time()-start,environment={k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_TARGET_DIR','PLANTUML_STDLIB','RUSTUML_DEBUG','PATH']},binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest() if result.returncode==0 else None))
    (S/'build-records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,result.returncode,records[-1]['binary_sha256'],flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
