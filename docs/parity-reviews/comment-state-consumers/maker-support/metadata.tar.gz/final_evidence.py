# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();base='138ca3e5f';review='075f5095520bb1dc85a32c1f051a98421522419d'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(n,v):(S/n).write_text(json.dumps(v,indent=2)+'\n')
entries=[]
for line in subprocess.check_output(['git','ls-tree','-r',base,'docs/parity-reviews','test-diagrams/perturbations']).decode().splitlines():
 info,name=line.split('\t');mode,typ,oid=info.split()
 if typ=='blob':entries.append((oid,name))
p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);history=[]
for oid,name in entries:
 p.stdin.write((oid+'\n').encode());p.stdin.flush();n=int(p.stdout.readline().split()[2]);b=p.stdout.read(n);assert p.stdout.read(1)==b'\n';assert b==(R/name).read_bytes(),name;history.append(dict(path=name,sha256=sha(b),bytes=n))
p.stdin.close();p.wait();put('historical-preservation.json',dict(base=base,count=len(history),all_byte_identical=True,files=history))
rows=[]
for name in subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',review]).decode().splitlines():
 b=subprocess.check_output(['git','show',review+':'+name]);assert b==(R/name).read_bytes();rows.append(dict(path=name,sha256=sha(b)))
put('review-preservation.json',dict(original=review,import_commit=base,files=rows,all_byte_identical=True))
files=subprocess.check_output(['git','diff','--name-only',base,'--','crates']).decode().splitlines();expected={f'crates/rustuml-render/src/{n}.rs' for n in ['activity','class','creole','deployment','state']}|{'crates/rustuml/tests/pipe_mode.rs'};assert set(files)==expected
put('production-source-hashes.json',[dict(path=n,before_sha256=sha(subprocess.check_output(['git','show',base+':'+n])),after_sha256=sha((R/n).read_bytes())) for n in files])
put('binary-provenance.json',dict(before_revision='3875fee3b164d63d4b39df4bc6c13ca8ace89169',before_production='346f6b3f680895d3eb457041ed88ae224c583d95',after_source_hashes='production-source-hashes.json',binaries=[dict(path=str(S/n),sha256=sha((S/n).read_bytes()),bytes=(S/n).stat().st_size) for n in ['before-rustuml','after-rustuml','probe']],comparator_source_sha256=sha((S/'probe.rs').read_bytes()),build_jobs=4,no_shipping=True))
cohorts=json.loads((S/'cohorts.json').read_text())+['consumer16','full-golden'];xml=[]
for c in cohorts:
 for phase in ['before','after']:
  obs=json.loads((S/f'{c}-{phase}.json').read_text());bad=[];emitted=0
  for r in obs:
   b=(S/'replay'/phase/r['id']/'svg.stdout').read_bytes()
   if not b:continue
   emitted+=1
   try:ET.fromstring(b)
   except ET.ParseError as e:bad.append(dict(id=r['id'],error=str(e)))
  xml.append(dict(cohort=c,phase=phase,inputs=len(obs),emitted=emitted,malformed=len(bad),malformed_cases=bad,process_errors=sum(x['svg']['exit']!=0 for x in obs),panics=sum(x['panic'] for x in obs)))
put('xml-by-cohort.json',xml)
comparisons=json.loads((S/'comparison-summary.json').read_text());models=json.loads((S/'model-observations.json').read_text());changes=json.loads((S/'changed-outputs.json').read_text());lists=json.loads((S/'producer-list-census.json').read_text());byid={x['id']:x for x in lists if x['cohort']=='full-golden'}
for r in comparisons:assert not r['losses'] and not r['new_errors'] and not r['new_panics'],r['cohort']
for r in models:assert not r['semantic_changes'],r['cohort']
gold=[r for r in changes if r['cohort']=='full-golden'];groups=collections.defaultdict(list);valid_by_id={r['id']:r['reference_valid'] for r in json.loads((S/'full-golden-after.json').read_text())}
for r in gold:
 assert r['cause'] in ['comment consumer identity/producer','state fill selection/serialization','XML-equivalent re-encoding'],r
 p=byid.get(r['id']);r['comment_lists_newly_match_java']=bool(p and p['newly_exact']);r['comment_lists_match_java']=bool(p and p['after_exact'])
 r['reference_valid']=valid_by_id[r['id']]
 group='newly matching comment lists' if r['comment_lists_newly_match_java'] and r['reference_valid'] else 'other comment-only changes, whole result retained' if r['cause']=='comment consumer identity/producer' else r['cause'];groups[group].append(r['id'])
put('golden-byte-summary.json',dict(entries=12550,changed=len(gold),grouped_ids=dict(groups),categories=dict(collections.Counter(r['cause'] for r in gold)),newly_passing=[r['id'] for r in gold if not r['before_pass'] and r['after_pass']],newly_failing=[r['id'] for r in gold if r['before_pass'] and not r['after_pass']],changed_still_failing=[r['id'] for r in gold if not r['before_pass'] and not r['after_pass']],changed_still_passing=[r['id'] for r in gold if r['before_pass'] and r['after_pass']]))
put('changed-outputs-classified.json',changes)
# Compare the final follow-on against the preserved intermediate, independently.
follow=[]
for c in cohorts:
 a=json.loads((S/f'{c}-after.json').read_text());b=json.loads((S/'intermediate'/f'{c}-after.json').read_text())
 for x,y in zip(b,a):
  assert x['id']==y['id'];assert not(x['svg_match'] and not y['svg_match']);old=(S/'intermediate/replay/after'/x['id']/'svg.stdout').read_bytes();new=(S/'replay/after'/x['id']/'svg.stdout').read_bytes()
  if old!=new:
   only=re.sub(rb'<!--[\s\S]*?-->',b'',old)==re.sub(rb'<!--[\s\S]*?-->',b'',new);assert only,x['id'];follow.append(dict(cohort=c,id=x['id'],comment_only=True,before_pass=x['svg_match'],after_pass=y['svg_match']))
put('follow-on-byte-audit.json',follow)
# Failure names are diagnostics, never actual CLI pass counts.
fail=[]
for name in ['no_oracle_failure_names.txt','golden_failure_names.txt']:
 a=(R/'test-diagrams'/name).read_bytes();b=(S.parent/'rustuml-shared-svg-corrective-maker'/('final-'+name)).read_bytes();(S/('final-'+name)).write_bytes(a);lost=sorted(set(a.decode().splitlines())-set(b.decode().splitlines()));assert not lost
 fail.append(dict(file=name,count=len(a.splitlines()),baseline_count=len(b.splitlines()),byte_identical=a==b,sha256=sha(a),baseline_sha256=sha(b),lost_passes=lost,gained_passes=sorted(set(b.decode().splitlines())-set(a.decode().splitlines()))))
put('failure-set-comparison.json',fail)
gates=[]
for x in json.loads((S/'gates.json').read_text()):
 t=(S/'logs'/(x['name']+'.log')).read_text();gates.append(dict(**x,test_results=re.findall(r'test result: .*',t),diagnostic_lines=[l for l in t.splitlines() if any(z in l for z in ['XML corpus=','TOTAL','TOTAL:','total eligible','passed,','failed,','test result:'])][-15:]))
put('gate-summary.json',gates)
print('preserved',len(history),'historical files; golden changes',len(gold),{k:len(v) for k,v in groups.items()},'follow-on changes',len(follow),flush=True)
