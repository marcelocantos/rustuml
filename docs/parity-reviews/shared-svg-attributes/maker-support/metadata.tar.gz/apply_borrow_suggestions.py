# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,collections,re
from pathlib import Path
S=Path(__file__).parent;groups=collections.defaultdict(dict);applied=[];unmatched=[]
for line in (S/'logs/focused-clippy.jsonl').read_text().splitlines():
 x=json.loads(line)
 if x.get('reason')!='compiler-message':continue
 m=x['message']
 if (m.get('code') or {}).get('code')!='clippy::needless_borrow':continue
 for child in m['children']:
  for sp in child.get('spans',[]):
   if sp.get('suggestion_applicability')!='MachineApplicable' or len(sp['text'])!=1:continue
   txt=sp['text'][0];old=txt['text']
   if 'crate::svg::' not in old:continue
   groups[(sp['file_name'],old)][(txt['highlight_start']-1,txt['highlight_end']-1)]=sp['suggested_replacement']
byfile=collections.defaultdict(list)
for (file,old),changes in groups.items():
 new=old
 for (a,b),value in sorted(changes.items(),reverse=True):new=new[:a]+value+new[b:]
 byfile[file].append((old,new))
for file,changes in byfile.items():
 p=Path(file);s=p.read_text()
 for old,new in changes:
  if old not in s:unmatched.append(dict(file=file,line=old));continue
  s=s.replace(old,new);applied.append(dict(file=file,before=old,after=new))
 # Remove redundant expression parentheses introduced by mechanical routing.
 pattern=r'(crate::svg::(?:escape_attribute|font_family_attribute))\('
 for m in list(re.finditer(pattern,s))[::-1]:
  start=m.end();depth=1;i=start
  while depth:
   if s[i]=='(':depth+=1
   elif s[i]==')':depth-=1
   i+=1
  expr=s[start:i-1]
  if expr.startswith('&(') and expr.endswith(')'):expr='&'+expr[2:-1]
  elif expr.startswith('(') and expr.endswith(')'):expr=expr[1:-1]
  s=s[:start]+expr+s[i-1:]
 p.write_text(s)
(S/'borrow-suggestions-applied.json').write_text(json.dumps(dict(applied=applied,unmatched=unmatched),indent=2)+'\n');print(len(applied),'lines applied',len(unmatched),'unmatched')
