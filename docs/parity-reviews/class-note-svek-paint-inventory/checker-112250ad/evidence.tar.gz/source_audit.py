# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,subprocess
s=Path(__file__).resolve().parent;root=Path.cwd();jroot=Path('/Users/marcelo/work/github.com/plantuml/plantuml');rev='71806a23780b04a5ccde2f8ceb5121edad5eb711';sha=lambda b:hashlib.sha256(b).hexdigest();prior=json.loads((s/'integrity.json').read_text());paths=[r['path'] for r in prior['java_source']]+['src/main/java/net/sourceforge/plantuml/'+x for x in ['command/NameAndCodeParser.java','svek/EntityImageDegenerated.java','decoration/symbol/USymbolSimpleAbstract.java','klimt/drawing/svg/DriverRectangleSvg.java']];rows=[]
for p in paths:
 b=(jroot/p).read_bytes();assert b==subprocess.check_output(['git','-C',str(jroot),'show',rev+':'+p]);rows.append(dict(path=p,sha256=sha(b),revision=rev))
rs=['crates/rustuml-parser/src/parse/class.rs','crates/rustuml-render/src/class.rs','crates/rustuml-parser/src/parse/style.rs','Cargo.toml','Cargo.lock'];sources=[]
for revision,base in [('154d4c7fd58bc7a1b91df7d01f530b3ea911a5fc',s/'before-source'),('68ab512be964e243ae1943f7a9fefd3537091401',root)]:
 for p in rs:
  b=(base/p).read_bytes();assert b==subprocess.check_output(['git','show',revision+':'+p]);sources.append(dict(revision=revision,path=p,sha256=sha(b)))
(s/'source-audit-provenance.json').write_text(json.dumps(dict(java=rows,rust=sources,initial_build_interruption={'reason':'Host turn interruption killed both compile processes before completion; no success inferred. Partial logs retained; resumed same-target builds succeeded. No broad gate had yet begun.','logs':['before-build-interrupted.log','after-build-interrupted.log']},account_location_qualifiers={'originals_unchanged':True,'corrections_postimplementation':True,'qualifiers':['classdiagram/command/NameAndCodeParser is command/NameAndCodeParser','utils/StringUtils is package-root StringUtils','USymbolBoundary#getSkinParameter is getDrawing, with inherited USymbolSimpleAbstract#asSmall'],'assessment':'Corrected paths/hashes verified against pinned Java. These are real mistakes in the preimplementation account. They do not invalidate the identified classes but cannot be relabeled accurate preimplementation provenance. Exact original chronology and older missing-mechanism/draft defects remain immutable.'}),indent=2)+'\n')
