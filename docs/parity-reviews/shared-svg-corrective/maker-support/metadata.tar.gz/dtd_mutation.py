# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();D=S.parent/'rustuml-shared-svg-maker/target-after/release/deps';T=S/'dtd-mutation';(T/'crates/rustuml').mkdir(parents=True,exist_ok=True)
g=T/'test-diagrams/golden';g.mkdir(parents=True,exist_ok=True)
for i in range(26):
 (g/f'dot_{i}.puml').write_bytes(f'@startdot\ndigraph G {{ a -> b }}\n@enddot\n\' checker-slot-{i}\n'.encode());(g/f'dot_{i}.svg').write_bytes(b'<svg/>')
paths=[Path('test-diagrams/perturbations/shared-svg-attributes')/(n+'.puml') for n in ['attr_link_c0_one','attr_link_c0_zero','attr_link_c0_escape']]+[Path('test-diagrams/perturbations/shared-svg-attributes/checker-independent-astra')/(n+'.puml') for n in ['href_c0','raw_c0_zero','raw_c0_one','raw_c0_escape']]
for path in paths:
 (T/path.parent).mkdir(parents=True,exist_ok=True)
 for ext in ['.puml','.svg']:shutil.copy2(R/path.with_suffix(ext),T/path.with_suffix(ext))
shim=T/'cli-shim.py';shim.write_text('#!'+sys.executable+'\n'+'''import os,subprocess,sys
source=sys.stdin.buffer.read()
p=subprocess.run([BINARY,*sys.argv[1:]],input=source,capture_output=True)
out=p.stdout
if os.environ.get('CHECKER_DTD_INJECT') and b"checker-slot-0\\n" in source:
 standard=b'<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">'
 actual=b'<!DOCTYPE svg [<!ENTITY checker "unapproved-internal-entity">]>'
 out=b'<!--'+standard+b'-->'+actual+b'<svg xmlns="http://www.w3.org/2000/svg"><text>&checker;</text></svg>'
sys.stdout.buffer.write(out);sys.stderr.buffer.write(p.stderr);sys.exit(p.returncode)
'''.replace('BINARY',repr(str(S/'before-rustuml'))));shim.chmod(0o755)
env=dict(os.environ,CARGO_MANIFEST_DIR=str(T/'crates/rustuml'),CARGO_BIN_EXE_rustuml=str(shim))
roxml=next(dep for dep in D.glob('roxmltree-*.d') if '/roxmltree-0.20.0/' in dep.read_text());results=[]
for phase in ['before','after']:
 source=subprocess.check_output(['git','show','741d1785a:crates/rustuml/tests/pipe_mode.rs']) if phase=='before' else (R/'crates/rustuml/tests/pipe_mode.rs').read_bytes();src=T/'crates/rustuml/tests'/('dtd-'+phase+'.rs');src.parent.mkdir(exist_ok=True);shutil.copy2(R/'test-diagrams/no_oracle_baseline.txt',T/'test-diagrams/no_oracle_baseline.txt');src.write_bytes(source);(S/('dtd-'+phase+'.rs')).write_bytes(source);binary=S/('dtd-'+phase+'-oracle')
 cmd=['rustc','--edition=2024','--test',str(src),'-L','dependency='+str(D),'--extern','roxmltree='+str(D/('lib'+roxml.stem+'.rlib')),'--extern','sha2='+str(next(D.glob('libsha2-*.rlib'))),'-o',str(binary)]
 q=subprocess.run(cmd,env=env,capture_output=True);assert q.returncode==0,q.stderr
 for name,inject in [('control',False),('comment-decoy-internal-dtd',True)]:
  argv=[str(binary),'every_cli_golden_and_registered_perturbation_svg_is_strict_xml','--nocapture'];q=subprocess.run(argv,env=env|({'CHECKER_DTD_INJECT':'1'} if inject else {}),capture_output=True,timeout=90);log=q.stdout+q.stderr;(S/'logs'/('dtd-'+phase+'-'+name+'.log')).write_bytes(log);results.append(dict(phase=phase,name=name,compile_argv=cmd,argv=argv,test_source_sha256=hashlib.sha256(source).hexdigest(),exit=q.returncode,log_sha256=hashlib.sha256(log).hexdigest()))
assert [r['exit'] for r in results]==[0,0,0,101],results
(S/'dtd-mutation-results.json').write_text(json.dumps(dict(kind='test-oracle stdout injection only; no product/Java claim',results=results,control26_dot_passes_both=True,decoy_rejected_after=True,external_dtd_or_entity_resolved=False,scratch_removed=True),indent=2)+'\n');shutil.rmtree(T);print(json.dumps(results,indent=2))
