# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,gzip,base64
S=Path(__file__).parent;N=S/'new';N.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();old=S.parent/'rustuml-creole-fallback-maker'
seq=lambda xs:'@startuml\nElm -> Cedar : '+r'\n'.join(xs)+'\n@enduml\n'
note=lambda xs:'@startuml\nparticipant Elm\nnote right of Elm\n'+'\n'.join(xs)+'\nend note\n@enduml\n'
act=lambda xs:'@startuml\nstart\n:'+r'\n'.join(xs)+';\nstop\n@enduml\n'
cases={
'attr_font_quotes':seq(['q<font:"Oak & Pine">fir</font>r',"q<font:Oak'Pine>fir</font>r"]),
'attr_font_unicode':note(['q<font:Oak Ω𐐷>fir</font>r','q<font:Oak«Fir»>fir</font>r']),
'attr_link_ascii':seq(['q[[https://example.org/?a=1&b=2{Oak & <Fir> "Sap" \'Bud\'}tree]]r']),
'attr_link_whitespace':note(['q[[https://example.org/tree{Oak<U+0009>Fir<U+000D>Pine<U+000A>Elm}leaf]]r']),
'attr_link_unicode':seq(['q[[https://example.org/tree{Oak Ω𐐷«Fir»}leaf]]r']),
'attr_link_c0_one':seq(['q[[https://example.org/tree{Oak<U+0001>Fir}leaf]]r']),
'attr_link_c0_zero':seq(['q[[https://example.org/tree{Oak<U+0000>Fir}leaf]]r']),
'attr_link_c0_escape':seq(['q[[https://example.org/tree{Oak<U+001B>Fir}leaf]]r']),
'attr_actor_metadata':'@startuml\nactor "Oak & <Fir>"\nusecase "Map" as U\n"Oak & <Fir>" --> U\n@enduml\n',
'attr_state_font':'@startuml\nskinparam stateFontName "Oak & Fir"\nstate Branch\n@enduml\n',
'color_short_full':note(['q<color:#2ad>fir</color>r','q<color:#aBcDeF>fir</color>r','q<color:#7>fir</color>r']),
'color_named_hash':act(['q<color:BUSINESS>fir</color>r','q<color:#red>fir</color>r','q<color:APPLICATION>fir</color>r']),
'color_transparent':seq(['q<color:transparent>fir</color>r','q<color:background>fir</color>r','q<color:#aabbcc00>fir</color>r']),
'color_alpha':note(['q<color:#8044aa77>fir</color>r','q<color:#2a6b9c01>fir</color>r','q<color:#2a6b9cfe>fir</color>r','q<color:#2a6b9cff>fir</color>r']),
'color_alpha_nested':act(['q<color:#2a6b9c77>a<color:red>fir</color>b</color>r','q<color:navy>a<color:#2a6b9c88>fir</color>b</color>r']),
'color_font_alpha':seq(['q<font color=#8044aa77>fir</font>r','q<font color=#2ad size=15>fir</font>r']),
'back_special_alpha':note(['q<back:transparent>fir</back>r','q<back:background>fir</back>r','q<back:#8044aa77>fir</back>r','q<back:#2ad>fir</back>r']),
'color_wbs':'@startwbs\n* Oak\n** q<color:#2ad>fir</color>r\n**_ q<color:#8044aa77>fir</color>r\n@endwbs\n',
'color_automatic_light':note(['q<color:automatic>fir</color>r']),
'color_automatic_dark':'@startuml\nskinparam backgroundColor black\nElm -> Cedar : q<color:automatic>fir</color>r\n@enduml\n',
'color_invalid_controls':seq(['q<color:#GGGGGG>fir</color>r','q<back:NoSuchShade>fir</back>r']),
'font_invalid_color':seq(['q<font color=NoSuchShade>fir</font>r'])}
rows=[]
for name,source in cases.items():
 p=N/(name+'.puml');p.write_bytes(source.encode());negative=('c0_' in name or name=='font_invalid_color');rows.append(dict(source=str(p),mechanism='shared-svg-attributes' if name.startswith('attr_') else 'shared-svg-color',axes=[name,'attribute character class / consumer family / paint role / opacity endpoints'],cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=negative,intended_validity='requires_raw_classification' if negative else 'intended_valid'))
(S/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n');resources=[dict(local_path=str(p),remote_relative_path='new/'+p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(N.glob('*.puml'))];request=json.loads((old/'request.json').read_bytes());request.update(manifest_path=str(S/'manifest.json'),manifest_sha256=sha((S/'manifest.json').read_bytes()),case_count=len(rows),resources=resources,case_contracts=[dict(source=x['source'],source_sha256=sha(Path(x['source']).read_bytes()),cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']) for x in rows]);(S/'request.json').write_text(json.dumps(request,indent=2)+'\n');files=[dict(local_path=x['local_path'],remote_relative_path=x['remote_relative_path'],sha256=x['sha256'],base64=base64.b64encode(Path(x['local_path']).read_bytes()).decode()) for x in resources];(S/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=request,manifest=rows,files=files)).encode(),mtime=0));print({p.name:sha(p.read_bytes()) for p in [S/'request.json',S/'manifest.json',S/'input-bundle.json.gz']})
