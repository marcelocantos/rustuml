# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,gzip,pathlib,hashlib,tarfile,xml.etree.ElementTree as E
O=pathlib.Path(__file__).parent;R=pathlib.Path('/Users/marcelo/.t3/worktrees/rustuml/t3-5c023380')
p=json.loads(gzip.decompress((R/'docs/parity-reviews/sequence-rejection-repair/checker-support/replay1449.json.gz').read_bytes()))
def rel(s):return 'test-diagrams/'+s.split('/test-diagrams/',1)[1] if '/test-diagrams/' in s else s
m=json.loads((O/'all2083.json').read_text());ps={x['original_source'] for x in p};ms={x['source'] for x in m};ph={x['source_sha256'] for x in p};mh={hashlib.sha256((R/x).read_bytes()).hexdigest() for x in ms};s=dict(parent_entries=len(p),parent_paths=len(ps),overlapping_paths=len(ps&ms),unreplayed_paths=len(ps-ms),parent_unique_bytes=len(ph),overlapping_unique_bytes=len(ph&mh),unreplayed_unique_bytes=len(ph-mh));print(s);(O/'parent-overlap.json').write_text(json.dumps(s,indent=2))
rows=json.loads((O/'after-fresh/measurements.json').read_text());e=[]
for x in rows:
 if 'double_pending' not in x['name']:continue
 texts={}
 for stage in ['before','after']:
  rs=json.loads((O/(stage+'-fresh')/'measurements.json').read_text());r=next(r for r in rs if r['name']==x['name']);root=E.fromstring((O/(stage+'-fresh')/r['cli']['svg']).read_bytes());texts[stage]=sum(t.text=='Roe' for t in root.iter() if t.tag.endswith('text'))
 root=E.fromstring((R/x['golden']).read_bytes());texts['java']=sum(t.text=='Roe' for t in root.iter() if t.tag.endswith('text'));e.append(dict(source=x['source'],label_occurrences=texts));print(e[-1])
(O/'pending-create-witness.json').write_text(json.dumps(e,indent=2))
with tarfile.open(R/'docs/parity-reviews/sequence-component-display-packet/maker-results/captures.tar.gz') as t:
 first=json.loads(t.extractfile('first62/measurements.json').read());before=json.loads((O/'before2083/measurements.json').read_text());bm={x['source']:x for x in before};lost=[x['source'] for x in first if bm[x['source']]['cli_comparison']['exit']==0 and x['cli_comparison']['exit']!=0];print('historical first draft loss',lost);(O/'historical-drafts.json').write_text(json.dumps(dict(first62_losses=lost,classification='Historical maker captures only, not independent exact-source executions. First binary hashes preserved; display-bin lacks simultaneous full source binding and remains unbound. No retrospective acceptance.'),indent=2))
