# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import hashlib, json, os, pathlib, shutil, subprocess, time
ROOT=pathlib.Path('/Users/marcelo/.t3/worktrees/rustuml/t3-5c023380')
OUT=pathlib.Path('/Users/marcelo/.cache/rustuml-review-711-5c023380')
BRANCH='review/sequence-711dbca7-5c023380'
VERSIONS={'before':'672cd8f26e1d7c6725d8971e01ad7575defd8567','intermediate':'cf3eafb293de2f01699399321d2220c4de9eb28c','after':'711dbca7c5e29592395f0927881aabfc2517b217'}
records=[]
def run(cmd, name, env):
    start=time.time()
    with (OUT/(name+'.log')).open('wb') as f:
        p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    records.append(dict(command=cmd,cwd=str(ROOT),exit=p.returncode,seconds=time.time()-start,log=name+'.log',environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS']}))
    (OUT/'build-commands.json').write_text(json.dumps(records,indent=2))
    if p.returncode: raise RuntimeError(name)
try:
    for name,rev in VERSIONS.items():
        subprocess.run(['git','switch','--detach',rev],cwd=ROOT,check=True)
        env=dict(os.environ,CARGO_TARGET_DIR=str(OUT/('target-'+name)),CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='4')
        run(['cargo','build','--release','-p','rustuml','--bin','rustuml','-p','rustuml-oracle','--example','diff_one'],name+'-build',env)
        binary=OUT/(name+'-bin'); binary.mkdir(exist_ok=True)
        target=pathlib.Path(env['CARGO_TARGET_DIR'])/'release'
        for src in [target/'rustuml',target/'examples/diff_one']:
            shutil.copy2(src,binary/src.name)
        libs=list((target/'deps').glob('librustuml_oracle-*.rlib')); assert len(libs)==1,libs
        run(['rustc','--edition=2024',str(OUT/'compare_cli.rs'),'-L','dependency='+str(target/'deps'),'--extern','rustuml_oracle='+str(libs[0]),'-o',str(binary/'compare_cli')],name+'-comparator',env)
        files=subprocess.check_output(['git','ls-files','crates','Cargo.lock','Cargo.toml'],cwd=ROOT).decode().splitlines()
        record=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).decode(),files={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files if (ROOT/p).is_file()},binaries={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in binary.iterdir()})
        (OUT/(name+'-binding.json')).write_text(json.dumps(record,indent=2))
        print(name+' built '+rev,flush=True)
finally:
    subprocess.run(['git','switch',BRANCH],cwd=ROOT,check=True)
