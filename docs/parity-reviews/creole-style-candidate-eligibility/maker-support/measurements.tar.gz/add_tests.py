# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
p=Path('crates/rustuml-render/src/creole.rs');s=p.read_text();at=s.index('    #[test]\n    fn missing_sprites_consume');s=s[:at]+'''    #[test]
    fn style_candidates_require_nonempty_captures() {
        for (open, close) in [("b", "b"), ("i", "I"), ("u", "u"), ("s", "del"), ("w", "W"), ("back:red", "back")] {
            let markup = format!("<{open}></{close}>");
            let segments = parse_segments(&markup);
            assert_eq!(segments.len(), 1, "{markup}");
            assert_eq!(unescape_for_metrics(&segments[0].text), format!("</{close}>"));
            assert_ne!(segments[0].style, Style::default(), "{markup}");
        }
        assert_eq!(stripped_text("<b>"), "<b>");
        assert_eq!(parse_segments("<size:25></size>"), Vec::<Segment>::new());
        assert_eq!(parse_segments("<color:red></color>"), Vec::<Segment>::new());
        assert_eq!(parse_segments("<b><$bud></b>"), vec![seg(" ", Style::default())]);
    }

    #[test]
    fn style_candidate_order_preserves_closing_literals_and_escapes() {
        assert_eq!(parse_segments("<b><b></b></b>"), vec![
            seg("&lt;b&gt;", bold_style()), seg("&lt;/b&gt;", Style::default()),
        ]);
        assert_eq!(parse_segments("<b>A~</b>B</b>C"), vec![
            seg("A&lt;/b&gt;B", bold_style()), seg("C", Style::default()),
        ]);
        assert_eq!(parse_segments("A<outer<b></b>>B<$bud>C"), vec![
            seg("A&lt;outer", Style::default()), seg("&lt;/b&gt;&gt;B", bold_style()), seg("C", bold_style()),
        ]);
        assert_eq!(stripped_text("~<b></b>"), "<b></b>");
    }

'''+s[at:];p.write_text(s)
p=Path('crates/rustuml-parser/src/parse/wbs.rs');s=p.read_text();at=s.index('    #[test]\n    fn single_root');s=s[:at]+'''    #[test]
    fn shape_markers_are_command_fields_not_label_text() {
        let d = parse("* Root\\n**_[#pink] East\\n***[#yellow]_ Leaf\\\\nTwig\\n--_ West\\n** _ Literal");
        let root = &d.nodes[0];
        assert_eq!(root.shape, WbsShape::Box);
        assert_eq!(root.children[0].shape, WbsShape::None);
        assert_eq!(root.children[0].color.as_deref(), Some("#pink"));
        assert_eq!(root.children[0].label, "East");
        let leaf = &root.children[0].children[0];
        assert_eq!(leaf.shape, WbsShape::None);
        assert_eq!(leaf.label, "Leaf\\\\nTwig");
        assert_eq!(leaf.depth, 3);
        assert_eq!(root.children[1].side, WbsSide::Left);
        assert_eq!(root.children[2].shape, WbsShape::Box);
        assert_eq!(root.children[2].label, "_ Literal");
    }

    #[test]
    fn omitted_shape_models_remain_backward_compatible() {
        let old = serde_json::json!({"label":"Root","color":null,"depth":1,"side":"Right","children":[]});
        let node: WbsNode = serde_json::from_value(old.clone()).unwrap();
        assert_eq!(node.shape, WbsShape::Box);
        assert_eq!(serde_json::to_value(&node).unwrap(), old);
        let d = parse("*_ Root");
        let encoded = serde_json::to_value(&d.nodes[0]).unwrap();
        assert_eq!(encoded["shape"], "None");
        let decoded: WbsNode = serde_json::from_value(encoded).unwrap();
        assert_eq!(decoded.shape, WbsShape::None);
        assert_eq!(decoded.label, "Root");
    }

'''+s[at:];p.write_text(s)
p=Path('crates/rustuml-render/src/wbs.rs');s=p.read_text();at=s.index('    #[test]\n    fn renders_simple_wbs');s=s[:at]+'''    #[test]
    fn display_projection_preserves_blanks_and_escaped_content() {
        assert_eq!(super::display_lines(r"\\nRoot\\n\\n"), ["", "Root", "", ""]);
        assert_eq!(super::display_lines(r"A\\\\nB\\nC"), [r"A\\nB", "C"]);
        assert_eq!(super::display_lines(r"[[https://example.test/a\\nb label]]\\nTail"),
            [r"[[https://example.test/a\\nb label]]", "Tail"]);
        assert_eq!(super::display_lines(r"<math>a\\nb</math>\\n"), [r"<math>a\\nb</math>", ""]);
    }

'''+s[at:];p.write_text(s)
