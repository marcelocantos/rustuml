# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import concurrent.futures,json,os,subprocess
from pathlib import Path
S=Path('/Users/marcelo/Library/Caches/rustuml-tim7-maker');R=Path.cwd();env=dict(os.environ,RUSTUML_DEBUG='date=1774210426000,tz=AEDT+1100',PLANTUML_STDLIB='/Users/marcelo/work/github.com/plantuml/plantuml-stdlib/stdlib')
def check(p):
 q=subprocess.run([S/'final-rustuml','--yaml','-pipe'],input=p.read_bytes(),cwd=R,env=env,capture_output=True)
 if q.returncode:
  before=subprocess.run([S/'before-rustuml','--yaml','-pipe'],input=p.read_bytes(),cwd=R,env=env,capture_output=True)
  d=S/'main-diagnostic'/p.stem;d.mkdir(parents=True,exist_ok=True);(d/'before.yaml').write_bytes(before.stdout);(d/'before.stderr').write_bytes(before.stderr);(d/'current.yaml').write_bytes(q.stdout);(d/'current.stderr').write_bytes(q.stderr)
  return dict(source=str(p),before_exit=before.returncode,current_exit=q.returncode,stderr=q.stderr.decode(),commands=[[str(S/'final-rustuml'),'--yaml','-pipe'],[str(S/'before-rustuml'),'--yaml','-pipe']])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=[r for r in pool.map(check,sorted((R/'test-diagrams/golden/preprocessing').glob('*.puml'))) if r]
(S/'main-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
