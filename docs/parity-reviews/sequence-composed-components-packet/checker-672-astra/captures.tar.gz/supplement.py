import base64,hashlib,json
from pathlib import Path
cache=Path(__file__).parent;manifest=json.loads((cache/'reference-request.json').read_text());cases=[]
for engine in ['legacy','teoz']:
 for tag,body,claim,valid in [
 ('queue_multiline','participant Cedar\nqueue "First\\nSecond" as Maple\ncreate Maple\nCedar -> Maple: build\nMaple -> Cedar: deliver','sequence-queue-preferred-component',True),
 ('body_unclosed','participant Cedar\nCedar -> Cedar: before\nnote right\n__ Heading __\ncontent','sequence-note-body-composition',False),
 ('create_duplicate','participant Cedar\nparticipant Maple\ncreate Maple\nCedar -> Maple: one\ncreate Maple\nCedar -> Maple: two','sequence-created-participant-component',False),
 ]:
  name=tag+'_'+engine;data=('@startuml\n'+('!pragma teoz true\n' if engine=='teoz' else '')+body+'\n@enduml\n').encode();p=cache/'fresh'/(name+'.puml');p.write_bytes(data)
  cases.append(dict(name=name,remote_name=name+'.puml',source=str(p),source_bytes=len(data),source_sha256=hashlib.sha256(data).hexdigest(),source_base64=base64.b64encode(data).decode(),resources=[],timezone='GMT+11:00',cwd='PRIVATE_CWD',invocation=['/Users/marcelo/rustuml-reference/bin/reference','--cwd','PRIVATE_CWD','--timezone','GMT+11:00','--','-pipe','-tsvg'],claim=claim,axes=[tag,engine],intended_valid=valid))
manifest['cases']=cases;manifest['source_derivation']='Queue branch computes line_h times one/two rather than USymbolQueue merged Display height; exercise actual multiline Display. Negative controls exercise unclosed BodyEnhanced input and duplicate creation semantics.'
p=cache/'reference-supplement.json';p.write_text(json.dumps(manifest,indent=2)+'\n');p.chmod(0o444);print(len(cases),p,hashlib.sha256(p.read_bytes()).hexdigest())
