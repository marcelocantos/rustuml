# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import collections,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();base='2ed88eb55ec5f0974ec2830deccfcc401f6d9885'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,v):(S/name).write_text(json.dumps(v,indent=2)+'\n')
entries=[]
for line in subprocess.check_output(['git','ls-tree','-r',base,'docs/parity-reviews','test-diagrams/perturbations']).decode().splitlines():
 info,name=line.split('\t');mode,typ,oid=info.split()
 if typ=='blob':entries.append((oid,name))
proc=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);rows=[]
for oid,name in entries:
 proc.stdin.write((oid+'\n').encode());proc.stdin.flush();size=int(proc.stdout.readline().split()[2]);data=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n';assert data==(R/name).read_bytes(),name;rows.append(dict(path=name,sha256=sha(data),bytes=len(data)))
proc.stdin.close();proc.wait();put('historical-preservation.json',dict(base_revision=base,count=len(rows),all_byte_identical=True,files=rows))
original='4931481fd495ffff9da55a0c7514f43a487b087e';names=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',original]).decode().splitlines();check=[]
for name in names:
 a=subprocess.check_output(['git','show',original+':'+name]);assert a==(R/name).read_bytes();check.append(dict(path=name,sha256=sha(a)))
put('rejection-preservation.json',dict(original=original,import_commit=base,files=check,all_byte_identical=True))
files=subprocess.check_output(['git','diff','--name-only',base,'--','crates']).decode().splitlines();allowed=set(json.loads((S/'scope-audit.json').read_text())['files'])|{'crates/rustuml/tests/pipe_mode.rs'};assert set(files)==allowed
source=[]
for name in files:source.append(dict(path=name,before_sha256=sha(subprocess.check_output(['git','show',base+':'+name])),after_sha256=sha((R/name).read_bytes())))
put('production-source-hashes.json',source)
put('binary-provenance.json',dict(binaries=[dict(path=str(S/n),sha256=sha((S/n).read_bytes()),bytes=(S/n).stat().st_size) for n in ['before-rustuml','after-rustuml','probe']],comparator_source_sha256=sha((S/'probe.rs').read_bytes()),before_revision=base,production_before='a33dccc8e94dc44b5bafdc756fc1b88c42823a7d',after_source_hashes='production-source-hashes.json',build_jobs=4,shipping=False))
xml=[]
for p in sorted(S.glob('*-membership.json')):
 cohort=p.name.removesuffix('-membership.json')
 if cohort.endswith('-original') or not (S/(cohort+'-after.json')).exists():continue
 for phase in ['before','after']:
  observations=json.loads((S/(cohort+'-'+phase+'.json')).read_bytes());bad=[];emitted=0
  for row in observations:
   b=(S/'replay'/phase/row['id']/'svg.stdout').read_bytes()
   if not b:continue
   emitted+=1
   try:ET.fromstring(b)
   except ET.ParseError as e:bad.append(dict(id=row['id'],error=str(e)))
  xml.append(dict(cohort=cohort,phase=phase,inputs=len(observations),emitted=emitted,malformed=len(bad),malformed_cases=bad,process_errors=sum(r['svg']['exit']!=0 for r in observations),panics=sum(r['panic'] for r in observations)))
put('xml-by-cohort.json',xml)
# Classify every decoded delta, including comments; no changed verdict is hidden.
changes=json.loads((S/'changed-outputs.json').read_bytes())
for row in changes:
 delta=row.get('decoded_changes',[])
 if row['cause']=='XML parse transition':row['explanation']='Before contains invalid double/trailing dash in user comment; source-derived whole-body comment serialization makes after well formed. Whole comparator verdict remains separately recorded.'
 elif row.get('decoded_xml_equivalent'):row['explanation']='Decoded tree, attributes, text and comments identical; lexical encoding only.'
 elif delta and all(d['kind']=='tag/text/tail' and d['before'][0].startswith('<function Comment') for d in delta):row['cause']='comment serialization';row['explanation']='Java ToStream whole-body dash spacing and US-ASCII writer scalar replacement. Attribute/text/geometry projection unchanged.'
 elif delta and all(d['kind']=='attribute' and d['attribute'] in ['fill','fill-opacity'] for d in delta):row['cause']='state fill serialization';row['explanation']='Two ordinary state rectangle consumers now call existing shared RGB/alpha serializer; no coordinate or dimension changes.'
 else:row['explanation']='Inspect complete decoded delta retained here.'
put('changed-outputs-classified.json',changes)
for row in changes:
 if row['cohort']=='full-golden':assert row['cause'] in ['comment serialization','state fill serialization','XML-equivalent attribute encoding'],row
for r in json.loads((S/'comparison-summary.json').read_text()):assert not r['losses'] and not r['new_errors'] and not r['new_panics'],r['cohort']
for r in json.loads((S/'model-observations.json').read_text()):assert r['semantic_changes']==0,r['cohort']
residuals={'comment_class_unicode':'Unicode/font metrics: Java81.4297 vs Rust81.7646 textLength; comment scalar replacement exact','comment_object_links':'Object parser/consumer emits empty100x50SVG; Java14elements; no comment control claim for missing consumer output','comment_archimate':'Archimate source dispatch yields welcome SVG in Rust; JavaDESCRIPTION diagram; no comment control claim','state_alpha_empty':'Empty-state geometry: Java50x40 vs Rust59.7578x50, text origin differs; both fill#2468AC opacity0.00392','comment_state_links':'Intended-valid versus observed Java syntax-error exit200; nonpositive, Rust acceptance remains negative-contract difference'}
b=json.loads((S/'corrective16-before.json').read_text());a=json.loads((S/'corrective16-after.json').read_text());cls=json.loads((S/'fresh-classification.json').read_text());observations=[]
for x,y,c in zip(b,a,cls):
 name=c['name'];ref=(S/'fresh-reference'/name/'java.svg.stdout').read_text();actual=(S/'replay/after'/y['id']/'svg.stdout').read_text()
 observations.append(dict(**c,id=y['id'],source=str(S/'new'/(name+'.puml')),reference=str(S/'fresh-reference'/name/'java.svg.stdout'),registered_source='test-diagrams/perturbations/shared-svg-corrective/'+name+'.puml',before_pass=x['svg_match'],after_pass=y['svg_match'],whole_failure=residuals.get(name),java_comments=re.findall(r'<!--(.*?)-->',ref,re.S),rust_comments=re.findall(r'<!--(.*?)-->',actual,re.S)))
put('fresh-outcomes.json',observations)
for n in ['no_oracle_failure_names.txt','golden_failure_names.txt']:
 actual=(R/'test-diagrams'/n).read_bytes();old=(S.parent/'rustuml-shared-svg-maker'/('final-'+n)).read_bytes();(S/('final-'+n)).write_bytes(actual)
 if n=='no_oracle_failure_names.txt':failure=[]
 failure.append(dict(file=n,identical=actual==old,count=len(actual.splitlines()),sha256=sha(actual),baseline_sha256=sha(old),lost_passes=sorted(set(actual.decode().splitlines())-set(old.decode().splitlines())),gained_passes=sorted(set(old.decode().splitlines())-set(actual.decode().splitlines()))))
assert all(x['identical'] for x in failure);put('failure-set-comparison.json',failure)
reg=next(Path('/Users/marcelo/.cargo/registry/src').glob('*/roxmltree-0.20.0/src'));put('xml-parser-provenance.json',dict(version='0.20.0',files=[dict(path=str(reg/n),sha256=sha((reg/n).read_bytes())) for n in ['parse.rs','tokenizer.rs']],source_boundary='parse.rs315–345 optional DTD policy; tokenizer.rs390–430 consumes external identifiers,471–504 external entity definitions yield None. No resolver/network/filesystem access.',no_external_dtd_or_entity_fetched_or_resolved=True))
put('golden-byte-summary.json',dict(corpus=12550,changed=len([r for r in changes if r['cohort']=='full-golden']),categories=dict(collections.Counter(r['cause'] for r in changes if r['cohort']=='full-golden')),newly_passing=[r['id'] for r in changes if r['cohort']=='full-golden' and not r['before_pass'] and r['after_pass']],newly_failing=[r['id'] for r in changes if r['cohort']=='full-golden' and r['before_pass'] and not r['after_pass']],changed_still_failing=[r['id'] for r in changes if r['cohort']=='full-golden' and not r['before_pass'] and not r['after_pass']],changed_still_passing=[r['id'] for r in changes if r['cohort']=='full-golden' and r['before_pass'] and r['after_pass']]))
print('preserved',len(rows),'old files; source files',len(source),'fresh classified',len(observations),flush=True)
