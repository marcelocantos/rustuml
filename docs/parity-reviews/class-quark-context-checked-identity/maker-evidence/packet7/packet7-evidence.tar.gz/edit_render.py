from pathlib import Path
p=Path('crates/rustuml-parser/src/parse/class.rs');s=p.read_text();s=s.replace('                    QuarkLookup::ReuseUnique,\n                );','                    QuarkLookup::ReuseUnique,\n                )?;');p.write_text(s)
p=Path('crates/rustuml-render/src/class.rs');s=p.read_text()
s=s.replace('use rustuml_parser::diagram::style::StyleScheme;', 'use rustuml_parser::diagram::style::{StyleOrigin, StyleScheme};')
s=s.replace('use crate::style_cascade::{StyleCascade, StyleSignature};','use crate::style_cascade::{ResolvedStyle, StyleCascade, StyleSignature};')
a=s.index('fn parse_shadowing_delta(');b=s.index('fn resolved_note_shadowing',a)
s=s[:a]+'''fn fashion_shadowing_delta(value: &str) -> f64 {
    // Style#getShadowing -> ValueImpl#asDoubleDefaultTo(1.5) extracts only
    // ASCII digits and dots. A sign or unit is not part of the numeric value;
    // malformed/empty extracted numbers take Style's default, not zero.
    value
        .chars()
        .filter(|ch| ch.is_ascii_digit() || *ch == '.')
        .collect::<String>()
        .parse::<f64>()
        .unwrap_or(1.5)
}

fn parse_shadowing_delta(value: &str) -> f64 {
    // FromSkinparamToStyle#getShadowingValue maps legacy booleans before
    // ValueImpl performs numeric conversion. Raw style values skip this step.
    match value.trim().to_ascii_lowercase().as_str() {
        "true" | "yes" => 3.0,
        "false" | "no" => 0.0,
        _ => fashion_shadowing_delta(value),
    }
}

fn style_shadowing_delta(style: &ResolvedStyle<'_>) -> Option<f64> {
    style.declaration("shadowing").map(|declaration| {
        match declaration.origin {
            StyleOrigin::UserSkinParam | StyleOrigin::ThemeSkinParam { .. } => {
                parse_shadowing_delta(&declaration.value)
            }
            StyleOrigin::UserStyle | StyleOrigin::ThemeStyle { .. } => {
                fashion_shadowing_delta(&declaration.value)
            }
        }
    })
}

'''+s[b:]
s=s.replace('''    cascade
        .resolve(&signature, StyleScheme::Regular)
        .property("shadowing")
        .map(parse_shadowing_delta)''','''    style_shadowing_delta(&cascade.resolve(&signature, StyleScheme::Regular))''')
s=s.replace('''            let shadow = style
                .property("shadowing")
                .map(parse_shadowing_delta)
                .unwrap_or(0.0);''','''            let shadow = style_shadowing_delta(&style).unwrap_or(0.0);''')
s=s.replace('''        if let Some(value) = style.property("shadowing") {
            result.shadow = parse_shadowing_delta(value);
        }''','''        if let Some(value) = style_shadowing_delta(&style) {
            result.shadow = value;
        }''')
a=s.index('fn render_single_named_note(');b=s.index('fn render_meta_only',a);block=s[a:b]
needle='''    write!(
        body,
        r#"<path d="M{},{} L{},{} L{},{} L{},{} L{},{} L{},{}"'''
assert needle in block
block=block.replace(needle,'''    // EntityImageNote#drawU starts the entity URL inside its entity group;
    // EntityImageDegenerated changes the envelope, not this URL ownership.
    let anchor = note_anchor(diagram, note);
    if let Some(anchor) = &anchor {
        body.push_str(anchor);
    }
'''+needle,1)
block=block.replace('    body.push_str("</g>");','    if anchor.is_some() {\n        body.push_str("</a>");\n    }\n    body.push_str("</g>");',1)
s=s[:a]+block+s[b:];p.write_text(s)
