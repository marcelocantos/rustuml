from pathlib import Path
import subprocess,re,json,hashlib
S=Path(__file__).parent;R=Path.cwd();exec((S/'metadata/inventory.py').read_text().split('rows=[]')[0])
# Derive sites independently from actual committed sources, then check frozen inventory.
def comments(s):
 rows=[]
 for m in re.finditer(r'\b(format|write|writeln)!\s*\(',s):
  spans,end=args(s,m.end()-1);fi=0 if m[1]=='format' else 1;a=[s[x:y].strip() for x,y in spans]
  if len(a)>fi and '<!--' in a[fi]:rows.append(dict(start=m.start(),end=end,a=a,fi=fi,line=s.count('\n',0,m.start())+1,macro=s[m.start():end]))
 return rows
def compact(s):
 out=[];last=0
 for m in lex.finditer(s):out.extend([re.sub(r'\s+','',s[last:m.start()]),m[0]]);last=m.end()
 return ''.join(out)+re.sub(r'\s+','',s[last:])
inv=json.loads((R/'docs/parity-reviews/shared-svg-corrective/comment-routing-list.json').read_bytes());files=json.loads((R/'docs/parity-reviews/shared-svg-corrective/comment-account.json').read_bytes())['production_files'];changes=subprocess.check_output(['git','diff','--name-only','db8955411','346f6b3f6','--','crates']).decode().splitlines();assert sorted(files)==changes
records=[]
for file in files:
 before=subprocess.check_output(['git','show','db8955411:'+file]).decode();after=(R/file).read_text()
 if file.endswith('/svg.rs'):continue
 bb=comments(before);aa=comments(after);assert len(bb)==len(aa)
 for b,a in zip(bb,aa):
  if compact(b['macro'])==compact(a['macro']):continue
  fi=b['fi'];bt=b['a'][fi];at=a['a'][fi];body=re.search(r'<!--(.*?)-->',bt,re.S)[1];n=body.count('{}')
  assert at==bt.replace('<!--'+body+'-->','<!--{svg_comment}-->'), (file,b['line'],bt,at)
  assert [compact(x) for x in a['a'][:fi]+a['a'][fi+1:-1]]==[compact(x) for x in b['a'][:fi]+b['a'][fi+1+n:]]
  assert any(x['file']==file and x['line']==b['line'] and x['macro']==b['macro'] for x in inv)
  records.append(dict(file=file,line=b['line'],mixed=len(at.split('-->')[1])>4,outside_comment_template_unchanged=True,noncomment_arguments_unchanged=True))
 for rows,which in [(bb,'before'),(aa,'after')]:
  text=before if which=='before' else after
  for row in reversed(rows):text=text[:row['start']]+'COMMENT_SITE'+text[row['end']:]
  if which=='before':before=text
  else:after=text
 if file.endswith('/class.rs'):
  before=re.sub(r'(fn emit_layout_empty_package\([^)]*entity_id: &str),', r'\1', before)
 if file.endswith('/state.rs'):
  assert before.count('<rect fill="{fill_color}"{state_shadow_attr}')==2
  before=before.replace('<rect fill="{fill_color}"{state_shadow_attr}','<rect {fill_color}{state_shadow_attr}')
  # These fill args appear at exactly the two changed rect sites; compare remaining tokens.
  before=before.replace('fmt_f(box_y), fill_color = crate::svg::escape_attribute(&fill_color)', 'fmt_f(box_y), fill_color = crate::svg::fill_attributes(&fill_color)')
 
 if compact(before)!=compact(after):
  import difflib
  a=compact(before);b=compact(after)
  i=next(i for i,(x,y) in enumerate(zip(a,b)) if x!=y);print(repr(a[i-100:i+100]),repr(b[i-100:i+100]))
 assert compact(before)==compact(after),file
assert len(records)==45
(S/'scope-audit.json').write_text(json.dumps(dict(sites=records,count=len(records),mixed=sum(x['mixed'] for x in records),production_files=files,no_sequence_changes=True,no_fixture_shaped_logic=True,remaining_diffs='svg.rs: comment helper, single focused unit, fill_attributes visibility; state: two fill producers only'),indent=2))
print('scope verified',len(records),'mixed',sum(x['mixed'] for x in records))
