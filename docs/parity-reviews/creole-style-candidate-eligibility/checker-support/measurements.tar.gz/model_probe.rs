// Copyright 2026 Marcelo Cantos
// SPDX-License-Identifier: Apache-2.0
use rustuml_parser::diagram::wbs::{WbsNode,WbsShape};
fn main() {
    let old=serde_json::json!({"label":"Cedar\\nBranch","color":"#cyan","depth":3,"side":"Left","children":[{"label":"_ twig","color":null,"depth":4,"side":"Right","children":[]}]});
    let decoded:WbsNode=serde_json::from_value(old.clone()).unwrap();
    assert_eq!(decoded.shape,WbsShape::Box);
    assert_eq!(decoded.children[0].shape,WbsShape::Box);
    assert_eq!(serde_json::to_value(&decoded).unwrap(),old);
    let mut explicit=old.clone();explicit["shape"]=serde_json::json!("None");explicit["children"][0]["shape"]=serde_json::json!("None");
    let decoded:WbsNode=serde_json::from_value(explicit.clone()).unwrap();
    assert_eq!(decoded.shape,WbsShape::None);
    assert_eq!(decoded.children[0].shape,WbsShape::None);
    assert_eq!(serde_json::to_value(&decoded).unwrap(),explicit);
    println!("{}",serde_json::json!({"old_input":old,"none_input":explicit,"old_defaults_box":true,"box_omitted":true,"none_roundtrip_exact":true}));
}
