# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys,concurrent.futures
import replay_checker as m
S=Path(__file__).parent
cohort=sys.argv[1] if len(sys.argv)>1 else 'checker94'
rows=json.loads((S/(cohort+'-membership.json')).read_text())
for phase in ['before','after']:
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(lambda r:m.measure(r,phase),rows))
    (S/(cohort+'-'+phase+'.json')).write_text(json.dumps(results,indent=2)+'\n')
    print(phase,'valid',sum(v['reference_valid'] for v in results),'passes',sum(v['svg_match'] for v in results),'errors',sum(v['svg']['exit']!=0 for v in results),'panics',sum(v['panic'] for v in results),'malformed',sum(bool(v['xml_error']) for v in results),flush=True)
