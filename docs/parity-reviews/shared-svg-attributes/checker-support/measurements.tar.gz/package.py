# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import gzip,hashlib,json,tarfile
from pathlib import Path
S=Path(__file__).parent;D=Path.cwd()/'docs/parity-reviews/shared-svg-attributes/checker-support';sha=lambda b:hashlib.sha256(b).hexdigest()
files=[]
for dirname in ['replay','fresh','new','logs']:
 files.extend(p for p in (S/dirname).rglob('*') if p.is_file())
for pattern in ['*.py','*.rs','*.json','*.json.gz','*.txt']:
 files.extend(S.glob(pattern))
files=sorted(set(p for p in files if p.name not in ['archive-manifest.json']))
manifest=[];archive=D/'measurements.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p in files:
  b=p.read_bytes();name=str(p.relative_to(S));manifest.append(dict(path=name,bytes=len(b),sha256=sha(b)));t.add(p,arcname=name,recursive=False)
manifest_path=D/'measurement-entries.json.gz';manifest_path.write_bytes(gzip.compress((json.dumps(manifest,indent=2)+'\n').encode(),mtime=0))
with tarfile.open(archive) as t:
 for entry,row in zip(t,manifest,strict=True):
  assert entry.name==row['path'] and entry.isfile();b=t.extractfile(entry).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
report=dict(archive=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,entries=len(manifest),uncompressed_bytes=sum(r['bytes'] for r in manifest),entry_manifest=manifest_path.name,entry_manifest_sha256=sha(manifest_path.read_bytes()),readback_verified=True)
(D/'measurement-archive.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
