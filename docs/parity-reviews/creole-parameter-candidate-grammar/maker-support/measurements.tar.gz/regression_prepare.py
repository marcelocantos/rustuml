# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
import json,shutil,hashlib
from pathlib import Path
S=Path(__file__).parent;R=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest()
d=S/'initial-broad';d.mkdir(exist_ok=True)
for p in (S/'logs').glob('*.log'):shutil.copy2(p,d/p.name)
shutil.copy2(S/'gates.json',d/'gates.json')
for name in ['no_oracle_failure_names.txt','golden_failure_names.txt','golden_ulp_candidates.txt']:shutil.copy2(R/'test-diagrams'/name,d/name)
shutil.copy2(S/'after-rustuml',S/'after-initial-rustuml')
rows=[]
for name in ['activity/act_creole_monospace']+['creole/creole_font_name_in_'+x for x in ['activity','class','note','sequence','title']]:
 p=R/'test-diagrams/golden'/(name+'.puml');g=p.with_suffix('.svg');rows.append(dict(id='golden-regressions/'+name,suite='golden-regressions',membership=dict(source=str(p),reference_valid=True),cwd=str(R),source_capture=str(p),source_sha256=sha(p.read_bytes()),golden_capture=str(g),golden_sha256=sha(g.read_bytes())))
(S/'golden-regressions-membership.json').write_text(json.dumps(rows,indent=2)+'\n')
