# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
p=Path('crates/rustuml-render/src/creole.rs');s=p.read_text();pos=s.index('fn handle_tag(')
helper=r'''/// Candidate recognition runs on CharHidder's stream, before consuming a body.
/// Splitter supplies the size/color/family/image/icon grammars; the combined
/// font command and BACKCOLOR use their own patterns (not Splitter.fontPattern).
enum ParameterCommand<'a> {
    Size(&'a str),
    Color(&'a str),
    Font { size: Option<&'a str>, color: Option<&'a str> },
    Family(&'a str),
    Background(&'a str),
    Image(&'a str),
    Icon,
}

fn parameter_command(tag: &str) -> Option<ParameterCommand<'_>> {
    static PATTERNS: std::sync::LazyLock<[regex::Regex; 8]> = std::sync::LazyLock::new(|| {
        // Pattern2 uses ASCII CASE_INSENSITIVE, \d and \w. Its [%s] also
        // includes NBSP; [%g] includes curly quotes and Jaws' invisible quote.
        let space = r"[\t\n\x0B\x0C\r \u{00A0}]";
        let separator = r"[\t\n\x0B\x0C\r :]";
        let quote = r#"["“”\u{E121}]"#;
        let attribute = format!(
            r"{space}+(?:(?i-u:size){space}*={space}*{quote}?([0-9]+){quote}?|(?i-u:color){space}*={space}*{quote}?(#[0-9a-fA-F]{{6}}|[A-Za-z0-9_]+){quote}?)"
        );
        [
            format!(r"\A(?i-u:size){separator}+([0-9]+){space}*\z"),
            format!(r"\A(?i-u:color){separator}+(#[0-9a-fA-F]{{1,6}}|#?[A-Za-z0-9_]+){space}*\z"),
            format!(r"\A(?i-u:font)(?:{attribute})+{space}*\z"),
            attribute,
            format!(r"\A(?i-u:font){separator}+([^>]+)/?\z"),
            // FontStyle.getUbrexActivationPattern + CharClassRaw.WORD.
            r"\A(?i-u:back):((?:#[0-9a-fA-F]{6}|[A-Za-z0-9_]+)(?:[-\|/](?:[0-9a-fA-F]{6}|[A-Za-z0-9_]+))?)\z".into(),
            format!(r"\A(?i-u:img){separator}+([^>{{}}]+)(?:\{{(?i-u:scale)=[0-9.]+\}})?\z"),
            r"\A(?:#[A-Za-z0-9_]+)?&[-A-Za-z0-9_]+(?:[\{,]?(?:(?:(?i-u:scale=)|\*)[0-9.]+)?(?:,?(?i-u:color)[= :](?:#[0-9a-fA-F]{1,8}|[A-Za-z0-9_]+))?\}?)?\z".into(),
        ].map(|pattern| regex::Regex::new(&pattern).expect("Java parameter candidate grammar"))
    });
    let [size, color, font, attribute, family, background, image, icon] = &*PATTERNS;
    if let Some(capture) = size.captures(tag) {
        return Some(ParameterCommand::Size(capture.get(1).unwrap().as_str()));
    }
    if let Some(capture) = color.captures(tag) {
        return Some(ParameterCommand::Color(capture.get(1).unwrap().as_str()));
    }
    // CommandCreoleBuilder registers combined attributes before the broader
    // font-family candidate. Java retains the last capture for each attribute.
    if font.is_match(tag) {
        let (mut size, mut color) = (None, None);
        for capture in attribute.captures_iter(tag) {
            if let Some(value) = capture.get(1) { size = Some(value.as_str()); }
            if let Some(value) = capture.get(2) { color = Some(value.as_str()); }
        }
        return Some(ParameterCommand::Font { size, color });
    }
    if let Some(capture) = family.captures(tag) {
        return Some(ParameterCommand::Family(capture.get(1).unwrap().as_str()));
    }
    if let Some(capture) = background.captures(tag) {
        return Some(ParameterCommand::Background(capture.get(1).unwrap().as_str()));
    }
    if let Some(capture) = image.captures(tag) {
        return Some(ParameterCommand::Image(capture.get(1).unwrap().as_str()));
    }
    icon.is_match(tag).then_some(ParameterCommand::Icon)
}

fn walk_parameter_body(
    chars: &mut std::iter::Peekable<std::str::Chars>,
    close: &str,
    style: &Style,
    nested: &Style,
    skip_underline: bool,
    out: &mut Vec<Segment>,
) {
    // Parameter commands select the first case-insensitive bounded capture,
    // otherwise their EOL alternative. Hidden closing candidates stay inert.
    let remaining: String = chars.clone().collect();
    let end = remaining.to_ascii_lowercase().find(close);
    let content_end = end.unwrap_or(remaining.len());
    let consumed = end.map_or(remaining.len(), |offset| offset + close.len());
    for _ in remaining[..consumed].chars() { chars.next(); }
    out.push(Segment { text: String::new(), style: style.clone() });
    walk_segments(&remaining[..content_end], nested, skip_underline, out);
    out.push(Segment { text: String::new(), style: style.clone() });
}

'''
s=s[:pos]+helper+s[pos:]
start=s.index('fn handle_tag(');body=s.index('    match tag {',start)
new=r'''    if let Some(command) = parameter_command(tag) {
        let mut nested = style.clone();
        let close = match command {
            ParameterCommand::Size(size) => {
                // Lexical eligibility is distinct from Java's parseInt failure
                // for oversized values. Keep the existing nonpanicking contract.
                if let Ok(size) = size.parse::<u32>() { nested.size = Some(size); }
                Some("</size>")
            }
            ParameterCommand::Color(color) => {
                nested.fill = Some(color.to_string());
                Some("</color>")
            }
            ParameterCommand::Font { size, color } => {
                if let Some(size) = size.and_then(|value| value.parse::<u32>().ok()) {
                    nested.size = Some(size);
                }
                if let Some(color) = color { nested.fill = Some(color.to_string()); }
                Some("</font>")
            }
            ParameterCommand::Family(family) => {
                // CommandCreoleFontFamilyChange changes only the selected family,
                // not the font face and not an unconditional monospace mode.
                nested.font_family = Some(family.to_string());
                nested.monospace = false;
                Some("</font>")
            }
            ParameterCommand::Background(color) => {
                return walk_style_tag(chars, &["back"], style,
                    |s| s.background = Some(color.to_string()), skip_underline, out);
            }
            ParameterCommand::Image(src) => {
                // CommandCreoleImg removes src= and paired double quotes only
                // after the complete image candidate grammar has matched.
                let src = if src.get(..4).is_some_and(|s| s.eq_ignore_ascii_case("src=")) {
                    &src[4..]
                } else { src };
                let src = src.strip_prefix('"').and_then(|s| s.strip_suffix('"')).unwrap_or(src);
                let fallback = if src.starts_with("https://") || src.starts_with("http://") {
                    format!("(Cannot\u{00a0}decode:\u{00a0}{})", escape_creole_text(src))
                } else { "(Cannot\u{00a0}decode)".to_string() };
                nested.monospace = true;
                nested.size = Some(14);
                out.push(Segment { text: String::new(), style: style.clone() });
                push_segment(out, &fallback, &nested);
                None
            }
            ParameterCommand::Icon => {
                // The sprite/icon-aware consumer owns image resolution. A valid
                // command still flushes pending text if no drawable atom is added.
                out.push(Segment { text: String::new(), style: style.clone() });
                None
            }
        };
        if let Some(close) = close {
            walk_parameter_body(chars, close, style, &nested, skip_underline, out);
        } else {
            out.push(Segment { text: String::new(), style: style.clone() });
        }
        return true;
    }
'''
s=s[:body]+new+s[body:]
start=s.index('        _ if tag.starts_with("color:")',s.index('fn handle_tag('));end=s.index('        _ => return false,',start);s=s[:start]+s[end:]
p.write_text(s)
