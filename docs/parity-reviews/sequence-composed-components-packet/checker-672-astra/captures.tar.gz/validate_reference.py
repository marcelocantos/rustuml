import base64,gzip,hashlib,json,re,sys,xml.etree.ElementTree as ET
from pathlib import Path
c=Path(__file__).parent; prefix=sys.argv[1] if len(sys.argv)>1 else 'reference'; request='reference-request.json' if prefix=='reference' else 'reference-supplement.json'
def sha(b):return hashlib.sha256(b).hexdigest()
m=json.loads((c/request).read_text());raw=(c/(prefix+'-results.json')).read_bytes();gz=(c/(prefix+'-results.json.gz')).read_bytes();transport=json.loads((c/(prefix+'-transport.json')).read_text());assert gzip.decompress(gz)==raw;assert sha(gz)==transport['sha256'];assert base64.b64decode(transport['data'])==gz
r=json.loads(raw);env=r['environment'];assert env['manifest_sha256']==sha((c/request).read_bytes());assert env['jar_sha256']==m['jar_sha256'];assert env['java_revision']==m['java_revision'];assert env['headless'] is True;assert env['env_overrides']=={};assert env['timezone']=='GMT+11:00'
items={x['name']:x for x in m['cases']};assert len(items)==len(r['results'])==len({x['name'] for x in r['results']});assert set(items)=={x['name'] for x in r['results']};rows=[]
for x in r['results']:
 i=items[x['name']];data=Path(i['source']).read_bytes();assert data==base64.b64decode(i['source_base64']);assert sha(data)==i['source_sha256']==x['source_sha256']==x['stdin_sha256'];assert len(data)==i['source_bytes']==x['source_bytes']==x['stdin_bytes'];assert x['remote_name']==i['remote_name'];assert re.fullmatch(r'[a-z0-9_]+\.puml',x['remote_name']);assert x['requested_argv']==i['invocation'];assert x['requested_cwd']=='PRIVATE_CWD';assert x['cwd']==env['worker'];assert x['cwd'].startswith('/Users/marcelo/rustuml-reference/scratch/');assert x['argv']==[a if a!='PRIVATE_CWD' else x['cwd'] for a in i['invocation']];assert x['actual_wrapper_argv']==x['argv'];assert x['timezone']=='GMT+11:00';assert x['env_overrides']=={};assert not x['timed_out'];assert x['actual_java_argv']==x['java_argv'];assert x['java_argv']==[env['java'],'-Djava.awt.headless=true','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=AU','-Duser.timezone=GMT+11:00','-jar',env['jar'],'-pipe','-tsvg']
 out=base64.b64decode(x['stdout_base64']);err=base64.b64decode(x['stderr_base64']);assert sha(out)==x['stdout_sha256'];assert sha(err)==x['stderr_sha256'];p=Path(i['source']);p.with_suffix('.svg').write_bytes(out);p.with_suffix('.java.stderr').write_bytes(err)
 text=out.decode('utf-8');xml=None;parse_error=None
 try:xml=ET.fromstring(out)
 except ET.ParseError as e:parse_error=str(e)
 diagram_type=xml.get('data-diagram-type') if xml is not None else None
 markers=[marker for marker in ['Syntax Error','[From string','An error has occured','Error','Welcome to PlantUML'] if marker in text]
 # Classify valid only with status, SVG root, diagram type and absence of error-page semantics together.
 valid=x['exit_code']==0 and xml is not None and xml.tag=='{http://www.w3.org/2000/svg}svg' and diagram_type not in [None,'ERROR'] and not markers
 row=dict(name=x['name'],source=i['source'],claim=i['claim'],axes=i['axes'],intended_valid=i['intended_valid'],valid=valid,disagreement=valid!=i['intended_valid'],exit=x['exit_code'],bytes=len(out),diagram_type=diagram_type,error_markers=markers,xml_error=parse_error,source_sha256=sha(data),stdout_sha256=sha(out),stderr_sha256=sha(err));rows.append(row)
 print(x['name'],x['exit_code'],diagram_type,'valid' if valid else 'INVALID', 'INTENT DISAGREEMENT' if row['disagreement'] else '')
(c/(prefix+'-classification.json')).write_text(json.dumps(dict(request_sha256=sha((c/request).read_bytes()),gzip_sha256=sha(gz),validated=True,cases=rows),indent=2)+'\n')
(c/(prefix+'-measure-manifest.json')).write_text(json.dumps([dict(source=i['source'],golden=str(Path(i['source']).with_suffix('.svg')),cohort='fresh',name=i['name'],claim=i['claim'],axes=i['axes']) for i in m['cases']],indent=2)+'\n')
