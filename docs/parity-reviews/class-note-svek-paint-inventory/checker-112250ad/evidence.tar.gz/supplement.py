# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import base64,gzip,hashlib,json
s=Path(__file__).resolve().parent;m=json.loads((s/'fresh-manifest.json').read_text());m['inputs']=[];m['batch']+='-cleanid';d=s/'supplement';d.mkdir(exist_ok=True)
for name,target in [('cleanid_guillemets','«Vessel»'),('cleanid_parentheses','(Vessel)'),('cleanid_brackets','[Vessel]')]:
 raw=('@startuml\nclass Vessel\nnote right of '+target+' [[manual{tip}]]\nreceipt\nend note\n@enduml\n').encode();p=d/(name+'.puml');p.write_bytes(raw);m['inputs'].append(dict(name=p.name,source=str(p),source_bytes=len(raw),source_sha256=hashlib.sha256(raw).hexdigest(),source_base64=base64.b64encode(raw).decode(),remote_name=p.name,mechanism='class-attached-note-consuming-url-grammar',axes=['cleanId boundary recognition distinct from Pattern2 quote tokens','bare target forms with multiline URL ownership'],expected_java_valid=True,timezone='GMT+11:00'))
raw=(json.dumps(m,indent=2)+'\n').encode();(s/'supplement-manifest.json').write_bytes(raw);blob=gzip.compress(raw,mtime=0);(s/'supplement-inputs.json.gz').write_bytes(blob);(s/'supplement-transport.json').write_text(json.dumps(dict(sha256=hashlib.sha256(blob).hexdigest(),data=base64.b64encode(blob).decode()))+'\n');print(hashlib.sha256(raw).hexdigest(),hashlib.sha256(blob).hexdigest())
