# Copyright 2026 Marcelo Cantos
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,base64,gzip
P=Path(__file__).parent;S=P/'supplement';N=S/'new';N.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
cases={
'circle_root_rebecca':'<style>\nroot {\nLineColor RebeccaPurple\n}\n</style>\n[*] --> Harbor\nHarbor --> [*]',
'circle_root_unknown':'<style>\nroot {\nLineColor NoSuchHarborColor\n}\n</style>\n[*] --> Harbor\nHarbor --> [*]',
'circle_ineffective_legacy_keys':'skinparam stateStartBorderColor RebeccaPurple\nskinparam stateEndBorderColor RebeccaPurple\n[*] --> Harbor\nHarbor --> [*]',
'circle_root_alpha':'<style>\nroot {\nLineColor #7a3c917f\nBackgroundColor #7a3c9101\n}\n</style>\n[*] --> Harbor\nHarbor --> [*]',
'activity_named_end_corrected':'(*) --> "Inspect amber"\n--> (*) as Z',
'group_identity_collision':'node "Copper Bay" as Copper_Bay {\nartifact "Metal Case" as Metal_Case\n}\nnode Jetty\nCopper_Bay --> Jetty',
}
rows=[]
for name,body in cases.items():
 p=N/(name+'.puml');p.write_text('@startuml\n'+body+'\n@enduml\n');rows.append(dict(source=str(p),mechanism='state-paint' if name.startswith('circle') else 'missing-comments' if name.startswith('activity') else 'comment-identity',axes=['line versus fill roles / explicit-alias collision','style inheritance / container topology / end identity'],cwd='new',zone='GMT+11:00',debug='date=1774210426000,tz=AEDT+1100',env={},negative=False,intended_validity='intended_valid; classify returned Java independently'))
(S/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
resources=[dict(local_path=str(p),remote_relative_path='new/'+p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(N.glob('*.puml'))]
request=json.loads((P/'request.json').read_text());request.update(manifest_path=str(S/'manifest.json'),manifest_sha256=sha((S/'manifest.json').read_bytes()),case_count=len(rows),resources=resources,case_contracts=[dict(source=r['source'],source_sha256=sha(Path(r['source']).read_bytes()),cwd='<worker>/new',timezone='GMT+11:00',env_overrides={},svg_argv=['reference','--cwd','<worker>/new','--timezone','GMT+11:00','--','-pipe','-tsvg']) for r in rows])
(S/'request.json').write_text(json.dumps(request,indent=2)+'\n');files=[dict(local_path=r['local_path'],remote_relative_path=r['remote_relative_path'],sha256=r['sha256'],base64=base64.b64encode(Path(r['local_path']).read_bytes()).decode()) for r in resources];(S/'input-bundle.json.gz').write_bytes(gzip.compress(json.dumps(dict(request=request,manifest=rows,files=files)).encode(),mtime=0))
for p in [S/'manifest.json',S/'request.json',S/'input-bundle.json.gz']:
 p.chmod(0o444);print(p.name,sha(p.read_bytes()))
for p in N.glob('*.puml'):p.chmod(0o444)
